/* specific to general */

/* list of drives that affect autosensing in ATAPI specific portions of code 
   (force drives to detect as ATAPI or SCSI, force ATAPI read command */

static exception atapi_list[]={
  {"SAMSUNG SCR-830 REV 2.09 2.09 ", 1,   0,           Dummy,scsi_read_mmc2,0},
  {"NULL",0,0,NULL,NULL,0}};

/* list of drives that affect MMC default settings */

static exception mmc_list[]={
  {"SAMSUNG SCR-830 REV 2.09 2.09 ", 1,   0,           Dummy,scsi_read_mmc2,0},
  {"NULL",0,0,NULL,NULL,0}};

/* list of drives that affect SCSI default settings */

static exception scsi_list[]={
  {"TOSHIBA",                       -1,0x82,scsi_enable_cdda,scsi_read_10,  0},
  {"IBM",                           -1,0x82,scsi_enable_cdda,scsi_read_10,  0},
  {"DEC",                           -1,0x82,scsi_enable_cdda,scsi_read_10,  0},
  
  {"IMS",                           -1,   0,scsi_enable_cdda,scsi_read_10,  1},
  {"KODAK",                         -1,   0,scsi_enable_cdda,scsi_read_10,  1},
  {"RICOH",                         -1,   0,scsi_enable_cdda,scsi_read_10,  1},
  {"HP",                            -1,   0,scsi_enable_cdda,scsi_read_10,  1},
  {"PHILIPS",                       -1,   0,scsi_enable_cdda,scsi_read_10,  1},
  {"PLASMON",                       -1,   0,scsi_enable_cdda,scsi_read_10,  1},
  {"GRUNDIG CDR100IPW",             -1,   0,scsi_enable_cdda,scsi_read_10,  1},
  {"MITSUMI CD-R ",                 -1,   0,scsi_enable_cdda,scsi_read_10,  1},

  {"YAMAHA",                        -1,   0,scsi_enable_cdda,        NULL,  0},

  {"PLEXTOR",                       -1,   0,            NULL,        NULL,  0},
  {"SONY",                          -1,   0,            NULL,        NULL,  0},

  {"NEC",                           -1,   0,            NULL,scsi_read_nec, 0},

  {NULL,0,0,NULL,NULL,0}};

