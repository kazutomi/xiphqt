== Opusfile ==

Library for decoding .opus files, including seeking support.
