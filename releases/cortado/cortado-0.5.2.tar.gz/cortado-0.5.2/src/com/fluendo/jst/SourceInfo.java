package com.fluendo.jst;

public class SourceInfo
{
  public String revision = "0.5.2";
  public String branch = "Xiph";

  public SourceInfo() {
  }
}
