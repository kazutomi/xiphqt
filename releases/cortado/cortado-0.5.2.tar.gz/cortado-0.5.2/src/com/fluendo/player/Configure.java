
package com.fluendo.player;

class Configure
{
  public String buildInfo = "Built on 2010-02-14 11:58:02 GMT (version 0.5.2) in debug mode.";

  public String buildDate = "2010-02-14 11:58:02 GMT";
  public String buildVersion = "0.5.2";
  public String buildType = "debug";
  public String revision = "0.5.2";
  public String branch = "Xiph";

  public Configure() {
  }
}
    