package com.fluendo.player;

class Configure
{
  public String buildInfo = "I was built on Fri Apr 22 16:01:13 CEST 2005 (version 0.1.2). Built using ant.";

  public Configure() {
  }
}
