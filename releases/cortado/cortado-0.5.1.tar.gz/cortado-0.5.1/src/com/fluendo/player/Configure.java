
package com.fluendo.player;

class Configure
{
  public String buildInfo = "Built on 2009-11-05 20:43:41 GMT (version 0.5.1) in debug mode.";

  public String buildDate = "2009-11-05 20:43:41 GMT";
  public String buildVersion = "0.5.1";
  public String buildType = "debug";
  public String revision = "0.5.1";
  public String branch = "Xiph";

  public Configure() {
  }
}
    