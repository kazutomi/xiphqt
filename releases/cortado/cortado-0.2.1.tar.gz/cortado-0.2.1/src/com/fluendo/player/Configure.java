
package com.fluendo.player;

class Configure
{
  public String buildInfo = "Built on 2006-08-31 18:53:04 (version 0.2.0.1) in debug mode.";

  public String buildDate = "2006-08-31 18:53:04";
  public String buildVersion = "0.2.0.1";
  public String buildType = "debug";

  public Configure() {
  }
}
    