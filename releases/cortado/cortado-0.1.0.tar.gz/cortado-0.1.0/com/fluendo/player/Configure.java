package com.fluendo.player;

class Configure
{
  public String buildInfo = "I was built on Fri Dec 24 17:49:22 CET 2004.\nBuilt using ant.";

  public Configure() {
  }
}
