
package com.fluendo.player;

class Dist
{
  public String revision = "4059";
  public String branch = "cortado-0.2.2";

  public Dist() {
  }
}
    