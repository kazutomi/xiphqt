package com.fluendo.jst;

public class SourceInfo
{
  public String revision = "0.5.0";
  public String branch = "Xiph";

  public SourceInfo() {
  }
}
