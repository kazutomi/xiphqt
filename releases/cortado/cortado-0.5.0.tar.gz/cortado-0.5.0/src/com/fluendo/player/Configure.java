
package com.fluendo.player;

class Configure
{
  public String buildInfo = "Built on 2009-10-27 21:57:52 GMT (version 0.5.0) in debug mode.";

  public String buildDate = "2009-10-27 21:57:52 GMT";
  public String buildVersion = "0.5.0";
  public String buildType = "debug";
  public String revision = "0.5.0";
  public String branch = "Xiph";

  public Configure() {
  }
}
    