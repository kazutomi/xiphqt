README.win32 - Information about the binary Ezstream distribution for Windows
=============================================================================



1. .ZIP Archive Contents
------------------------


|         File          |               Description                    |
+======================================================================+
| \COPYING.txt          | License for using, modifying and             |
|                       | distributing Ezstream.                       |
+-----------------------+----------------------------------------------+
| \README.txt           | This file.                                   |
+-----------------------+----------------------------------------------+
| \ezstream.1.pdf       | The ezstream manual in PDF format.           |
+-----------------------+----------------------------------------------+
| \ezstream.exe         | The ezstream executable file.                |
+-----------------------+----------------------------------------------+
| \ezstream-X.Y.Z.zip   | The ezstream source distribution, from which |
|                       | ezstream.exe was built.                      |
+-----------------------+----------------------------------------------+
| \examples\*.xml       | Ezstream example configuration files.        |
+-----------------------+----------------------------------------------+
| \examples\*.sh        | Example playlist and metadata scripts, for   |
|                       | demonstrational purposes (these are shell    |
|                       | scripts.)                                    |
+-----------------------+----------------------------------------------+



2. Installation
---------------


As of version 0.3.0, ezstream no longer comes with an installer. If you have a
previous version of ezstream installed, you might want to simply uninstall it.

The ezstream.exe file will work from any location. To install it, simply copy
it to a location of your choosing. Add this place to your PATH environment
variable, if ezstream.exe is supposed to be executable from anywhere on the
system.



3. Limited functionality
------------------------


A few useful features are missing in the Windows version of ezstream:
 * Runtime control via signals is not possible.
 * Some useful external utilities (encoders, decoders, etc) may not be
   available on Windows.



4. Source code
--------------


Ezstream uses:
 * zlib (http://www.zlib.net/, BSD-like license)
 * libiconv (http://www.gnu.org/software/libiconv/, LGPL)
 * libxml2 (http://xmlsoft.org/, BSD-like license)
 * libogg, libvorbis, libvorbisfile (http://www.vorbis.com/, BSD-like license)
 * libtheora (http://www.theora.org/, BSD-like license)
 * libshout (http://www.icecast.org, LGPL)
 * TagLib (http://ktown.kde.org/~wheeler/taglib.html, LGPL)

These libraries are statically linked into the ezstream.exe file.

Ezstream itself is licensed under the GPL version 2 (see COPYING.txt for
details.)



5. Support
----------


For information on how to report issues with ezstream, please visit the
ezstream home page at http://www.icecast.org/ezstream.php
