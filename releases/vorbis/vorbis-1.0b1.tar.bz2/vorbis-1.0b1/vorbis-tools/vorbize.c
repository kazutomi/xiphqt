/* Vorbize v. 0.2
 *  modifications by Kenneth Arnold
 * 
 * Since this is taken from the Ogg Vorbis CVS tree, many of the comments are
 * retained. This file used to be examples/encoder_example.c.
 *
 * Questions, comments, and suggestions to <kcarnold@yahoo.com>.
 *
 * Do not bother Xiphophorus or Monty with bugs in this modification. If there
 * are problems with the original version, I will notify the appropriate
 * people. Thanks.
 *
 * I have marked some of my modifications, but not all, and I don't intend to,
 * because the Unix 'diff' utility makes it quite easy to see what I have
 * changed.
 *
 * All modifications (easily obtained with the 'diff' utility) are copyright
 * (C) Kenneth Arnold <kcarnold@yahoo.com>, and distributed under the GPL-2
 * as required by the original license terms (see below).
 */

/* This is from the original source: */

/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************/

/* Vorbize encodes Vorbis bitstreams. Need I say more? */

/* Note that this is POSIX, not ANSI, code */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <getopt.h>
#include "vorbis/modes.h"
#include "riff.h"

#define READ 1024
signed char readbuffer[READ * 4 + 44];	/* out of the data segment, not the stack */

#define my_free(ptr) free (ptr); ptr = NULL;

struct
{
  signed short verbose;
  unsigned char raw;
  signed char mode;
  unsigned char nocomment;
  char *single_comment;
  char *artist;
  char *album;
  char *track;
  char *read_file;
  char *write_file;
  FILE *instream;
  FILE *outstream;
}
param =
{
0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};

struct option long_options[] = {
  {"verbose", 0, 0, 'v'},
  {"help", 0, 0, 'h'},
  {"nocomment", 0, 0, 'n'},
  {"comment", 1, 0, 'c'},
  {"artist", 1, 0, 'a'},
  {"album", 1, 0, 'l'},
  {"track", 1, 0, 't'},
  {"write", 1, 0, 'w'},
  {"quiet", 0, 0, 'q'},
  {"raw", 0, 0, 'r'},
  {"mode", 1, 0, 'm'},
  {0, 0, 0, 0}
};

struct timeval start_time, now;

struct
{
  unsigned long int samples_per_sec;
  unsigned long int bits_per_sample;
  unsigned long int channels;
}
fmt =
{
0, 0, 0};

unsigned long int filelen = 0;	/* Expected length of input file */
unsigned long int fileread = 0;	/* Actual bytes read from input file */

int
Is_WAV_Header (struct RIFF header)
     /* General WAV header checking */
{
  if (memcmp (header.riffheader, "RIFF", 4) ||
      memcmp (header.WAVE.fmtheader, "WAVEfmt ", 8) ||
      memcmp (header.WAVE.data.dataheader, "data", 4))
    return 0;
  return 1;
}

int
Get_WAV_Format (struct RIFF header)
     /* See above; sets fmt_* and filelen global variables. */
     /* Returns 0 on error. */
{
  struct stat buf;
  if (header.WAVE.fmt.FormatTag == 1 &&
      header.WAVE.fmt.Channels == 2 &&
      header.WAVE.fmt.SamplesPerSec == 44100 &&
      header.WAVE.fmt.AvgBytesPerSec == 44100 * 2 * 2 &&
      header.WAVE.fmt.BlockAlign == 4 && header.WAVE.fmt.BitsPerSample == 16)
    {
      /* 44.1 kHz, 16 bit, stereo. Good. This is the only currently supported
       * format */
      if (strcmp (param.read_file, "-") &&	/* ! stdin ? */
	  stat (param.read_file, &buf) != -1)
	{
	  /* stat successful. */
	  filelen = buf.st_size - 44;	/* Chop off header */
	}
      else
	{
	  /* Otherwise we must trust the header. */
	  filelen = header.WAVE.data.datalen;
	}
      fmt.bits_per_sample = header.WAVE.fmt.BitsPerSample;
      fmt.samples_per_sec = header.WAVE.fmt.SamplesPerSec;
      fmt.channels = header.WAVE.fmt.Channels;
      return 1;
    }
  return 0;			/* i.e., unsupported format */
}

void
usage (void)
{
  FILE *o;
  o = stdout;

  fprintf (o, "Vorbize 0.6\n by Kenneth Arnold <kcarnold@yahoo.com>\n\n");
  fprintf (o, "Usage: vorbize [options] [<inputfile>]\n\n");
  fprintf (o, " -m, --mode=m     encoding mode (0-6) (default 0)\n");
  fprintf (o, " -w, --write=w    writes output Vorbis stream to w\n");
  fprintf (o, " -r, --raw        treat input as raw\n");
  fprintf (o, " -h, --help       this help\n");
  fprintf (o, " -v, --verbose    enable verbose output\n");
  fprintf (o, " -q, --quiet      don't display progress\n\n");
  fprintf (o, "Comments:\n");
  fprintf (o, " If you do not want to specify any comment, use\n");
  fprintf (o, "  -n, --nocomment encodes no comments\n");
  fprintf (o, " If you want just one comment, use\n");
  fprintf (o, "  -c, --comment=c sets the comment to c\n");
  fprintf (o, " If you want the full artist/album/track format, use\n");
  fprintf (o, "  -a, --artist=a  sets the artist field to a\n");
  fprintf (o, "  -l, --album=l   sets the album field to l\n");
  fprintf (o, "  -t, --track=t   sets the track field to t\n\n");
  fprintf (o,
	   "By default, Vorbize reads from standard input and writes to standard output.\n");
  fprintf (o,
	   "The -r / --raw option skips reading a WAVE header, and thus can handle raw\n");
  fprintf (o,
	   "audio files. However, the file must indeed be a RAW sound sample at\n");
  fprintf (o,
	   "44.1 k, 16 bit stereo with no header information, or weird things will happen.\n");
}

int
main (int argc, char **argv)
{
  ogg_stream_state os;		/* take physical pages, weld into a logical
				   stream of packets */
  ogg_page og;			/* one Ogg bitstream page.  Vorbis packets are inside */
  ogg_packet op;		/* one raw packet of data for decode */
  vorbis_info *vi;		/* struct that stores all the static vorbis bitstream
				   settings */
  vorbis_comment vc;		/* struct that stores all the user comments */
  vorbis_dsp_state vd;		/* central working state for the packet->PCM decoder */
  vorbis_block vb;		/* local working space for packet->PCM decode */
  vorbis_info modes[] = {info_A/*, info_B, info_C, info_D, info_E, info_F, info_G*/};
  int eos = 0;
  int ret;
  int option_index = 1;
  /* Default streams */
  param.instream = stdin;
  param.outstream = stdout;
  while (-1 != (ret = getopt_long (argc, argv, "ac:hlmnqrtvw:",
				   long_options, &option_index)))
    {
      switch (ret)
	{
	case 0:
	  /* Currently there are no long-only options. */
	  fprintf (stderr, "Oops? Long option? Huh?\n");
	  exit (1);
	  break;
	case 'a':		/* Artist */
	  if (param.artist != NULL)
	    {
	      fprintf (stderr,
		       "Warning: more than one artist given. Using last one.\n");
	      my_free (param.artist);
	    }
	  param.artist = strdup (optarg);
	  break;
	case 'l':		/* Album */
	  if (param.album != NULL)
	    {
	      fprintf (stderr,
		       "Warning: more than one album given. Using last one.\n");
	      my_free (param.album);
	    }
	  param.album = strdup (optarg);
	  break;
	case 'm':		/* Mode */
	  param.mode = atoi (optarg);
	  if (param.mode < 0 || param.mode > 6) {
	    fprintf (stderr, "Mode must be 0-6. See vorbis/cmdline/main.c.\n");
	    exit(1);
	  }
	  break;
	case 'n':
	  if (param.single_comment || param.artist || param.album || param.track)
	    {
	      fprintf (stderr,
		       "Warning: null comment when comments given.\n");
	      if (param.single_comment)
		my_free (param.single_comment);
	      if (param.artist)
		my_free (param.artist);
	      if (param.album)
		my_free (param.album);
	      if (param.track)
		my_free (param.track);
	    }
	  param.nocomment = 1;
	case 't':		/* Track */
	  if (param.track != NULL)
	    {
	      fprintf (stderr,
		       "Warning: more than one track given. Using last one.\n");
	      my_free (param.track);
	    }
	  param.track = strdup (optarg);
	  break;
	case 'v':		/* Verbose */
	  param.verbose++;
	  break;
	case 'q':
	  param.verbose--;	/* So verbose will be < 0 if quiet set */
	  break;
	case 'h':		/* Help */
	  usage ();
	  exit (0);
	case 'c':		/* Comment */
	  if (optarg != NULL)
	    {			/* Sanity check; shouldn't be needed */
	      if (param.single_comment != NULL)
		{
		  fprintf (stderr,
			   "Warning: more than one comment specified.\n");
		  my_free (param.single_comment);
		}
	      if (param.artist != NULL ||
		  param.album != NULL || param.track != NULL)
		{
		  fprintf (stderr,
			   "You cannot use both comment formats at the same time.\n");
		  if (param.artist != NULL)
		    my_free (param.artist);
		  if (param.album != NULL)
		    my_free (param.album);
		  if (param.track != NULL)
		    my_free (param.track);
		}
	      param.single_comment = strdup (optarg);
	    }
	  break;
	case 'w':		/* Write file */
	  if (optarg != NULL)
	    {			/* Sanity check again */
	      if (param.write_file != NULL)
		{
		  fprintf (stderr,
			   "Warning: more than one output file. Not supported.\n");
		  my_free (param.write_file);
		}
	      param.write_file = strdup (optarg);
	    }
	  break;
	case 'r':
	  param.raw = 1;
	  break;
	case '?':
	  break;
	default:
	  usage ();
	  exit (0);
	}
    }

  if (optind < argc)
    {
      /* There should be one file name after this. */
      param.read_file = strdup (argv[optind]);
      /* Problems if there are still options left. */
      if (++optind > argc)
	{
	  fprintf (stderr, "Multiple input files not yet supported.\n");
	  exit (1);
	}

      /* Attempt to open the input file for reading. */
      if (strcmp (param.read_file, "-"))
	{
	  param.instream = fopen (param.read_file, "rb");
	  if (param.instream == NULL)
	    {			/* Error! */
	      fprintf (stderr, "Error opening input file.\n");
	      exit (1);
	    }
	}
    }
  else
    {
      param.read_file = strdup ("-");
    }

  if (param.single_comment == NULL && param.artist == NULL &&
      param.album == NULL && param.track == NULL && !param.nocomment)
    {
      fprintf (stderr,
	       "Using default comment. Use -n if you want no comment.\n");
      if (param.read_file == NULL)
	{
	  param.single_comment =
	    strdup ("Encoded by Vorbize 0.2 from standard input");
	}
      else
	{
	  param.single_comment = strdup (param.read_file);
	}
    }

  /* Now try to open output file, if applicable. */
  if (param.write_file != NULL && strcmp (param.write_file, "-"))
    {
      param.outstream = fopen (param.write_file, "w");
      if (param.outstream == NULL)
	{			/* Error! */
	  fprintf (stderr, "Error opening output file.\n");
	}
    }
  else
    {
      param.write_file = strdup ("-");
    }

  if (param.instream == stdin && param.outstream == stdout)
    fprintf (stderr,
	     "Encoding from stdin to stdout. 'vorbize --help' to see other possibilities.\n");
  /* Thanks greatly to mpg123 (wav.c written by Samual Audet) for this... */
  /* Thanks also to Andy Key for the specific header values for
   * 44.1 kHz, 16 bit, stereo. */
  if (!param.raw)
    {
      /* Read and verify RIFF header. */
      struct RIFF header;
      int ret = fread (&header, 1, sizeof (struct RIFF), param.instream);
      if (ret < 44)
	{
	  fprintf (stderr, "Error reading RIFF header.\n");
	  exit (1);
	}

      /* RIFF header is in header. Now check values. */

      if (!Is_WAV_Header (header))
	{
	  fprintf (stderr, "Error: not a WAV header!\n");
	  exit (1);
	}

      /* Get_WAV_Format also sets filelen and fmt.* */
      if (!Get_WAV_Format (header))
	{
	  fprintf (stderr,
		   "Error: WAV input file must be 44.1 kHz, 16 bit stero.\n");
	}
    }
  else
    {
      struct stat buf;
      /* Bad things could very possibly happen... */
      fprintf (stderr,
	       "Warning: file type RAW! Better be 44.1k 16 bit stereo!\n");
      if (strcmp (param.read_file, "-") &&	/* ! stdin ? */
	  stat (param.read_file, &buf) != -1)
	{
	  /* stat successful. */
	  filelen = buf.st_size;
	}
      else
	{
	  /* hmmm... what to do here... */
	  fprintf (stderr,
		   "Warning: file size not known! Setting to 1 byte.\n");
	  filelen = 1;
	}

      /* Assume... */
      fmt.samples_per_sec = 44100;
      fmt.channels = 2;
      fmt.bits_per_sample = 16;
    }

  /********** Encode setup ************/

  /* choose an encoding mode */

  vi = &modes[param.mode];

  /* add a comment */
  vorbis_comment_init (&vc);
  if (param.single_comment != NULL)
    {
      vorbis_comment_add (&vc, param.single_comment);
    }
  else if (! param.nocomment)
    {
      vorbis_comment_add (&vc, param.artist);
      vorbis_comment_add (&vc, param.album);
      vorbis_comment_add (&vc, param.track);
    }

  /* set up the analysis state and auxiliary encoding storage */
  vorbis_analysis_init (&vd, vi);
  vorbis_block_init (&vd, &vb);
  /* set up our packet->stream encoder */
  /* pick a random serial number; that way we can more likely build
     chained streams just by concatenation */
  srandom (time (NULL));
  ogg_stream_init (&os, random ());
  /* Vorbis streams begin with three headers; the initial header (with
     most of the codec setup parameters) which is mandated by the Ogg
     bitstream spec.  The second header holds any comment fields.  The
     third header holds the bitstream codebook.  We merely need to
     make the headers, then pass them to libvorbis one at a time;
     libvorbis handles the additional Ogg bitstream constraints */
  {
    ogg_packet header;
    ogg_packet header_comm;
    ogg_packet header_code;
    vorbis_analysis_headerout (&vd, &vc, &header, &header_comm, &header_code);
    ogg_stream_packetin (&os, &header);	/* automatically placed in its own
					   page */
    ogg_stream_packetin (&os, &header_comm);
    ogg_stream_packetin (&os, &header_code);
    /* no need to write out here.  We'll get to that in the main loop */
  }

  if (param.verbose >= 0)	/* aka, quiet not set */
    {
      fprintf (stderr, "Vorbize 0.6 by Kenneth Arnold\n");
      fprintf (stderr, "-----------------------------\n");
      fprintf (stderr, "Encoding status:\n");
      fprintf (stderr, "Reading from %s\nWriting to %s\n",
	       (strcmp (param.read_file, "-") ? param.read_file :
		"standard input"),
	       (strcmp (param.write_file, "-") ? param.write_file :
		"standard output"));
      if (param.single_comment != NULL)
	{
	  fprintf (stderr, "File comment: %s\n\n", param.single_comment);
	}
      else
	{
	  fprintf (stderr, "Artist:  %s\n", param.artist);
	  fprintf (stderr, "Album:   %s\n", param.album);
	  fprintf (stderr, "Track:   %s\n", param.track);
	}
      fprintf (stderr, "Input file information:\n");
      fprintf (stderr, "Samples per second: %li\n", fmt.samples_per_sec);
      fprintf (stderr, "Bits per sample:    %li\n", fmt.bits_per_sample);
      fprintf (stderr, "Channels:           %li\n\n", fmt.channels);
      /* Get starting time */
      gettimeofday (&start_time, NULL);
    }

  while (!eos)
    {
      long i;
      long bytes = fread (readbuffer, 1, READ * 4, param.instream);	/* stereo hardwired here */
      /* Update fileread accordingly */
      fileread += READ * 4;
      /* And of course tell the user what the heck is going on. */
      if (param.verbose >= 0 && bytes)
	{
	  if (param.raw)
	    {
	      fprintf (stderr, "\r%li kB encoded", fileread / 1024);
	    }
	  else
	    {
	      fprintf (stderr, "\r%li out of %li kB (%.1f%%) encoded",
		       fileread / 1024, filelen / 1024,
		       (float) fileread * 100.0 / (float) filelen);
	    }
	}

      if (bytes == 0)
	{
	  /* end of file.  this can be done implicitly in the mainline,
	     but it's easier to see here in non-clever fashion.
	     Tell the library we're at end of stream so that it can handle
	     the last frame and mark end of stream in the output properly */
	  vorbis_analysis_wrote (&vd, 0);
	}
      else
	{
	  /* data to encode */

	  /* expose the buffer to submit data */
	  double **buffer = vorbis_analysis_buffer (&vd, READ);
	  /* uninterleave samples */
	  for (i = 0; i < bytes / 4; i++)
	    {
	      buffer[0][i] = ((readbuffer[i * 4 + 1] << 8) |
			      (0x00ff & (int) readbuffer[i * 4])) / 32768.;
	      buffer[1][i] = ((readbuffer[i * 4 + 3] << 8) |
			      (0x00ff & (int) readbuffer[i * 4 + 2])) /
		32768.;}

	  /* tell the library how much we actually submitted */
	  vorbis_analysis_wrote (&vd, i);
	}

      /* vorbis does some data preanalysis, then divvies up blocks for
         more involved (potentially parallel) processing.  Get a single
         block for encoding now */
      while (vorbis_analysis_blockout (&vd, &vb) == 1)
	{

	  /* analysis */
	  vorbis_analysis (&vb, &op);
	  /* weld the packet into the bitstream */
	  ogg_stream_packetin (&os, &op);
	  /* write out pages (if any) */
	  while (!eos)
	    {
	      int result = ogg_stream_pageout (&os, &og);
	      if (result == 0)
		break;
	      fwrite (og.header, 1, og.header_len, param.outstream);
	      fwrite (og.body, 1, og.body_len, param.outstream);
	      /* this could be set above, but for illustrative purposes, I do
	         it here (to show that vorbis does know where the stream ends) */
	      if (ogg_page_eos (&og))
		eos = 1;
	    }
	}
    }

  /* clean up and exit.  vorbis_info_clear() must be called last */

  ogg_stream_clear (&os);
  vorbis_block_clear (&vb);
  vorbis_dsp_clear (&vd);
  /* ogg_page and ogg_packet structs always point to storage in
     libvorbis.  They're never freed or manipulated directly */
  gettimeofday (&now, NULL);
  if (param.verbose >= 0)
    {
      double now_sec = (double) now.tv_sec + (double) now.tv_usec / 1000000.0;
      double start_sec =
	(double) start_time.tv_sec + (double) start_time.tv_usec / 1000000.0;
      double etime = now_sec - start_sec;
      double filetime =
	((double) filelen / (double) fmt.samples_per_sec /
	 (double) fmt.bits_per_sample * 8.0 / (double) fmt.channels);	/* 8 bits per byte */
      fprintf (stderr, "\nDone.\n\nStatistics:\n\n");
      fprintf (stderr, "Elapsed time:  %.2f sec.\n", etime);
      fprintf (stderr, "File length:   %.2f sec.\n", filetime);
      fprintf (stderr, "Rate:          %.4f\n\n", filetime / etime);
    }

  /* Free locally allocated memory, for good measure. */
  if (param.single_comment != NULL)
    my_free (param.single_comment);
  if (param.artist != NULL)
    my_free (param.artist);
  if (param.album != NULL)
    my_free (param.album);
  if (param.track != NULL)
    my_free (param.track);
  my_free (param.read_file);
  my_free (param.write_file);
  /* Close streams, again for good measure. */
  if (param.instream != stdin)
    fclose (param.instream);
  if (param.outstream != stdout)

    fclose (param.outstream);
  return (0);
}
