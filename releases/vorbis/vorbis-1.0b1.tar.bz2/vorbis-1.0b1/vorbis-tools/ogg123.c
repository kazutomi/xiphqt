/* ogg123.c by Kenneth Arnold <kcarnold@yahoo.com
 * based on decoder_example.c
 */

/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 function: simple example decoder
 last mod: $Id: ogg123.c,v 1.2 2000/06/19 16:01:15 kcarnold Exp $

 ********************************************************************/

/* Takes a vorbis bitstream from stdin and writes raw stereo PCM to
   stdout.  Decodes simple and chained OggVorbis files from beginning
   to end.  Vorbisfile.a is somewhat more complex than the code below.  */

/* Note that this is POSIX, not ANSI code */

#define OGG123_VERSION "0.1"

#include <sys/ioctl.h>
#include <sys/soundcard.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <getopt.h>
#include <fcntl.h>
#include "vorbis/codec.h"
#include "riff.h"

int16_t convbuffer[4096];	/* take 8k out of the data segment, not the stack */
int convsize = 4096;

/* For facilitating output to multiple streams */
struct streams_struct
{
  FILE * stream;
  struct streams_struct * next_stream;
};

typedef struct streams_struct streams;

struct
{
  char *read_file;			/* File to decode */
  char *device;			/* Device to play on */
  char *write;			/* File to write WAV output to */
  unsigned short int output;	/* Should we play to the sound card? */
  signed short int verbose;	/* Verbose output if > 0, quiet if < 0 */
  FILE *instream; /* Stream to read from. */
  streams * outstreams; /* Streams to write to. */
}
param =
{
NULL, NULL, NULL, 1, 0, NULL, NULL};

struct option long_options[] = {
  {"help", no_argument, 0, 'h'},
  {"version", no_argument, 0, 'V'},
  {"write", required_argument, 0, 'w'},
  {"device", required_argument, 0, 'd'},
  {"silent", no_argument, 0, 's'},
  {"verbose", no_argument, 0, 'v'},
  {"quiet", no_argument, 0, 'q'}
};

void play_file (void);  /* This really needs to go in a header file. */

void
append_stream (streams ** streams_list, FILE * stream)
{
  if (*streams_list != NULL)
    {
      while ((*streams_list)->next_stream != NULL)
	{
	  *streams_list=(*streams_list)->next_stream;
	}
      (*streams_list)->next_stream = (streams *) malloc ( sizeof ( streams ) );
      *streams_list = (*streams_list)->next_stream;
    }
  else
    {
      *streams_list = (streams *) malloc ( sizeof (streams ));
    }
  (*streams_list)->stream = stream;
  (*streams_list)->next_stream = NULL;
}

void
free_streams (streams * streams_list)
{
  streams temp_stream;
  while (streams_list->next_stream)
    {
      temp_stream = *streams_list;
      free (streams_list);
      streams_list = temp_stream.next_stream;
    }
  free (streams_list);
}

#if 0
FILE *
get_stream (int num, streams * streams_list)
{
  if (num < 0)
    {
      fprintf (stderr, "Internal error: get_stream called with a negative argument.\n");
      exit (1);
    }
  else
    if (num == 0)
      {
	return streams_list->stream;
      }
    else
      {
	return get_stream ( num--, streams_list->next_stream );
      }
}
#endif

void streams_write (void *ptr, size_t size, size_t nmemb, streams *str)
{
  while (str)
    {
      fwrite (ptr, size, nmemb, str->stream);
      str = str->next_stream;
    }
}

void usage ()
{
  FILE * o;
  o = stderr;
  
  fprintf (o, "Ogg123 %s\n", OGG123_VERSION);
  fprintf (o, " by Kenneth Arnold <kcarnold@yahoo.com>\n\n");
  fprintf (o, "Usage: ogg123 [<options>] <input file> ...\n\n");
  fprintf (o, "  -h, --help     this help\n");
  fprintf (o, "  -V, --version  display Ogg123 version\n");
  fprintf (o, "  -w, --write=w  writes WAV output to 'w' (not yet)\n");
  fprintf (o, "  -d, --device=d uses 'd' as an OSS output device (not yet)\n");
  fprintf (o, "  -s, --silent   don't play anything (not yet)\n");
  fprintf (o, "  -v, --verbose  display progress and other useful stuff (not yet)\n");
  fprintf (o, "  -q, --quiet    don't display anything (not yet)\n");
  fprintf (o, "\nAs you can see, this version is basically nonfunctional.\n");
}

int
main (int argc, char **argv)
{
  /* Parse command line */

  int ret;
  int option_index=1;
  
  while (-1 != ( ret = getopt_long (argc, argv, "d:hqvVw:", 
				    long_options, &option_index)))
    {
      switch (ret)
	{
	case 0:
	  fprintf (stderr, "Internal error: long option given when none expected.\n");
	  exit (1);
	case 'd':
	  if (param.device != NULL)
	    {
	      fprintf (stderr, "Only one device supported. Using last one.\n");
	      free (param.device);
	    }
	  param.device = strdup (optarg);
	  if (! param.output)
	    {
	      fprintf (stderr, "Since you specified a device, overriding request to be silent.\n");
	      param.output = 1;
	    }
	  break;
	case 's':
	  if (param.device != NULL)
	    {
	      fprintf (stderr, "Overriding previous specification of a device.\n");
	      free (param.device);
	    }
	  param.output = 0;
	  break;
	case 'h':
	  usage ();
	  exit (0);
	case 'q':
	  param.verbose--;
	  break;
	case 'v':
	  param.verbose++;
	  break;
	case 'V':
	  fprintf (stderr, "Ogg123 %s\n", OGG123_VERSION);
	  exit (0);
	case 'w':
	  if (param.write != NULL)
	    {
	      fprintf (stderr, "Writing to more than one output file is not supported. Using last one.\n");
	      free (param.write);
	    }
	  param.write = strdup (optarg);
	  break;
	case '?':
	  break;
	default:
	  usage ();
	  exit (1);
	}
    }

  if (optind == argc)
    {
      fprintf (stderr, "Please specify a file to decode on the command line.\n");
      exit (1);
    }

  if (param.output)
    {
      FILE * tstream;
      int fd, temp;
      if (param.device == NULL)
	{
	  fprintf (stderr, "Playing to default device /dev/dsp.\n");
	  param.device = strdup ("/dev/dsp");
	}
      if ( ! ( fd = open ( param.device, O_WRONLY )))
	{
	  fprintf (stderr, "Error opening %s\n", param.device);
	  exit (1);
	}
      fprintf (stderr, "Attempting to set DSP parameters.\n");
      if ( (ioctl (fd, SNDCTL_DSP_RESET)))
	{
	  fprintf (stderr, "Error resetting audio!\n");
	  exit (1);
	}
      temp=AFMT_S16_NE;
      if ( ioctl (fd, SNDCTL_DSP_SETFMT, &temp))
	{
	  fprintf (stderr, "Error setting format! Your sound device should support signed-16.\n");
	  exit (1);
	}
      temp=1;
      if ( ioctl (fd, SNDCTL_DSP_STEREO, &temp) )
	{
	  fprintf (stderr, "ioctl() error while setting channels.\n");
	  exit (1);
	}
      temp=44100;
      if ( ioctl (fd, SNDCTL_DSP_SPEED, &temp) )
	{
	  fprintf (stderr, "ioctl() error while setting rate.\n");
	  exit (1);
	}
      tstream = fdopen ( fd, "w" ); 
      append_stream (&param.outstreams, tstream);
    }
  
  while (optind < argc)
    {
      param.read_file = argv[optind];
      play_file();
      optind++;
    }
  return (0);
}

void
play_file (void)
{
  ogg_sync_state oy;		/* sync and verify incoming physical bitstream */
  ogg_stream_state os;		/* take physical pages, weld into a logical
				   stream of packets */
  ogg_page og;			/* one Ogg bitstream page.  Vorbis packets are inside */
  ogg_packet op;		/* one raw packet of data for decode */

  vorbis_info vi;		/* struct that stores all the static vorbis bitstream
				   settings */
  vorbis_comment vc;		/* struct that stores all the bitstream user comments */
  vorbis_dsp_state vd;		/* central working state for the packet->PCM decoder */
  vorbis_block vb;		/* local working space for packet->PCM decode */

  char *buffer;
  int bytes;

  if ( strcmp (param.read_file, "-") ) /* input file not stdin */
    {
      fprintf (stderr, "Playing from file %s.\n", param.read_file);
      /* Open the file. */
      if ( (param.instream = fopen (param.read_file, "rb")) == NULL)
	{
	  fprintf (stderr, "Error opening input file.\n");
	  exit (1);
	}
    }
  else
    {
      fprintf (stderr, "Playing from standard input.\n");
      param.instream = stdin;
    }

  /* TODO: Open and prewrite a WAV file here, if necessary. */

  /********** Decode setup ************/

  ogg_sync_init (&oy);		/* Now we can read pages */

  while (1)
    {				/* we repeat if the bitstream is chained */
      int eos = 0;
      int i;

      /* grab some data at the head of the stream.  We want the first page
         (which is guaranteed to be small and only contain the Vorbis
         stream initial header) We need the first page to get the stream
         serialno. */

      /* submit a 4k block to libvorbis' Ogg layer */
      buffer = ogg_sync_buffer (&oy, 4096);
      bytes = fread (buffer, 1, 4096, param.instream);
      ogg_sync_wrote (&oy, bytes);

      /* Get the first page. */
      if (ogg_sync_pageout (&oy, &og) != 1)
	{
	  /* have we simply run out of data?  If so, we're done. */
	  if (bytes < 4096)
	    break;

	  /* error case.  Must not be Vorbis data */
	  fprintf (stderr, "Input does not appear to be an Ogg bitstream.\n");
	  exit (1);
	}

      /* Get the serial number and set up the rest of decode. */
      /* serialno first; use it to set up a logical stream */
      ogg_stream_init (&os, ogg_page_serialno (&og));

      /* extract the initial header from the first page and verify that the
         Ogg bitstream is in fact Vorbis data */

      /* I handle the initial header first instead of just having the code
         read all three Vorbis headers at once because reading the initial
         header is an easy way to identify a Vorbis bitstream and it's
         useful to see that functionality seperated out. */

      vorbis_info_init (&vi);
      vorbis_comment_init (&vc);
      if (ogg_stream_pagein (&os, &og) < 0)
	{
	  /* error; stream version mismatch perhaps */
	  fprintf (stderr,
		   "Error reading first page of Ogg bitstream data.\n");
	  exit (1);
	}

      if (ogg_stream_packetout (&os, &op) != 1)
	{
	  /* no page? must not be vorbis */
	  fprintf (stderr, "Error reading initial header packet.\n");
	  exit (1);
	}

      if (vorbis_synthesis_headerin (&vi, &vc, &op) < 0)
	{
	  /* error case; not a vorbis header */
	  fprintf (stderr, "This Ogg bitstream does not contain Vorbis "
		   "audio data.\n");
	  exit (1);
	}

      /* At this point, we're sure we're Vorbis.  We've set up the logical
         (Ogg) bitstream decoder.  Get the comment and codebook headers and
         set up the Vorbis decoder */

      /* The next two packets in order are the comment and codebook headers.
         They're likely large and may span multiple pages.  Thus we reead
         and submit data until we get our two packets, watching that no
         pages are missing.  If a page is missing, error out; losing a
         header page is the only place where missing data is fatal. */

      i = 0;
      while (i < 2)
	{
	  while (i < 2)
	    {
	      int result = ogg_sync_pageout (&oy, &og);
	      if (result == 0)
		break;		/* Need more data */
	      /* Don't complain about missing or corrupt data yet.  We'll
	         catch it at the packet output phase */
	      if (result == 1)
		{
		  ogg_stream_pagein (&os, &og);	/* we can ignore any errors here
						   as they'll also become apparent
						   at packetout */
		  while (i < 2)
		    {
		      result = ogg_stream_packetout (&os, &op);
		      if (result == 0)
			break;
		      if (result == -1)
			{
			  /* Uh oh; data at some point was corrupted or missing!
			     We can't tolerate that in a header.  Die. */
			  fprintf (stderr,
				   "Corrupt secondary header.  Exiting.\n");
			  exit (1);
			}
		      vorbis_synthesis_headerin (&vi, &vc, &op);
		      i++;
		    }
		}
	    }
	  /* no harm in not checking before adding more */
	  buffer = ogg_sync_buffer (&oy, 4096);
	  bytes = fread (buffer, 1, 4096, param.instream);
	  if (bytes == 0)
	    {
	      fprintf (stderr,
		       "End of file before finding all Vorbis headers!\n");
	      exit (1);
	    }
	  ogg_sync_wrote (&oy, bytes);
	}

      /* Throw the comments plus a few lines about the bitstream we're
         decoding */
      if (vc.comments == 3) /* artist/album/track */
      {
	fprintf (stderr, "Artist: %s\n", vc.user_comments[0]);
	fprintf (stderr, "Album:  %s\n", vc.user_comments[1]);
	fprintf (stderr, "Track:  %s\n", vc.user_comments[2]);
      }
      else
	{
	char **ptr = vc.user_comments;
	while (*ptr)
	  {
	    fprintf (stderr, "%s\n", *ptr);
	    ++ptr;
	  }
	fprintf (stderr, "\nBitstream is %d channel, %ldHz\n", vi.channels,
		 vi.rate);
	fprintf (stderr, "Encoded by: %s\n\n", vc.vendor);
      }

      convsize = 4096 / vi.channels;

      /* OK, got and parsed all three headers. Initialize the Vorbis
         packet->PCM decoder. */
      vorbis_synthesis_init (&vd, &vi);	/* central decode state */
      vorbis_block_init (&vd, &vb);	/* local state for most of the decode
					   so multiple block decodes can
					   proceed in parallel.  We could init
					   multiple vorbis_block structures
					   for vd here */

      /* The rest is just a straight decode loop until end of stream */
      while (!eos)
	{
	  while (!eos)
	    {
	      int result = ogg_sync_pageout (&oy, &og);
	      if (result == 0)
		break;		/* need more data */
	      if (result == -1)
		{		/* missing or corrupt data at this page position */
		  fprintf (stderr, "Corrupt or missing data in bitstream; "
			   "continuing...\n");
		}
	      else
		{
		  ogg_stream_pagein (&os, &og);	/* can safely ignore errors at
						   this point */
		  while (1)
		    {
		      result = ogg_stream_packetout (&os, &op);
		      if (result == 0)
			break;	/* need more data */
		      if (result == -1)
			{	/* missing or corrupt data at this page position */
			  /* no reason to complain; already complained above */
			}
		      else
			{
			  /* we have a packet.  Decode it */
			  double **pcm;
			  int samples;

			  vorbis_synthesis (&vb, &op);
			  vorbis_synthesis_blockin (&vd, &vb);
			  /* 

			     **pcm is a multichannel double vector.  In stereo, for
			     example, pcm[0] is left, and pcm[1] is right.  samples is
			     the size of each channel.  Convert the float values
			     (-1.<=range<=1.) to whatever PCM format and write it out */

			  while (
				 (samples =
				  vorbis_synthesis_pcmout (&vd, &pcm)) > 0)
			    {
			      int j;
			      int clipflag = 0;
			      int out =
				(samples < convsize ? samples : convsize);

			      /* convert doubles to 16 bit signed ints (host order) and
			         interleave */
			      for (i = 0; i < vi.channels; i++)
				{
				  int16_t *ptr = convbuffer + i;
				  double *mono = pcm[i];
				  for (j = 0; j < out; j++)
				    {
				      int val = mono[j] * 32767.;
				      /* might as well guard against clipping */
				      if (val > 32767)
					{
					  val = 32767;
					  clipflag = 1;
					}
				      if (val < -32768)
					{
					  val = -32768;
					  clipflag = 1;
					}
				      *ptr = val;
				      ptr += 2;
				    }
				}

			      if (clipflag && param.verbose > 1)
				fprintf (stderr, "Clipping in frame %ld\n",
					 (long)(vd.sequence));


			      streams_write (convbuffer, 2 * vi.channels,
					     out, param.outstreams);

			      vorbis_synthesis_read (&vd, out);	/* tell libvorbis how
								   many samples we
								   actually consumed */
			    }
			}
		    }
		  if (ogg_page_eos (&og))
		    eos = 1;
		}
	    }
	  if (!eos)
	    {
	      buffer = ogg_sync_buffer (&oy, 4096);
	      bytes = fread (buffer, 1, 4096, param.instream);
	      ogg_sync_wrote (&oy, bytes);
	      if (bytes == 0)
		eos = 1;
	    }
	}

      /* clean up this logical bitstream; before exit we see if we're
         followed by another [chained] */

      ogg_stream_clear (&os);

      /* ogg_page and ogg_packet structs always point to storage in
         libvorbis.  They're never freed or manipulated directly */

      vorbis_block_clear (&vb);
      vorbis_dsp_clear (&vd);
      vorbis_info_clear (&vi);	/* must be called last */
    }

  /* OK, clean up the framer */
  ogg_sync_clear (&oy);

  fclose (param.instream);

  fprintf (stderr, "Done.\n");
}
