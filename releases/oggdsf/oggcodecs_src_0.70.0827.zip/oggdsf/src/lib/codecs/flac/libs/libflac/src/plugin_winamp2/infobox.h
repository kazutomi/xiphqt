/* in_flac - Winamp2 FLAC input plugin
 * Copyright (C) 2002,2003,2004,2005  Josh Coalson
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

/*
 *  prototypes
 */

ULONGLONG FileSize(const char *fileName);
void ReadTags(const char *fileName, FLAC__StreamMetadata **tags, BOOL forDisplay);

void InitInfobox();
void DeinitInfobox();
void DoInfoBox(HINSTANCE inst, HWND hwnd, const char *filename);
