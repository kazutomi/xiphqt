#!/bin/bash
rm -f html/*.css
rm -f html/*.gif
rm -f html/*.html
rm -f html/*.png

rm -f html/*.map
rm -f html/*.md5
rm -f html/graph_legend.dot

aclocal && automake && autoconf && ./configure && make phony_html_doc
