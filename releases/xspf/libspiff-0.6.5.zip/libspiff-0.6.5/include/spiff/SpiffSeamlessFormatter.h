/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, sping@xiph.org
 */

/**
 * @file SpiffSeamlessFormatter.h
 * Interface of SpiffSeamlessFormatter.
 */

#ifndef SPIFF_SEAMLESS_FORMATTER_H
#define SPIFF_SEAMLESS_FORMATTER_H



#include "SpiffXmlFormatter.h"

namespace Spiff {



/**
 * Outputs XML without any indentation or newlines.
 * Please only use this XML formatter if you have to
 * squeeze out the very last byte. Please consider using
 * SpiffIndentFormatter instead, which produces much
 * more readable output.
 */
class SpiffSeamlessFormatter : public SpiffXmlFormatter {

public:
	/**
	 * Creates a new zero-whitespace formatter.
	 */
	SpiffSeamlessFormatter();

	/**
	 * Deletes all own memory.
	 */
	~SpiffSeamlessFormatter();

private:
	void writeStart(const XML_Char * name, const XML_Char ** atts);
	void writeEnd(const XML_Char * name);
	void writeBody(const XML_Char * text);
	void writeBody(int number);

};



}

#endif // SPIFF_SEAMLESS_FORMATTER_H
