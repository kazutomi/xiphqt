/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, sping@xiph.org
 */

/**
 * @file SpiffReader.cpp
 * Implementation of SpiffReader.
 */

#include <spiff/SpiffReader.h>
#include <spiff/SpiffProps.h>
#include <spiff/SpiffTrack.h>
#include <spiff/SpiffReaderCallback.h>
#include <spiff/SpiffToolbox.h>
#include <spiff/SpiffStack.h>
#include <spiff/SpiffSkipExtensionReader.h>
#include <spiff/SpiffExtensionReaderFactory.h>
#include <uriparser/Uri.h>
#include <stdio.h>
#include <algorithm>
#include <stdlib.h> // atoi

#if (URI_VER_MINOR < 3)
# uriparser 0.3.0 or later is required
#endif

namespace Spiff {



SpiffReader::SpiffReader(SpiffExtensionReaderFactory * handlerFactory)
		: stack(new SpiffStack()), props(NULL), track(NULL), version(-1),
		callback(callback), extensionReader(NULL), extensionReaderFactory(handlerFactory),
		errorCode(SPIFF_READER_SUCCESS), errorLine(-1), insideExtension(false),
		firstPlaylistAnnotation(true), firstPlaylistAttribution(true),
		firstPlaylistCreator(true),	firstPlaylistDate(true), firstPlaylistIdentifier(true),
        firstPlaylistImage(true), firstPlaylistInfo(true), firstPlaylistLicense(true),
		firstPlaylistLocation(true), firstPlaylistTitle(true), firstPlaylistTrackList(true),
		firstTrackTitle(true), firstTrackCreator(true),	firstTrackAnnotation(true),
		firstTrackInfo(true), firstTrackImage(true), firstTrackAlbum(true),
		firstTrackTrackNum(true), firstTrackDuration(true), firstTrack(true) {

}



void SpiffReader::makeReusable() {
	// Reset everything but the error state
	this->stack->clear();
	if (this->props != NULL) {
		delete this->props;
		this->props = NULL;
	}
	if (this->track != NULL) {
		delete this->track;
		this->track = NULL;
	}
	this->callback = NULL;
	this->accum.clear();
	this->lastRelValue.clear();

	this->firstPlaylistAnnotation = true;
	this->firstPlaylistAttribution = true;
	this->firstPlaylistCreator = true;
	this->firstPlaylistDate = true;
	this->firstPlaylistIdentifier = true;
	this->firstPlaylistImage = true;
	this->firstPlaylistInfo = true;
	this->firstPlaylistLicense = true;
	this->firstPlaylistLocation = true;
	this->firstPlaylistTitle = true;
	this->firstPlaylistTrackList = true;

	this->firstTrackTitle = true;
	this->firstTrackCreator = true;
	this->firstTrackAnnotation = true;
	this->firstTrackInfo = true;
	this->firstTrackImage = true;
	this->firstTrackAlbum = true;
	this->firstTrackTrackNum = true;
	this->firstTrackDuration = true;

	this->firstTrack = true;

	this->insideExtension = false;
	this->version = -1;

	if (this->extensionReader != NULL) {
		delete this->extensionReader;
		this->extensionReader = NULL;
	}
}



SpiffReader::~SpiffReader() {
	if (this->stack != NULL) {
		delete this->stack;
		this->stack = NULL;
	}
	if (this->props != NULL) {
		delete this->props;
		this->props = NULL;
	}
	if (this->track != NULL) {
		delete this->track;
		this->track = NULL;
	}
	if (this->extensionReader != NULL) {
		delete this->extensionReader;
		this->extensionReader = NULL;
	}
}



void SpiffReader::onBeforeParse(SpiffReaderCallback * callback) {
	// Set callback, NULL is no problem
	this->callback = callback;

	clearError();

	// Create parser
	this->parser = XML_ParserCreateNS(NULL, SPIFF_NS_SEP_CHAR);

	// Put class pointer into user data
	XML_SetUserData(this->parser, this);

	// Register handlers
	XML_SetElementHandler(this->parser, masterStart, masterEnd);
	XML_SetCharacterDataHandler(this->parser, masterCharacters);
}



void SpiffReader::onAfterParse() {
	XML_ParserFree(this->parser);
	makeReusable();
}



int SpiffReader::parse(const XML_Char * filename,
		SpiffReaderCallback * callback) {
	// Backward compatibility
	return parseFile(filename, callback);
}



int SpiffReader::parseFile(const XML_Char * filename,
		SpiffReaderCallback * callback) {
	// Check filename
	if (filename == NULL) {
		setError(SPIFF_READER_ERROR_NO_INPUT, SPIFF_READER_TEXT_ZERO_FILENAME_NULL);
		return this->errorCode;
	}

	// Init
	onBeforeParse(callback);

	// Open file
	FILE * file = ::PORT_FOPEN(filename, _PT("r"));
	if (file == NULL) {
		setError(SPIFF_READER_ERROR_NO_INPUT, SPIFF_READER_TEXT_ONE_FILE_READING_ERROR, filename);
		return this->errorCode;
	}

	// Get filesize
	::fseek(file, 0, SEEK_END);
	const long filesize = ::ftell(file);
	::fseek(file, 0, SEEK_SET);

	// Read and parse file
	void * buffer;
	if (filesize > SPIFF_MAX_BLOCK_SIZE) {
		// In several blocks
		long sizeLeft = filesize;
		while (sizeLeft > 0) {
			const long blockSize = std::min<long>(sizeLeft, SPIFF_MAX_BLOCK_SIZE);
			buffer = malloc(blockSize);
			::fread(buffer, 1, blockSize, file);
			sizeLeft -= blockSize;
			if (XML_Parse(this->parser, reinterpret_cast<char *>(buffer), blockSize, sizeLeft == 0) == XML_STATUS_ERROR) {
				if (this->errorCode == SPIFF_READER_SUCCESS) {
					const XML_Error expatCode = XML_GetErrorCode(this->parser);
					setError(SPIFF_READER_ERROR_EXPAT + static_cast<int>(expatCode),
							SPIFF_READER_TEXT_ONE_EXPAT_ERROR,
							XML_ErrorString(expatCode));
				}
				break;
			}
		}
		::fclose(file);
	} else {
		// One single go
		buffer = XML_GetBuffer(this->parser, filesize);
		::fread(buffer, 1, filesize, file);
		::fclose(file);

		if (XML_ParseBuffer(this->parser, filesize, 1) == XML_STATUS_ERROR) {
			if (this->errorCode == SPIFF_READER_SUCCESS) {
				const XML_Error expatCode = XML_GetErrorCode(this->parser);
				setError(SPIFF_READER_ERROR_EXPAT + static_cast<int>(expatCode),
						SPIFF_READER_TEXT_ONE_EXPAT_ERROR,
						XML_ErrorString(expatCode));
			}
		}
	}

	// Cleanup
	onAfterParse();

	return this->errorCode;
}



int SpiffReader::parseMemory(const char * memory, int numBytes,
		SpiffReaderCallback * callback) {
	// Init
	onBeforeParse(callback);

	// Parse
	if (XML_Parse(this->parser, memory, numBytes, 1) == XML_STATUS_ERROR) {
		if (this->errorCode == SPIFF_READER_SUCCESS) {
			const XML_Error expatCode = XML_GetErrorCode(this->parser);
			setError(SPIFF_READER_ERROR_EXPAT + static_cast<int>(expatCode),
					SPIFF_READER_TEXT_ONE_EXPAT_ERROR,
					XML_ErrorString(expatCode));
		}
	}

	// Cleanup
	onAfterParse();

	return this->errorCode;
}



bool SpiffReader::handleStartOne(const XML_Char * fullName, const XML_Char ** atts) {
	// Check full root name
	if (::PORT_STRNCMP(fullName, SPIFF_NS_HOME, SPIFF_NS_HOME_LEN)
			|| ::PORT_STRCMP(fullName + SPIFF_NS_HOME_LEN + 1, _PT("playlist"))) {
		setError(SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
				SPIFF_READER_TEXT_ONE_WRONG_ROOT_NAME,
				fullName);
		return false;
	}

	if (!handlePlaylistAttribs(atts)) {
		return false;
	}

	this->stack->push(TAG_PLAYLIST);
	this->props = new SpiffProps();
	this->props->setVersion(this->version);
	return true;
}



bool SpiffReader::handleStartTwo(const XML_Char * fullName, const XML_Char ** atts) {
	// Check and skip namespace
	if (::PORT_STRNCMP(fullName, SPIFF_NS_HOME, SPIFF_NS_HOME_LEN)) {
		setError(SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
				SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN,
				fullName);
		return false;
	}
	const XML_Char * localName = fullName + SPIFF_NS_HOME_LEN + 1;

	switch (localName[0]) {
	case _PT('a'):
		switch (localName[1]) {
		case _PT('n'):
			if (::PORT_STRCMP(localName + 2, _PT("notation"))) {
				break;
			}
			if (!this->firstPlaylistAnnotation) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("annotation")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstPlaylistAnnotation = false;
				this->stack->push(TAG_PLAYLIST_ANNOTATION);
				return true;
			}
			break;

		case _PT('t'):
			if (::PORT_STRCMP(localName + 2, _PT("tribution"))) {
				break;
			}
			if (!this->firstPlaylistAttribution) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("attribution")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstPlaylistAttribution = false;
				this->stack->push(TAG_PLAYLIST_ATTRIBUTION);
				return true;
			}
			break;

		}
		break;

	case _PT('c'):
		if (::PORT_STRCMP(localName + 1, _PT("reator"))) {
			break;
		}
		if (!this->firstPlaylistCreator) {
			setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
					SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("creator")));
			return false;
		} else if (!handleNoAttribs(atts)) {
			return false;
		} else {
			this->firstPlaylistCreator = false;
			this->stack->push(TAG_PLAYLIST_CREATOR);
			return true;
		}
		break;

	case _PT('d'):
		if (::PORT_STRCMP(localName + 1, _PT("ate"))) {
			break;
		}
		if (!this->firstPlaylistDate) {
			setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
					SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("date")));
			return false;
		} else if (!handleNoAttribs(atts)) {
			return false;
		} else {
			this->firstPlaylistDate = false;
			this->stack->push(TAG_PLAYLIST_DATE);
			return true;
		}
		break;

	case _PT('e'):
		if (::PORT_STRCMP(localName + 1, _PT("xtension"))) {
			break;
		}

		// Tag only allowed in v1
		if (this->version == 0) {
			setError(SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
					SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN_VERSION_ZERO,
					fullName);
			return false;
		}

		const XML_Char * applicationUri;
		if (handleExtensionAttribs(atts, &applicationUri)) {
			this->insideExtension = true;

			// Create suitable handler
			if (this->extensionReaderFactory != NULL) {
				this->extensionReader = this->extensionReaderFactory
						->newPlaylistExtensionReader(applicationUri, this);
			}
			if (this->extensionReader == NULL) {
				this->extensionReader = new SpiffSkipExtensionReader(this);
			}

			return this->extensionReader->handleExtensionStart(fullName, atts);
		} else {
			return false;
		}
		break;

	case _PT('i'):
		switch (localName[1]) {
		case _PT('d'):
			if (::PORT_STRCMP(localName + 2, _PT("entifier"))) {
				break;
			}
			if (!this->firstPlaylistIdentifier) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("identifier")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstPlaylistIdentifier = false;
				this->stack->push(TAG_PLAYLIST_IDENTIFIER);
				return true;
			}
			break;

		case _PT('m'):
			if (::PORT_STRCMP(localName + 2, _PT("age"))) {
				break;
			}
			if (!this->firstPlaylistImage) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("image")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstPlaylistImage = false;
				this->stack->push(TAG_PLAYLIST_IMAGE);
				return true;
			}
			break;

		case _PT('n'):
			if (::PORT_STRCMP(localName + 2, _PT("fo"))) {
				break;
			}
			if (!this->firstPlaylistInfo) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("info")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstPlaylistInfo = false;
				this->stack->push(TAG_PLAYLIST_INFO);
				return true;
			}
			break;

		}
		break;

	case _PT('l'):
		switch (localName[1]) {
		case _PT('i'):
			switch (localName[2]) {
			case _PT('c'):
				if (::PORT_STRCMP(localName + 3, _PT("ense"))) {
					break;
				}
				if (!this->firstPlaylistLicense) {
					setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
							SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("license")));
					return false;
				} else if (!handleNoAttribs(atts)) {
					return false;
				} else {
					this->firstPlaylistLicense = false;
					this->stack->push(TAG_PLAYLIST_LICENSE);
					return true;
				}
				break;

			case _PT('n'):
				if (::PORT_STRCMP(localName + 3, _PT("k"))) {
					break;
				}
				if (handleMetaLinkAttribs(atts)) {
					this->stack->push(TAG_PLAYLIST_LINK);
					this->lastRelValue.assign(atts[1]);
					return true;
				} else {
					return false;
				}
				break;

			}
			break;

		case _PT('o'):
			if (::PORT_STRCMP(localName + 2, _PT("cation"))) {
				break;
			}
			if (!this->firstPlaylistLocation) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("location")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstPlaylistLocation = false;
				this->stack->push(TAG_PLAYLIST_LOCATION);
				return true;
			}
			break;

		}
		break;

	case _PT('m'):
		if (::PORT_STRCMP(localName + 1, _PT("eta"))) {
			break;
		}
		if (handleMetaLinkAttribs(atts)) {
			this->stack->push(TAG_PLAYLIST_META);
			this->lastRelValue.assign(atts[1]);
			return true;
		} else {
			return false;
		}
		break;

	case _PT('t'):
		switch (localName[1]) {
		case _PT('i'):
			if (::PORT_STRCMP(localName + 2, _PT("tle"))) {
				break;
			}
			if (!this->firstPlaylistTitle) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("title")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstPlaylistTitle = false;
				this->stack->push(TAG_PLAYLIST_TITLE);
				return true;
			}
			break;

		case _PT('r'):
			if (::PORT_STRCMP(localName + 2, _PT("ackList"))) {
				break;
			}
			if (!this->firstPlaylistTrackList) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("trackList")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstPlaylistTrackList = false;
				this->stack->push(TAG_PLAYLIST_TRACKLIST);
				return true;
			}
			break;

		}
		break;

	}

	setError(SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
			SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN,
			fullName);
	return false;
}



bool SpiffReader::handleStartThree(const XML_Char * fullName, const XML_Char ** atts) {
	// Check and skip namespace
	if (::PORT_STRNCMP(fullName, SPIFF_NS_HOME, SPIFF_NS_HOME_LEN)) {
		setError(SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
				SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN,
				fullName);
		return false;
	}
	const XML_Char * localName = fullName + SPIFF_NS_HOME_LEN + 1;

	switch (this->stack->top()) {
	case TAG_PLAYLIST_ATTRIBUTION:
		switch (localName[0]) {
		case _PT('i'):
			if (::PORT_STRCMP(localName + 1, _PT("dentifier"))) {
				break;
			}
			if (!handleNoAttribs(atts)) {
				return false;
			}
			this->stack->push(TAG_PLAYLIST_ATTRIBUTION_IDENTIFIER);
			return true;

		case _PT('l'):
			if (::PORT_STRCMP(localName + 1, _PT("ocation"))) {
				break;
			}
			if (!handleNoAttribs(atts)) {
				return false;
			}
			this->stack->push(TAG_PLAYLIST_ATTRIBUTION_LOCATION);
			return true;

		}
		break;

	case TAG_PLAYLIST_TRACKLIST:
		if (::PORT_STRCMP(localName, _PT("track"))) {
			break;
		}
		if (!handleNoAttribs(atts)) {
			return false;
		}
		this->firstTrack = false;
		this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK);
		this->track = new SpiffTrack();
		return true;

	}

	setError(SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
			SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN,
			fullName);
	return false;
}



bool SpiffReader::handleStartFour(const XML_Char * fullName, const XML_Char ** atts) {
	if (this->stack->top() != TAG_PLAYLIST_TRACKLIST_TRACK) {
		return false;
	}

	// Check and skip namespace
	if (::PORT_STRNCMP(fullName, SPIFF_NS_HOME, SPIFF_NS_HOME_LEN)) {
		setError(SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
				SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN,
				fullName);
		return false;
	}
	const XML_Char * localName = fullName + SPIFF_NS_HOME_LEN + 1;

	switch (localName[0]) {
	case _PT('a'):
		switch (localName[1]) {
		case _PT('l'):
			if (::PORT_STRCMP(localName + 2, _PT("bum"))) {
				break;
			}
			if (!this->firstTrackAlbum) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("album")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstTrackAlbum = false;
				this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_ALBUM);
				return true;
			}
			break;

		case _PT('n'):
			if (::PORT_STRCMP(localName + 2, _PT("notation"))) {
				break;
			}
			if (!this->firstTrackAnnotation) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("annotation")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstTrackAnnotation = false;
				this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_ANNOTATION);
				return true;
			}
			break;

		}
		break;

	case _PT('c'):
		if (::PORT_STRCMP(localName + 1, _PT("reator"))) {
			break;
		}
		if (!this->firstTrackCreator) {
			setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
					SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("creator")));
			return false;
		} else if (!handleNoAttribs(atts)) {
			return false;
		} else {
			this->firstTrackCreator = false;
			this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_CREATOR);
			return true;
		}
		break;

	case _PT('d'):
		if (::PORT_STRCMP(localName + 1, _PT("uration"))) {
			break;
		}
		if (!this->firstTrackDuration) {
			setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
					SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("duration")));
			return false;
		} else if (!handleNoAttribs(atts)) {
			return false;
		} else {
			this->firstTrackDuration = false;
			this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_DURATION);
			return true;
		}
		break;

	case _PT('e'):
		if (::PORT_STRCMP(localName + 1, _PT("xtension"))) {
			break;
		}

		// Tag only allowed in v1
		if (this->version == 0) {
			setError(SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
					SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN_VERSION_ZERO,
					fullName);
			return false;
		}

		const XML_Char * applicationUri;
		if (handleExtensionAttribs(atts, &applicationUri)) {
			this->insideExtension = true;

			// Create suitable handler
			if (this->extensionReaderFactory != NULL) {
				this->extensionReader = this->extensionReaderFactory
						->newTrackExtensionReader(applicationUri, this);
			}
			if (this->extensionReader == NULL) {
				this->extensionReader = new SpiffSkipExtensionReader(this);
			}

			return this->extensionReader->handleExtensionStart(fullName, atts);
		} else {
			return false;
		}
		break;

	case _PT('i'):
		switch (localName[1]) {
		case _PT('d'):
			if (::PORT_STRCMP(localName + 2, _PT("entifier"))) {
				break;
			}
			if (!handleNoAttribs(atts)) {
				return false;
			}
			this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_IDENTIFIER);
			return true;

		case _PT('m'):
			if (::PORT_STRCMP(localName + 2, _PT("age"))) {
				break;
			}
			if (!this->firstTrackImage) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("image")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstTrackImage = false;
				this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_IMAGE);
				return true;
			}
			break;

		case _PT('n'):
			if (::PORT_STRCMP(localName + 2, _PT("fo"))) {
				break;
			}
			if (!this->firstTrackInfo) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("info")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstTrackInfo = false;
				this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_INFO);
				return true;
			}
			break;

		}
		break;

	case _PT('l'):
		switch (localName[1]) {
		case _PT('i'):
			if (::PORT_STRCMP(localName + 2, _PT("nk"))) {
				break;
			}
			if (handleMetaLinkAttribs(atts)) {
				this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_LINK);
				this->lastRelValue.assign(atts[1]);
				return true;
			} else {
				return false;
			}
			break;

		case _PT('o'):
			if (::PORT_STRCMP(localName + 2, _PT("cation"))) {
				break;
			}
			if (!handleNoAttribs(atts)) {
				return false;
			}
			this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_LOCATION);
			return true;

		}
		break;

	case _PT('m'):
		if (::PORT_STRCMP(localName + 1, _PT("eta"))) {
			break;
		}
		if (handleMetaLinkAttribs(atts)) {
			this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_META);
			this->lastRelValue.assign(atts[1]);
			return true;
		} else {
			return false;
		}
		break;

	case _PT('t'):
		switch (localName[1]) {
		case _PT('i'):
			if (::PORT_STRCMP(localName + 2, _PT("tle"))) {
				break;
			}
			if (!this->firstTrackTitle) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("title")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstTrackTitle = false;
				this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_TITLE);
				return true;
			}
			break;

		case _PT('r'):
			if (::PORT_STRCMP(localName + 2, _PT("ackNum"))) {
				break;
			}
			if (!this->firstTrackTrackNum) {
				setError(SPIFF_READER_ERROR_ELEMENT_TOOMANY,
						SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(SPIFF_NS_HOME, _PT("trackNum")));
				return false;
			} else if (!handleNoAttribs(atts)) {
				return false;
			} else {
				this->firstTrackTrackNum = false;
				this->stack->push(TAG_PLAYLIST_TRACKLIST_TRACK_TRACKNUM);
				return true;
			}
			break;

		}
		break;

	}

	setError(SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
			SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN,
			fullName);
	return false;
}



void SpiffReader::handleStart(const XML_Char * fullName, const XML_Char ** atts) {
	bool res = false; // Init not needed
	if (this->insideExtension) {
		res = this->extensionReader->handleExtensionStart(fullName, atts);
	} else {
		switch (this->stack->getSize() + 1) {
		case 1:
			res = handleStartOne(fullName, atts);
			break;

		case 2:
			res = handleStartTwo(fullName, atts);
			break;

		case 3:
			res = handleStartThree(fullName, atts);
			break;

		case 4:
			res = handleStartFour(fullName, atts);
			break;

		case 5:
			setError(SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
					SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN,
					fullName);
			res = false;
			break;

		}
	}

	if (!res) {
		stop();
	}
}



bool SpiffReader::handleEndOne(const XML_Char * /*fullName*/) {
	if (this->firstPlaylistTrackList) {
		setError(SPIFF_READER_ERROR_ELEMENT_MISSING,
				SPIFF_READER_TEXT_ZERO_ELEMENT_MISSING(SPIFF_NS_HOME, _PT("trackList")));
		return false;
	}

	// Call property callback
	if (this->callback != NULL) {
		// Note: setProps() deletes the props for us
		this->callback->setProps(this->props);
	} else {
		delete this->props;
	}
	this->props = NULL;
	return true;
}



bool SpiffReader::handleEndTwo(const XML_Char * /*fullName*/) {
	const XML_Char * const finalAccum = this->accum.c_str();

	switch (this->stack->top()) {
	case TAG_PLAYLIST_ANNOTATION:
		this->props->giveAnnotation(finalAccum, true);
		break;
/*
	case TAG_PLAYLIST_ATTRIBUTION:
		break;
*/
	case TAG_PLAYLIST_CREATOR:
		this->props->giveCreator(finalAccum, true);
		break;

	case TAG_PLAYLIST_DATE:
		{
			SpiffDateTime * const dateTime = new SpiffDateTime;
			if (!SpiffReader::extractDateTime(finalAccum, dateTime)) {
				setError(SPIFF_READER_ERROR_CONTENT_INVALID,
						SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("date"), _PT("dateTime")));
				delete dateTime;
				return false;
			} else {
				this->props->giveDate(dateTime, false);
			}
		}
		break;
/*
	case TAG_PLAYLIST_EXTENSION:
		break;
*/
	case TAG_PLAYLIST_IDENTIFIER:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("identifier"), _PT("URI")));
			return false;
		} else {
			this->props->giveIdentifier(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_IMAGE:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("image"), _PT("URI")));
			return false;
		} else {
			this->props->giveImage(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_INFO:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("info"), _PT("URI")));
			return false;
		} else {
			this->props->giveInfo(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_LICENSE:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("license"), _PT("URI")));
			return false;
		} else {
			this->props->giveLicense(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_LINK:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("link"), _PT("URI")));
			return false;
		} else {
			this->props->giveAppendLink(this->lastRelValue.c_str(), true, finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_LOCATION:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("location"), _PT("URI")));
			return false;
		} else {
			this->props->giveLocation(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_META:
		this->props->giveAppendMeta(this->lastRelValue.c_str(), true, finalAccum, true);
		break;

	case TAG_PLAYLIST_TITLE:
		this->props->giveTitle(finalAccum, true);
		break;

	case TAG_PLAYLIST_TRACKLIST:
		// Check if empty for v0
		if ((this->version == 0) && (this->firstTrack)) {
			setError(SPIFF_READER_ERROR_ELEMENT_MISSING,
					SPIFF_READER_TEXT_ZERO_ELEMENT_MISSING_VERSION_ZERO(SPIFF_NS_HOME, _PT("track")));
			return false;
		}
		break;

	}

	this->accum.clear();
	return true;
}



bool SpiffReader::handleEndThree(const XML_Char * /*fullName*/) {
	const XML_Char * const finalAccum = this->accum.c_str();

	switch (this->stack->top()) {
	case TAG_PLAYLIST_ATTRIBUTION_IDENTIFIER:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("identifier"), _PT("URI")));
			return false;
		} else {
			this->props->giveAppendAttributionIdentifier(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_ATTRIBUTION_LOCATION:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("location"), _PT("URI")));
			return false;
		} else {
			this->props->giveAppendAttributionLocation(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK:
		// Call track callback
		if (this->callback != NULL) {
			// Note: addTrack() deletes the track for us
			this->callback->addTrack(this->track);
		} else {
			delete this->track;
		}
		this->track = NULL;

		this->firstTrackTitle = true;
		this->firstTrackCreator = true;
		this->firstTrackAnnotation = true;
		this->firstTrackInfo = true;
		this->firstTrackImage = true;
		this->firstTrackAlbum = true;
		this->firstTrackTrackNum = true;
		this->firstTrackDuration = true;
	}

	this->accum.clear();
	return true;
}



bool SpiffReader::handleEndFour(const XML_Char * /*fullName*/) {
	const XML_Char * const finalAccum = this->accum.c_str();

	switch (this->stack->top()) {
	case TAG_PLAYLIST_TRACKLIST_TRACK_ALBUM:
		this->track->giveAlbum(finalAccum, true);
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK_ANNOTATION:
		this->track->giveAnnotation(finalAccum, true);
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK_CREATOR:
		this->track->giveCreator(finalAccum, true);
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK_DURATION:
		int duration;
		if (!SpiffReader::extractInteger(finalAccum, 0, &duration)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("duration"), _PT("unsigned integer")));
			return false;
		} else {
			this->track->setDuration(duration);
		}
		break;
/*
	case TAG_PLAYLIST_TRACKLIST_TRACK_EXTENSION:
		break;
*/
	case TAG_PLAYLIST_TRACKLIST_TRACK_IDENTIFIER:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("identifier"), _PT("URI")));
			return false;
		} else {
			this->track->giveAppendIdentifier(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK_IMAGE:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("image"), _PT("URI")));
			return false;
		} else {
			this->track->giveImage(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK_INFO:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("info"), _PT("URI")));
			return false;
		} else {
			this->track->giveInfo(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK_LINK:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("link"), _PT("URI")));
			return false;
		} else {
			this->track->giveAppendLink(this->lastRelValue.c_str(), true, finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK_LOCATION:
		if (!isURI(finalAccum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("location"), _PT("URI")));
			return false;
		} else {
			this->track->giveAppendLocation(finalAccum, true);
		}
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK_META:
		this->track->giveAppendMeta(this->lastRelValue.c_str(), true, finalAccum, true);
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK_TITLE:
		this->track->giveTitle(finalAccum, true);
		break;

	case TAG_PLAYLIST_TRACKLIST_TRACK_TRACKNUM:
		int trackNum;
		if (!SpiffReader::extractInteger(finalAccum, 1, &trackNum)) {
			setError(SPIFF_READER_ERROR_CONTENT_INVALID,
					SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(SPIFF_NS_HOME, _PT("trackNum"),
							_PT("unsigned integer greater zero")));
			return false;
		} else {
			this->track->setTrackNum(trackNum);
		}
		break;

	}

	this->accum.clear();
	return true;
}



void SpiffReader::handleEnd(const XML_Char * fullName) {
	bool extensionLeft = false;
	int pushBackTag = TAG_UNKNOWN; // Init not needed but kills the warning...
	if (this->insideExtension) {
		switch (this->stack->getSize()) {
		case 2:
			if (this->stack->top() == TAG_PLAYLIST_EXTENSION) {
				pushBackTag = TAG_PLAYLIST_EXTENSION;
				extensionLeft = true;
			}
			break;

		case 4:
			if (this->stack->top() == TAG_PLAYLIST_TRACKLIST_TRACK_EXTENSION) {
				pushBackTag = TAG_PLAYLIST_TRACKLIST_TRACK_EXTENSION;
				extensionLeft = true;
			}
			break;

		}

		if (!this->extensionReader->handleExtensionEnd(fullName)) {
			stop();
			return;
		}

		if (extensionLeft) {
			this->insideExtension = false;

			// Add extension
			SpiffExtension * const extension = this->extensionReader->wrap();
			if (extension != NULL) {
				if (pushBackTag == TAG_PLAYLIST_EXTENSION) {
					this->props->giveAppendExtension(extension, false);
				} else {
					this->track->giveAppendExtension(extension, false);
				}
			}

			// Destroy extension reader
			delete this->extensionReader;
			this->extensionReader = NULL;

			this->stack->push(pushBackTag);
		} else {
			return;
		}
	}

	bool res = false;
	switch (this->stack->getSize()) {
	case 1:
		res = handleEndOne(fullName);
		break;

	case 2:
		res = handleEndTwo(fullName);
		break;

	case 3:
		res = handleEndThree(fullName);
		break;

	case 4:
		res = handleEndFour(fullName);
		break;

	}

	if (!res) {
		stop();
		return;
	}

	// Prevent popping twice
//	if (!extensionLeft) {
		this->stack->pop();
//	}
}



void SpiffReader::handleCharacters(const XML_Char * s, int len) {
	if (this->insideExtension) {
		if (!this->extensionReader->handleExtensionCharacters(s, len)) {
			stop();
		}
		return;
	}

	switch (this->stack->getSize()) {
	case 2:
		switch (this->stack->top()) {
		case TAG_PLAYLIST_TRACKLIST:
		case TAG_PLAYLIST_ATTRIBUTION:
			break;

		default:
			this->accum.append(s, len);

		}
		break;

	case 3:
		switch (this->stack->top()) {
		case TAG_PLAYLIST_ATTRIBUTION_IDENTIFIER:
		case TAG_PLAYLIST_ATTRIBUTION_LOCATION:
			this->accum.append(s, len);
			break;

		}
		break;

	case 4:
		this->accum.append(s, len);
		break;

	}
}



void SpiffReader::stop() {
	// Remove handlers
	XML_SetElementHandler(this->parser, NULL, NULL);
	XML_SetCharacterDataHandler(this->parser, NULL);

	// Full stop
	XML_StopParser(this->parser, XML_FALSE);
}



bool SpiffReader::handlePlaylistAttribs(const XML_Char ** atts) {
	// No attributes?
	if (atts[0] == NULL) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_MISSING, SPIFF_READER_TEXT_ZERO_ATTRIBUTE_MISSING(_PT("version")));
		return false;
	}

	// Is key "version"?
	if (::PORT_STRCMP(atts[0], _PT("version"))) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_FORBIDDEN, SPIFF_READER_TEXT_ONE_ATTRIBUTE_FORBIDDEN, atts[0]);
		return false;
	}

	// Check and set version
	int dummyVersion;
	if (!SpiffReader::extractInteger(atts[1], 0, &dummyVersion)
			|| (dummyVersion > 1)) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_INVALID,
				SPIFF_READER_TEXT_ONE_WRONG_VERSION,
				atts[1]);
		return false;
	}
	this->version = dummyVersion;

	// More than this one attribute?
	if (atts[2] != NULL) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_FORBIDDEN, SPIFF_READER_TEXT_ONE_ATTRIBUTE_FORBIDDEN, atts[2]);
		return false;
	}

	return true;
}



bool SpiffReader::handleMetaLinkAttribs(const XML_Char ** atts) {
	// No attributes?
	if (atts[0] == NULL) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_MISSING, SPIFF_READER_TEXT_ZERO_ATTRIBUTE_MISSING(_PT("rel")));
		return false;
	}

	// Is key "rel"?
	if (::PORT_STRCMP(atts[0], _PT("rel"))) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_FORBIDDEN, SPIFF_READER_TEXT_ONE_ATTRIBUTE_FORBIDDEN, atts[0]);
		return false;
	}

	// Check URI
	if (!isURI(atts[1])) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_INVALID, SPIFF_READER_TEXT_ZERO_WRONG_ATTRIBUTE_TYPE(_PT("rel"), _PT("URI")));
		return false;
	}

	// More than this one attribute?
	if (atts[2] != NULL) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_FORBIDDEN, SPIFF_READER_TEXT_ONE_ATTRIBUTE_FORBIDDEN, atts[2]);
		return false;
	}

	return true;
}



bool SpiffReader::handleExtensionAttribs(const XML_Char ** atts, const XML_Char ** application) {
	// No attributes?
	if (atts[0] == NULL) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_MISSING, SPIFF_READER_TEXT_ZERO_ATTRIBUTE_MISSING(_PT("application")));
		return false;
	}

	// Is key "application"?
	if (::PORT_STRCMP(atts[0], _PT("application"))) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_FORBIDDEN, SPIFF_READER_TEXT_ONE_ATTRIBUTE_FORBIDDEN, atts[0]);
		return false;
	}

	// Check URI
	if (!isURI(atts[1])) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_INVALID, SPIFF_READER_TEXT_ZERO_WRONG_ATTRIBUTE_TYPE(_PT("application"), _PT("URI")));
		return false;
	}

	// More than this one attribute?
	if (atts[2] != NULL) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_FORBIDDEN, SPIFF_READER_TEXT_ONE_ATTRIBUTE_FORBIDDEN, atts[2]);
		return false;
	}

	// Extract URI
	if (application != NULL) {
		*application = atts[1];
	}

	return true;
}



bool SpiffReader::handleNoAttribs(const XML_Char ** atts) {
	// No attributes?
	if (atts[0] != NULL) {
		setError(SPIFF_READER_ERROR_ATTRIBUTE_FORBIDDEN, SPIFF_READER_TEXT_ONE_ATTRIBUTE_FORBIDDEN, atts[0]);
		return false;

	}

	return true;
}



void SpiffReader::setError(int code, const XML_Char * text) {
	this->errorCode = code;
	this->errorText.assign(text);
	this->errorLine = XML_GetCurrentLineNumber(this->parser);
	/* TODO this->errorColumn = XML_GetCurrentColumnNumber(this->parser); */
}



void SpiffReader::setError(int code, const XML_Char * format, const XML_Char * param) {
	this->errorCode = code;
	if (param == NULL) {
		this->errorText.assign(format);
	} else {
		XML_Char * const final = new XML_Char[::PORT_STRLEN(format) + ::PORT_STRLEN(param) + 1];
		::PORT_SPRINTF(final, format, param);
		this->errorText.assign(final);
		delete [] final;
	}
	this->errorLine = XML_GetCurrentLineNumber(this->parser);
}



void SpiffReader::clearError() {
	this->errorCode = SPIFF_READER_SUCCESS;
	this->errorLine = -1;
	this->errorText.clear();
}



const XML_Char * SpiffReader::getErrorText() {
	return this->errorText.c_str();
}



int SpiffReader::getErrorLine() {
	return this->errorLine;
}



/*static*/ inline void SpiffReader::masterStart(void * userData, const XML_Char * fullName, const XML_Char ** atts) {
	SpiffReader * const parser = reinterpret_cast<SpiffReader *>(userData);
	parser->handleStart(fullName, atts);
}



/*static*/ inline void SpiffReader::masterEnd(void * userData, const XML_Char * fullName) {
	SpiffReader * const parser = reinterpret_cast<SpiffReader *>(userData);
	parser->handleEnd(fullName);
}



/*static*/ inline void SpiffReader::masterCharacters(void * userData, const XML_Char * s, int len) {
	SpiffReader * const parser = reinterpret_cast<SpiffReader *>(userData);
	parser->handleCharacters(s, len);
}



/*static*/ bool SpiffReader::isURI(const XML_Char * text) {
#ifdef UNICODE
	UriParserStateW stateW;
	UriUriW uriW;
	stateW.uri = &uriW;
	const int res = uriParseUriW(&stateW, text);
	uriFreeUriMembersW(&uriW);
#else
	UriParserStateA stateA;
	UriUriA uriA;
	stateA.uri = &uriA;
	const int res = uriParseUriA(&stateA, text);
	uriFreeUriMembersA(&uriA);
#endif
	return (res == 0);
}



/*static*/ bool SpiffReader::extractInteger(const XML_Char * text, int inclusiveMinimum, int * output) {
	int & number = *output;
	number = ::PORT_ATOI(text);
	if ((number < inclusiveMinimum)
			|| ((number == 0) && ::PORT_STRCMP(text, _PT("0")))) {
		return false;
	} else {
		return true;
	}
}



/*static*/ bool SpiffReader::extractDateTime(const XML_Char * text, SpiffDateTime * output) {
	// http://www.w3.org/TR/xmlschema-2/#dateTime-lexical-representation
	// '-'? yyyy '-' mm '-' dd 'T' hh ':' mm ':' ss ('.' s+)? (zzzzzz)?

	// '-'?
	const bool leadingMinus = (*text == _PT('-'));
	if (leadingMinus) {
		text++;
	}

	// yyyy
	if ((::PORT_STRNCMP(text, _PT("0001"), 4) < 0) || (::PORT_STRNCMP(_PT("9999"), text, 4) < 0)) {
		return false;
	}
	output->year = Toolbox::PORT_ANTOI(text, 4);
	text += 4;

	// '-' mm
	if ((::PORT_STRNCMP(text, _PT("-01"), 3) < 0) || (::PORT_STRNCMP(_PT("-12"), text, 3) < 0)) {
		return false;
	}
	output->month = Toolbox::PORT_ANTOI(text + 1, 2);
	text += 3;

	// '-' dd
	if ((::PORT_STRNCMP(text, _PT("-01"), 3) < 0) || (::PORT_STRNCMP(_PT("-31"), text, 3) < 0)) {
		return false;
	}
	output->day = Toolbox::PORT_ANTOI(text + 1, 2);
	text += 3;

	// Month specific day check
	switch (output->month) {
	case 2:
		switch (output->day) {
		case 31:
		case 30:
			return false;

		case 29:
			if (((output->year % 400) != 0) && (((output->year % 4) != 0)
					|| ((output->year % 100) == 0))) {
				// Not a leap year
				return false;
			}
			break;

		case 28:
			break;
		}
		break;

	case 4:
	case 6:
	case 9:
	case 11:
		if (output->day > 30) {
			return false;
		}
		break;

	}

	// 'T' hh
	if ((::PORT_STRNCMP(text, _PT("T00"), 3) < 0) || (::PORT_STRNCMP(_PT("T23"), text, 3) < 0)) {
		return false;
	}
	output->hour = Toolbox::PORT_ANTOI(text + 1, 2);
	text += 3;

	// ':' mm
	if ((::PORT_STRNCMP(text, _PT(":00"), 3) < 0) || (::PORT_STRNCMP(_PT(":59"), text, 3) < 0)) {
		return false;
	}
	output->minutes = Toolbox::PORT_ANTOI(text + 1, 2);
	text += 3;

	// ':' ss
	if ((::PORT_STRNCMP(text, _PT(":00"), 2) < 0) || (::PORT_STRNCMP(_PT(":59"), text, 2) < 0)) {
		return false;
	}
	output->seconds = Toolbox::PORT_ANTOI(text + 1, 2);
	text += 3;

	// ('.' s+)?
	if (*text == _PT('.')) {
		text++;
		int counter = 0;
		while ((*text >= _PT('0')) && (*text <= _PT('9'))) {
			text++;
			counter++;
		}
		if (counter == 0) {
			return false;
		} else {
			// The fractional second string, if present, must not end in '0'
			if (*(text - 1) == _PT('0')) {
				return false;
			}
		}
	}

	// (zzzzzz)? := (('+' | '-') hh ':' mm) | 'Z'
	const XML_Char * const timeZoneStart = text;
	switch (*text) {
	case _PT('+'):
	case _PT('-'):
		{
			text++;
			if ((::PORT_STRNCMP(text, _PT("00"), 2) < 0) || (::PORT_STRNCMP(_PT("14"), text, 2) < 0)) {
				return false;
			}
			output->distHours = Toolbox::PORT_ANTOI(text, 2);
			text += 2;

			if ((::PORT_STRNCMP(text, _PT(":00"), 3) < 0) || (::PORT_STRNCMP(_PT(":59"), text, 3) < 0)) {
				return false;
			}
			output->distMinutes = Toolbox::PORT_ANTOI(text + 1, 2);
			if ((output->distHours == 14) && (output->distMinutes != 0)) {
				return false;
			}
			text += 3;

			if (*text != _PT('\0')) {
				return false;
			}

			if (*timeZoneStart == _PT('-')) {
				output->distHours = -output->distHours;
				output->distMinutes = -output->distMinutes;
			}
		}
		break;

	case _PT('Z'):
		text++;
		if (*text != _PT('\0')) {
			return false;
		}
		// NO BREAK

	case _PT('\0'):
		output->distHours = 0;
		output->distMinutes = 0;
		break;

	default:
		return false;

	}

	return true;
}



}
