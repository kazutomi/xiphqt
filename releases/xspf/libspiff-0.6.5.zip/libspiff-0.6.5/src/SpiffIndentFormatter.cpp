/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, sping@xiph.org
 */

/**
 * @file SpiffIndentFormatter.cpp
 * Implementation of SpiffIndentFormatter.
 */

#include <spiff/SpiffIndentFormatter.h>
#include <spiff/SpiffStack.h>

namespace Spiff {



/**
 * Specifies the type of basic XML unit.
 */
enum SpiffElemPos {
	SPIFF_ELEM_DUMMY, ///< Stack returns 0 if empty

	SPIFF_ELEM_START, ///< Opening tag
	SPIFF_ELEM_BODY ///< Tag body
};



SpiffIndentFormatter::SpiffIndentFormatter(bool newlineFinish)
		: level(0), stack(new SpiffStack()), newlineFinish(newlineFinish),
		shift(0) {

}



SpiffIndentFormatter::SpiffIndentFormatter(int shift)
		: level(0), stack(new SpiffStack()), newlineFinish(true),
		shift(shift) {
	// Fix broken indent shift
	if (this->shift > 0) {
		this->shift = 0;
	}
}



SpiffIndentFormatter::~SpiffIndentFormatter() {
	delete this->stack;
}



void SpiffIndentFormatter::writeStart(const XML_Char * name, const XML_Char ** atts) {
	// XML Header
	if (!this->introDone) {
		*this->output << _PT("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
		this->introDone = true;
	} else {
		*this->output << _PT('\n');
	}

	// Indent
	for (int i = -(this->shift); i < this->level; i++) {
		*this->output << _PT('\t');
	}

	// Element
	*this->output << _PT('<') << name;
	while (atts[0] != NULL) {
		*this->output << _PT(' ') << atts[0] << _PT("=\"") << atts[1] << _PT("\"");
		atts += 2;
	}
	*this->output << _PT(">");

	this->level++;
	this->stack->push(SPIFF_ELEM_START);
}



void SpiffIndentFormatter::writeEnd(const XML_Char * name) {
	this->level--;
	if (this->stack->top() != SPIFF_ELEM_BODY) {
		*this->output << _PT('\n');
		for (int i = -(this->shift); i < this->level; i++) {
			*this->output << _PT('\t');
		}
	} else {
		// Pop body
		this->stack->pop();
	}
	// Pop start
	this->stack->pop();

	*this->output << _PT("</") << name << _PT('>');

	if ((this->level == 0) && newlineFinish) {
		*this->output << _PT("\n");
	}
}



void SpiffIndentFormatter::writeBody(const XML_Char * text) {
	writeCharacterData(text);
	this->stack->push(SPIFF_ELEM_BODY);
}



void SpiffIndentFormatter::writeBody(int number) {
	*this->output << number;
	this->stack->push(SPIFF_ELEM_BODY);
}



}
