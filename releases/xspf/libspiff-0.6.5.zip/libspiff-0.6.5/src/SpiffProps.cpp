/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, sping@xiph.org
 */

/**
 * @file SpiffProps.cpp
 * Implementation of SpiffProps.
 */

#include <spiff/SpiffProps.h>
#include <spiff/SpiffToolbox.h>
#include <string.h>
using namespace std;

namespace Spiff {



SpiffProps::SpiffProps() : location(NULL), license(NULL), identifier(NULL),
		ownLocation(false), ownLicense(false), ownIdentifier(false),
		attributions(NULL), date(NULL), ownDate(false), version(-1) {

}



SpiffProps::~SpiffProps() {
	if (this->ownLocation && (this->location != NULL)) {
		delete [] this->location;
	}
	if (this->ownIdentifier && (this->identifier != NULL)) {
		delete [] this->identifier;
	}
	if (this->ownLicense && (this->license != NULL)) {
		delete [] this->license;
	}
	if (this->attributions != NULL) {
		deque<pair<bool, pair<const XML_Char *, bool> *> *>::const_iterator iter = this->attributions->begin();
		while (iter != this->attributions->end()) {
			pair<bool, pair<const XML_Char *, bool> *> * const entry = *iter;
			if (entry->second->second) {
				delete [] entry->second->first;
			}
			delete entry->second;
			delete entry;
			iter++;
		}
		delete this->attributions;
	}
	if (this->ownDate && (this->date != NULL)) {
		delete this->date;
	}
}



void SpiffProps::giveLocation(const XML_Char * location, bool copy) {
	Toolbox::deleteNewAndCopy(this->location, this->ownLocation, location, copy);
}



void SpiffProps::giveLicense(const XML_Char * license, bool copy) {
	Toolbox::deleteNewAndCopy(this->license, this->ownLicense, license, copy);
}



void SpiffProps::giveIdentifier(const XML_Char * identifier, bool copy) {
	Toolbox::deleteNewAndCopy(this->identifier, this->ownIdentifier, identifier, copy);
}



void SpiffProps::giveAppendAttributionIdentifier(const XML_Char * identifier, bool copy) {
	appendHelper(this->attributions, copy ? Toolbox::newAndCopy(identifier)
		: identifier, true, false);
}



void SpiffProps::giveAppendAttributionLocation(const XML_Char * location, bool copy) {
	appendHelper(this->attributions, copy ? Toolbox::newAndCopy(location)
		: location, true, true);
}



void SpiffProps::giveDate(const SpiffDateTime * date, bool copy) {
	SpiffProps::deleteNewAndCopy(this->date, this->ownDate, date, copy);
}



void SpiffProps::lendLocation(const XML_Char * location) {
	Toolbox::deleteNewAndCopy(this->location, this->ownLocation, location, false);
}



void SpiffProps::lendLicense(const XML_Char * license) {
	Toolbox::deleteNewAndCopy(this->license, this->ownLicense, license, false);
}



void SpiffProps::lendIdentifier(const XML_Char * identifier) {
	Toolbox::deleteNewAndCopy(this->identifier, this->ownIdentifier, identifier, false);
}



void SpiffProps::lendAppendAttributionIdentifier(const XML_Char * identifier) {
	appendHelper(this->attributions, identifier, false, false);
}



void SpiffProps::lendAppendAttributionLocation(const XML_Char * location) {
	appendHelper(this->attributions, location, false, true);
}



void SpiffProps::lendDate(const SpiffDateTime * date) {
	SpiffProps::deleteNewAndCopy(this->date, this->ownDate, date, false);
}



XML_Char * SpiffProps::stealLocation() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->location));
}



XML_Char * SpiffProps::stealIdentifier() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->identifier));
}



XML_Char * SpiffProps::stealLicense() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->license));
}



pair<bool, XML_Char *> * SpiffProps::stealFirstAttribution() {
	return stealFirstHelper(this->attributions);
}



SpiffDateTime * SpiffProps::stealDate() {
	return const_cast<SpiffDateTime *>(Toolbox::getSetNull<SpiffDateTime>(this->date));
}



void SpiffProps::setVersion(int version) {
	this->version = version;
}



const XML_Char * SpiffProps::getLicense() {
	return this->license;
}



const XML_Char * SpiffProps::getLocation() {
	return this->location;
}



const XML_Char * SpiffProps::getIdentifier() {
	return this->identifier;
}



pair<bool, const XML_Char *> * SpiffProps::getAttribution(int index) {
	return getHelper(this->attributions, index);
}



const SpiffDateTime * SpiffProps::getDate() {
	return this->date;
}



int SpiffProps::getVersion() {
	return this->version;
}



int SpiffProps::getAttributionCount() {
	return (this->attributions == NULL) ? 0 : static_cast<int>(this->attributions->size());
}



/*static*/ void SpiffProps::appendHelper(
		std::deque<std::pair<bool,
		std::pair<const XML_Char *, bool> *> *> * & container,
		const XML_Char * value, bool ownership, bool isLocation) {
	if (container == NULL) {
		container = new deque<pair<bool, pair<const XML_Char *, bool> *> *>;
	}
	pair<const XML_Char *, bool> * const second = new pair<const XML_Char *, bool>(value, ownership);
	pair<bool, pair<const XML_Char *, bool> *> * const entry =
		new pair<bool, pair<const XML_Char *, bool> *>(isLocation, second);
	container->push_back(entry);
}



/*static*/ pair<bool, const XML_Char *> * SpiffProps::getHelper(
		std::deque<std::pair<bool,
		std::pair<const XML_Char *, bool> *> *> * & container,
		int index) {
	if ((container == NULL) || container->empty() || (index < 0)
			|| (index >= static_cast<int>(container->size()))) {
		return NULL;
	}
	pair<bool, pair<const XML_Char *, bool> *> * const entry = container->at(index);
	pair<bool, const XML_Char *> * const res = new pair<bool, const XML_Char *>(
		entry->first, entry->second->first);
	return res;
}



/*static*/ pair<bool, XML_Char *> * SpiffProps::stealFirstHelper(
		std::deque<std::pair<bool,
		std::pair<const XML_Char *, bool> *> *> * & container) {
	if ((container == NULL) || container->empty()) {
		return NULL;
	}
	pair<bool, pair<const XML_Char *, bool> *> * const entry =
			container->front();
	container->pop_front();
	pair<bool, XML_Char *> * const res = new pair<bool, XML_Char *>(
		entry->first, entry->second->second
		? const_cast<XML_Char *>(entry->second->first)
		: Toolbox::newAndCopy(entry->second->first));
	delete entry->second;
	delete entry;
	return res;
}



/*static*/ void SpiffProps::deleteNewAndCopy(const SpiffDateTime * & dest,
		bool & destOwnership, const SpiffDateTime * source, bool sourceCopy) {
	// Delete old memory if owner
	if (destOwnership && (dest != NULL)) {
		delete [] dest;
	}

	if (source == NULL) {
		dest = NULL;
		destOwnership = false;
	} else {
		// Copy new memory if desired
		if (sourceCopy) {
			SpiffDateTime * const dup = source->clone();
			dest = dup;
			destOwnership = true;
		} else {
			dest = source;
			destOwnership = false;
		}
	}
}



}
