/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffWriter.h
 * Interface of SpiffWriter.
 */

#ifndef SPIFF_WRITER_H
#define SPIFF_WRITER_H

#include "SpiffDefines.h"
#include <sstream>

namespace Spiff {



class SpiffXmlFormatter;
class SpiffTrackWriter;
class SpiffPropsWriter;


// TODO
enum SpiffWriterReturnCode {
	SPIFF_WRITER_SUCCESS,
	SPIFF_WRITER_ERROR
};



/**
 * Writes a playlist as XSPF to a file.
 * XSPF version 0 and 1 are supported.
 */
class SpiffWriter {

private:
	SpiffXmlFormatter * formatter; ///< Output formatter in use
	SpiffPropsWriter * propsWriter; ///< Related playlist properties
	std::basic_ostringstream<XML_Char> * accum; ///< Output text accumulator
	bool trackListEmpty; ///< Tracklist empty flag
	bool headerWritten; ///< <c>playlist</c> and <c>trackList</c> tag opened flag
	bool footerWritten; ///< <c>trackList</c> and <c>trackList</c> tag closed flag
	int version; ///< XSPF version to use

public:
	SpiffWriter(int version, SpiffXmlFormatter & formatter, SpiffPropsWriter & propsWriter);
	~SpiffWriter();

	void registerNamespace(const XML_Char * uri, const XML_Char * prefixSuggestion);

	void addTrack(SpiffTrackWriter & trackWriter);
	int write(const XML_Char * filename);
	void reset(int version, SpiffXmlFormatter & formatter, SpiffPropsWriter & propsWriter);


};



}


#endif // SPIFF_WRITER_H
