/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffProps.h
 * Interface of SpiffProps.
 */

#ifndef SPIFF_PROPS_H
#define SPIFF_PROPS_H



#include "SpiffData.h"
#include <deque>
#include <utility>

namespace Spiff {



/**
 * Represents a "dateTime" timestamp
 * without fractional second component.
 */
class SpiffDateTime {

public:
	int year;
	int month;
	int day;
	int hour;
	int minutes;
	int seconds;
	int distHours;
	int distMinutes;

	SpiffDateTime(int year, int month, int day, int hour, int minutes,
			int seconds, int distHours, int distMinutes)
			: year(year), month(month), day(day), hour(hour), minutes(minutes),
			seconds(seconds), distHours(distHours), distMinutes(distMinutes) {

	}

	SpiffDateTime() : year(0), month(0), day(0), hour(-1), minutes(-1), seconds(-1),
		distHours(0), distMinutes(0) {

	}

	SpiffDateTime * clone() const {
		return new SpiffDateTime(this->year, this->month, this->day,
				this->hour, this->minutes, this->seconds, this->distHours,
				this->distMinutes);
	}

};



/**
 * Represents the properties of playlist
 * without extensions. This includes all
 * information except the track list.
 */
class SpiffProps : public SpiffData {

private:
	const XML_Char * location; ///< Location URI
	const XML_Char * license; ///< License URI
	const XML_Char * identifier; ///< Identifier URI
	bool ownLocation; ///< Location memory ownership flag
	bool ownLicense; ///< License memory ownership flag
	bool ownIdentifier; ///< Identifier memory ownership flag
	std::deque<std::pair<bool, std::pair<const XML_Char *, bool> *> *> * attributions; ///< List of location and identifier URIs
	const SpiffDateTime * date; ///< Date
	bool ownDate; ///< Date memory ownership flag
	int version; ///< XSPF version

public:
	SpiffProps();
	~SpiffProps();

	void giveIdentifier(const XML_Char * identifier, bool copy);
	void giveLicense(const XML_Char * license, bool copy);
	void giveLocation(const XML_Char * location, bool copy);
	void giveAppendAttributionIdentifier(const XML_Char * identifier, bool copy);
	void giveAppendAttributionLocation(const XML_Char * location, bool copy);
	void giveDate(const SpiffDateTime * date, bool copy);
	void lendIdentifier(const XML_Char * identifier);
	void lendLicense(const XML_Char * license);
	void lendLocation(const XML_Char * location);
	void lendAppendAttributionIdentifier(const XML_Char * identifier);
	void lendAppendAttributionLocation(const XML_Char * location);
	void lendDate(const SpiffDateTime * date);
	void setVersion(int version);
	XML_Char * stealLicense();
	XML_Char * stealLocation();
	XML_Char * stealIdentifier();
	std::pair<bool, XML_Char *> * stealFirstAttribution();
	SpiffDateTime * stealDate();
	const XML_Char * getLicense();
	const XML_Char * getLocation();
	const XML_Char * getIdentifier();
	std::pair<bool, const XML_Char *> * getAttribution(int index);
	int getAttributionCount();
	const SpiffDateTime * getDate();
	int getVersion();

private:
	static void appendHelper(std::deque<std::pair<bool, std::pair<const XML_Char *, bool> *> *> * & container,
			const XML_Char * value, bool ownership, bool isLocation);
	static std::pair<bool, const XML_Char *> * getHelper(
			std::deque<std::pair<bool, std::pair<const XML_Char *, bool> *> *> * & container, int index);
	static std::pair<bool, XML_Char *> * stealFirstHelper(
			std::deque<std::pair<bool, std::pair<const XML_Char *, bool> *> *> * & container);
	static void deleteNewAndCopy(const SpiffDateTime * & dest, bool & destOwnership,
			const SpiffDateTime * source, bool sourceCopy);

};



}

#endif // SPIFF_PROPS_H
