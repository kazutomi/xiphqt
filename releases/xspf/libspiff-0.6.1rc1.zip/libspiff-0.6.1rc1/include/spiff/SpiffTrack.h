/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffTrack.h
 * Interface of SpiffTrack.
 */

#ifndef SPIFF_TRACK_H
#define SPIFF_TRACK_H



#include "SpiffData.h"
#include <deque>
#include <utility>

namespace Spiff {



/**
 * Represents an XSPF track without extensions.
 */
class SpiffTrack : public SpiffData {

private:
	const XML_Char * album; ///< Album
	bool ownAlbum; ///< Album memory ownership flag
	std::deque<std::pair<const XML_Char *, bool> *> * locations; ///< List of URI locations
	std::deque<std::pair<const XML_Char *, bool> *> * identifiers; ///< List of URI identifiers
	int trackNum; ///< Number of the track, must be positive
	int duration; ///< Duration in milliseconds, must be non-negative

public:
	SpiffTrack();
	~SpiffTrack();

	void giveAlbum(const XML_Char * album, bool copy);
	void giveAppendIdentifier(const XML_Char * identifier, bool copy);
	void giveAppendLocation(const XML_Char * location, bool copy);
	void lendAlbum(const XML_Char * album);
	void lendAppendLocation(const XML_Char * location);
	void lendAppendIdentifier(const XML_Char * identifier);
	void setTrackNum(int trackNum);
	void setDuration(int duration);
	XML_Char * stealAlbum();
	XML_Char * stealFirstIdentifier();
	XML_Char * stealFirstLocation();
	const XML_Char * getAlbum();
	const XML_Char * getIdentifier(int index);
	const XML_Char * getLocation(int index);
	int getIdentifierCount();
	int getLocationCount();
	int getDuration();
	int getTrackNum();

private:
	static void appendHelper(std::deque<std::pair<const XML_Char *, bool> *> * & container, const XML_Char * value, bool ownership);
	static XML_Char * stealFirstHelper(std::deque<std::pair<const XML_Char *, bool> *> * & container);
	static const XML_Char * getHelper(std::deque<std::pair<const XML_Char *, bool> *> * & container, int index);

};



}

#endif // SPIFF_TRACK_H
