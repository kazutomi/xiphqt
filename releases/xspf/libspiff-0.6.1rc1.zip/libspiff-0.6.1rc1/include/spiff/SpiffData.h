/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffData.h
 * Interface of SpiffData.
 */

#ifndef SPIFF_DATA_H
#define SPIFF_DATA_H

#include "SpiffDefines.h"
#include <deque>
#include <utility>

namespace Spiff {



class SpiffExtension;



/**
 * Provides shared functionality for SpiffTrack and SpiffProps.
 */
class SpiffData {

private:
	const XML_Char * image; ///< Image URI
	const XML_Char * info; ///< Info URI
	const XML_Char * annotation; ///< Annotation
	const XML_Char * creator; ///< Creator/artist
	const XML_Char * title; ///< Title
	bool ownImage; ///< Image memory ownership flag
	bool ownInfo; ///< Info memory ownership flag
	bool ownAnnotation; ///< Annotation memory ownership flag
	bool ownCreator; ///< Creator memory ownership flag
	bool ownTitle; ///< Title memory ownership flag
	std::deque<std::pair<std::pair<const XML_Char *, bool> *, std::pair<const XML_Char *, bool> *> *> * links; ///< List of link pairs
	std::deque<std::pair<std::pair<const XML_Char *, bool> *, std::pair<const XML_Char *, bool> *> *> * metas; ///< List of meta pairs
	std::deque<std::pair<const SpiffExtension *, bool> *> * extensions;

protected:
	SpiffData();
	virtual ~SpiffData();

public:
	void giveImage(const XML_Char * image, bool copy);
	void giveInfo(const XML_Char * info, bool copy);
	void giveAnnotation(const XML_Char * annotation, bool copy);
	void giveCreator(const XML_Char * creator, bool copy);
	void giveTitle(const XML_Char * title, bool copy);
	void giveAppendLink(const XML_Char * rel, bool copyRel, const XML_Char * content, bool copyContent);
	void giveAppendMeta(const XML_Char * rel, bool copyRel, const XML_Char * content, bool copyContent);
	void giveAppendExtension(const SpiffExtension * extension, bool copy);

	void lendImage(const XML_Char * image);
	void lendInfo(const XML_Char * info);
	void lendAnnotation(const XML_Char * annotation);
	void lendCreator(const XML_Char * creator);
	void lendTitle(const XML_Char * title);
	void lendAppendLink(const XML_Char * rel, const XML_Char * content);
	void lendAppendMeta(const XML_Char * rel, const XML_Char * content);
	void lendAppendExtension(SpiffExtension * extension);

	XML_Char * stealImage();
	XML_Char * stealInfo();
	XML_Char * stealAnnotation();
	XML_Char * stealCreator();
	XML_Char * stealTitle();
	std::pair<XML_Char *, XML_Char *> * stealFirstLink();
	std::pair<XML_Char *, XML_Char *> * stealFirstMeta();
	SpiffExtension * stealFirstExtension();

	const XML_Char * getImage();
	const XML_Char * getInfo();
	const XML_Char * getAnnotation();
	const XML_Char * getCreator();
	const XML_Char * getTitle();
	std::pair<const XML_Char *, const XML_Char *> * getLink(int index);
	std::pair<const XML_Char *, const XML_Char *> * getMeta(int index);
	const SpiffExtension * getExtension(int index);

	int getLinkCount();
	int getMetaCount();
	int getExtensionCount();

private:
	static void appendHelper(std::deque<std::pair<std::pair<const XML_Char *, bool> *, std::pair<const XML_Char *, bool> *> *> * & container,
			const XML_Char * rel, bool ownRel, const XML_Char * content, bool ownContent);
	static void appendHelper(std::deque<std::pair<const SpiffExtension *, bool> *> * & container,
			const SpiffExtension * extenstion, bool own);

	static std::pair<XML_Char *, XML_Char *> * stealFirstHelper(
			std::deque<std::pair<std::pair<const XML_Char *, bool> *, std::pair<const XML_Char *, bool> *> *> * & container);
	static SpiffExtension * stealFirstHelper(
		std::deque<std::pair<const SpiffExtension *, bool> *> * & container);

	static std::pair<const XML_Char *, const XML_Char *> * getHelper(
			std::deque<std::pair<std::pair<const XML_Char *, bool> *, std::pair<const XML_Char *, bool> *> *> * & container, int index);
	static const SpiffExtension * getHelper(
		std::deque<std::pair<const SpiffExtension *, bool> *> * & container, int index);

};



}

#endif // SPIFF_DATA_H
