/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffExtensionReaderFactory.h
 * Interface of SpiffExtensionReaderFactory.
 */

#ifndef SPIFF_EXTENSION_READER_FACTROY_H
#define SPIFF_EXTENSION_READER_FACTROY_H



#include "SpiffDefines.h"
#include "SpiffToolbox.h"
#include <map>

namespace Spiff {



class SpiffExtensionReader;
class SpiffReader;



class SpiffExtensionReaderFactory {

protected:
	std::map<const XML_Char *, const SpiffExtensionReader *, Toolbox::SpiffStringCompare> playlistExtensionReaders;
	std::map<const XML_Char *, const SpiffExtensionReader *, Toolbox::SpiffStringCompare> trackExtensionReaders;
	const SpiffExtensionReader * playlistCatchAllReader;
	const SpiffExtensionReader * trackCatchAllReader;

public:
	SpiffExtensionReaderFactory();
	~SpiffExtensionReaderFactory();

	void registerPlaylistExtensionReader(const SpiffExtensionReader * example,
			const XML_Char * triggerUri);
	void registerTrackExtensionReader(const SpiffExtensionReader * example,
			const XML_Char * triggerUri);
	void unregisterPlaylistExtensionReader(
			const XML_Char * triggerUri);
	void unregisterTrackExtensionReader(
			const XML_Char * triggerUri);
	SpiffExtensionReader * newPlaylistExtensionReader(
			const XML_Char * applicationUri, SpiffReader * reader);
	SpiffExtensionReader * newTrackExtensionReader(
			const XML_Char * applicationUri, SpiffReader * reader);

private:
	void registerReader(std::map<const XML_Char *,
			const SpiffExtensionReader *, Toolbox::SpiffStringCompare> & container,
			const SpiffExtensionReader * & catchAll,
			const SpiffExtensionReader * example,
			const XML_Char * triggerUri);
	void unregisterReader(std::map<const XML_Char *,
			const SpiffExtensionReader *, Toolbox::SpiffStringCompare> & container,
			const SpiffExtensionReader * & catchAll,
			const XML_Char * triggerUri);
	SpiffExtensionReader * newReader(std::map<const XML_Char *,
			const SpiffExtensionReader *, Toolbox::SpiffStringCompare> & container,
			const SpiffExtensionReader * catchAll,
			const XML_Char * applicationUri, SpiffReader * reader);
	void freeMap(std::map<const XML_Char *, const SpiffExtensionReader *,
			Toolbox::SpiffStringCompare> & container);

};



}

#endif // SPIFF_EXTENSION_READER_FACTROY_H
