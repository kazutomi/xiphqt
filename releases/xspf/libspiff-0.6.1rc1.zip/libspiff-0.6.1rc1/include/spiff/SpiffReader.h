/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffReader.h
 * Interface of SpiffReader.
 */

#ifndef SPIFF_READER_H
#define SPIFF_READER_H



#include "SpiffDefines.h"
#include <string>

namespace Spiff {



// Error messages with ONE "%s" in it
#define SPIFF_READER_TEXT_ONE_ATTRIBUTE_FORBIDDEN                      _PT("Attribute '%s' not allowed.")
#define SPIFF_READER_TEXT_ONE_EXPAT_ERROR                              _PT("Expat error '%s'")
#define SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN                        _PT("Element '%s' not allowed.")
#define SPIFF_READER_TEXT_ONE_ELEMENT_FORBIDDEN_VERSION_ZERO           _PT("Element '%s' not allowed in XSPF-0.")
#define SPIFF_READER_TEXT_ONE_FILE_READING_ERROR                       _PT("File '%s' could not be read.")
#define SPIFF_READER_TEXT_ONE_WRONG_ROOT_NAME                          _PT("Root element must be '") SPIFF_NS_HOME SPIFF_NS_SEP_STRING _PT("playlist', not '%s'.")
#define SPIFF_READER_TEXT_ONE_WRONG_VERSION                            _PT("Version must be '0' or '1', not '%s'.")

// Error messages with ZERO "%s" in it
#define SPIFF_READER_TEXT_ZERO_ATTRIBUTE_MISSING(name)                 _PT("Attribute '") name _PT("' missing.")
#define SPIFF_READER_TEXT_ZERO_ELEMENT_MISSING(ns, name)               _PT("Element '") ns SPIFF_NS_SEP_STRING name _PT("' missing.")
#define SPIFF_READER_TEXT_ZERO_ELEMENT_MISSING_VERSION_ZERO(ns, name)  _PT("Element '") ns SPIFF_NS_SEP_STRING name _PT("' missing. This is not allowed in XSPF-0.")
#define SPIFF_READER_TEXT_ZERO_FILENAME_NULL                           _PT("Filename must not be NULL.")
#define SPIFF_READER_TEXT_ZERO_TOO_MANY_ELEMENTS(ns, name)             _PT("Only one '") ns SPIFF_NS_SEP_STRING name _PT("' allowed.")
#define SPIFF_READER_TEXT_ZERO_WRONG_ATTRIBUTE_TYPE(attr, type)        _PT("Attribute '") attr _PT("' is not a valid ") type _PT(".")
#define SPIFF_READER_TEXT_ZERO_WRONG_CONTENT_TYPE(ns, elem, type)      _PT("Content of '") ns SPIFF_NS_SEP_STRING elem _PT("' is not a valid ") type _PT(".")



enum SpiffReaderReturnCode {
	SPIFF_READER_SUCCESS,

	SPIFF_READER_ERROR_NO_INPUT,

	SPIFF_READER_ERROR_ELEMENT_TOOMANY,
	SPIFF_READER_ERROR_ELEMENT_FORBIDDEN,
	SPIFF_READER_ERROR_ELEMENT_MISSING,

	SPIFF_READER_ERROR_ATTRIBUTE_INVALID,
	SPIFF_READER_ERROR_ATTRIBUTE_MISSING,
	SPIFF_READER_ERROR_ATTRIBUTE_FORBIDDEN,

	SPIFF_READER_ERROR_CONTENT_INVALID,

	SPIFF_READER_ERROR_EXPAT // This one must come last!
};



/*
playlist									1
	title							?
	creator							?
	annotation						?
	info							?
	location						?
	identifier						?
	image							?
	date							?
	license							?
	attribution						?
		location						*
		identifier						*
	link								*
	meta								*
	extension							*
		...								*
	trackList								1
		track							+|*
			location					*
			identifier					*
			title					?
			creator					?
			annotation				?
			info					?
			image					?
			album 					?
			trackNum (uint > 0)		?
			duration (uint)			?
			link						*
			meta						*
			extension					*
*/

enum SpiffTag {
	TAG_UNKNOWN, // Stack returns 0 if empty

	TAG_PLAYLIST,
	TAG_PLAYLIST_TITLE,
	TAG_PLAYLIST_CREATOR,
	TAG_PLAYLIST_ANNOTATION,
	TAG_PLAYLIST_INFO,
	TAG_PLAYLIST_LOCATION,
	TAG_PLAYLIST_IDENTIFIER,
	TAG_PLAYLIST_IMAGE,
	TAG_PLAYLIST_DATE,
	TAG_PLAYLIST_LICENSE,
	TAG_PLAYLIST_ATTRIBUTION,
	TAG_PLAYLIST_ATTRIBUTION_LOCATION,
	TAG_PLAYLIST_ATTRIBUTION_IDENTIFIER,
	TAG_PLAYLIST_LINK,
	TAG_PLAYLIST_META,
	TAG_PLAYLIST_EXTENSION,
	TAG_PLAYLIST_TRACKLIST,
	TAG_PLAYLIST_TRACKLIST_TRACK,
	TAG_PLAYLIST_TRACKLIST_TRACK_LOCATION,
	TAG_PLAYLIST_TRACKLIST_TRACK_IDENTIFIER,
	TAG_PLAYLIST_TRACKLIST_TRACK_TITLE,
	TAG_PLAYLIST_TRACKLIST_TRACK_CREATOR,
	TAG_PLAYLIST_TRACKLIST_TRACK_ANNOTATION,
	TAG_PLAYLIST_TRACKLIST_TRACK_INFO,
	TAG_PLAYLIST_TRACKLIST_TRACK_IMAGE,
	TAG_PLAYLIST_TRACKLIST_TRACK_ALBUM,
	TAG_PLAYLIST_TRACKLIST_TRACK_TRACKNUM,
	TAG_PLAYLIST_TRACKLIST_TRACK_DURATION,
	TAG_PLAYLIST_TRACKLIST_TRACK_LINK,
	TAG_PLAYLIST_TRACKLIST_TRACK_META,
	TAG_PLAYLIST_TRACKLIST_TRACK_EXTENSION,

	TAG_USER // New tags can start from this value
};



class SpiffProps;
class SpiffDateTime;
class SpiffTrack;
class SpiffReaderCallback;
class SpiffStack;

class SpiffExtensionReaderFactory;
class SpiffExtensionReader;



/**
 * Reads a XSPF playlist from a file.
 */
class SpiffReader {

protected:
	SpiffStack * stack; ///< Element stack
	SpiffProps * props; ///< Playlist properties slot
	SpiffTrack * track; ///< Track slot
	int version; ///< XSPF version

private:
	XML_Parser parser; ///< Expat parser handle
	SpiffReaderCallback * callback; ///< Reader callback
	std::basic_string<XML_Char> accum; ///< Element content accumulator
	std::basic_string<XML_Char> lastRelValue; ///< Value of the previous "rel" attribute

	SpiffExtensionReader * extensionReader;
	SpiffExtensionReaderFactory * extensionReaderFactory;

	int errorCode; ///< Error code
	int errorLine; ///< Number of the line that caused an error
	std::basic_string<XML_Char> errorText; ///< Detailed error info

	bool insideExtension; ///< Flag wether the parser is inside an extension element

	bool firstPlaylistAnnotation;
	bool firstPlaylistAttribution;
	bool firstPlaylistCreator;
	bool firstPlaylistDate;
	bool firstPlaylistIdentifier;
	bool firstPlaylistImage;
	bool firstPlaylistInfo;
	bool firstPlaylistLicense;
	bool firstPlaylistLocation;
	bool firstPlaylistTitle;
	bool firstPlaylistTrackList;

	bool firstTrackTitle;
	bool firstTrackCreator;
	bool firstTrackAnnotation;
	bool firstTrackInfo;
	bool firstTrackImage;
	bool firstTrackAlbum;
	bool firstTrackTrackNum;
	bool firstTrackDuration;

	bool firstTrack;

public:
	SpiffReader(SpiffExtensionReaderFactory * handlerFactory = NULL);
	~SpiffReader();

	int parse(const XML_Char * filename, SpiffReaderCallback * callback);
	const XML_Char * getErrorText();
	int getErrorLine();

protected:
	void makeReusable();

	void setError(int code, const XML_Char * text);
	void setError(int code, const XML_Char * format, const XML_Char * param);
	void stop();

private:
	void handleStart(const XML_Char * fullName, const XML_Char ** atts);
	bool handleStartOne(const XML_Char * fullName, const XML_Char ** atts);
	bool handleStartTwo(const XML_Char * fullName, const XML_Char ** atts);
	bool handleStartThree(const XML_Char * fullName, const XML_Char ** atts);
	bool handleStartFour(const XML_Char * fullName, const XML_Char ** atts);

	void handleCharacters(const XML_Char * s, int len);

	void handleEnd(const XML_Char * fullName);
	bool handleEndOne(const XML_Char * fullName);
	bool handleEndTwo(const XML_Char * fullName);
	bool handleEndThree(const XML_Char * fullName);
	bool handleEndFour(const XML_Char * fullName);

	bool handlePlaylistAttribs(const XML_Char ** atts);
	bool handleMetaLinkAttribs(const XML_Char ** atts);
	bool handleExtensionAttribs(const XML_Char ** atts, const XML_Char ** application);
	bool handleNoAttribs(const XML_Char ** atts);

	void clearError();

public:
	static bool isURI(const XML_Char * text);
	static bool extractInteger(const XML_Char * text, int inclusiveMinimum, int * output);
	static bool extractDateTime(const XML_Char * text, SpiffDateTime * output);

private:
	static void masterStart(void * userData, const XML_Char * fullName, const XML_Char ** atts);
	static void masterEnd(void * userData, const XML_Char * fullName);
	static void masterCharacters(void * userData, const XML_Char * s, int len);

	friend class SpiffExtensionReader;

};



}

#endif // SPIFF_READER_H
