/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffToolbox.cpp
 * Implementation of Spiff::Toolbox.
 */

#include <spiff/SpiffToolbox.h>

namespace Spiff {
namespace Toolbox {



/**
 * Duplicates the string (using new() not malloc())
 * and returns the duplicate.
 *
 * @param src	Source text
 * @return		Duplaicated text
 */
XML_Char * newAndCopy(const XML_Char * src) {
	XML_Char * dup = new XML_Char[static_cast<int>(PORT_STRLEN(src)) + 1];
	PORT_STRCPY(dup, src);
	return dup;
}



/**
 * Replaces the string in <c>*dest</c> by a duplicate of the string in <c>src</c>
 * (using new() not malloc()). The old string is deleted.
 *
 * @param dest	Destination text
 * @param src	Source text
 */
void deleteNewAndCopy(XML_Char ** dest, const XML_Char * src) {
	if (dest == NULL) {
		return;
	}

	if (*dest != NULL) {
		delete [] *dest;
	}

	if (src == NULL) {
		*dest = NULL;
	} else {
		const int srcLen = static_cast<int>(::PORT_STRLEN(src));
		if (srcLen > 0) {
			*dest = new XML_Char[static_cast<int>(srcLen) + 1];
			PORT_STRCPY(*dest, src);
		} else {
			*dest = NULL;
		}
	}
}



/**
 * Replaces the string in <c>dest</c> by a duplicate of the string in <c>src</c>
 * (using new() not malloc()). The old string is deleted. If <c>destOwnership</c>
 * is false the old string is not deleted. If <c>sourceCopy</c> is false only
 * <c>source</c>'s pointer is copied, not the string.
 *
 * @param dest			Destination text
 * @param destOwnership	Destination ownership flag
 * @param source		Source text
 * @param sourceCopy	Source copy flag
 */
void deleteNewAndCopy(const XML_Char * & dest, bool & destOwnership,
		const XML_Char * source, bool sourceCopy) {
	// Delete old memory if owner
	if (destOwnership && (dest != NULL)) {
		delete [] dest;
	}

	if (source == NULL) {
		dest = NULL;
		destOwnership = false;
	} else {
		// Copy new memory if desired
		if (sourceCopy) {
			const int sourceLen = static_cast<int>(::PORT_STRLEN(source));
			if (sourceLen > 0) {
				XML_Char * const tempDest = new XML_Char[static_cast<int>(sourceLen) + 1];
				PORT_STRCPY(tempDest, source);
				dest = tempDest;
				destOwnership = true;
			} else {
				dest = NULL;
				destOwnership = false;
			}
		} else {
			dest = source;
			destOwnership = false;
		}
	}
}



/**
 * Calls atoi() on a limited number of characters.
 *
 * @param text	Text
 * @param len	Number of characters to read
 * @return		Result of atoi()
 */
int PORT_ANTOI(const XML_Char * text, int len) {
	XML_Char * final = new XML_Char[len + 1];
	::PORT_STRNCPY(final, text, len);
	final[len] = _PT('\0');
	const int res = ::PORT_ATOI(final);
	delete [] final;
	return res;
}



}
}
