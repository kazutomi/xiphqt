/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffTrackWriter.cpp
 * Implementation of SpiffTrackWriter.
 */

#include <spiff/SpiffTrackWriter.h>
#include <spiff/SpiffTrack.h>
#include <spiff/SpiffXmlFormatter.h>
#include <spiff/SpiffExtension.h>
#include <spiff/SpiffExtensionWriter.h>
using namespace std;

namespace Spiff {



SpiffTrackWriter::SpiffTrackWriter() : output(NULL), track(NULL) {

}



SpiffTrackWriter::~SpiffTrackWriter() {

}



void SpiffTrackWriter::setTrack(SpiffTrack * track) {
	this->track = track;
}



/**
 * Initializes the writer.
 *
 * @param output	Output formatter
 * @param version	XSPF version
 */
void SpiffTrackWriter::init(SpiffXmlFormatter & output, int version) {
	this->output = &output;
	this->version = version;
}



/**
 * Writes the track.
 */
void SpiffTrackWriter::write() {
	writeTrackOpen();
	writeLocations();
	writeIdentifiers();
	writeTitle();
	writeCreator();
	writeAnnotation();
	writeInfo();
	writeImage();
	writeAlbum();
	writeTrackNum();
	writeDuration();
	writeLinks();
	writeMetas();
	if (this->version > 0) {
		writeExtensions();
	}
	writeTrackClose();
}



void SpiffTrackWriter::writePrimitive(const XML_Char * name, const XML_Char * body) {
	const XML_Char * atts[1] = {NULL};
	this->output->writeHomeStart(name, atts);
	this->output->writeBody(body);
	this->output->writeHomeEnd(name);
}



void SpiffTrackWriter::writePrimitive(const XML_Char * name, int body) {
	const XML_Char * atts[1] = {NULL};
	this->output->writeHomeStart(name, atts);
	this->output->writeBody(body);
	this->output->writeHomeEnd(name);
}



void SpiffTrackWriter::writeAlbum() {
	const XML_Char * const album = this->track->getAlbum();
	if (album != NULL) {
		writePrimitive(_PT("album"), album);
	}
}



void SpiffTrackWriter::writeImage() {
	const XML_Char * const image = this->track->getImage();
	if (image != NULL) {
		writePrimitive(_PT("image"), image);
	}
}



void SpiffTrackWriter::writeInfo() {
	const XML_Char * const info = this->track->getInfo();
	if (info != NULL) {
		writePrimitive(_PT("info"), info);
	}
}



void SpiffTrackWriter::writeAnnotation() {
	const XML_Char * const annotation = this->track->getAnnotation();
	if (annotation != NULL) {
		writePrimitive(_PT("annotation"), annotation);
	}
}



void SpiffTrackWriter::writeCreator() {
	const XML_Char * const creator = this->track->getCreator();
	if (creator != NULL) {
		writePrimitive(_PT("creator"), creator);
	}
}



void SpiffTrackWriter::writeTitle() {
	const XML_Char * const title = this->track->getTitle();
	if (title != NULL) {
		writePrimitive(_PT("title"), title);
	}
}



void SpiffTrackWriter::writeDuration() {
	const int duration = this->track->getDuration();
	if (duration != -1) {
		writePrimitive(_PT("duration"), duration);
	}
}



void SpiffTrackWriter::writeTrackNum() {
	const int trackNum = this->track->getTrackNum();
	if (trackNum != -1) {
		writePrimitive(_PT("trackNum"), trackNum);
	}
}



void SpiffTrackWriter::writeExtensions() {
	int index = 0;
	const SpiffExtension * entry;
	for (;;) {
		entry = this->track->getExtension(index++);
		if (entry == NULL) {
			return;
		}

		SpiffExtensionWriter * const writer
				= entry->newWriter(this->output);
		if (writer != NULL) {
			writer->write();
			delete writer;
		}
	}
}



void SpiffTrackWriter::writeMetas() {
	int index = 0;
	const pair<const XML_Char *, const XML_Char *> * entry;
	for (;;) {
		entry = this->track->getMeta(index++);
		if (entry == NULL) {
			return;
		}

		const XML_Char * atts[3] = {_PT("rel"), entry->first, NULL};
		this->output->writeHomeStart(_PT("meta"), atts);
		this->output->writeBody(entry->second);
		this->output->writeHomeEnd(_PT("meta"));

		delete entry; // since the pair was created for us
	}
}



void SpiffTrackWriter::writeLinks() {
	int index = 0;
	const pair<const XML_Char *, const XML_Char *> * entry;
	for (;;) {
		entry = this->track->getLink(index++);
		if (entry == NULL) {
			return;
		}

		const XML_Char * atts[3] = {_PT("rel"), entry->first, NULL};
		this->output->writeHomeStart(_PT("link"), atts);
		this->output->writeBody(entry->second);
		this->output->writeHomeEnd(_PT("link"));

		delete entry; // since the pair was created for us
	}
}



void SpiffTrackWriter::writeLocations() {
	int index = 0;
	const XML_Char * location;
	for (;;) {
		location = this->track->getLocation(index++);
		if (location == NULL) {
			return;
		}

		writePrimitive(_PT("location"), location);
	}
}



void SpiffTrackWriter::writeIdentifiers() {
	int index = 0;
	const XML_Char * identifier;
	for (;;) {
		identifier = this->track->getIdentifier(index++);
		if (identifier == NULL) {
			return;
		}

		writePrimitive(_PT("identifier"), identifier);
	}
}



void SpiffTrackWriter::writeTrackClose() {
	this->output->writeHomeEnd(_PT("track"));
}



void SpiffTrackWriter::writeTrackOpen() {
	const XML_Char * atts[1] = {NULL};
	this->output->writeHomeStart(_PT("track"), atts);
}



}
