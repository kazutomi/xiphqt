/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffXmlFormatter.cpp
 * Implementation of SpiffXmlFormatter.
 */

#include <spiff/SpiffXmlFormatter.h>
#include <spiff/SpiffToolbox.h>
#include <sstream>
using namespace std;
using namespace Spiff::Toolbox;

namespace Spiff {



/*static*/ const XML_Char * const SpiffXmlFormatter::namespaceKey
		= SPIFF_NS_HOME;



/**
 * Creates a new formatter.
 */
SpiffXmlFormatter::SpiffXmlFormatter() : level(0), namespaceToPrefix(),
		undo(), prefixPool(), introDone(false), output(NULL) {

}



/**
 * Does nothing. Without this virtual destrcutor the destructor
 * of a derived class would not be called.
 */
SpiffXmlFormatter::~SpiffXmlFormatter() {

}

const XML_Char * SpiffXmlFormatter::getPrefix(const XML_Char * nsUri) const {
	map<const XML_Char *, XML_Char *, SpiffStringCompare>
			::const_iterator found = this->namespaceToPrefix.find(nsUri);
	if (found != this->namespaceToPrefix.end()) {
		return found->second;
	} else {
		return NULL;
	}
}

XML_Char * SpiffXmlFormatter::makeFullName(const XML_Char * nsUri,
		const XML_Char * localName) const {
	const XML_Char * const prefix = getPrefix(nsUri);
	if (prefix != NULL) {
		const int prefixLen = static_cast<int>(::PORT_STRLEN(prefix));
		const int localNameLen = static_cast<int>(::PORT_STRLEN(localName));
		XML_Char * fullName = NULL;
		if (prefixLen == 0) {
			// Default namespace
			fullName = new XML_Char[localNameLen + 1];
			::PORT_STRCPY(fullName, localName);
		} else {
			// Namespace with prefix
			fullName = new XML_Char[prefixLen + 1 + localNameLen + 1];
			::PORT_STRCPY(fullName, prefix);
			::PORT_STRCPY(fullName + prefixLen, _PT(":"));
			::PORT_STRCPY(fullName + prefixLen + 1, localName);
		}
		return fullName;
	} else {
		// TODO What exactly do we do with unregistered
		// namespace URIs? Register a new prefix and use it?
		return newAndCopy(localName);
	}
}

bool SpiffXmlFormatter::registerNamespace(const XML_Char * uri, const XML_Char * prefix) {
	// Uri registered already?
	map<const XML_Char *, XML_Char *, SpiffStringCompare>
			::iterator found = this->namespaceToPrefix.find(uri);
	if (found != this->namespaceToPrefix.end()) {
		return false; // == Existing
	}

	// Find unbound prefix (appending "x" if occupied)
	XML_Char * testPrefix = newAndCopy(prefix);
	while (this->prefixPool.find(testPrefix) != this->prefixPool.end()) {
		const int testPrefixLen = static_cast<int>(::PORT_STRLEN(testPrefix));
        XML_Char * nextPrefix = new XML_Char[testPrefixLen + 1 + 1];
		::PORT_SPRINTF(nextPrefix, _PT("%sx"), testPrefix);
		delete [] testPrefix;
		testPrefix = nextPrefix;
	}

	// Add prefix to map and pool
	this->namespaceToPrefix.insert(pair<const XML_Char *,
			XML_Char *>(uri, testPrefix));
	this->prefixPool.insert(testPrefix);

	// Create undo entry
	SpiffNamespaceRegistrationUndo * undo
				= new SpiffNamespaceRegistrationUndo(this->level, uri);
	this->undo.push_front(undo);

	return true; // == Added
}

void SpiffXmlFormatter::cleanupNamespaceRegs() {
	list<SpiffNamespaceRegistrationUndo *>::iterator iter = this->undo.begin();
	while (iter != this->undo.end()) {
		SpiffNamespaceRegistrationUndo * const entry = *iter;
		if (entry->level >= this->level) {
			map<const XML_Char *, XML_Char *, SpiffStringCompare>
				::iterator foundUri = this->namespaceToPrefix.find(entry->uri);
			if (foundUri != this->namespaceToPrefix.end()) {
				XML_Char * & prefix = foundUri->second;

				// Remove prefix
				set<const XML_Char *, SpiffStringCompare>::iterator foundPrefix
						= this->prefixPool.find(prefix);
				if (foundPrefix != this->prefixPool.end()) {
					this->prefixPool.erase(foundPrefix);
				}
				delete [] prefix;

				// Remove URI
				this->namespaceToPrefix.erase(foundUri);
			}
			this->undo.erase(iter);
		} else {
			break;
		}
		iter = this->undo.begin();
	}
}



/**
 * Associate the formatter with an output accumulator.
 *
 * @param output	Output accumulator
 */
void SpiffXmlFormatter::setOutput(basic_ostringstream<XML_Char> & output) {
	this->output = &output;
}

void SpiffXmlFormatter::writeStart(const XML_Char * ns,
		const XML_Char * localName, const XML_Char ** atts,
		const XML_Char ** nsRegs) {
	if (nsRegs != NULL) {
		list<pair<const XML_Char *, const XML_Char *> > attribs;

		// Process namespace registrations
		const XML_Char ** nsRegsWalk = nsRegs;
		while (nsRegsWalk[0] != NULL) {
			const XML_Char * & uri = nsRegsWalk[0];
			const XML_Char * & prefix = nsRegsWalk[1];

			// New namespace?
			if (registerNamespace(uri, prefix)) {
				const XML_Char * const finalPrefix = getPrefix(uri);

				XML_Char * finalKey = NULL;
				if (::PORT_STRLEN(finalPrefix) == 0) {
					// Default namespace
					finalKey = new XML_Char[5 + 1];
					::PORT_STRCPY(finalKey, _PT("xmlns"));
				} else {
					// Namespace with prefix
					const int finalPrefixLen = static_cast<int>(::PORT_STRLEN(finalPrefix));
					finalKey = new XML_Char[5 + 1 + finalPrefixLen + 1];
					::PORT_STRCPY(finalKey, _PT("xmlns:"));
					::PORT_STRCPY(finalKey + 6, finalPrefix);
				}

				attribs.push_back(pair<const XML_Char *, const XML_Char *>(finalKey, uri));
			}

			nsRegsWalk += 2;
		}

		// Append normal attributes
		const XML_Char ** attsWalk = atts;
		while (attsWalk[0] != NULL) {
			// TODO Copying the first is a lazy hack. Improve.
			attribs.push_back(pair<const XML_Char *, const XML_Char *>(
					newAndCopy(attsWalk[0]), attsWalk[1]));
			attsWalk += 2;
		}

		// Convert
		const int attribCount = static_cast<int>(attribs.size());
		const XML_Char ** finalAtts = new const XML_Char *[2 * attribCount + 1];
		list<pair<const XML_Char *, const XML_Char *> >::iterator iter = attribs.begin();
		const XML_Char ** finalAttsWalk = finalAtts;
		while (iter != attribs.end()) {
			finalAttsWalk[0] = (*iter).first;
			finalAttsWalk[1] = (*iter).second;
			finalAttsWalk += 2;
			iter++;
		}
		finalAttsWalk[0] = NULL;

		// Write tag
		const XML_Char * fullName = makeFullName(ns, localName);
		writeStart(fullName, finalAtts);

		// Full cleanup
		delete [] fullName;
		finalAttsWalk = finalAtts;
		while (finalAttsWalk[0] != NULL) {
			delete [] finalAttsWalk[0];
			finalAttsWalk += 2;
			iter++;
		}
		delete [] finalAtts;
	} else {
		// No registrations
		const XML_Char * fullName = makeFullName(ns, localName);
		writeStart(fullName, atts);
		delete [] fullName;
	}

	this->level++;
}

void SpiffXmlFormatter::writeEnd(const XML_Char * ns,
		const XML_Char * localName) {
	const XML_Char * fullName = makeFullName(ns, localName);
	writeEnd(fullName);
	delete [] fullName;

	cleanupNamespaceRegs();

	this->level--;
}

void SpiffXmlFormatter::writeHomeStart(const XML_Char * localName,
		const XML_Char ** atts, const XML_Char ** nsRegs) {
	writeStart(SpiffXmlFormatter::namespaceKey,
			localName, atts, nsRegs);
}

void SpiffXmlFormatter::writeHomeEnd(const XML_Char * localName) {
	writeEnd(SpiffXmlFormatter::namespaceKey,
			localName);
}



/**
 * Writes well-formed character data to the output accumulator.
 *
 * @param data	Character data
 */
void SpiffXmlFormatter::writeCharacterData(const XML_Char * data) {
	// Extensible Markup Language (XML) 1.0 (Fourth Edition)
	// 2.4 Character Data and Markup
	// http://www.w3.org/TR/REC-xml/#syntax
	const XML_Char * start = data;
	const XML_Char * end = data;

	for (;;) {
		switch (*end) {
		case _PT('\0'):
			this->output->write(start, static_cast<streamsize>(end - start));
			return;

		case _PT('<'):
			this->output->write(start, static_cast<streamsize>(end - start));
			*this->output << _PT("&lt;");
			end++;
			start = end;
			break;

		case _PT('&'):
			this->output->write(start, static_cast<streamsize>(end - start));
			*this->output << _PT("&amp;");
			end++;
			start = end;
			break;

		case _PT('\''):
			this->output->write(start, static_cast<streamsize>(end - start));
			*this->output << _PT("&apos;");
			end++;
			start = end;
			break;

		case _PT('"'):
			this->output->write(start, static_cast<streamsize>(end - start));
			*this->output << _PT("&quot;");
			end++;
			start = end;
			break;

		case _PT(']'):
			if ((*(end + 1) == _PT(']')) && (*(end + 2) == _PT('>'))) {
				this->output->write(start, static_cast<streamsize>(end - start));
				*this->output << _PT("]]&gt;");
				end += 3;
				start = end;
			} else {
				end++;
			}
			break;

		default:
			end++;
			break;

		}
	}
}



}
