/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2006 Sebastian Pipping
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Sebastian Pipping, webmaster@hartwork.org
 */

#include "ReadWriteSuite.h"
#include <spiff/SpiffProps.h>
#include <spiff/SpiffIndentFormatter.h>
#include <spiff/SpiffPropsWriter.h>
#include <spiff/SpiffReader.h>
#include <spiff/SpiffReaderCallback.h>
#include <spiff/SpiffWriter.h>
using namespace Spiff;



ReadWriteSuite::ReadWriteSuite() {
	TEST_ADD(ReadWriteSuite::testProps);
}



class PropsGrabberCallback : public SpiffReaderCallback {

private:
	SpiffProps * m_props;

	void setProps(SpiffProps * props) {
		delete m_props;
		m_props = props;
	}

public:
	PropsGrabberCallback() : m_props(NULL) {

	}

	~PropsGrabberCallback() {
		delete m_props;
		m_props = NULL;
	}

	SpiffProps * get() const {
		return m_props;
	}
};



void ReadWriteSuite::testProps() {
	SpiffProps props;
///////////////////////////////////////////////////////////////////////////////
	const XML_Char * const expectedXmlBase = _PT("http://example.org/one/two");
	props.lendXmlBase(expectedXmlBase);
///////////////////////////////////////////////////////////////////////////////

	// Write to memory
	SpiffPropsWriter propsWriter(&props);
	SpiffIndentFormatter layout;
	SpiffWriter writer(1, layout, propsWriter);
	char * output = new char[5000];
	int numBytes = 5000;
	const int writeRes = writer.writeMemory(output, numBytes);
	TEST_ASSERT(writeRes == 0);
	TEST_ASSERT(numBytes > 0);
	TEST_ASSERT(output[0] != '\0');

	// Read back from memory
	SpiffReader reader;
	PropsGrabberCallback propsGrabber;
	const int readRes = reader.parseMemory(output, numBytes, &propsGrabber);
	TEST_ASSERT(readRes == 0);

	// Compare
	const SpiffProps * const afterProps = propsGrabber.get();
	TEST_ASSERT(afterProps != NULL);
///////////////////////////////////////////////////////////////////////////////
	TEST_ASSERT(!::PORT_STRCMP(afterProps->getXmlBase(), expectedXmlBase));
///////////////////////////////////////////////////////////////////////////////

	delete [] output;
}
