/*
 * spiff_c - Simple C interface for libSpiff
 *
 * Copyright (C) 2007, Ed Schouten / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Ed Schouten <ed@fxq.nl>
 */
/**
 * @file spiff_c.cpp
 * @brief Simple libSpiff C bindings.
 */

#include <spiff/SpiffProps.h>
#include <spiff/SpiffReader.h>
#include <spiff/SpiffReaderCallback.h>
#include <spiff/SpiffTrack.h>

extern "C" {
#include "spiff_c.h"
}

using namespace Spiff;

/**
 * @brief Spiff list reading callback, which stores data in a specific
 *        C-style Spiff list.
 */
class SpiffCReaderCallback : public SpiffReaderCallback {
private:
	/**
	 * @brief The C-style Spiff list the tracks should be appended
	 *        to.
	 */
	spiff_list *list;
	/**
	 * @brief Pointer to the `next' field in the last inserted item
	 *        for improving append speed.
	 */
	spiff_track **newtrack;

	void addTrack(SpiffTrack *track);
	void setProps(SpiffProps *props);
public:
	SpiffCReaderCallback(spiff_list *list);
	virtual ~SpiffCReaderCallback();
};

SpiffCReaderCallback::SpiffCReaderCallback(spiff_list *list)
{
	this->list = list;
	newtrack = &list->tracks;
}

SpiffCReaderCallback::~SpiffCReaderCallback()
{
	/* Null-terminate the tracks list */
	*newtrack = NULL;
}

void
SpiffCReaderCallback::addTrack(SpiffTrack *track)
{
	spiff_mvalue **newmv;
	char *str;

	/* Append new item to the track list */
	*newtrack = new spiff_track;

	(*newtrack)->title = track->stealTitle();
	(*newtrack)->album = track->stealAlbum();
	(*newtrack)->duration = track->getDuration();
	(*newtrack)->tracknum = track->getTrackNum();

	/* Locations */
	newmv = &(*newtrack)->locations;
	while ((str = track->stealFirstLocation()) != NULL) {
		*newmv = new spiff_mvalue;
		(*newmv)->value = str;

		/* On to the next location */
		newmv = &(*newmv)->next;
	}
	*newmv = NULL;

	/* Identifiers */
	newmv = &(*newtrack)->identifiers;
	while ((str = track->stealFirstIdentifier()) != NULL) {
		*newmv = new spiff_mvalue;
		(*newmv)->value = str;

		/* On to the next location */
		newmv = &(*newmv)->next;
	}
	*newmv = NULL;

	/* Clean up and move to the next track */
	delete track;
	newtrack = &(*newtrack)->next;
}

void
SpiffCReaderCallback::setProps(SpiffProps *props)
{
	list->license = props->stealLicense();
	list->location = props->stealLocation();
	list->identifier = props->stealIdentifier();

	delete props;
}

static void
spiff_mvalue_free(struct spiff_mvalue *mv)
{
	struct spiff_mvalue *nmv;

	for (; mv != NULL; mv = nmv) {
		/* Back-up pointer */
		nmv = mv->next;
		delete mv->value;
		delete mv;
	}
}

/*
 * Public C interface
 */

extern "C" struct spiff_list *
spiff_parse(const char *filename)
{
	SpiffReader read;
	spiff_list *ret;

	/* Allocate empty playlist */
	ret = new spiff_list;

	/* Fill the list with parser results */
	SpiffCReaderCallback readcb(ret);
	if (read.parse(filename, &readcb) == SPIFF_READER_SUCCESS) {
		/* Success */
		return (ret);
	} else {
		/* Malformed/non-existent list */
		delete ret;
		return (NULL);
	}
}

extern "C" void
spiff_free(struct spiff_list *list)
{
	spiff_track *tr, *ntr;

	delete list->license;
	delete list->location;
	delete list->identifier;

	for (tr = list->tracks; tr != NULL; tr = ntr) {
		/* Back-up pointer */
		ntr = tr->next;

		delete tr->title;
		delete tr->album;

		spiff_mvalue_free(tr->locations);
		spiff_mvalue_free(tr->identifiers);

		delete tr;
	}

	delete list;
}
