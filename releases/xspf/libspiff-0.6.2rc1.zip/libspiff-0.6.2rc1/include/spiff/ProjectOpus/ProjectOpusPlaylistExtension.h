/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file ProjectOpusPlaylistExtension.h
 * Interface of ProjectOpusPlaylistExtension.
 */

#ifndef SPIFF_PROJECT_OPUS_PLAYLIST_EXTENSION_H
#define SPIFF_PROJECT_OPUS_PLAYLIST_EXTENSION_H 1



#include "../SpiffExtension.h"

namespace Spiff {
namespace ProjectOpus {



#define PROJECT_OPUS_NS_HOME      _PT("http://www.projectopus.com")
#define PROJECT_OPUS_NS_HOME_LEN  26



/**
 * Specifies a playlist type.
 */
enum ProjectOpusPlaylistType {
	TYPE_PLAYLIST, ///< Playlist is a regular playlist
	TYPE_ALBUM ///< Playlist is an album
};



/**
 * Represents a Project Opus playlist extension.
 */
class ProjectOpusPlaylistExtension : public SpiffExtension {

private:
	ProjectOpusPlaylistType type; ///< Playlist type
	unsigned int nodeId; ///< Node ID

public:
	/**
	 * Creates a new Project Opus playlist extension.
	 */
	ProjectOpusPlaylistExtension();

	/**
	 * Destroys this extension.
	 */
	~ProjectOpusPlaylistExtension();

	/**
	 * Returns the type of the playlist.
	 *
	 * @return	Playlist type
	 */
	ProjectOpusPlaylistType getType() const { return this->type; }

	/**
	 * Returns the node ID.
	 *
	 * @return	Node ID
	 */
	unsigned int getNodeId() const { return this->nodeId; }

	/**
	 * Sets the playlist type.
	 *
	 * @param type	Playlist type to set
	 */
	void setType(ProjectOpusPlaylistType type) { this->type = type; }

	/**
	 * Sets the playlist type.
	 *
	 * @param nodeId	Playlist type to set
	 */
	void setNodeId(unsigned int nodeId) { this->nodeId = nodeId; }

	SpiffExtension * clone() const;

private:
	SpiffExtensionWriter * newWriter(SpiffXmlFormatter * output) const;

public:
	/**
	 * Returns a string representation of the given playlist type.
	 *
	 * @param type	Playlist type
	 * @return		Corresponding string
	 */
	static const XML_Char * typeToString(ProjectOpusPlaylistType type);

	/**
	 * Converts the given node ID to a string.
	 *
	 * @param nodeId	Node ID
	 * @return			Node ID string, delete on your own
	 */
	static XML_Char * nodeIdToString(unsigned int nodeId);

	static const XML_Char * const namespaceKey; ///< Namespace key pointer

};



}
}

#endif // SPIFF_PROJECT_OPUS_PLAYLIST_EXTENSION_H
