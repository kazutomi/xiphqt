/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, sping@xiph.org
 */

/**
 * @file SpiffIndentFormatter.h
 * Interface of SpiffIndentFormatter.
 */

#ifndef SPIFF_INDENT_FORMATTER_H
#define SPIFF_INDENT_FORMATTER_H



#include "SpiffXmlFormatter.h"

namespace Spiff {



class SpiffStack;
class SpiffIndentFormatterPrivate;



/**
 * Outputs XML with proper indentation and newlines.
 * The finishing newline is optional.
 */
class SpiffIndentFormatter : public SpiffXmlFormatter {

private:
	/// @cond DOXYGEN_NON_API
	SpiffIndentFormatterPrivate * const d; ///< D pointer
	/// @endcond

public:
	/**
	 * Creates a new SpiffIndentFormatter object with default indent shift.
	 *
	 * @deprecated				Will be removed with 0.8.x, use SpiffIndentFormatter(int) instead
	 * @param newlineFinish		When true a newline will be appended to the end of the file which is strongly recommended
	 */
	SpiffIndentFormatter(bool newlineFinish);

	/**
	 * Creates a new SpiffIndentFormatter object with custom indent shift.
	 *
	 * @param shift		Non-positive indent shift (-2 will create two tabs less)
	 */
	SpiffIndentFormatter(int shift = 0);

	/**
	 * Copy constructor.
	 *
	 * @param source  Source to copy from
	 */
	SpiffIndentFormatter(const SpiffIndentFormatter & source);

	/**
	 * Assignment operator.
	 *
	 * @param source  Source to copy from
	 */
	SpiffIndentFormatter & operator=(const SpiffIndentFormatter & source);

	/**
	 * Destroys this SpiffIndentFormatter object and deletes all
	 * memory associated with it.
	 */
	~SpiffIndentFormatter();

private:
	void writeStart(const XML_Char * name, const XML_Char ** atts);
	void writeEnd(const XML_Char * name);
	void writeBody(const XML_Char * text);
	void writeBody(int number);

};



}

#endif // SPIFF_INDENT_FORMATTER_H
