/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffTrack.cpp
 * Implementation of SpiffTrack.
 */

#include <spiff/SpiffTrack.h>
#include <spiff/SpiffToolbox.h>
#include <string.h>
using namespace std;

namespace Spiff {



SpiffTrack::SpiffTrack() : album(NULL), ownAlbum(false), locations(NULL),
		identifiers(NULL), trackNum(-1), duration(-1) {

}



SpiffTrack::~SpiffTrack() {
	if (this->ownAlbum && (this->album != NULL)) {
		delete [] this->album;
	}
	if (this->locations != NULL) {
		deque<pair<const XML_Char *, bool> *>::const_iterator iter = this->locations->begin();
		while (iter != this->locations->end()) {
			pair<const XML_Char *, bool> * const entry = *iter;
			if (entry->second) {
				delete [] entry->first;
			}
			delete entry;
			iter++;
		}
		delete this->locations;
	}
	if (this->identifiers != NULL) {
		deque<pair<const XML_Char *, bool> *>::const_iterator iter = this->identifiers->begin();
		while (iter != this->identifiers->end()) {
			pair<const XML_Char *, bool> * const entry = *iter;
			if (entry->second) {
				delete [] entry->first;
			}
			delete entry;
			iter++;
		}
		delete this->identifiers;
	}
}



void SpiffTrack::giveAlbum(const XML_Char * album, bool copy) {
	Toolbox::deleteNewAndCopy(this->album, this->ownAlbum, album, copy);
}



void SpiffTrack::lendAlbum(const XML_Char * album) {
	Toolbox::deleteNewAndCopy(this->album, this->ownAlbum, album, false);
}



void SpiffTrack::setTrackNum(int trackNum) {
	this->trackNum = trackNum;
}



void SpiffTrack::setDuration(int duration) {
	this->duration = duration;
}



int SpiffTrack::getTrackNum() {
	return this->trackNum;
}



int SpiffTrack::getDuration() {
	return this->duration;
}



XML_Char * SpiffTrack::stealAlbum() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->album));
}



const XML_Char * SpiffTrack::getAlbum() {
	return this->album;
}



void SpiffTrack::giveAppendIdentifier(const XML_Char * identifier, bool copy) {
	appendHelper(this->identifiers, copy
			? Toolbox::newAndCopy(identifier)
			: identifier,
			true);
}



void SpiffTrack::giveAppendLocation(const XML_Char * location, bool copy) {
	appendHelper(this->locations, copy
			? Toolbox::newAndCopy(location)
			: location,
			true);
}



void SpiffTrack::lendAppendIdentifier(const XML_Char * identifier) {
	appendHelper(this->identifiers, identifier, false);
}



void SpiffTrack::lendAppendLocation(const XML_Char * location) {
	appendHelper(this->locations, location, false);
}



XML_Char * SpiffTrack::stealFirstIdentifier() {
	return stealFirstHelper(this->identifiers);
}



XML_Char * SpiffTrack::stealFirstLocation() {
	return stealFirstHelper(this->locations);
}



const XML_Char * SpiffTrack::getIdentifier(int index) {
	return getHelper(this->identifiers, index);
}



const XML_Char * SpiffTrack::getLocation(int index) {
	return getHelper(this->locations, index);
}



int SpiffTrack::getIdentifierCount() {
	return (this->identifiers == NULL) ? 0 : static_cast<int>(this->identifiers->size());
}



int SpiffTrack::getLocationCount() {
	return (this->locations == NULL) ? 0 : static_cast<int>(this->locations->size());
}



/*static*/ void SpiffTrack::appendHelper(
		std::deque<std::pair<const XML_Char *, bool> *> * & container,
		const XML_Char * value, bool ownership) {
	if (container == NULL) {
		container = new deque<pair<const XML_Char *, bool> *>;
	}
	pair<const XML_Char *, bool> * const entry =
			new pair<const XML_Char *, bool>(value, ownership);
	container->push_back(entry);
}



/*static*/ XML_Char * SpiffTrack::stealFirstHelper(
		std::deque<std::pair<const XML_Char *, bool> *> * & container) {
	if ((container == NULL) || container->empty()) {
		return NULL;
	}
	pair<const XML_Char *, bool> * const entry = container->front();
	container->pop_front();
	XML_Char * const res = entry->second ? const_cast<XML_Char *>(entry->first)
			: Toolbox::newAndCopy(entry->first);
	delete entry;
	return res;
}



/*static*/ const XML_Char * SpiffTrack::getHelper(
		std::deque<std::pair<const XML_Char *, bool> *> * & container,
		int index) {
	if ((container == NULL) || container->empty() || (index < 0)
			|| (index >= static_cast<int>(container->size()))) {
		return NULL;
	}
	pair<const XML_Char *, bool> * const entry = container->at(index);
	if (entry->second) {
		return entry->first;
	} else {
		return Toolbox::newAndCopy(entry->first);
	}
}



}
