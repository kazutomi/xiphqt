#!/bin/bash
aclocal && automake && autoconf && ./configure && make
