/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffData.cpp
 * Implementation of SpiffData.
 */

#include <spiff/SpiffData.h>
#include <spiff/SpiffToolbox.h>
#include <spiff/SpiffExtension.h>
using namespace Spiff::Toolbox;
using namespace std;

namespace Spiff {



SpiffData::SpiffData() : image(NULL), info(NULL), annotation(NULL),
		creator(NULL), title(NULL), ownImage(false), ownInfo(false),
		ownAnnotation(false), ownCreator(false), ownTitle(false),
		links(NULL), metas(NULL), extensions(NULL) {

}



SpiffData::~SpiffData() {
	if (this->ownTitle && (this->title != NULL)) {
		delete [] this->title;
	}
	if (this->ownCreator && (this->creator != NULL)) {
		delete [] this->creator;
	}
	if (this->ownAnnotation && (this->annotation != NULL)) {
		delete [] this->annotation;
	}
	if (this->ownImage && (this->image != NULL)) {
		delete [] this->image;
	}
	if (this->ownInfo && (this->info != NULL)) {
		delete [] this->info;
	}
	if (this->links != NULL) {
		deque<pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> *>::const_iterator iter = this->links->begin();
		while (iter != this->links->end()) {
			pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> * const entry = *iter;
			if (entry->first->second) {
				delete [] entry->first->first;
			}
			delete entry->first;
			if (entry->second->second) {
				delete [] entry->second->first;
			}
			delete entry->second;
			delete entry;
			iter++;
		}
		delete this->links;
	}
	if (this->metas != NULL) {
		deque<pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> *>::const_iterator iter = this->metas->begin();
		while (iter != this->metas->end()) {
			pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> * const entry = *iter;
			if (entry->first->second) {
				delete [] entry->first->first;
			}
			delete entry->first;
			if (entry->second->second) {
				delete [] entry->second->first;
			}
			delete entry->second;
			delete entry;
			iter++;
		}
		delete this->metas;
	}
	if (this->extensions != NULL) {
		deque<pair<const SpiffExtension *, bool> *>::const_iterator
				iter = this->extensions->begin();
		while (iter != this->extensions->end()) {
			pair<const SpiffExtension *, bool> * const entry = *iter;
			if (entry->second) {
				delete entry->first;
			}
			delete entry;
			iter++;
		}
		delete this->extensions;
	}
}



/**
 * Overwrites the annotation property. If <c>copy</c> is true
 * the string will be copied, otherwise just assigned.
 * In both cases the associated memory will be deleted on
 * object destruction.
 *
 * @param annotation	Annotation string to set
 * @param copy			Copy flag
 */
void SpiffData::giveAnnotation(const XML_Char * annotation, bool copy) {
	Toolbox::deleteNewAndCopy(this->annotation, this->ownAnnotation, annotation, copy);
}



/**
 * Overwrites the creator property. If <c>copy</c> is true
 * the string will be copied, otherwise just assigned.
 * In both cases the associated memory will be deleted on
 * object destruction.
 *
 * @param creator	Creator string to set
 * @param copy		Copy flag
 */
void SpiffData::giveCreator(const XML_Char * creator, bool copy) {
	Toolbox::deleteNewAndCopy(this->creator, this->ownCreator, creator, copy);
}



/**
 * Overwrites the info property. If <c>copy</c> is true
 * the string will be copied, otherwise just assigned.
 * In both cases the associated memory will be deleted on
 * object destruction.
 *
 * @param info		Info string to set
 * @param copy		Copy flag
 */
void SpiffData::giveInfo(const XML_Char * info, bool copy) {
	Toolbox::deleteNewAndCopy(this->info, this->ownInfo, info, copy);
}



/**
 * Overwrites the image property. If <c>copy</c> is true
 * the string will be copied, otherwise just assigned.
 * In both cases the associated memory will be deleted on
 * object destruction.
 *
 * @param image		Image string to set
 * @param copy		Copy flag
 */
void SpiffData::giveImage(const XML_Char * image, bool copy) {
	Toolbox::deleteNewAndCopy(this->image, this->ownImage, image, copy);
}



/**
 * Overwrites the title property. If <c>copy</c> is true
 * the string will be copied, otherwise just assigned.
 * In both cases the associated memory will be deleted on
 * object destruction.
 *
 * @param title		Title string to set
 * @param copy		Copy flag
 */
void SpiffData::giveTitle(const XML_Char * title, bool copy) {
	Toolbox::deleteNewAndCopy(this->title, this->ownTitle, title, copy);
}



/**
 * Appends a link to the link list.
 *
 * @param rel			Link rel to append
 * @param copyRel		Rel copy flag
 * @param content		Link content to append
 * @param copyContent	Content copy flag
 */
void SpiffData::giveAppendLink(const XML_Char * rel, bool copyRel, const XML_Char * content, bool copyContent) {
	appendHelper(this->links, copyRel ? Toolbox::newAndCopy(rel) : rel, true,
			copyContent ? Toolbox::newAndCopy(content) : content, true);
}



/**
 * Appends a meta to the meta list.
 *
 * @param rel			Meta rel to append
 * @param copyRel		Rel copy flag
 * @param content		Meta content to append
 * @param copyContent	Content copy flag
 */
void SpiffData::giveAppendMeta(const XML_Char * rel, bool copyRel, const XML_Char * content, bool copyContent) {
	appendHelper(this->metas, copyRel ? Toolbox::newAndCopy(rel) : rel, true,
			copyContent ? Toolbox::newAndCopy(content) : content, true);
}

void SpiffData::giveAppendExtension(const SpiffExtension * extension, bool copy) {
	appendHelper(this->extensions,
			copy
				? extension->clone()
				: extension,
			true);
}



/**
 * Overwrites the annotation property. The string is
 * only assigned not copied. The ownership is
 * not transferred.
 *
 * @param annotation		Annotation string to set
 */
void SpiffData::lendAnnotation(const XML_Char * annotation) {
	Toolbox::deleteNewAndCopy(this->annotation, this->ownAnnotation, annotation, false);
}



/**
 * Overwrites the creator property. The string is
 * only assigned not copied. The ownership is
 * not transferred.
 *
 * @param creator		Creator string to set
 */
void SpiffData::lendCreator(const XML_Char * creator) {
	Toolbox::deleteNewAndCopy(this->creator, this->ownCreator, creator, false);
}



/**
 * Overwrites the info property. The string is
 * only assigned not copied. The ownership is
 * not transferred.
 *
 * @param info		Info string to set
 */
void SpiffData::lendInfo(const XML_Char * info) {
	Toolbox::deleteNewAndCopy(this->info, this->ownInfo, info, false);
}



/**
 * Overwrites the image property. The string is
 * only assigned not copied. The ownership is
 * not transferred.
 *
 * @param image		Image string to set
 */
void SpiffData::lendImage(const XML_Char * image) {
	Toolbox::deleteNewAndCopy(this->image, this->ownImage, image, false);
}


/**
 * Overwrites the title property. The string is
 * only assigned not copied. The ownership is
 * not transferred.
 *
 * @param title		Title string to set
 */
void SpiffData::lendTitle(const XML_Char * title) {
	Toolbox::deleteNewAndCopy(this->title, this->ownTitle, title, false);
}



/**
 * Appends a link pair to the link list.
 * The associated memory is neither copied nor
 * deleted on onject destruction.
 *
 * @param rel		Link rel to append
 * @param content	Link content to append
 */
void SpiffData::lendAppendLink(const XML_Char * rel, const XML_Char * content) {
	appendHelper(this->links, rel, false, content, false);
}



/**
 * Appends a meta pair to the meta list.
 * The associated memory is neither copied nor
 * deleted on onject destruction.
 *
 * @param rel		Meta rel to append
 * @param content	Meta content to append
 */
void SpiffData::lendAppendMeta(const XML_Char * rel, const XML_Char * content) {
	appendHelper(this->metas, rel, false, content, false);
}


void SpiffData::lendAppendExtension(SpiffExtension * extension) {
	appendHelper(this->extensions, extension, false);
}



/**
 * Steals the title property.
 *
 * @return	Title
 */
XML_Char * SpiffData::stealTitle() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->title));
}



/**
 * Steals the annotation property.
 *
 * @return	Annotation
 */
XML_Char * SpiffData::stealAnnotation() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->annotation));
}



/**
 * Steals the creator property.
 *
 * @return	Creator
 */
XML_Char * SpiffData::stealCreator() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->creator));
}



/**
 * Steals the info property.
 *
 * @return	Info URI
 */
XML_Char * SpiffData::stealInfo() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->info));
}



/**
 * Steals the image property.
 *
 * @return	Image URI
 */
XML_Char * SpiffData::stealImage() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->image));
}



/**
 * Steals the first meta pair from the list.
 * If the list is empty <c>NULL</c> is returned.
 *
 * NOTE: Do not forget to delete the pair!
 *
 * @return		First meta pair
 */
pair<XML_Char *, XML_Char *> * SpiffData::stealFirstMeta() {
	return stealFirstHelper(this->metas);
}



/**
 * Steals the first link pair from the list.
 * If the list is empty <c>NULL</c> is returned.
 *
 * NOTE: Do not forget to delete the pair!
 *
 * @return		First link pair
 */
pair<XML_Char *, XML_Char *> * SpiffData::stealFirstLink() {
	return stealFirstHelper(this->links);
}

SpiffExtension * SpiffData::stealFirstExtension() {
	return stealFirstHelper(this->extensions);
}


/**
 * Returns the image property.
 *
 * @return	Image URI
 */
const XML_Char * SpiffData::getImage() {
	return this->image;
}



/**
 * Returns the info property.
 *
 * @return	Info URI
 */
const XML_Char * SpiffData::getInfo() {
	return this->info;
}



/**
 * Returns the annotation property.
 *
 * @return	Annotation
 */
const XML_Char * SpiffData::getAnnotation() {
	return this->annotation;
}



/**
 * Returns the creator property.
 *
 * @return	Creator
 */
const XML_Char * SpiffData::getCreator() {
	return this->creator;
}



/**
 * Returns the title property.
 *
 * @return	Title
 */
const XML_Char * SpiffData::getTitle() {
	return this->title;
}



/**
 * Gets a specific link pair from the list.
 * If the list is empty <c>NULL</c> is returned.
 *
 * NOTE: The returned pair has to be deleted manually!
 *
 * @return		Specified link pair
 */
pair<const XML_Char *, const XML_Char *> * SpiffData::getLink(int index) {
	return getHelper(this->links, index);
}



/**
 * Gets a specific meta pair from the list.
 * If the list is empty <c>NULL</c> is returned.
 *
 * NOTE: The returned pair has to be deleted manually!
 *
 * @return		Specified meta pair
 */
pair<const XML_Char *, const XML_Char *> * SpiffData::getMeta(int index) {
	return getHelper(this->metas, index);
}


const SpiffExtension * SpiffData::getExtension(int index) {
	return getHelper(this->extensions, index);
}



/**
 * Returns the number of link pairs.
 *
 * @return	Number of link pairs
 */
int SpiffData::getLinkCount() {
	return (this->links == NULL) ? 0 : static_cast<int>(this->links->size());
}



/**
 * Returns the number of meta pairs.
 *
 * @return	Number of meta pairs
 */
int SpiffData::getMetaCount() {
	return (this->metas == NULL) ? 0 : static_cast<int>(this->metas->size());
}


int SpiffData::getExtensionCount() {
	return (this->extensions == NULL) ? 0 : static_cast<int>(this->extensions->size());
}



/**
 * Appends a meta or link pair a container.
 *
 * @param container		Container to work with
 * @param rel			Rel to append
 * @param ownRel		Rel ownership flag
 * @param content		Content to append
 * @param ownContent	Content ownership flag
 */
/*static*/ void SpiffData::appendHelper(deque<pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> *> * & container,
		const XML_Char * rel, bool ownRel, const XML_Char * content, bool ownContent) {
	if (container == NULL) {
		container = new deque<pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> *>;
	}
	pair<const XML_Char *, bool> * const first = new pair<const XML_Char *, bool>(rel, ownRel);
	pair<const XML_Char *, bool> * const second = new pair<const XML_Char *, bool>(content, ownContent);
	pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> * const entry =
			new pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *>(first, second);
	container->push_back(entry);
}

/*static*/ void SpiffData::appendHelper(deque<pair<const SpiffExtension *, bool> *> * & container,
		const SpiffExtension * extension, bool own) {
	if (container == NULL) {
		container = new deque<pair<const SpiffExtension *, bool> *>;
	}
	pair<const SpiffExtension *, bool> * const entry =
			new pair<const SpiffExtension *, bool>(extension, own);
	container->push_back(entry);
}



/**
 * Steals the first entry from a container.
 *
 * @param container		Container to steal from
 * @return				First entry
 */
/*static*/ pair<XML_Char *, XML_Char *> * SpiffData::stealFirstHelper(
		deque<pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> *> * & container) {
	if ((container == NULL) || container->empty()) {
		return NULL;
	}
	pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> * const entry =
			container->front();
	container->pop_front();
	pair<XML_Char *, XML_Char *> * const res = new pair<XML_Char *, XML_Char *>(
			entry->first->second
			? const_cast<XML_Char *>(entry->first->first)
			: Toolbox::newAndCopy(entry->first->first), entry->second->second
			? const_cast<XML_Char *>(entry->second->first)
			: Toolbox::newAndCopy(entry->second->first));
	delete entry->first;
	delete entry->second;
	delete entry;
	return res;
}

/*static*/ SpiffExtension * SpiffData::stealFirstHelper(
		deque<pair<const SpiffExtension *, bool> *> * & container) {
	if ((container == NULL) || container->empty()) {
		return NULL;
	}
	pair<const SpiffExtension *, bool> * const entry = container->front();
	container->pop_front();
	SpiffExtension * res = entry->second
			? const_cast<SpiffExtension *>(entry->first)
			: entry->first->clone();
	delete entry;
	return res;
}



/**
 * Returns a specific entry from a container
 * or <c>NULL</c> if the entry does not exist.
 *
 * NOTE: The returned pair has to be deleted manually!
 *
 * @param container		Container to work with
 * @param index			Index of the entry to return
 * @return				Entry content
 */
/*static*/ pair<const XML_Char *, const XML_Char *> * SpiffData::getHelper(
		deque<pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> *> * & container, int index) {
	if ((container == NULL) || container->empty() || (index < 0)
			|| (index >= static_cast<int>(container->size()))) {
		return NULL;
	}
	pair<pair<const XML_Char *, bool> *, pair<const XML_Char *, bool> *> * const entry =
			container->at(index);
	pair<const XML_Char *, const XML_Char *> * const res =
			new pair<const XML_Char *, const XML_Char *>(entry->first->second
			? entry->first->first
			: Toolbox::newAndCopy(entry->first->first), entry->second->second
			? entry->second->first
			: Toolbox::newAndCopy(entry->second->first));
	return res;
}



/*static*/ const SpiffExtension * SpiffData::getHelper(
		deque<pair<const SpiffExtension *, bool> *> * & container, int index) {
	if ((container == NULL) || container->empty() || (index < 0)
			|| (index >= static_cast<int>(container->size()))) {
		return NULL;
	}
	pair<const SpiffExtension *, bool> * const entry
			= container->at(index);
	if (entry->second) {
		return entry->first;
	} else {
		return entry->first->clone();
	}
}



}
