/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2007, Sebastian Pipping / Xiph.Org Foundation
 * All rights reserved.
 *
 * Redistribution  and use in source and binary forms, with or without
 * modification,  are permitted provided that the following conditions
 * are met:
 *
 *     * Redistributions   of  source  code  must  retain  the   above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer.
 *
 *     * Redistributions  in  binary  form must  reproduce  the  above
 *       copyright  notice, this list of conditions and the  following
 *       disclaimer   in  the  documentation  and/or  other  materials
 *       provided with the distribution.
 *
 *     * Neither  the name of the Xiph.Org Foundation nor the names of
 *       its  contributors may be used to endorse or promote  products
 *       derived  from  this software without specific  prior  written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT  NOT
 * LIMITED  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND  FITNESS
 * FOR  A  PARTICULAR  PURPOSE ARE DISCLAIMED. IN NO EVENT  SHALL  THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL,    SPECIAL,   EXEMPLARY,   OR   CONSEQUENTIAL   DAMAGES
 * (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES;  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT  LIABILITY,  OR  TORT (INCLUDING  NEGLIGENCE  OR  OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Sebastian Pipping, dllmain@xiph.org
 */

/**
 * @file SpiffProps.cpp
 * Implementation of SpiffProps.
 */

#include <spiff/SpiffProps.h>
#include <spiff/SpiffToolbox.h>
#include <string.h>
using namespace std;

namespace Spiff {



/**
 * Creates a new, blank playlist property package.
 */
SpiffProps::SpiffProps() : location(NULL), license(NULL), identifier(NULL),
		ownLocation(false), ownLicense(false), ownIdentifier(false),
		attributions(NULL), date(NULL), ownDate(false), version(-1) {

}



/**
 * Frees all memory that has not been stolen.
 */
SpiffProps::~SpiffProps() {
	if (this->ownLocation && (this->location != NULL)) {
		delete [] this->location;
	}
	if (this->ownIdentifier && (this->identifier != NULL)) {
		delete [] this->identifier;
	}
	if (this->ownLicense && (this->license != NULL)) {
		delete [] this->license;
	}
	if (this->attributions != NULL) {
		deque<pair<bool, pair<const XML_Char *, bool> *> *>::const_iterator iter = this->attributions->begin();
		while (iter != this->attributions->end()) {
			pair<bool, pair<const XML_Char *, bool> *> * const entry = *iter;
			if (entry->second->second) {
				delete [] entry->second->first;
			}
			delete entry->second;
			delete entry;
			iter++;
		}
		delete this->attributions;
	}
	if (this->ownDate && (this->date != NULL)) {
		delete this->date;
	}
}



/**
 * Overwrites the location property. If <c>copy</c> is true
 * the string will be copied, otherwise just assigned.
 * In both cases the associated memory will be deleted on
 * object destruction.
 *
 * @param location	Location string to set
 * @param copy		Copy flag
 */
void SpiffProps::giveLocation(const XML_Char * location, bool copy) {
	Toolbox::deleteNewAndCopy(this->location, this->ownLocation, location, copy);
}



/**
 * Overwrites the license property. If <c>copy</c> is true
 * the string will be copied, otherwise just assigned.
 * In both cases the associated memory will be deleted on
 * object destruction.
 *
 * @param license	License string to set
 * @param copy		Copy flag
 */
void SpiffProps::giveLicense(const XML_Char * license, bool copy) {
	Toolbox::deleteNewAndCopy(this->license, this->ownLicense, license, copy);
}



/**
 * Overwrites the identifier property. If <c>copy</c> is true
 * the string will be copied, otherwise just assigned.
 * In both cases the associated memory will be deleted on
 * object destruction.
 *
 * @param identifier	Identifier string to set
 * @param copy			Copy flag
 */
void SpiffProps::giveIdentifier(const XML_Char * identifier, bool copy) {
	Toolbox::deleteNewAndCopy(this->identifier, this->ownIdentifier, identifier, copy);
}



/**
 * Appends an identifier to the attribution list.
 *
 * @param identifier	Identifier to append
 * @param copy		Copy flag
 */
void SpiffProps::giveAppendAttributionIdentifier(const XML_Char * identifier, bool copy) {
	appendHelper(this->attributions, copy ? Toolbox::newAndCopy(identifier)
		: identifier, true, false);
}



/**
 * Appends an location to the attribution list.
 *
 * @param location	Location to append
 * @param copy		Copy flag
 */
void SpiffProps::giveAppendAttributionLocation(const XML_Char * location, bool copy) {
	appendHelper(this->attributions, copy ? Toolbox::newAndCopy(location)
		: location, true, true);
}



/**
 * Overwrites the date property. If <c>copy</c> is true
 * the date object will be copied, otherwise just assigned.
 * In both cases the associated memory will be deleted on
 * object destruction.
 *
 * @param date		Date object to set
 * @param copy		Copy flag
 */
void SpiffProps::giveDate(const SpiffDateTime * date, bool copy) {
	SpiffProps::deleteNewAndCopy(this->date, this->ownDate, date, copy);
}



/**
 * Overwrites the location property. The string is
 * only assigned not copied. The ownership is
 * not transferred.
 *
 * @param location		Location string to set
 */
void SpiffProps::lendLocation(const XML_Char * location) {
	Toolbox::deleteNewAndCopy(this->location, this->ownLocation, location, false);
}



/**
 * Overwrites the license property. The string is
 * only assigned not copied. The ownership is
 * not transferred.
 *
 * @param license		License string to set
 */
void SpiffProps::lendLicense(const XML_Char * license) {
	Toolbox::deleteNewAndCopy(this->license, this->ownLicense, license, false);
}



/**
 * Overwrites the identifier property. The string is
 * only assigned not copied. The ownership is
 * not transferred.
 *
 * @param identifier		Identifier string to set
 */
void SpiffProps::lendIdentifier(const XML_Char * identifier) {
	Toolbox::deleteNewAndCopy(this->identifier, this->ownIdentifier, identifier, false);
}



/**
 * Appends an identifier to the attribution list.
 * The associated memory is neither copied nor
 * deleted on onject destruction.
 *
 * @param identifier	Identifier to append
 */
void SpiffProps::lendAppendAttributionIdentifier(const XML_Char * identifier) {
	appendHelper(this->attributions, identifier, false, false);
}



/**
 * Appends an location to the attribution list.
 * The associated memory is neither copied nor
 * deleted on onject destruction.
 *
 * @param location	Location to append
 */
void SpiffProps::lendAppendAttributionLocation(const XML_Char * location) {
	appendHelper(this->attributions, location, false, true);
}



/**
 * Overwrites the date property. The date object is
 * only assigned not copied. The ownership is
 * not transferred.
 *
 * @param date		Date object to set
 */
void SpiffProps::lendDate(const SpiffDateTime * date) {
	SpiffProps::deleteNewAndCopy(this->date, this->ownDate, date, false);
}



/**
 * Steals the location property.
 *
 * @return	Location URI
 */
XML_Char * SpiffProps::stealLocation() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->location));
}



/**
 * Steals the identifier property.
 *
 * @return	Identifier URI
 */
XML_Char * SpiffProps::stealIdentifier() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->identifier));
}



/**
 * Steals the license property.
 *
 * @return	License URI
 */
XML_Char * SpiffProps::stealLicense() {
	return const_cast<XML_Char *>(Toolbox::getSetNull<XML_Char>(this->license));
}



/**
 * Steals the first attribution entry from the list.
 * If the list is empty <c>NULL</c> is returned.
 *
 * NOTE: Do not forget to delete the pair!
 *
 * @return		First attribution entry
 */
pair<bool, XML_Char *> * SpiffProps::stealFirstAttribution() {
	return stealFirstHelper(this->attributions);
}



/**
 * Steals the date object property.
 *
 * @return	Date object
 */
SpiffDateTime * SpiffProps::stealDate() {
	return const_cast<SpiffDateTime *>(Toolbox::getSetNull<SpiffDateTime>(this->date));
}



/**
 * Overwrites the XSPF version property.
 *
 * @param version		XSPF version (0 or 1)
 */
void SpiffProps::setVersion(int version) {
	this->version = version;
}



/**
 * Returns the license property.
 *
 * @return	License
 */
const XML_Char * SpiffProps::getLicense() {
	return this->license;
}



/**
 * Returns the location property.
 *
 * @return	Location
 */
const XML_Char * SpiffProps::getLocation() {
	return this->location;
}



/**
 * Returns the identifier property.
 *
 * @return	Identifier
 */
const XML_Char * SpiffProps::getIdentifier() {
	return this->identifier;
}



/**
 * Gets the specific attribution entry from the list.
 * If the list is empty <c>NULL</c> is returned.
 *
 * NOTE: The returned pair has to be deleted manually!
 *
 * @return		Specified attribution entry
 */
pair<bool, const XML_Char *> * SpiffProps::getAttribution(int index) {
	return getHelper(this->attributions, index);
}



/**
 * Returns the date object property.
 *
 * @return	Date object
 */
const SpiffDateTime * SpiffProps::getDate() {
	return this->date;
}



/**
 * Returns the XSPF version property.
 *
 * @return	XSPF version (0 or 1)
 */
int SpiffProps::getVersion() {
	return this->version;
}



/**
 * Returns the number of attributions.
 *
 * @return	Number of attributions
 */
int SpiffProps::getAttributionCount() {
	return (this->attributions == NULL) ? 0 : static_cast<int>(this->attributions->size());
}



/**
 * Appends a location or identifier to a container.
 *
 * @param container	Container to work with
 * @param value		Value
 * @param ownership	Ownership flag
 * @param isLocation	Location/identifier switch
 */
/*static*/ void SpiffProps::appendHelper(deque<pair<bool, pair<const XML_Char *, bool> *> *> * & container,
		const XML_Char * value, bool ownership, bool isLocation) {
	if (container == NULL) {
		container = new deque<pair<bool, pair<const XML_Char *, bool> *> *>;
	}
	pair<const XML_Char *, bool> * const second = new pair<const XML_Char *, bool>(value, ownership);
	pair<bool, pair<const XML_Char *, bool> *> * const entry =
		new pair<bool, pair<const XML_Char *, bool> *>(isLocation, second);
	container->push_back(entry);
}



/**
 * Returns a specific entry from a container
 * or <c>NULL</c> if the entry does not exist.
 *
 * NOTE: The returned pair has to be deleted manually!
 *
 * @param container		Container to work with
 * @param index			Index of the entry to return
 * @return				Entry content
 */
/*static*/ pair<bool, const XML_Char *> * SpiffProps::getHelper(
		deque<pair<bool, pair<const XML_Char *, bool> *> *> * & container, int index) {
	if ((container == NULL) || container->empty() || (index < 0)
			|| (index >= static_cast<int>(container->size()))) {
		return NULL;
	}
	pair<bool, pair<const XML_Char *, bool> *> * const entry = container->at(index);
	pair<bool, const XML_Char *> * const res = new pair<bool, const XML_Char *>(
		entry->first, entry->second->first);
	return res;
}



/**
 * Steals the first entry from a container.
 *
 * @param container		Container to steal from
 * @return				First entry
 */
/*static*/ pair<bool, XML_Char *> * SpiffProps::stealFirstHelper(
		deque<pair<bool, pair<const XML_Char *, bool> *> *> * & container) {
	if ((container == NULL) || container->empty()) {
		return NULL;
	}
	pair<bool, pair<const XML_Char *, bool> *> * const entry =
			container->front();
	container->pop_front();
	pair<bool, XML_Char *> * const res = new pair<bool, XML_Char *>(
		entry->first, entry->second->second
		? const_cast<XML_Char *>(entry->second->first)
		: Toolbox::newAndCopy(entry->second->first));
	delete entry->second;
	delete entry;
	return res;
}



/**
 * Replaces the date object in <c>dest</c> by a duplicate of the date object
 * in <c>src</c>  (using new() not malloc()). The old object is deleted.
 * If <c>destOwnership</c> is false the old string is not deleted.
 * If <c>sourceCopy</c> is false only <c>source</c>'s pointer is copied,
 * not the whole object.
 *
 * @param dest			Destination date object
 * @param destOwnership	Destination ownership flag
 * @param source		Source date object
 * @param sourceCopy	Source copy flag
 */
/*static*/ void SpiffProps::deleteNewAndCopy(const SpiffDateTime * & dest, bool & destOwnership,
		const SpiffDateTime * source, bool sourceCopy) {
	// Delete old memory if owner
	if (destOwnership && (dest != NULL)) {
		delete [] dest;
	}

	if (source == NULL) {
		dest = NULL;
		destOwnership = false;
	} else {
		// Copy new memory if desired
		if (sourceCopy) {
			SpiffDateTime * const dup = source->clone();
			dest = dup;
			destOwnership = true;
		} else {
			dest = source;
			destOwnership = false;
		}
	}
}



}
