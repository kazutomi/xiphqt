/*
 * libSpiff - XSPF playlist handling library
 *
 * Copyright (C) 2006 Sebastian Pipping
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Sebastian Pipping, webmaster@hartwork.org
 */

#include "ChunkCallbackSuite.h"
#include <spiff/SpiffReader.h>
#include <memory>
using namespace Spiff;
using namespace std;



ChunkCallbackSuite::ChunkCallbackSuite() {
	TEST_ADD(ChunkCallbackSuite::valid)
	TEST_ADD(ChunkCallbackSuite::invalid)
}



void ChunkCallbackSuite::reset(const XML_Char ** lines,
		int numLines, int expextedRes, int errorLine) {
	this->lines = lines;
	this->numLines = numLines;
	this->expextedRes = expextedRes;
	this->errorLine = errorLine;
	this->curLine = 0;
	this->stopCalled = false;
}



void ChunkCallbackSuite::run() {
	SpiffReader reader;
	const int res = reader.parseChunks(this, NULL);
	TEST_ASSERT(res == this->expextedRes);
	if (this->expextedRes == SPIFF_READER_SUCCESS) {
		TEST_ASSERT(this->curLine == this->numLines);
	} else {
		TEST_ASSERT((this->curLine - 1) == this->errorLine);
	}
	TEST_ASSERT(this->stopCalled);
}



void ChunkCallbackSuite::valid() {
	static const XML_Char ** const validLines = new const XML_Char *[4];
	validLines[0] = _PT("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	validLines[1] = _PT("<playlist version=\"1\" xmlns=\"http://xspf.org/ns/0/\">\n");
	validLines[2] = _PT("\t<trackList />\n");
	validLines[3] = _PT("</playlist>\n");
	reset(validLines, 4, SPIFF_READER_SUCCESS);
	run();
}



void ChunkCallbackSuite::invalid() {
	static const XML_Char ** const invalidLines = new const XML_Char *[4];
	invalidLines[0] = _PT("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	invalidLines[1] = _PT("<playlist version=\"1\" xmlns=\"http://xspf.org/ns/0/\">\n");
	invalidLines[2] = _PT("\t<FORBIDDEN />\n");
	invalidLines[3] = _PT("</playlist>\n");
	reset(invalidLines, 4, SPIFF_READER_ERROR_ELEMENT_FORBIDDEN, 2);
	run();
}



int ChunkCallbackSuite::getMinimumBufferByteSize() {
	if (this->curLine < numLines) {
		return static_cast<int>(PORT_STRLEN(this->lines[this->curLine]));
	} else {
		return 0;
	}
}



int ChunkCallbackSuite::fillBuffer(void * buffer) {
	if (this->curLine < numLines) {
		const int byteLen = static_cast<int>(PORT_STRLEN(this->lines[this->curLine]))
				* sizeof(XML_Char);
		memcpy(buffer, this->lines[this->curLine], byteLen);
		this->curLine++;
		return byteLen;
	} else {
		return 0;
	}
}



void ChunkCallbackSuite::notifyStop() {
	this->stopCalled = true;
}
