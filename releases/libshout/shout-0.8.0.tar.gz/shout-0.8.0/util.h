#ifndef _UTIL_H_
#define _UTIL_H_

typedef	unsigned long	DWORD;


#define BUFSIZE 1024
#define ABUFSIZE 65535

#ifdef HAVE_LONG_LONG
typedef unsigned long long int my_long_t;
#else
typedef unsigned long int my_long_t;
#endif

#ifdef HAVE_SNPRINTF
# define my_snprintf(a,b,c,d) snprintf(a,b,c,d);
# define my_vsnprintf(a,b,c,d) vsnprintf(a,b,c,d);
# define my_snprintf5(a,b,c,d,e) snprintf (a,b,c,d,e);
#else
# define my_snprintf5(a,b,c,d,e) sprintf (a,c,d,e);
# define my_snprintf(a,b,c,d) sprintf (a,c,d);
# define my_vsnprintf(a,b,c,d) vsprintf (a,c,d);
#endif

my_long_t my_get_time ();
void my_sleep (my_long_t thislong);

#define nmalloc(x) n_malloc (x,__LINE__);
#define nfree(x) n_free (x,__LINE__), x = NULL;

void n_free (void *ptr, int line);
void *n_malloc (int size, int line);
char *splitc (char *first, char *rest, const char divider);

#ifdef _WIN32
const char *desc_priorityclass( DWORD class );
#endif /* win32 */


#endif 
