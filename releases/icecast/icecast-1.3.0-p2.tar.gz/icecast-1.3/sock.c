/* sock.c
 * - General Socket Functions
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif
#include <stdarg.h>
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <ctype.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <string.h>
#include <errno.h>
#include <fcntl.h>

#ifndef _WIN32
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#else
#include <winsock.h>
#endif

#ifdef HAVE_LIBWRAP
# include <tcpd.h>
# ifdef NEED_SYS_SYSLOG_H
#  include <sys/syslog.h>
# else
#  include <syslog.h>
# endif
int allow_severity = LOG_INFO;
int deny_severity = LOG_WARNING;
#endif

#include "avl.h"
#include "threads.h"
#include "icetypes.h"
#include "icecast.h"
#include "sock.h"
#include "log.h"
#include "avl_functions.h"
#include "main.h"
#include "utility.h"
#include "ice_string.h"
#include "memory.h"

#ifdef _WIN32
extern int running;
#else
extern int h_errno, errno, running;
#endif
extern server_info_t info;
extern struct in_addr localaddr;

#if defined(_WIN32) || !defined(HAVE_INET_ATON)
/* 
 * guess this isn't part of win32. weird! -- ajs 3/99 
 * Assert Class: 2 
 */
int 
inet_aton(const char *s, struct in_addr *a)
{
    int lsb, b2, b3, msb;
    if (sscanf(s, "%d.%d.%d.%d", &lsb, &b2, &b3, &msb) < 4)
		return -1;

    a->s_addr = lsb + (b2 << 8) + (b3 << 16) + (msb << 24);
		return 0;
}
#endif

SOCKET
create_udp_socket ()
{
	SOCKET s = socket (AF_INET, SOCK_DGRAM, 0);
	if (s < 0)
		xa_debug (1, "WARNING: Creation of udp socket failed!");
	return s;
}
/* 
 * Check if socket is a valid socket.
 * Assert Class: 1 (don't have a clue about win32 yet)
 * Potential problems: Can we do this on win32?
 *                     What about OS's where sockets are not integers?
 */
int
valid_socket (const SOCKET sockfd)
{
	return sockfd >= 0;
}

/* 
 * Set or the socket to blocking or nonblocking. 
 * Assert Class: 1 
 */
int 
sock_set_blocking(SOCKET sockfd, const int block)
{
#ifdef _WIN32
	int varblock = block;
#endif

	if (!valid_socket (sockfd)) {
		xa_debug (1, "ERROR: sock_set_blocking() called with invalid socket");
		return -1;
	} else if ((block < 0) || (block > 1)) {
		xa_debug (1, "ERROR: sock_set_blocking() called with invalid block value");
		return -1;
	}

#ifdef _WIN32
	return ioctlsocket(sockfd, FIONBIO, &varblock);
#else
	return fcntl(sockfd, F_SETFL, block ? O_NONBLOCK : 0);
#endif
}

/* 
 * Close the socket 
 * Assert Class: 0
 */
int 
sock_close(SOCKET sockfd)
{
#ifdef _WIN32
	if (sockfd > 1) /* it's a real socket */
		return closesocket(sockfd);
	else
		return 0;
#else
	return fd_close(sockfd);
#endif
}

/* 
 * Write len bytes from buff to the client. Kick him out on network errors.
 * Return the number of bytes written and -1 on error.
 * Assert Class: 2
 * Potential problems: Any usage of errno is bad in a threaded application.
 */
int
sock_write_bytes_or_kick (SOCKET sockfd, connection_t *clicon, const char *buff, const int len)
{
	int res, err;

	if (!valid_socket (sockfd)) {
		xa_debug (1, "ERROR: sock_write_bytes_or_kick() called with invalid socket");
		return -1;
	} else if (!clicon) {
		xa_debug (1, "ERROR: sock_write_bytes_or_kick() called with NULL client");
		return -1;
	} else if (!buff) {
		xa_debug (1, "ERROR: sock_write_bytes_or_kick() called with NULL data");
		return -1;
	} else if (len <= 0) {
		xa_debug (1, "ERROR: sock_write_bytes_or_kick() called with invalid length");
		return -1;
	}
	
	errno = 666; /* Oh, how frigolous :) */

	res = sock_write_bytes (sockfd, buff, len);
	err = errno;

	if (res < 0) {
		xa_debug (4, "DEBUG: sock_write_bytes_or_kick: %d err [%d]", res,  err);
#ifdef _WIN32
		if (WSAGetLastError() != WSAEWOULDBLOCK && WSAGetLastError() != WSAEINTR) {
#else
		if (err != EAGAIN && err != EINTR && err != 666) {
#endif
			kick_connection (clicon, "Client signed off");
			return -1;
		}
	

	}
	return res;
}

/* 
 * Write len bytes from buf to the socket.
 * Returns the return value from send()
 * Assert Class: 0
 */
int 
sock_write_bytes(SOCKET sockfd, const char *buff, const int len)
{
	if (!buff) {
		xa_debug (1, "ERROR: sock_write_bytes() called with NULL data");
		return -1;
	} else if (len <= 0) {
		xa_debug (1, "ERROR: sock_write_bytes() called with zero or negative len");
		return -1;
	} else if (!valid_socket (sockfd)) {
		xa_debug (1, "ERROR: sock_write_bytes() called with invalid socket");
		return -1;
	}
	
	return send (sockfd, buff, len, 0);
}

/*
 * Write a string to a socket. 
 * Return 1 if all bytes where successfully written, and 0 if not.
 * Assert Class: 2
 */
int
sock_write_string (SOCKET sockfd, const char *buff)
{
	int write_bytes = 0;

	if (!valid_socket (sockfd)) {
		fprintf (stderr, "ERROR: sock_write() called with invalid socket\n");
		return -1;
	} else if (!buff) {
		fprintf (stderr, "ERROR: sock_write() called with NULL format\n");
		return -1;
	}

	/* Never use send() to sockets 0 or 1 in Win32. What about 2 (stderr?).
	   Also, if the server is running, and is used as an  admin console, or an
	   admin console with console tail, don't use send(), cause it's not a 
	   network socket. Use fprintf() */
	   
        if (sockfd == 1 || sockfd == 0) {
		if (running == 1 && ((info.console_mode == CONSOLE_ADMIN) || (info.console_mode == CONSOLE_ADMIN_TAIL))) {
			write_bytes = fprintf (stdout, "%s", buff);
			fflush (stdout);
		}
#ifndef _WIN32
		else {
			write_bytes = send (sockfd, buff, strlen (buff), 0);
		}
#endif
        } else {
                write_bytes = send (sockfd, buff, strlen (buff), 0);
        }

	return (write_bytes == strlen (buff) ? 1 : 0);
}

/* 
 * Write a printf() style formatted message to the socket 
 * Return 1 if all bytes where successfully written, and 0 if not.
 * Assert Class: 2
 * Potential problems: Will truncate the string if longer than BUFSIZE bytes.
 *                     Might fuck everything up if no vsnprintf is available 
 * Never, ever, _ever_ ever _ever_ put a write_log or sock_write in here 
 */
int 
sock_write (SOCKET sockfd, const char *fmt, ...)
{
	char buff[BUFSIZE];
	va_list ap;

	va_start(ap, fmt);
#ifdef HAVE_VSNPRINTF
	vsnprintf(buff, BUFSIZE, fmt, ap);
#else
	vsprintf (buff, fmt, ap);
#endif
	va_end (ap);
	
	return sock_write_string (sockfd, buff);
}

/* 
 * Write a printf() style and newline terminated message to the socket 
 * Return 1 if all bytes where successfully written, and 0 if not.
 * Assert Class: 2
 * Potential problems: Will truncate the string if longer than BUFSIZE bytes.
 *                     Might fuck everything up if no vsnprintf is available 
 * Never, ever, _ever_ ever _ever_ put a write_log or sock_write in here 
 */
int 
sock_write_line (SOCKET sockfd, const char *fmt, ...)
{
	char buff[BUFSIZE];
	va_list ap;

	va_start(ap, fmt);
#ifdef HAVE_VSNPRINTF
	vsnprintf(buff, BUFSIZE, fmt, ap);
#else
	vsprintf (buff, fmt, ap);
#endif
	return sock_write (sockfd, "%s\r\n", buff);
}
	

/* 
 * Read a HTTP header. A number of lines terminated by a two newlines.
 * Reads no more than len bytes into string pointed to by buff. If the
 * return value is 1, then the string is valid and null terminated.
 * Assert Class: 3
 * Potential Problems: Usage of errno
 */
int 
sock_read_lines_np (SOCKET sockfd, char *buff, const int len)
{
	char c = '\0';
	int read_bytes, pos = 0;
  
	if (!valid_socket (sockfd)) {
		xa_debug (1, "ERROR: sock_read_lines_np() called with invalid socket");
		return 0;
	} else if (!buff) {
		xa_debug (1, "ERROR: sock_read_lines_np() called with NULL storage pointer");
		return 0;
	} else if (len <= 0) {
		xa_debug (1, "ERROR: sock_read_lines_np() called with invalid length");
		return 0;
	}
	
#ifdef _WIN32
	WSASetLastError(0);
#else
	errno = 0;
#endif

	read_bytes = recv (sockfd, &c, 1, 0);

	if (read_bytes < 0)
	{
		xa_debug (1, "DEBUG: Socket error on socket %d %d", sockfd, errno);
		return 0;
	}
	
	while ((read_bytes == 1) && (pos < (len - 1))) 
	{
		if (c != '\r')
			buff[pos++] = c;
		if ((pos > 1) && (buff[pos - 1] == '\n' && buff[pos - 2] == '\n'))
			break;
#ifdef _WIN32
		WSASetLastError(0);
#else
		errno = 0;
#endif
		read_bytes = recv (sockfd, &c, 1, 0);
		if (read_bytes < 0)
		{
			xa_debug (1, "DEBUG: Socket error on socket %d %d", sockfd, errno);
			return 0;
		}
	}

	if (read_bytes == 1)
	{
		buff[pos] = '\0';
		return 1;
	} else {
		return 0;
	}
}

/*
 * Same as sock_read_lines_np() but with two special cases. One for a header that winamp sends when connecting
 * as a source. And one with a header with just "\n", which xaudio sends in tcp:// mode.
 */
int 
sock_read_lines(SOCKET sockfd, char *buff, const int len)
{
	char c[2];
	int read_bytes, pos = 0;
	
	if (!valid_socket (sockfd)) {
		xa_debug (1, "ERROR: sock_read_lines() called with invalid socket");
		return 0;
	} else if (!buff) {
		xa_debug (1, "ERROR: sock_read_lines() called with NULL storage pointer");
		return 0;
	} else if (len <= 0) {
		xa_debug (1, "ERROR: sock_read_lines() called with invalid length");
		return 0;
	}	

	c[0] = c[1] = '\0';

#ifdef _WIN32
	WSASetLastError(0);
#else
	errno = 0;
#endif

	read_bytes = recv(sockfd, &c[0], 1, 0);

	if (read_bytes < 0)
	{
		xa_debug (1, "DEBUG: Socket error on socket %d %d", sockfd, errno);
		return 0;
	}
		
	while ((read_bytes == 1) && (pos < (len - 1))) 
	{
		if (c[0] == '\n' && pos <= 1) /* Special case for xaudio tcp:// */
			return 2;
		if (c[0] != '\r')
			buff[pos++] = c[0];
		if ((pos > 1) && (buff[pos - 1] == '\n' && buff[pos - 2] == '\n'))
			break;
		if (c[0] == '\n' && (strchr (buff, ' ') == NULL)) /* Special case for winamp as source */
			break;
#ifdef _WIN32
		WSASetLastError(0);
#else
		errno = 0;
#endif
		read_bytes = recv(sockfd, &c[0], 1, 0);
		if (read_bytes < 0)
		{
			xa_debug (1, "DEBUG: Socket error on socket %d %d", sockfd, errno);
			return 0;
		}
	}

	if (read_bytes == 1)
	{
		buff[pos] = '\0';
		return 1;
	} else {
		return 0;
	}
}

/*
 * Read one line of at max len bytes from sockfd into buff.
 * If ok, return 1 and nullterminate buff. Otherwize return 0.
 * Terminating \n is not put into the buffer.
 * Assert Class: 2
 */
int 
sock_read_line (SOCKET sockfd, char *buff, const int len)
{
	char c = '\0';
	int read_bytes, pos;
  
	if (!valid_socket (sockfd)) {
		xa_debug (1, "ERROR: sock_read_line () called with invalid socket");
		return 0;
	} else if (!buff) {
		xa_debug (1, "ERROR: sock_read_lines () called with NULL storage pointer");
		return 0;
	} else if (len <= 0) {
		xa_debug (1, "ERROR: sock_read_lines () called with invalid length");
		return 0;
	}

	pos = 0;
	read_bytes = recv(sockfd, &c, 1, 0);

	if (read_bytes < 0)
	{
		xa_debug (1, "DEBUG: Socket error on socket %d", sockfd);
		return 0;
	}

	while ((c != '\n') && (pos < len) && (read_bytes == 1)) {
		if (c != '\r')
			buff[pos++] = c;
		read_bytes = recv (sockfd, &c, 1, 0);
	}
	
	if (read_bytes == 1)
	{
		buff[pos] = '\0';
		return 1;
	} else {
		return 0;
	}
}

/* 
 * Create a socket for all incoming requests on specified port.
 * If info.myhostname is NULL, bind it to INADDR_ANY (all available interfaces).
 * If info.myhostname is not NULL, resolv it (if needed), and bind to that.
 * Return the socket for bound socket, or INVALID_SOCKET if failed.
 * Assert Class: 3
 */
SOCKET 
get_server_socket (const int port)
{
	struct sockaddr_in sin;
	char *buf;
	int sin_len, error;
	SOCKET sockfd;

	if (port < 0)
	{
		write_log (LOG_DEFAULT, "ERROR: Invalid port number %d. Cannot listen for requests, this is bad!", port);
		return INVALID_SOCKET;
	}

	buf = (char *) nmalloc (20);

	/* get socket descriptor */
	sockfd = socket (AF_INET, SOCK_STREAM, 0);
	if (sockfd == INVALID_SOCKET) 
		return INVALID_SOCKET;

	/* Setup socket */
#ifdef HAVE_SETSOCKOPT
	{
		int tmp = 1;
		if (setsockopt (sockfd, SOL_SOCKET, SO_REUSEADDR, (const void *)&tmp, sizeof(tmp)) != 0)
			write_log (LOG_DEFAULT, "ERROR: setsockopt() failed to set SO_REUSEADDR flag. (mostly harmless)");
	}
#endif

	/* setup sockaddr structure */
	sin_len = sizeof (sin);
	memset (&sin, 0, sin_len);
	sin.sin_family = AF_INET;

	if (info.myhostname != NULL && info.myhostname[0]) {
		if (isdigit ((int)info.myhostname[0]) && isdigit ((int)info.myhostname[strlen (info.myhostname) - 1])) {
			if (inet_aton (info.myhostname, (struct in_addr *)&localaddr) == 0) {
				write_log (LOG_DEFAULT, "ERROR: Invalid ip number %s, will die now", info.myhostname);
				clean_shutdown (&info);
			}
		} else {
			struct hostent *hostinfo = ice_gethostbyname (info.myhostname);
			if (hostinfo == NULL) {
				write_log (LOG_DEFAULT, "Unknown host %s, that's it for me!", info.myhostname);
				ice_clean_hostent ();
				clean_shutdown (&info);
			}
			sin.sin_addr = *(struct in_addr *)hostinfo->h_addr;
			memcpy ((void *)&localaddr, hostinfo->h_addr, sizeof (localaddr));
			ice_clean_hostent ();
		}
	} else {
		sin.sin_addr.s_addr = htonl(INADDR_ANY);
	}

	sin.sin_port = htons (port);
	
	info.myhostname = makeasciihost ((char *)&sin.sin_addr, buf);

	/* bind socket to port */
	error = bind (sockfd, (struct sockaddr *)&sin, sin_len);
	if (error == SOCKET_ERROR) {
		write_log (LOG_DEFAULT, "Bind to socket on port %d failed. Shutting down now.", port);
		clean_shutdown (&info);
	}

	return sockfd;
}

/*
 * Connect to hostname on specified port and return the created socket.
 * Assert Class: 3
 */
SOCKET 
sock_connect (const char *hostname, const int port)
{
	SOCKET sockfd;
	struct sockaddr_in sin, server;
	struct hostent *host;

	if (!hostname || !hostname[0])
	{
		write_log (LOG_DEFAULT, "ERROR: sock_connect() called with NULL or empty hostname");
		return INVALID_SOCKET;
	} else if (port <= 0) {
		write_log (LOG_DEFAULT, "ERROR: sock_connect() called with invalid port number");
		return INVALID_SOCKET;
	}
		
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == INVALID_SOCKET) { 
		sock_close (sockfd); 
		return INVALID_SOCKET; 
	}

	if (info.myhostname != NULL) {
		struct sockaddr_in localsin;
		memset (&localsin, 0, sizeof (struct sockaddr_in));
		xa_debug (2, "DEBUG: Trying to bind to %s", info.myhostname);

		localsin.sin_addr = localaddr;
		localsin.sin_family = AF_INET;
		localsin.sin_port = 0;

		if (bind (sockfd, (struct sockaddr *)&localsin, sizeof(localsin)) == SOCKET_ERROR)
		{
			write_log(LOG_DEFAULT, "ERROR: Bind to local address %s failed", info.myhostname);
			sock_close (sockfd);
			return INVALID_SOCKET;
		}
	}

	memset(&sin, 0, sizeof(sin));
	memset(&server, 0, sizeof(struct sockaddr_in));

	if (isdigit ((int)hostname[0]) && isdigit ((int)hostname[strlen (hostname) - 1])) {
		if (inet_aton(hostname, (struct in_addr *)&sin) == 0) {
			write_log(LOG_DEFAULT, "ERROR: Invalid ip number %s", hostname);
			sock_close(sockfd);
			return INVALID_SOCKET;
		}
		memcpy (&server.sin_addr, &sin, sizeof (sin));
	} else {
		host = ice_gethostbyname (hostname);
		if (host == NULL) { 
			xa_debug (1, "DEBUG: gethostbyname %s failed", hostname);
			sock_close(sockfd); 
			ice_clean_hostent ();
			return INVALID_SOCKET;
		}
		memcpy(&server.sin_addr, host->h_addr, host->h_length);
		ice_clean_hostent ();
	}

	server.sin_family = AF_INET;
	server.sin_port = htons(port);

	{
		char buf[50];
		makeasciihost ((char *)&server.sin_addr, buf);
		xa_debug (1, "Trying to connect to %s:%d", buf, port);
	}

  	if (connect (sockfd, (struct sockaddr *)&server, sizeof(server)) == 0) {
		return sockfd;
	} else {
		sock_close (sockfd);
		return SOCKET_ERROR;
	}
}

#ifdef HAVE_LIBWRAP
static const char libwraptype[4][20] = { "icecast_client", "icecast_source", "icecast_admin", "icecast" };

/*
 * Return the corresponding string for libwrap for the specified connection type.
 * Assert Class: 1
 */
const char *
get_libwrap_type (const contype_t contype)
{
	switch (contype)
	{
		case client_e:
			return libwraptype[0];
			break;
		case source_e:
			return libwraptype[1];
			break;
		case admin_e:
			return libwraptype[2];
			break;
		default:
			return libwraptype[3];
			break;
	}
}

/* 
 * Checks whether the host connected to the sock socket is allowed in or not.
 * Assert Class: 1
 */
int 
check_libwrap (const int sock, const contype_t contype)
{
	struct request_info req;
	
	if (!valid_socket (sock))
	{
		xa_debug (1, "ERROR: check_libwrap() called with invalid socket");
		return 0;
	} 

	xa_debug (2, "Checking socket %d for validation", sock);
	/* This looks up the tables and stuff in /etc/hosts.[deny|allow] */
	request_init(&req, RQ_DAEMON, get_libwrap_type (contype), RQ_FILE, sock, NULL);
	fromhost(&req);
	if (!hosts_access(&req))
		return 0;
	return 1;
}
#endif


/* 
 *  This should, ultimately use gethostbyname_r()
 * But.. since I can't find any decent documentation
 * on the glibc version of that, I'll leave that for later.
 */
struct hostent *
ice_gethostbyname (const char *hostname)
{
	struct hostent *res;
	thread_mutex_lock (&info.resolvmutex);
	res = gethostbyname (hostname);
	if (!res)
	{
		xa_debug (1, "DEBUG: gethostbyname (%s) failed", hostname);
	}
	return res;
}

/*
 * When using gethostbyname_r() this should free all the
 * allocated buffers used in gethostbyname_r() (which will mean changin the parameters)
 * For now, all we do is unlock the resolv mutex
 */
void
ice_clean_hostent ()
{
	thread_mutex_unlock (&info.resolvmutex);
}

struct hostent *
ice_gethostbyaddr (const char *host, const int len, const int proto)
{
	thread_mutex_lock (&info.resolvmutex);
	return gethostbyaddr (host, len, proto);
}

char *
reverse (const char *host)
{
  struct hostent *hostinfo;
  struct in_addr inp;
  char *outhost;

  if (!host)
  {
	  write_log (LOG_DEFAULT, "ERROR: reverse() called with NULL host");
	  return NULL;
  }

  if (inet_aton (host, &inp))
  {
	  hostinfo = ice_gethostbyaddr((char *) &inp, sizeof(struct in_addr), AF_INET); 

	  if (hostinfo && hostinfo->h_name)
		  outhost = nstrdup (hostinfo->h_name);
	  else
		  outhost = NULL;

	  ice_clean_hostent ();
	  return outhost;
  }
  else
	  return NULL;
}

char *
forward (const char *name, char *target)
{
	struct hostent *hostinfo;
	struct sockaddr_in sin;
	
	thread_mutex_lock (&info.misc_mutex);

	hostinfo = ice_gethostbyname (name);

	if (!hostinfo)
	{
		thread_mutex_unlock (&info.misc_mutex);
		ice_clean_hostent();
		return NULL;
	}

	memset (&sin, 0, sizeof (sin));
	
	sin.sin_addr.s_addr = *(unsigned long *)hostinfo->h_addr_list[0];

	ice_clean_hostent();

	makeasciihost((char *)&sin.sin_addr, target);
	
	thread_mutex_unlock (&info.misc_mutex);

	return target;
}

char *
get_local_ipaddress ()
{
	return nstrdup ("dynamic");
}

	







