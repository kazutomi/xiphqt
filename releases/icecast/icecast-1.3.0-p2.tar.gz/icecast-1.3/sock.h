/* sock.h
 * - General Socket Function Headers
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifndef __ICECAST_SOCK_H
#define __ICECAST_SOCK_H

#include "icetypes.h"

#ifndef _WIN32
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#endif

#define SOCK_BLOCK 0
#define SOCK_NONBLOCK 1

#ifdef _WIN32
int inet_aton(const char *s, struct in_addr *a);
#endif

/* Misc socket functions */
int valid_socket (const SOCKET sockfd);
int sock_set_blocking(SOCKET sockfd, const int block);
int sock_close(SOCKET sockfd);
SOCKET create_udp_socket ();
char *get_local_ipaddress ();

/* Connection related socket functions */
SOCKET get_server_socket(const int port);
SOCKET sock_connect(const char *hostname, const int port);

/* Socket write functions */
int sock_write_bytes(SOCKET sockfd, const char *buff, const int len);
int sock_write_bytes_or_kick (SOCKET sockfd, connection_t *clicon, const char *buff, const int len);
int sock_write(SOCKET sockfd, const char *fmt, ...);
int sock_write_line (SOCKET sockfd, const char *fmt, ...);
int sock_write_string (SOCKET sokfd, const char *buff);

/* Socket read functions */
int sock_read_lines(SOCKET sockfd, char *string, const int len);
int sock_read_lines_np(SOCKET sockfd, char *string, const int len);
int sock_read_line (SOCKET sockfd, char *string, const int len);

/* Libwrap functions */
int check_libwrap(const SOCKET sock, const contype_t contype);
const char *get_libwrap_type (const contype_t contype);

/* Resolv functions */
struct hostent *ice_gethostbyname (const char *hostname);
struct hostent *ice_gethostbyaddr (const char *host, const int len, const int proto);
void ice_clean_hostent();
char *reverse (const char *hostname);
char *forward (const char *name, char *buf);
#endif






