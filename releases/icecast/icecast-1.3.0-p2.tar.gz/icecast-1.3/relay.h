int relay_push (connection_t *admcon, char *arg);
int relay_pull (connection_t *admcon, char *arg);
connection_t *relay_pull_stream (request_t *req);
