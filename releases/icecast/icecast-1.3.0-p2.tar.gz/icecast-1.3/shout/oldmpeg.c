/* This sort of stolen from mp3info, by slicer@bimbo.hive.no, who deserves
   a lot of credit */
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#ifndef __USE_GNU
# define __USE_GNU
#endif

#ifndef __USE_SVID
#define __USE_SVID
#endif
#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif
#ifndef __USE_BSD
# define __USE_BSD
#endif

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#ifdef SHOUT
#include "shout.h"
#endif
#include "mpeg.h"

#define MPG_MD_MONO 3

unsigned int bitrates[3][3][15] =
{
  {
    {0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448},
    {0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384},
    {0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320}
  },
  {
    {0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256},
    {0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160},
    {0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160}
  },
  {
    {0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256},
    {0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160},
    {0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160}
  }
};

unsigned int s_freq[3][4] =
{
    {44100, 48000, 32000, 0},
    {22050, 24000, 16000, 0},
    {11025, 8000, 8000, 0}
};

char *mode_names[5] = {"stereo", "j-stereo", "dual-ch", "single-ch", 
			"multi-ch"};
char *layer_names[3] = {"I", "II", "III"};
char *version_names[3] = {"MPEG-1", "MPEG-2 LSF", "MPEG-2.5"};
char *version_nums[3] = {"1", "2", "2.5"};

int
decode_mp3_header(mp3_header_t *mh, unsigned char *buffer)
{
  if (buffer[0] != 0xFF || (buffer[1] & 0xE0) != 0xE0) 
    {
      return -1;
    } 
  
  switch ((buffer[1] >> 3 & 0x3))
    {
    case 3:
      mh->version = 0;
      break;
    case 2:
      mh->version = 1;
      break;
    case 0:
      mh->version = 2;
      break;
    default:
      return -1;
      break;
    }
  mh->lay = 4 - ((buffer[1] >> 1) & 0x3);
  mh->error_protection = !(buffer[1] & 0x1);
  mh->bitrate_index = (buffer[2] >> 4) & 0x0F;
  mh->sampling_frequency = (buffer[2] >> 2) & 0x3;
  mh->padding = (buffer[2] >> 1) & 0x01;
  mh->extension = buffer[2] & 0x01;
  mh->mode = (buffer[3] >> 6) & 0x3;
  mh->mode_ext = (buffer[3] >> 4) & 0x03;
  mh->copyright = (buffer[3] >> 3) & 0x01;
  mh->original = (buffer[3] >> 2) & 0x1;
  mh->emphasis = (buffer[3]) & 0x3;
  mh->stereo = (mh->mode == MPG_MD_MONO) ? 1 : 2;

  /* figure out the framesize */

  switch(mh->lay)
    {
    case 1:
      mh->framesize  = (long)bitrates[mh->version][mh->lay-1][mh->bitrate_index] * 12000;
      mh->framesize /= s_freq[mh->version][mh->sampling_frequency];
      mh->framesize  = ((mh->framesize+mh->padding)<<2)-4;
      break;
    case 2:
      mh->framesize = (long)bitrates[mh->version][mh->lay-1][mh->bitrate_index] * 144000;
      mh->framesize /= s_freq[mh->version][mh->sampling_frequency];
      mh->framesize += mh->padding - 4;
      break;
    case 3:
      mh->framesize  = (long) bitrates[mh->version][mh->lay-1][mh->bitrate_index] * 144000;
      mh->framesize /= s_freq[mh->version][mh->sampling_frequency]<<(mh->version);
      mh->framesize += mh->padding - 4;
      break;
    }

  {
    int byterate = bitrates[mh->version][mh->lay-1][mh->bitrate_index] * 1000 / 8;
    mh->frametime = (mh->framesize * 1000000) / byterate;
  }
  return 0;
}

/* "all or nothing" read; if we read something,
 * but not size, it's an unexpected EOF, so
 * return 0 */
int 
fullread(int fd, char *buf, size_t size)
{
  int ret, sizeleft = size;
  
  while(sizeleft)
    {
      ret = read(fd, buf, sizeleft);
      if(ret == -1) {
	  if(errno == EINTR)
	      continue;
	  if(errno == EAGAIN) {
	      /* probably shouldn't happen, but does
	       * occasionally: a partial packet from
	       * a sender. keep trying, but delay so
	       * as not to eat cpu */
	      usleep(5000);
	      continue;
	  }
	  return ret;
      }

      if(ret > 0) {
	  sizeleft -= ret;
	  buf+=ret;
	  
	  if(sizeleft == 0)
	      return size;
      }
      if(ret == 0) {
	  /* EOF; sizeleft != 0*/
	  return 0;
      }
    }
  return size;
}

/* shift buf left one byte, and fill it in with one
 * byte from fd; return 1 on success, 0 on EOF, -1 on failure */
static int
shift_mp3_header(int fd, char *buf)
{
  buf[0] = buf[1];
  buf[1] = buf[2];
  buf[2] = buf[3];
  return fullread (fd, buf+3, 1);
}

/* find the next header, read it, and return it in mh.
 * return 0 on success, -1 with errno set on failure. */
int
read_mp3_header (int fd, mp3_header_t *mh)
{
  unsigned char buf[4];
  size_t readsize;
  int pos;
  
  readsize = fullread (fd, buf, 4);
  if (readsize < 4)
    {
      return -1;
    }
 
  /* search byte by byte for an mp3 header, up to
   * 1024 bytes. more? */
  pos = 0;
  
  while(decode_mp3_header(mh, buf) != -1)
    {
      if(pos++ == 1024)
	{
	  close (fd);
	  return -1;
	}
	      
      buf[0] = buf[1];
      buf[1] = buf[2];
      buf[2] = buf[3];
      readsize = fullread (fd, &buf[3], 1);
      if(readsize < 1)
	{
	  return -1;
	}
    }

  return 0;
}

int 
read_frame(int fd, unsigned char *buf, mp3_header_t *rmh)
{
  int ret;
  mp3_header_t mh;

  if((ret = fullread(fd, buf, 4)) <= 0)
      return ret;

  if(buf[0] == 'T' && buf[1] == 'A' && buf[2] == 'G')
    {
      /* ID tag.  Skip it and return EOF */
      if((ret=fullread(fd,buf,124)) <= 0)
	  return ret;

      return 0;
    }

  if(buf[0] == 'R' && buf[1] == 'I' && buf[2] == 'F' && buf[3] == 'F')
    {
      /* *sigh* perhaps we should include a small util to remove these
       * things */
      while(buf[0] != 'd' || buf[1] != 'a' || buf[2] != 't' || buf[3] != 'a')
	{
	  if((ret = shift_mp3_header(fd, buf)) <= 0)
	      return ret;
	}
      
      if((ret = fullread(fd, buf, 4)) <= 0)
	  return ret;
      
      return read_frame(fd, buf, rmh);
    }
  
  if(decode_mp3_header(&mh, buf) == -1)
    {
      return -1;
    }

  if(rmh) *rmh = mh;

  if((ret = fullread(fd,buf+4,mh.framesize)) <= 0) return ret;
  return ret+4;
}









