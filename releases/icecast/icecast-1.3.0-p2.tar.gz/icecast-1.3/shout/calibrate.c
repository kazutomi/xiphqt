#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <syslog.h>
#include <netdb.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>

#include "shout.h"

extern int errno;
int s;
typedef struct host_n_portSt
{
  char *host;
  int port;
} host_n_port_t;

void s1gnal (const int sig);
int strip_ice_header (char *head, int len);
int strip_shout_header (char *head, int len);
host_n_port_t *get_url_host_and_port (char *string);
int find_frame_ofs (char *buff, int len);
char buf[8192];

#define abuf_size 8192
#define LBUFSIZE 8192

char audiobuf[abuf_size];

int
main (int argc, char **argv)
{
	int i = 0, n, len, proxy = 0, lastoutframe;
	int header_bytes, body_bytes, current_bytes = 0;
	int metaoffset;
	int show_frames = 0, show_speed = 0;
	int outfd;

	time_t start_time, t1, t2;

	char *contacthost = NULL;	
	int contactport = 0;

	struct hostent *hp;
	struct sockaddr_in name;
	
	if ((argc < 3) || (argc == 4))
	{
		if ((argc > 1 ) && (strncmp (argv[1], "-v", 2) == 0))
		{
			printf ("calibrate version 0.0.1 <eel@musiknet.se>\n");
			exit (2);
		}
		else if ((argc > 1) && strncmp (argv[1], "http://", 7) == 0)
		{
			host_n_port_t *hp = get_url_host_and_port (argv[1]);
			contacthost = hp->host;
			contactport = hp->port;
		}
		else
		{
			fprintf (stderr, 
				 "Usage: %s <hostname> <port> [<proxy> <proxyport>].\n", 
				 argv[0]);	
			exit (1);
		}
	}
	
	if (!contacthost)
	{
		contacthost = argv[1];
		contactport = atoi (argv[2]);
	}
	
	if (argc == 5)
	{
		proxy = 1;
		contacthost = argv[3];
		contactport = atoi (argv[4]);
		fprintf (stderr, "Using proxy %s:%d...\n", contacthost, contactport);
	}
	
	if ((hp = gethostbyname (contacthost)) == NULL)
	{
		fprintf (stderr, "unknown host: %s.\n", contacthost);
		exit (1);
	}
	
	/* Create socket */
	if ((s = socket (AF_INET, SOCK_STREAM, 6)) < 0)
	{
		perror ("socket:");
		exit (1);
	}
	
	/* Create server adress */
	memset (&name, 0, sizeof (struct sockaddr_in));
	name.sin_family = AF_INET;
	name.sin_port = htons (contactport);
	memcpy (&name.sin_addr, hp->h_addr_list[0], hp->h_length);
	len = sizeof (struct sockaddr_in);
	
	/* Connect to the server */
	fprintf (stderr, "Connecting to %s port %d\n", contacthost, contactport);
	if (connect (s, (struct sockaddr *) &name, len) < 0)
	{
		fprintf (stderr, "Could not connect to %s.\n", contacthost);
		perror ("connect:");
		exit (1);
	}
	
	signal (SIGPIPE, s1gnal);
	signal (SIGINT, s1gnal);
	
	/* Read from standard input and put on the socket */
	fprintf (stderr, "Sending request...\n");
	
	if (proxy)
#ifdef HAVE_SNPRINTF
		snprintf (buf, LBUFSIZE, "GET http://%s:%s/ HTTP/1.0\r\nHOST: %s\r\nUser-Agent: winamp/fake\r\nIcy-MetaData:1\r\nAccept: */*\r\n\r\n", argv[1], 
			  argv[2], argv[1]);
#else
	sprintf (buf, "GET http://%s:%s/ HTTP/1.0\r\nHOST: %s\r\nUser-Agent: winamp/fake\r\nIcy-MetaData:1\r\nAccept: */*\r\n\r\n", argv[1], argv[2], 
		 argv[1]);
#endif
	else
	{
		my_snprintf (buf, LBUFSIZE, 
			     "GET / HTTP/1.0\r\nHost: %s\r\nUser-Agent: winamp/fake\r\nIcy-MetaData:1\r\nAccept: */*\r\n\r\n", 
			     argv[1]);
	}
	send (s, buf, strlen (buf), 0);
	
	fprintf (stderr, "Reading response..\n");
	/* Make sure we read LBUFSIZE before we go on */
	start_time = time (NULL);
	header_bytes = 0;
	body_bytes = 0;
	n = 0;
	
	while ((n = recv (s, &audiobuf[i], 1, 0)) > 0)
	{
		if (n > 0)
			header_bytes += n;
		else if (n < 0)
		{
			fprintf (stderr, "Socket error.. \n");
			exit (1);
		}
		
		if (strstr (audiobuf, "\n\n"))
			break;
		if (strstr (audiobuf, "\n\r\n"))
			break;
		i++;
	}
	
	audiobuf[i] = '\0';
	printf ("[%s]\n", audiobuf);
	fflush (stdout);
	i = 0;

	t2 = time (NULL);

	#ifdef USE_DUMPFILE
	outfd = open ("dumpfile", O_WRONLY|O_TRUNC|O_CREAT, 00644);
	#endif
	lastoutframe = 0;
	metaoffset = 0;

	while ((n = recv (s, audiobuf, abuf_size, 0)))
	{
		i = n;
		while (n < abuf_size)
		{
			i = recv (s, &audiobuf[n], abuf_size - n, 0);
			if (i < 0)
			{
				fprintf (stderr, "Socket error.. \n");
				exit (1);
			}
			n += i;
		}
		
#ifdef USE_DUMPFILE
		write (outfd, audiobuf, n);
#endif
		
		t1 = time (NULL);
		
		for (i = 0; i < n; i++)
                {
			if (show_frames)
			{
				if ((audiobuf[i] & 0xFF) == 0xFF && (audiobuf[i + 1] & 0xF0) == 0xF0)
				{
					if (lastoutframe)
						printf (", %d", body_bytes + i);
					else
						printf ("\nFrame header found at offset %d", body_bytes + i);
					
					lastoutframe = body_bytes + i;
				}
			}
			
                        if (audiobuf[i] == 'S' && audiobuf[i + 1] == 't' && audiobuf[i + 2] == 'r')
			{
				char *ptr = strstr (&audiobuf[i], "StreamTitle");
				if (ptr)
				{
					int nulls = 0;
					int len;
					
					if (n > 0)
						len = (int) (audiobuf[i - 1]) * 16;
					else
						len = 0;
					
					printf ("Metainfo found at offset %d [%s] [%d bytes off target]\n", body_bytes + i - 1, ptr,
						((body_bytes + (i - 1) - metaoffset) % 8192));
					
					if (strlen (ptr) + 1 > len)
						printf ("Invalid length meta info [%d] [%d]\n", strlen (ptr) + 1, len);
					else
						printf ("Metainfo length %d + %d\n", strlen (ptr) + 1, len);

					metaoffset += len;
					lastoutframe = 0;
				}
				
			}

		}

		if (body_bytes != 0)
			metaoffset += 1;

		body_bytes += n;

		
			if (t1 > t2)
			{
				printf ("%d bytes read, %d bytes total, %fbps total", n, body_bytes, 				
					8 * (float) body_bytes / (float) (t1 - start_time));
				printf (" %fbps current\n", 8 * (float) (body_bytes - current_bytes) / (float) (t1 - t2));
				t2 = time (NULL);
				current_bytes = body_bytes;
				lastoutframe = 0;
			}
			n = 0;
	}
	return 1;
}

/* Shoutcasts variant: 
   http://www.shoutcast.com/cgi-bin/shoutcast-playlist.pls?addr=62.108.29.47:8000&file=filename.pls
   Icecast: 
   http://icecast.linuxpower.org/cgi-bin/gen-playlist.pls?server=129.237.50.80&port=8000 */

host_n_port_t *
get_url_host_and_port (char *string)
{
  host_n_port_t *hp = (host_n_port_t *) malloc (sizeof (host_n_port_t));
  char *string_m = (char *) malloc (strlen (string) + 1);
  char *mark;

  /* Lose the part before '=' */
  if (splitc (NULL, string, '=') == NULL)
    {
      fprintf (stderr, "Invalid url (didn't contain =), exiting\n");
      exit (2);
    }

  if ((mark = strchr (string, ':')) == NULL)
    {
      if (splitc (string_m, string, '&') == NULL)
	{
	  fprintf (stderr, "Invalid url, (didn't contain &), exiting\n");
	  exit (3);
	}
      hp->host = string_m;
      if (splitc (NULL, string, '=') == NULL)
	{
	  fprintf (stderr, "Couldn't read portnum, (no =), exiting\n");
	  exit (4);
	}
      hp->port = atoi (string);
      return hp;
    }

  splitc (string_m, string, ':');
  hp->port = atoi (string);
  hp->host = string_m;
  return hp;
}

int
strip_shout_header (char *head, int n)
{
  int i;
  for (i = 0; i < (n - 2); i++)
    {
      if (head[i] == 10 && head[i + 1] == 13)
	break;
      if (head[i] == '\n' && head[i + 1] == '\n')
	break;
    }
  head[i + 1] = '\0';
  fprintf (stderr, "Server said:%s\n", head);
  memcpy (buf, head, n - (i + 1));
  return n - (i + 1);
}

int
strip_ice_header (char *head, int n)
{
  int i;
  for (i = 0; i < (n - 2); i++)
    {
      if ((head[i] == '\n') && (head[i + 1] == '\n'))
	break;
    }
  head[i + 1] = '\0';
  fprintf (stderr, "Server said:%s\n", head);
  memcpy (buf, head, n - (i + 1));
  return n - (i + 1);
}

void 
s1gnal (const int sig)
{
  switch (sig)
    {
      case SIGPIPE:
	fprintf (stderr, 
		 "Caught signal %d, guess the player exited. Damn.\n", sig);
#ifdef DEBUG
	fprintf (stderr, "The last we fead it was:\n[%s]\n", buf);
	fprintf (stderr, "Which, in hex would be:\n[%p]\n", buf);
#endif
	exit (1);
	break;
      case SIGINT:
	fprintf (stderr, "Caught signal %d, exiting nicely.\n", sig);
	close (s);
	exit (0);
	break;
    }
}

char *
splitc (char *first, char *rest, const char divider)
{
  char *p;
  p = strchr (rest, divider);
  if (p == NULL)
    {
      if ((first != rest) && (first != NULL))
	first[0] = 0;
      return NULL;
    }
  *p = 0;
  if (first != NULL) strcpy (first, rest);
  if (first != rest) strcpy (rest, p + 1);
  return rest;
}

int 
find_frame_ofs (char *buff, int len)
{
  int pos = 0;
  
  while (pos < len) 
    {
      if ((buff[pos] & 0xFF) == 0xFF && (buff[pos + 1] & 0xF0) == 0xF0)
	break;
      pos++;
    }
  
  return pos;
}

