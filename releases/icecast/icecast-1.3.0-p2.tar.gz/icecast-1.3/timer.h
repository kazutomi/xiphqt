#ifndef ICECAST_TIMER_H
#define ICECAST_TIMER_H

void *startup_timer_thread(void *arg);
void *startup_heartbeat_thread(void *arg);
void *startup_udp_info_thread (void *arg);
void status_write(server_info_t *info);
void get_hourly_stats(statistics_t *stat);
void write_hourly_stats(statistics_t *stat);
void update_daily_statistics(statistics_t *stat);
void get_daily_stats(statistics_t *stat);
void update_total_statistics(statistics_t *stat);
void write_daily_stats(statistics_t *stat);
void zero_stats(statistics_t *stat);
void get_current_stats(statistics_t *stat);
void get_running_stats(statistics_t *stat);
void add_stats(statistics_t *target, statistics_t *source, unsigned long int factor);
int udp_update_streamtitle (SOCKET s, connection_t *sourcecon, connection_t *clicon);
int udp_update_streamurl (SOCKET s, connection_t *sourcecon, connection_t *clicon);
#endif
