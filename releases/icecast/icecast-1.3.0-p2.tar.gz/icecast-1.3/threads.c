/* threads.c
 * - Thread Abstraction Functions
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any latfer version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#ifndef __USE_BSD
#define __USE_BSD
#endif
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <time.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#ifdef _WIN32
#define HAVE_ASSERT_H
#endif

#ifdef HAVE_ASSERT_H
#include <assert.h>
#endif

#ifdef _WIN32
#include <windows.h>
# ifndef STACKSIZE
#  define STACKSIZE 8192
# endif
#else
#include <pthread.h>
#include <sys/socket.h>
#endif

#include "avl.h"
#include "threads.h"
#include "icetypes.h"
#include "icecast.h"
#include "log.h"
#include "utility.h"
#include "ice_string.h"
#include "logtime.h"
#include "main.h"
#include "memory.h"
#include <signal.h>

extern server_info_t info;

mutex_t library_mutex = {MUTEX_STATE_UNINIT};

#ifdef MEMORY_DEBUG
void thread_mem_check(mythread_t *thread)
{
	avl_traverser trav = {0};
	meminfo_t *mt;

	thread_mutex_lock(&info.memory_mutex);

	while ((mt = avl_traverse(info.mem, &trav))) {
		if (mt->thread_id == thread->id)
			xa_debug(1, "WARNING: %d bytes allocated by thread %d at line %d in %s not freed before thread exit", mt->size, thread->id, mt->line, mt->file);
	}
	
	thread_mutex_unlock(&info.memory_mutex);
}
#endif

thread_t thread_create_c(char *name, void *(*start_routine)(void *), void *arg, int line, char *file)
{
#ifndef _WIN32
	thread_t thread;
	int i;
#else
	HANDLE ret;
#endif
	mythread_t *mt = (mythread_t *)nmalloc(sizeof(mythread_t));

	mt->line = line;
	mt->file = nstrdup(file);
	mt->id = new_thread();
	mt->name = nstrdup (name);
	mt->created = get_time();

#ifdef _WIN32
	ret = CreateThread(NULL, STACKSIZE, (LPTHREAD_START_ROUTINE)start_routine, arg, 0, &mt->thread);
#else
	/* Why is this here?  Should we have to keep trying? -jm 
	   No reason other than that if the system is temporarily out of
	   resources, then icecast survives. - Eel   */
	for (i = 0; i < 10; i++) {
#ifdef hpux
		if (pthread_create ((pthread_t *) &thread, pthread_attr_LOG_DEFAULT,
				    (pthread_startroutine_t) start_routine,
				    (pthread_addr_t) arg) == 0)
#else
	        if (pthread_create(&thread, NULL, start_routine, arg) == 0)
#endif
			break;
		else
			write_log(LOG_DEFAULT, "ERROR: Could not create new thread, retrying");
	}
	
	mt->thread = thread;
#endif
	
#ifdef _WIN32
	if (ret == NULL) {
#else
	if (i >= 10) {
#endif
		write_log(LOG_DEFAULT, "System won't let me create more threads, giving up");
		clean_shutdown(&info);
	}

	internal_lock_mutex(&info.thread_mutex);
	avl_insert(info.threads, mt);
	internal_unlock_mutex(&info.thread_mutex);

	xa_debug(2, "DEBUG: Adding thread started at [%s:%d]", file, line);

#ifndef _WIN32
#ifdef hpux
	pthread_detach((pthread_t *) &thread);
#else
	pthread_detach(thread);
#endif
#endif

	return mt->thread;
}

void thread_create_mutex_c(mutex_t *mutex, int line, char *file)
{
	mutex->thread_id = MUTEX_STATE_NEVERLOCKED;
#ifdef _WIN32
	InitializeCriticalSection(&mutex->mutex);
#else
#ifdef hpux
	pthread_mutex_init (&mutex->mutex, pthread_mutexattr_default);
#else
	pthread_mutex_init(&mutex->mutex, NULL);
#endif
#endif
}

void thread_mutex_destroy(mutex_t *mutex)
{
#ifdef _WIN32
	DeleteCriticalSection(&mutex->mutex);
#else
	pthread_mutex_destroy(&mutex->mutex);
#endif
}

void thread_mutex_lock_c(mutex_t *mutex, int line, char *file)
{
#ifdef OPTIMIZE
	internal_lock_mutex(mutex);
#else
	mythread_t *mt = get_mythread();

#ifndef SAVE_CPU
	char name[40];
	xa_debug (4, "Locking %p (%s) on line %d in file %s by thread %d", mutex, mutex_to_string(mutex, name), line, file, mt ? mt->id : -1);
#endif

	if (mt) {
		if (mutex->thread_id == mt->id)	{
			write_log(LOG_DEFAULT, "DEADLOCK AVOIDED, please notify team@icecast.org!");
			return;
		}
	}

	internal_lock_mutex(mutex);
	
	if (mt)
		mutex->thread_id = mt->id;
#endif
}

void thread_mutex_unlock_c(mutex_t *mutex, int line, char *file)
{
#ifdef OPTIMIZE
	internal_unlock_mutex(mutex);
#else
	mythread_t *mt = get_mythread();
	
#ifndef SAVE_CPU
	char name[40];
	xa_debug(4, "Unlocking %p (%s) on line %d in file %s by thread %d", mutex, mutex_to_string (mutex, name), line, file, mt ? mt->id : -1);
#endif

	mutex->thread_id = MUTEX_STATE_NOTLOCKED;
	internal_unlock_mutex(mutex);
#endif
}

void thread_exit_c(int val, int line, char *file)
{
	mythread_t *out, *mt = get_mythread();
	
	if (mt)	{
		xa_debug(2, "DEBUG: Removing thread %d started at [%s:%d], reason: 'Thread Exited'", mt->id, mt->file, mt->line);

		internal_lock_mutex(&info.thread_mutex);
		out = avl_delete(info.threads, mt);
		internal_unlock_mutex(&info.thread_mutex);

		if (out) {
#ifdef MEMORY_DEBUG
			thread_mem_check(mt);
#endif
			nfree(out->file);
			nfree(out->name);
			nfree(out);
		}
	}
	
#ifdef _WIN32
	ExitThread(val);
#else
	pthread_exit((void *)val);
#endif
}


void init_thread()
{
#ifndef _WIN32
#  ifdef PTHREAD_CANCEL_ENABLE
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
#  endif
#endif
}

thread_t thread_self()
{
#ifdef _WIN32
    return GetCurrentThreadId();
#else
    return pthread_self();
#endif
}

int thread_equal(thread_t t1, thread_t t2)
{
#ifdef _WIN32
    return (t1 == t2) ? 1 : 0;
#else
    return pthread_equal(t1, t2);
#endif
}

unsigned long new_thread()
{
	info.threadid++;
	return info.threadid;
}

mythread_t *get_mythread()
{
	avl_traverser trav = {0};
	mythread_t *mt;
	
	if (info.threads == NULL)
		return NULL;
	
	internal_lock_mutex(&info.thread_mutex);

	while ((mt = avl_traverse(info.threads, &trav))) {
		if (thread_equal(thread_self(), mt->thread)) {
			internal_unlock_mutex(&info.thread_mutex);
			return mt;
		}
	}
	
	internal_unlock_mutex (&info.thread_mutex);
	return NULL;
}

void internal_lock_mutex(mutex_t *mutex)
{
#ifdef _WIN32
	EnterCriticalSection(&mutex->mutex);
#else
	pthread_mutex_lock(&mutex->mutex);
#endif
}

void internal_unlock_mutex(mutex_t *mutex)
{
#ifdef _WIN32
	LeaveCriticalSection(&mutex->mutex);
#else
	pthread_mutex_unlock(&mutex->mutex);
#endif
}

void thread_lib_init()
{
	thread_create_mutex (&library_mutex);	
}

void thread_library_lock()
{
	/* make sure thread_lib_init() was called! */
	assert(library_mutex.thread_id != MUTEX_STATE_UNINIT); 
	internal_lock_mutex(&library_mutex);
}

void thread_library_unlock()
{
	internal_unlock_mutex(&library_mutex);
}


