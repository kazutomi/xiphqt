#ifndef __AVL_FUNCTIONS_H
#define __AVL_FUNCTIONS_H

int compare_restricts (const void *first, const void *second, void *param);
int compare_vars (const void *first, const void *second, void *param);
int compare_strings (const void *first, const void *second, void *param);
int compare_connection(const void *first, const void *second, void *param);
int compare_aliases(const void *first, const void *second, void *param);
int compare_threads(const void *first, const void *second, void *param);
int compare_directories(const void *first, const void *second, void *param);
int compare_relays(const void *first, const void *second, void *param);
int compare_mem (const void *first, const void *second, void *param);
void free_connection(void *data, void *param);
void zero_trav(avl_traverser *trav);
void *avl_get_any_node (avl_tree *tree);
#endif
