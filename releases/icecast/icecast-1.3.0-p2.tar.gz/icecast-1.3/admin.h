/* admin.h
 * - Admin Function Headers
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifndef __ICECAST_ADMIN_H
#define __ICECAST_ADMIN_H

extern server_info_t info;

admin_t *create_admin();
void admin_login(connection_t *con, char *line);
void *handle_admin(void *vcon);
void handle_remote_admin(connection_t *con);
void put_admin(connection_t *con);
void add_admin ();
void del_admin ();
void add_icecast_console ();
void describe_admin (const connection_t *con, const connection_t *admcon);
#endif
