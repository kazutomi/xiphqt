<?php;

require("functions.phps");
db_connect();

echo "<table border=0>\n";

$result = mysql_query ("select * from xaudiocast_server_tbl order by id desc");
echo "<tr>";
echo "<td>id</td>";
echo "<td>ip</td>";
echo "<td>servername</td>";
echo "<td>serverversion</td>";
echo "<td>port</td>";
echo "<td>listeners</td>";
echo "<td>maxlisteners</td>";
echo "<td>maxlistenersperstream</td>";
echo "<td>averagelistenertime</td>";
echo "<td>averagesourcetime</td>";
echo "<td>maxsources</td>";
echo "<td>email</td>";
echo "<td>location</td>";
echo "<td>touchtime</td>";
echo "<td>starttime</td>";
echo "</tr>";

while ($row = mysql_fetch_object($result)) {
	echo "<tr>";
	echo "<td>$row->id</td><td>$row->ip</td><td>$row->servername</td><td>$row->serverversion</td><td>$row->port</td>\n";
	echo "<td>$row->listeners</td><td>$row->maxlisteners</td><td>$row->maxlistenersperstream</td><td>$row->averagelistenertime</td>\n";
	echo "<td>$row->averagesourcetime</td><td>$row->maxsources</td><td>$row->email</td><td>$row->location</td><td>$row->touchtime</td>\n";
	echo "<td>$row->starttime</td>";
}

echo "</table>"
?>
