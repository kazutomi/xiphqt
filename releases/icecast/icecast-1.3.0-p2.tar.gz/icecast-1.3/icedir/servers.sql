drop table servers;
create table servers (
	server_id int not null auto_increment,
	
	ip varchar(30) not null,
	host varchar(255) not null,
	port int not null,
	type varchar(255),
	version varchar(255),
	listeners int,
	maxlisteners int,
	maxstreamlisteners int,
	maxsources int,
	alt int,
	ast int,
	url varchar(255),
	email varchar(255),
	location varchar(255),

	starttime datetime not null,
	touchtime datetime not null,
	touched int not null,

	primary key (server_id)
);
