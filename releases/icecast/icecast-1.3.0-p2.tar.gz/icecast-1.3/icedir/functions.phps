<?php;
// functions.phps
//
// Copyright (c) 1999 Jack Moffitt, Barath Raghavan
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//

function db_connect() {
        $server = "beo-console";
        $user = "web-sql";
        $password = "abc123";
        $database = "test"; 

	mysql_pconnect("$server", "$user", "$password") or die("Unable to connect to server\n");
	mysql_select_db($database) or die("unable to select database\n");
}
?>
