#!/usr/bin/perl

use strict;
use Mysql;

my $dbh;

$dbh = Mysql->connect("localhost", "sometable", "someuser", "somepass");

if ($dbh) {
	$dbh->query("delete from servers where UNIX_TIMESTAMP() - UNIX_TIMESTAMP(touchtime) > 600");
	$dbh->query("delete from sources where UNIX_TIMESTAMP() - UNIX_TIMESTAMP(touchtime) > 600");
}
