<?php;

require("functions.phps");
db_connect();

echo "<table border=0>\n";

$result = mysql_query ("select * from xaudiocast_server_tbl order by id desc");
echo "<tr>";
echo "<td>id</td>";
echo "<td>server_id</td>";
echo "<td>orig_id</td>";
echo "<td>mountpoint</td>";
echo "<td>streamname</td>";
echo "<td>streamdesc</td>";
echo "<td>streamgenre</td>";
echo "<td>streamurl</td>";
echo "<td>listeners</td>";
echo "<td>averagelistenertime</td>";
echo "<td>touched</td>";
echo "<td>bitrate</td>";
echo "</tr>";

while ($row = mysql_fetch_object($result)) {
	echo "<tr>";
	echo "<td>$row->id</td><td>$row->server_id</td><td>$row->mountpoint</td><td>$row->streamname</td><td>$row->streamdesc</td>\n";
	echo "<td>$row->streamurl</td><td>$row->listeners</td><td>$row->averagelistenertime</td><td>$row->touched</td>\n";
	echo "<td>$row->bitrate</td>\n"
}

echo "</table>"
?>
