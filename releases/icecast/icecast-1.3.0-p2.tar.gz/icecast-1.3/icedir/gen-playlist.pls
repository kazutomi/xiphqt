<?
  header("Content-type: audio/x-scpls");

  $mount = ereg_replace("\/(.*)", "\\1", $mount);
  echo "[playlist]\n";
  echo "NumberOfEntries=15\n";
  echo "File1=http://$server:$port/$mount\n";
?>
