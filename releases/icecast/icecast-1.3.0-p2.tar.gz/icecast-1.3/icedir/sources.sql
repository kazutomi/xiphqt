drop table sources;
create table sources (
	server_id int not null,

	mount varchar(200) not null,
	genre varchar(255),
	name varchar(255),
	description varchar(255),
	url varchar(255),
	bitrate int,
	alt int,
	listeners int,
	stream_title varchar(255),
	stream_url varchar(255),

	touchtime datetime not null,

	primary key (server_id, mount)
);
