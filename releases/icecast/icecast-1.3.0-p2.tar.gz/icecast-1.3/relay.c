/* relay.c
 * - Relay functions *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <errno.h>
# ifndef __USE_BSD
#  define __USE_BSD
# endif
#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif

#include <string.h>
#include <stdlib.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#include <sys/types.h>
#include <time.h>
#include <fcntl.h>

#ifndef _WIN32
#include <sys/socket.h>
#else
#include <winsock.h>
#endif

#include "avl.h"
#include "threads.h"
#include "icetypes.h"
#include "icecast.h"
#include "utility.h"
#include "ice_string.h"
#include "connection.h"
#include "relay.h"
#include "threads.h"
#include "client.h"
#include "sock.h"
#include "source.h"
#include "log.h"
#include "memory.h"

extern int errno;

/* relay push <sourceid> <host:[port]> [-pmngdu <arg>] */
int relay_push (connection_t *admcon, char *arg)
{
	char host[BUFSIZE], buf[BUFSIZE], id[BUFSIZE];
	char carg[BUFSIZE];
	char password[BUFSIZE], mount_name[BUFSIZE], name[BUFSIZE];
	char genre[BUFSIZE], description[BUFSIZE], url[BUFSIZE];
	int bitrate, public, port, use_icy = 0, go_on = 1;
	SOCKET sockfd;
	connection_t *con, *relaycon;
	source_t *source;

	if (!arg || !arg[0] || (splitc (id, arg, ' ') == NULL)) {
		sock_write_line (admcon->sock, "usage: relay push <sourceid> <host[:port]> [options]");
		return 0;
    }
  
  if (splitc (host, arg, ':') == NULL)
  {
	  if (splitc (host, arg, ' ') == NULL)
		  strcpy (host, arg);
	  port = DEFAULT_PORT;
  }
  else
	  port = atoi (arg);
  
  sock_write_line (admcon->sock, "Connecting source %d to port %d on %s", 
	      atoi (id), port, host);

  if ((sockfd = sock_connect (host, port)) == -1)
    {
      sock_write_line (admcon->sock, "Could not connect to port %d on host %s", 
		  host, port);
      return 0;
    }
  
  sock_write_line (admcon->sock, "Source %d attached to socket %d", atoi (id), 
	      sockfd);
  
  {
    int tmp = 1;
    setsockopt (sockfd, SOL_SOCKET, SO_KEEPALIVE, (void *)&tmp, sizeof (tmp));
#ifdef INCREASED_BUFFER
    tmp = 100000;
    setsockopt (sockfd, SOL_SOCKET, SO_SNDBUF, (void *)&tmp, sizeof (tmp));
#endif
  }
    
  con = find_source_with_id (atoi (id));
  if (!con || (con->type != source_e))
    {
      sock_write_line (admcon->sock, "No source with id %d", atoi (id));
      sock_close(sockfd);
      return 0;
    }

  source = con->food.source;

  strncpy (password, info.encoder_pass, BUFSIZE);
  strncpy (url, source->audiocast.url, BUFSIZE);
  strncpy (description, source->audiocast.description, BUFSIZE);
  strncpy (name, source->audiocast.name, BUFSIZE);
  strncpy (genre, source->audiocast.genre, BUFSIZE);
  strncpy (mount_name, source->audiocast.mount, BUFSIZE);

  public = source->audiocast.public;
  bitrate = source->audiocast.bitrate;
  
  do
    {
      if (splitc (buf, arg, ' ') == NULL)
	{
	  go_on = 0;
	  strcpy (buf, arg);
	} else {
		if (buf[0] == '-' && buf[1] != 'i' && splitc (carg, arg, ' ') != NULL)
		{
			if (carg[0] == '-' || (strcmp (carg, buf) == 0))
			{
				sock_write_line (admcon->sock, "Option %c requires an argument", buf[1]);
				sock_close (sockfd);
				return 0;
			}
		} else {
			strcpy (carg, arg);
		}
	}
      
      if (buf[0] == '-')
	{
		xa_debug (2, "DEBUG: buf: [%s] arg: [%s] carg: [%s]", buf, arg, carg);
		
		switch (buf[1])
		{
			case 'p':
				strncpy (password, carg, BUFSIZE);
				break;
			case 'u':
				strncpy (url, carg, BUFSIZE);
				break;
			case 'm':
				strncpy (mount_name, carg, BUFSIZE);
				break;
			case 'n':
				strncpy (name, carg, BUFSIZE);
				break;
			case 'g':
				strncpy (genre, carg, BUFSIZE);
				break;
			case 'P':
				public = atoi (carg);
				break;
			case 'b':
				bitrate = atoi (carg);
				break;
			case 'd':
				strncpy (description, carg, BUFSIZE);
				break;
			case 'i':
				use_icy = 1;
				break;
		}
	}
    } while (go_on);
  
  if (use_icy)
    {
	    sock_write_line (admcon->sock, "Logging in with icy headers on relay %s", host);

	    sock_write_line (sockfd, "%s", password);
	    
	    if (recv (sockfd, buf, 100, 0) < 0)
	    {
		    sock_write_line (admcon->sock, "Error in read, aborting relay");
		    sock_close(sockfd);
		    return 0;
	    }
	    
	    if (buf[0] != 'O' && buf[0] != 'o')
	    {
		    sock_write_line (admcon->sock, "Error in connect, invalid password?");
		    sock_close(sockfd);
		    return 0;
	    }
	    
	    sock_write_line (admcon->sock, "icy-name:%s", name);
	    sock_write_line (sockfd, "icy-name:%s", name);

	    sock_write_line (admcon->sock, "icy-genre:%s", genre);
	    sock_write_line (sockfd, "icy-genre:%s", genre);

	    sock_write_line (admcon->sock, "icy-url:%s", url);
	    sock_write_line (sockfd, "icy-url:%s", url);

	    sock_write_line (admcon->sock, "icy-pub:%d", public);
	    sock_write_line (sockfd, "icy-pub:%d", public);

	    sock_write_line (admcon->sock, "icy-br:%d", bitrate);
	    sock_write_line (sockfd, "icy-br:%d", bitrate);
    }
  else
    {
	    avl_traverser trav = {0};
	    relay_id_t *rip;

	    sock_write_line (admcon->sock, "Logging in with x-audiocast headers on relay %s as mount %s", host, 
			     mount_name);
	    sock_write_line (sockfd, "SOURCE %s %s\r\n", password, mount_name);
	    
	    sock_write_line (admcon->sock, "x-audiocast-name:%s", name);
	    sock_write_line (sockfd, "x-audiocast-name:%s", name);
	    
	    sock_write_line (admcon->sock, "x-audiocast-genre:%s", genre);
	    sock_write_line (sockfd, "x-audiocast-genre:%s", genre);

	    sock_write_line (admcon->sock, "x-audiocast-url:%s", url);
	    sock_write_line (sockfd, "x-audiocast-url:%s", url);

	    sock_write_line (admcon->sock, "x-audiocast-public:%d", public);
	    sock_write_line (sockfd, "x-audiocast-public:%d", public);

	    sock_write_line (admcon->sock, "x-audiocast-bitrate:%d", bitrate);
	    sock_write_line (sockfd, "x-audiocast-bitrate:%d", bitrate);

	    sock_write_line (admcon->sock, "x-audiocast-description:%s", description);
	    sock_write_line (sockfd, "x-audiocast-description:%s", description);

	    while ((rip = avl_traverse (source->relay_tree, &trav)))
	    {
		    sock_write (admcon->sock, "x-audiocast-directory:%s:%d\n", rip->host, rip->id);
		    sock_write (sockfd, "x-audiocast-directory:%s\n", rip->host, rip->id);
	    }
	    
	    sock_write_line (admcon->sock, "x-audiocast-type:%s", "relay");
	    sock_write_line (sockfd, "x-audiocast-type:%s\r\n", "relay");
	    
	    if (recv (sockfd, buf, 100, 0) < 0)
	    {
		    sock_write_line (admcon->sock, "Error in read [%d], aborting relay\n", 
				     errno);
		    sock_close (sockfd);
		    return 0;
	    }
	    
	    /* HTTP/1.0 200 OK || ICY 200 OK */
	    if (buf[0] != 'O' && buf[0] != 'o')
	      {
		sock_write_line (admcon->sock, "Error in connect, invalid password?");
		sock_close(sockfd);
		return 0;
	      }
    }
  
  sock_write_line (admcon->sock, "Adding to client tree of source %d", atoi (id));
  
  relaycon = create_connection ();
  relaycon->sock = sockfd;
  sock_set_blocking(relaycon->sock, SOCK_BLOCK);

  relaycon->host = nstrdup (host);
  if (info.reverse_lookups)
    relaycon->hostname = reverse (relaycon->host);
  relaycon->id = info.id;
  info.id++;
  relaycon->connect_time = time (NULL);
  put_client (relaycon);
  relaycon->food.client->virgin = 1;
  relaycon->food.client->errors = 0;
  relaycon->food.client->write_bytes = 0;
  relaycon->food.client->type = pusher_e;
  
  thread_mutex_lock (&source->mutex);
  relaycon->food.client->source = source;
  insert_client (source, relaycon);
  thread_mutex_unlock (&source->mutex);

  add_client ();

  sock_write_line (admcon->sock, "Done, using %s as relay", host);
  return 1;
}

/* relay pull <options> <host:port> <mountpoint> */
#define USAGE "Usage: relay pull <options> <url>"
int
relay_pull (connection_t *admcon, char *arg)
{
	char buf[BUFSIZE], options[BUFSIZE], localmount[BUFSIZE] = "";
	connection_t *con;
	sock_t sockfd;
	request_t req;

	if (!arg || !arg[0])
	{
		sock_write_line (admcon->sock, USAGE);
		return 0;
	}
	
	if (arg[0] == '-')
	{
		if (splitc (options, arg, ' ') == NULL)
		{
			sock_write_line (admcon->sock, USAGE);
			return 0;
		}

		else if (options[1] == 'm')
		{
			localmount[0] = '\0';
			if (splitc (localmount, arg, ' ') == NULL)
			{
				sock_write_line (admcon->sock, "Option -m requires an argument");
				return 0;
			}
			
		}
	}
	
	generate_http_request (arg, &req);

	if (!req.path[0])
	{
		sock_write_line (admcon->sock, "Invalid url syntax, please do better.");
		return 0;
	}

	sock_write_line (admcon->sock, "Connecting to relay [%s:%d%s], please wait...", req.host, req.port, req.path);
	
	if ((sockfd = sock_connect (req.host, req.port)) == -1)
	{
		sock_write_line (admcon->sock, "Could not connect to port %d on host %s", 
			    req.port, req.host);
		return 0;
	}
  
	sock_write_line (admcon->sock, "Connected to port %d on %s, sending request",
			 req.port, req.host);

	con = create_connection ();
	con->connect_time = time (NULL);
	con->type = source_e;
	con->host = forward (req.host, (char *) nmalloc (20));
	con->id = info.id;
	con->sock = sockfd;
	info.id++;
	if (info.reverse_lookups)
		con->hostname = reverse (con->host);
  
	put_source (con);
	con->food.source->type = puller_e;
	
	if (localmount[0])
		con->food.source->audiocast.mount = nstrdup (localmount);
	else
	{
		sprintf (buf, "%s:%d%s", req.host, req.port, req.path);
		con->food.source->audiocast.mount = nstrdup (buf);
	}
	
	/* This comes after, so we don't get kicked out */
	sock_write_line (sockfd, "GET %s HTTP/1.0\r\nHOST: %s", req.path, req.host);
	sock_write_line (sockfd, "User-Agent: icecast/%s\r\nReferer: RELAY\r\n", VERSION);
	
	/* Here the remote server prints audiocast headers or
	   some kind of error */
	if (!sock_read_lines (sockfd, buf, BUFSIZE))
	  {
	    kick_connection (con, "Error in read");
	    return 0;
	  }
	
	if (strncmp (buf, "ICY", 3) == 0)
	  {
	    xa_debug (1, "DEBUG: Relay using icy protocol");
	    con->food.source->protocol = icy_e;
	  } else {
	    char *ptr = strstr (buf, "Server:");
	    if (ptr)
	      {
		if (strncmp (ptr + 1, " icecast/1.3", 12) == 0)
		  xa_debug (1, "DEBUG: Relay using xaudiocast protocol");
		else
		  {
		    con->food.source->protocol = icy_e;
		    xa_debug (1, "DEBUG: Relay using icy protocol");
		  }
	      } else {
		con->food.source->protocol = icy_e;
		xa_debug (1, "DEBUG: Relay using icy protocol");
	      }
	  }
	
	/* If there was an error, we need to deal with it here */
	{
		char *sptr = strchr (buf, ' ');
		if (!sptr)
		{
			kick_connection (con, "Erroneous header");
			return 0;
		}
		if ((strncmp (buf, "HTTP/1.0 200", 12) != 0)
		    && (strncmp (buf, "ICY 200", 7) != 0))
		{
			kick_connection (con, "Error in request, relay refused entrance");
			return 0;
		}
	}

	sock_write_line (admcon->sock, "Adding relay to source tree");
	source_login (con, buf);
	sock_write_line (admcon->sock, "Done, using as relay");
	return 1;
}

connection_t *
relay_pull_stream (request_t *req)
{
	char buf[BUFSIZE], host[BUFSIZE], mount[BUFSIZE];
	connection_t *con;
	sock_t sockfd;
	unsigned long int ed;

	xa_debug (1, "DEBUG: relay_pull_stream called with [%s:%d%s]", req->host, req->port, req->path);

	if ((sockfd = sock_connect (req->host, req->port)) == -1)
		return NULL;

	con = create_connection ();
	con->connect_time = time (NULL);
	con->type = source_e;
	con->host = nstrdup (req->host);
	ed = con->id = info.id;
	con->sock = sockfd;
	info.id++;
	if (info.reverse_lookups)
		con->hostname = reverse (con->host);
  
	put_source (con);
	con->food.source->type = puller_e;

	sprintf (buf, "%s:%d%s", req->host, req->port, req->path);

	con->food.source->audiocast.mount = nstrdup (buf);
	
	/* This comes after, so we don't get kicked out */
	sock_write_line (sockfd, "GET /%s HTTP/1.0\r\nHOST: %s", mount, host);
	sock_write_line (sockfd, "User-Agent: icecast/%s\r\nReferer: RELAY\r\n", VERSION);
	
	/* Here the remote server prints audiocast headers or
	   some kind of error */
	if (!sock_read_lines (sockfd, buf, BUFSIZE))
	{
		kick_connection (con, "Error in read");
		return NULL;
	}
  
	if (strncmp (buf, "ICY", 3) == 0)
	{
		xa_debug (1, "DEBUG: Relay using icy protocol");
		con->food.source->protocol = icy_e;
	} else {
		char *ptr = strstr (buf, "Server:");
		if (ptr)
		{
			if (strncmp (ptr + 1, " icecast/1.3", 12) == 0)
				xa_debug (1, "DEBUG: Relay using xaudiocast protocol");
			else
			{
				con->food.source->protocol = icy_e;
				xa_debug (1, "DEBUG: Relay using icy protocol");
			}
		} else {
			con->food.source->protocol = icy_e;
			xa_debug (1, "DEBUG: Relay using icy protocol");
		}
	}

	/* If there was an error, we need to deal with it here */
	{
		char *sptr = strchr (buf, ' ');
		if (!sptr)
		{
			kick_connection (con, "Erroneous header");
			return NULL;
		}
		if ((strncmp (buf, "HTTP/1.0 200", 12) != 0)
		    && (strncmp (buf, "ICY 200", 7) != 0))
		{
			kick_connection (con, "Error in request, relay refused entrance");
			return NULL;
		}
	}

	source_login (con, buf);

	/* Did it really get in? */
	{
		connection_t rcon;
		rcon.type = source_e;
		rcon.id = ed;
		thread_mutex_lock (&info.source_mutex);
		if (avl_find (info.sources, &rcon))
		{
			thread_mutex_unlock (&info.source_mutex);
			return con;
		} else {
			thread_mutex_unlock (&info.source_mutex);
			return NULL;
		}
	}
}
  







