/* Changing these is probably counter-productive :) */
#define MATCH (match+saved+sofar)
#define NOMATCH 0

int wild_match(register unsigned const char *m, register unsigned const char *n);
