/* vars.h
 * - function declarations for vars.c
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

void extract_vars (vartree_t *request_vars, char *requeststring);
void add_varpair (vartree_t *request_vars, char *varpair);
void add_varpair2 (vartree_t *request_vars, char *name, char *value);
const char *get_variable (vartree_t *request_vars, const char *name);
void free_variables (vartree_t *request_vars);
vartree_t *create_header_vars ();
void extract_header_vars (char *line, vartree_t *vars);
void free_con_variables (connection_t *con);
const char *get_con_variable (connection_t *con, const char *name);
