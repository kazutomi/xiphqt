/* http.c
 * Everything HTTP related
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#ifndef __USE_BSD
#define __USE_BSD
#endif
#include <string.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <sys/types.h>
#include <ctype.h>
#include <errno.h>

#include <fcntl.h>

#ifdef _WIN32
#include <windows.h>
#include <io.h>
#define read _read
#define strcasecmp stricmp
#else
#include <dirent.h>
#include <sys/socket.h>
#include <sys/wait.h>
#endif

#include <sys/stat.h>

#include "avl.h"
#include "avl_functions.h"
#include "threads.h"
#include "icetypes.h"
#include "icecast.h"
#include "admin.h"
#include "utility.h"
#include "ice_string.h"
#include "log.h"
#include "commands.h"
#include "sock.h"
#include "connection.h"
#include "logtime.h"
#include "restrict.h"
#include "memory.h"
#include "source.h"
#include "directory.h"
#include "http.h"
#include "match.h"
#include "dir.h"
#include "vars.h"

extern int running;

http_variable_t http_variables[] = 
{
  { "PORT", integer_e, &info.port },
  { "SOURCES", integer_e, &info.num_sources },
  { "LISTENERS", integer_e, &info.num_clients },
  { "MAXSOURCES", integer_e, &info.max_sources },
  { "MAXLISTENERS", integer_e, &info.max_clients },
  { "MAXLISTENERSPERSOURCE", integer_e, &info.max_clients_per_source},
  { "ADMINS", integer_e, &info.num_admins },
  { "MAXADMINS", integer_e, &info.max_admins },
  { "STATICDIR", string_e, &info.staticdir },
  { "CONFIGFILE", string_e, &info.configfile },
  { "LOGFILE", string_e, &info.logfile },
  { "STATSFILE", string_e, &info.statsfile },
  { "SERVERNAME", string_e, &info.server_name },
  { "THROTTLE", real_e, &info.throttle },
  { "BANDWIDTH", real_e, &info.bandwidth_usage },
  { "LOCATION", string_e, &info.location },
  { "RPEMAIL", string_e, &info.rp_email },
  { "URL", string_e, &info.server_url },
  { "HOSTNAME", string_e, &info.myhostname },
  { "CLIENT_TIMEOUT", integer_e, &info.client_timeout },
  { "UPTIME", function_e, (void *)ice_uptime },
  { "STARTTIME", function_e, (void *)ice_starttime },
  { (char *) NULL, 0, NULL }
};

/* Functions to call for the server-parsed language */
const char * http_foreach ();
const char * http_include ();
htf http_even (), http_odd();

http_parsable_t http_parsables[] = 
{
  { "FOREACH", http_foreach },
  { "INCLUDE", http_include },
  { "EVEN", http_even },
  { "ODD", http_odd },
  { (char *) NULL, (HttpFunction *) NULL}
};

http_parsable_t *
find_http_element (char *name, http_parsable_t *el)
{
	register int i;
	for (i = 0; el[i].name; i++)
	  {
	    if (strncmp (name, el[i].name, strlen (el[i].name)) == 0)
	      return (&el[i]);
	  }
	return ((http_parsable_t *)NULL);
}

const http_variable_t *
find_http_variable (const char *name, const http_variable_t *el)
{
	register int i;
	for (i = 0; el[i].name; i++)
	  {
	    if (strcmp (name, el[i].name) == 0)
	      return (&el[i]);
	  }
	return ((http_variable_t *)NULL);
}

#define HEX_ESCAPE '%'
#define ACCEPTABLE(a)  (a >= 32 && a < 128 && ((isAcceptable[a - 32]) & mask))

unsigned char isAcceptable[96] =
{
  0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0xF,0xE,0x0,0xF,0xF,0xC, 
  0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0x8,0x0,0x0,0x0,0x0,0x0, 
  0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF, 
  0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0x0,0x0,0x0,0x0,0xF, 
  0x0,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF, 
  0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0xF,0x0,0x0,0x0,0x0,0x0  
};
char *hex = "0123456789ABCDEF";
int mask = 0x8; 

char *
url_decode (const char *intarget)
{
    char *temp, *target;
    char c1, c2;
    int len, run, j;

    if (!intarget)
    {
	    xa_debug (1, "WARNING: url_decode called with NULL pointer");
	    return NULL;
    }

    target = nstrdup (intarget);

    len = strlen (target);
    temp = (char *) nmalloc (len + 1);
    strcpy (temp, target);

    for (j = 0, run = 0; j < len; j++, run++) 
    {
	    switch (temp[j]) 
	    {
		    case '+':
			    target[run] = ' ';
			    break;
		    case '%':
			    c1 = tolower (temp[++j]);
			    if (isdigit ((int)c1)) 
			    {
				    c1 -= '0';
			    } else {
				    c1 = c1 - 'a' + 10;
			    }
			    c2 = tolower (temp[++j]);
			    if (isdigit ((int)c2)) 
			    {
				    c2 -= '0';
			    } else {
				    c2 = c2 - 'a' + 10;
			    }
			    target[run] = c1 * 16 + c2;
			    break;
		    default:
			    target[run] = temp[j];
			    break;
	    }
    }
    target[run] = '\0';
    
    nfree (temp);
    return (target);
}

char * 
url_encode (char *str, char **result_p)
{
  const char *p;
  char *q;
  char *result;
  int unacceptable = 0;

  if (!str) 
  {
	  xa_debug (1, "WARNING: url_encode() called with NULL string");
	  return NULL;
  }

  for (p = str; *p; p++)
    if (!ACCEPTABLE((unsigned char) (*p)))
      unacceptable++;

  result = (char  *) nmalloc (p - str + unacceptable + unacceptable + 1);

  *result_p = result;

  for (q = result, p = str; *p; p++) 
    {
      unsigned char a = *p;
      if (!ACCEPTABLE(a)) 
	{
	  *q++ = HEX_ESCAPE;  /* Means hex commming */
	  *q++ = hex[a >> 4];
	  *q++ = hex[a & 15];
	}
      else *q++ = *p;
    }
  *q++ = 0;                   /* Terminate */
  return result;
}

void
updinfo (connection_t *con, vartree_t *request_vars)
{
	const char *song = get_variable (request_vars, "song");
	const char *url = get_variable (request_vars, "url");
	const char *mount = get_variable (request_vars, "mount");
	char *ptr;
	connection_t *sourcecon;

	if (!con || !request_vars)
	{
		xa_debug (2, "WARNING: updinfo called with NULL pointers");
		return;
	}

	if (!mount)
		sourcecon = get_source_from_host (con);
	else
		sourcecon = get_source_with_mount (mount);

	if (!sourcecon)
	{
		sock_write_line (con->sock, "Invalid request");
		return;
	}

	if (song)
	{
		char *ptr2;
		ptr = sourcecon->food.source->streamtitle;
		sourcecon->food.source->streamtitle = ice_sprintf (info.streamtitletemplate, ptr2 = url_decode (song));
		nfree (ptr2);
		info.streamtitle = ice_sprintf (info.streamtitletemplate, ptr2 = url_decode (song));
		nfree (ptr2);
		info.directorylasttime = 0; /* force an update */
		/* change_thread_id_on_mem (sourcecon->food.source->streamtitle, sourcecon->food.source->thread_id); */
		nfree (ptr);
		xa_debug (2, "DEBUG: updinfo() changed song info to %s", sourcecon->food.source->streamtitle);
	}

	if (url)
	{
		if (info.streamurllock)
		{
			sock_write_line (con->sock, "Error: StreamUrl is locked by admin and cannot be changed");
			return;
		}
		ptr = sourcecon->food.source->streamurl;
		sourcecon->food.source->streamurl = url_decode (url);
		/* change_thread_id_on_mem (sourcecon->food.source->url, sourcecon->food.source->thread_id); */
		nfree (ptr);
		xa_debug (2, "DEBUG: updinfo() changed url info to %s", url);
	}
}

void
handle_http_admin_command (connection_t *con, vartree_t *request_vars)
{
	const char *inmode = get_variable (request_vars, "mode");

	xa_debug (2, "DEBUG: handle_http_admin_command() doing command [%s]", inmode ? inmode : "null");

	if (inmode && strcmp (inmode, "updinfo") == 0)
		updinfo (con, request_vars);
	else
	{
		sock_write_line (con->sock, "Unknown command %s", inmode ? inmode : "null");
	}
}

int
http_admin_command (connection_t *con, request_t *req)
{
	vartree_t *request_vars = avl_create (compare_vars, &info);
	
	const char *inpass, *inmode;

	if (!req || !req->path)
	{
		xa_debug (1, "WARNING: http_admin_command called with NULL request");
		return 0;
	}

	if (strcmp (req->path, "admin.cgi") == 0 || strcmp (req->path, "/admin.cgi") == 0)
	{
		display_admin_page (con);
		return 1;
	}

	xa_debug (2, "DEBUG: http_admin_command() adding variables from [%s]", req->path);
	
	extract_vars (request_vars, req->path);

	inpass = get_variable (request_vars, "pass");
	inmode = get_variable (request_vars, "mode");

	xa_debug (2, "DEBUG: http_admin_command() checking password [%s] vs [%s]", info.remote_admin_pass, inpass ? inpass : "null");
	
	if (inpass && password_match (info.remote_admin_pass, inpass))
	{
		handle_http_admin_command (con, request_vars);
		free_variables (request_vars);
		return 1;
	} else if (inpass && inmode && (strcmp (inmode, "updinfo") == 0) && (password_match (info.encoder_pass, inpass)))
		
	{
		handle_http_admin_command (con, request_vars);
		free_variables (request_vars);
		return 1;
	} else {
		free_variables (request_vars);
		return 0;
	}
}

void
display_admin_page (connection_t *con)
{
	char *file = get_template ("admin.html");

	if (file)
	{
		write_template_parsed_html_page (con, NULL, file, -1, NULL);
		nfree (file);
	} else {
		write_http_header (con->sock, 200, "OK");
		sock_write_line (con->sock, "Connection: close");
		sock_write_line (con->sock, "Content-Type: text/plain\r\n");
		sock_write_line (con->sock, "No admin template page found. Create one and try again\n");
	}
}

void 
write_http_header(sock_t sockfd, int error, char *msg)
{
	sock_write_line (sockfd, "HTTP/1.0 %i %s", error, msg);
	sock_write_line (sockfd, "Server: icecast/%s", VERSION);
}
	
int
print_http_variable (vartree_t *request_vars, const char *name, connection_t *clicon, int fd)
{
  const char *out = get_variable (request_vars, name);

  if (out)
  {
	  if (fd < 0)
		  sock_write (clicon->sock, out);
	  else
		  fd_write (fd, out);
	  
	  return 1;
  } else {
	  const http_variable_t *var = find_http_variable (name, http_variables);
	  if (!var)
		  return 0;
	  if (var->type == integer_e)
	  {
		  if (fd < 0)
			  sock_write (clicon->sock, "%d", *(int *)var->valueptr);
		  else
			  fd_write (fd, "%d", *(int *)var->valueptr);
	  }
	  else if (var->type == real_e)
	  {
		  if (fd < 0)
			  sock_write (clicon->sock, "%f", *(double *)var->valueptr);
		  else
			  fd_write (fd, "%f", *(double *)var->valueptr);
	  }
	  else if (var->type == function_e)
	  {
		  /* Nice.. isn't it? ;) */
		  char *ptr = (char *)((*((HttpFunction *) (var->valueptr))) ());
		  if (fd < 0)
			  sock_write (clicon->sock, "%s", ptr);
		  else
			  fd_write (fd, "%s", ptr);
		  nfree (ptr);
	  }
	  else 
	  {
		  char *ptr;
		  if (!var->valueptr)
			  ptr = "(null)";
		  else
			  ptr = *(char **)var->valueptr;

		  if (fd < 0)
			  sock_write (clicon->sock, ptr);
		  else
			  fd_write (fd, ptr);
	  }
	  return 1;
  }
}
      
int
write_template_parsed_html_page (connection_t *clicon, connection_t *sourcecon, const char *template_file, int fd,
				 vartree_t *variables)
{
  int ffd = open_for_reading (template_file);
  struct stat st;
  char *fileptr = NULL;
  const char *res;
  int count = 0, readlen = 0;
   
  xa_debug (2, "DEBUG: wtphp(): Entering function with file=%s fd=%d", template_file, fd);

  if (fd < 0 && clicon)
  {
	  write_http_header (clicon->sock, 200, "OK");
	  sock_write_line (clicon->sock, "Connection: close");
	  sock_write_line (clicon->sock, "Content-Type: text/html\r\n");
  }
  
  if (ffd < 0)
  {
	  xa_debug (1, "ERROR: Cannot open file [%s]", template_file);
	  if (fd < 0)
		  sock_write_line (clicon->sock, "ERROR: Cannot open file [%s]", template_file);
	  return 0;
  }
  
  if (fstat (ffd, &st) == -1)
  {
	  xa_debug (1, "ERROR: Cannot stat file [%s]", template_file);
	  if (fd < 0)
		  sock_write_line (clicon->sock, "ERROR: Cannot stat file [%s]", template_file);
	  return 0;
  }
  
  xa_debug (2, "DEBUG: wtphp(): Parsing page %s", template_file);
  
  /* Don't use nmalloc here, we want our own error handling */
  fileptr = (char *) malloc (st.st_size + 2);
  if (!fileptr)
  {
	  if (fd < 0)
		  sock_write_line (clicon->sock, "ERROR: Cannot allocate enough memory, try again later");
	  return 0;
  }
  
  while ((readlen = read (ffd, &fileptr[count], 2048)) > 0)
  {
	  if (readlen > 0)
		  count += readlen;
  }
  
  fileptr[count] = '\0';
  
  if (!variables)
	  variables = avl_create (compare_vars, &info);
  
  xa_debug (2, "DEBUG: wtphp(): Done reading template file into memory, read %d bytes, starting parsing", count);
  
  res = parse_template_file (clicon, sourcecon, fileptr, fd, variables);
  
  xa_debug (2, "DEBUG: wtphp(): Done parsing, freeing variables and saying goodbye");
  
  free (fileptr);
  fd_close (ffd);
  free_variables (variables);
  
  return res ? 1 : 0;
}

/*
 * This is rather ugly.. but it will have to do for now
 */
const char *
parse_template_file (connection_t *clicon, connection_t *sourcecon, const char *ptr, int fd, vartree_t *variables)
{
  const char *start = ptr;
  char line[BUFSIZE];
  const char *tmpptr, *nextptr;
  
  http_parsable_t *ht;
  
  xa_debug (2, "DEBUG: parsing template file starting at [%s], fd: %d", ptr, fd);
  
  while (ptr && *ptr)
  {
	  if (ptr[0] == '@')
	  {
		  memset (line, 0, BUFSIZE);
		  if ((nextptr = strchr (ptr + 1, '@')))
		  {
			  if (nextptr - ptr < BUFSIZE)
				  memcpy (line, ptr + 1, nextptr - (ptr + 1));
			  else
			  {
				  if (fd < 0)
					  sock_write_bytes (clicon->sock, ptr, 1);
				  else
					  fd_write_bytes (fd, ptr, 1);
				  ptr++;
				  continue;
			  }
			  
			  ht = find_http_element (line, http_parsables);
			  
			  if (ht)
			  {
				  xa_debug (2, "DEBUG: parse_template_file(): Calling function for [%s]", line);
				  tmpptr = ((*(ht->func)) (line, clicon, sourcecon, nextptr + 1, fd, variables));
				  
				  if (tmpptr)
				  {
					  ptr = tmpptr;
				  }
				  else
					  ptr = nextptr + 1;
			  }
			  else if (print_http_variable (variables, line, clicon, fd))
			  {
				  xa_debug (2, "DEBUG: parse_template_file(): Evaluated variable [%s]", line);
				  ptr = nextptr + 1;
			  } 
			  else if (strncmp (line, "ENDFOR", 6) == 0)
			  {
				  xa_debug (2, "DEBUG: parse_tempate_file(): Returning from For-loop");
				  return nextptr + 1;
			  } else { /* @something but we should output it asis */
				  if (fd < 0)
					  sock_write (clicon->sock, "@%s@", line);
				  else
					  fd_write (fd, "@%s@", line);
				  ptr = nextptr + 1;
			  }
		  }
		  else /* @something with no ending @ */
		  {
			  if (fd < 0)
				  sock_write_bytes (clicon->sock, ptr, 1);
			  else 
				  fd_write_bytes (fd, ptr, 1);
			  ptr++;
		  }
	  } 
	  else /* Any other character */ 
	  {
		  if (fd < 0)
			  sock_write_bytes (clicon->sock, ptr, 1);
		  else
			  fd_write_bytes (fd, ptr, 1);
		  ptr++;
	  }
  }
  return start;
}

/* @ODD ident@ */
const char *
http_odd (char *command, connection_t *clicon, connection_t *sourcecon, const char *ptr, int fd, vartree_t *variables)
{
	const void *varptr;
	char endat[BUFSIZE];
	char *end;

	if (!command || !clicon || !ptr || !variables)
	{
		xa_debug (1, "ERROR: http_odd() called with NULL arguments");
		return NULL;
	}

	splitc (NULL, command, ' ');
	
	varptr = get_http_variable (variables, command);

	if (!varptr)
	{
		xa_debug (1, "ERROR: http_odd() called with invalid counter variable");
		if (fd < 0)
			sock_write_line (clicon->sock, "No such variable [%s]", command);
		else
			fd_write_line (fd, "No such variable [%s]", command);
		return NULL;
	}

	sprintf (endat, "@ENDFOR %s@", command);
	end = strchr (ptr + 1, '\n');

	xa_debug (1, "DEBUG: http_odd(): Checking %d", atoi ((char *)varptr));
	
	if (end && atoi ((char *)varptr) % 2 != 0)
	{
		parse_template_file (clicon, sourcecon, ptr, fd, variables);
		return end + 1;
	}
	
	return end ? end + 1 : NULL;
}

const char *
http_even (char *command, connection_t *clicon, connection_t *sourcecon, const char *ptr, int fd, vartree_t *variables)
{
	const void *varptr;
	char endat[BUFSIZE];
	char *end;
	
	if (!command || !clicon || !ptr || !variables)
	{
		xa_debug (1, "ERROR: http_even() called with NULL arguments");
		return NULL;
	}

	splitc (NULL, command, ' ');

	varptr = get_http_variable (variables, command);

	if (!varptr)
	{
		xa_debug (1, "ERROR: http_even() called with invalid counter variable");
		if (fd < 0)
			sock_write_line (clicon->sock, "No such variable [%s]", command);
		else
			fd_write_line (fd, "No such variable [%s]", command);
		return NULL;
	}
	
	sprintf (endat, "@ENDFOR %s@", command);
	end = strchr (ptr + 1, '\n');
	
	xa_debug (1, "DEBUG: http_even(): Checking %d", atoi ((char *)varptr));

	if (end && atoi ((char *)varptr) % 2 == 0)
	{
		parse_template_file (clicon, sourcecon, ptr, fd, variables);
		return end + 1;
	}

	return end ? end + 1 : NULL;
}

const char *
http_include (char *command, connection_t *clicon, connection_t *sourcecon, const char *ptr, int fd, vartree_t *variables)
{
	int ffd;
	struct stat st;
	char *fileptr;
	char *filename = NULL;
	const char *res;
	int count = 0, readlen = 0;
	
	splitc (NULL, command, ' ');
	
	filename = get_template (command);
	
	if (!filename)
	{
		xa_debug (1, "ERROR: Cannot find template file [%s]", command);
		if (fd < 0)
			sock_write_line (clicon->sock, "ERROR: Cannot find template file %s", command);
		else
			fd_write_line (fd, "ERROR: Cannot find template file %s", command);
		return NULL;
	}

  xa_debug (2, "DEBUG: http_include(): including file [%s]", command);
  ffd = open_for_reading (filename);

  if (ffd < 0)
    {
      xa_debug (1, "ERROR: Cannot open file [%s]", filename);
      if (fd < 0)
	      sock_write_line (clicon->sock, "ERROR: Cannot open file [%s]", filename);
      else
	      fd_write_line (fd, "ERROR: Cannot open file [%s]", filename);
      nfree (filename);
      return NULL;
    }
  
  if (fstat (ffd, &st) == -1)
    {
      xa_debug (1, "ERROR: Cannot stat file [%s]", filename);
      if (fd < 0)
	      sock_write_line (clicon->sock, "ERROR: Cannot stat file [%s]", filename);
      else
	      fd_write_line (fd, "ERROR: Cannot stat file [%s]", filename);
      nfree (filename);
      return NULL;
    }
  
  nfree (filename);
  
  /* Don't use nmalloc here, we want our own error handling */
  fileptr = (char *) malloc (st.st_size + 2);
  if (!fileptr)
  {
	  if (fd < 0)
		  sock_write_line (clicon->sock, "ERROR: Cannot allocate enough memory, try again later");
	  else
		  fd_write_line (fd, "ERROR: Cannot allocate enough memory, try again later");
	  return NULL;
  }
  
  while ((readlen = read (ffd, &fileptr[count], 2048)) > 0)
  {
	  if (readlen > 0)
		  count += readlen;
  }
  
  fileptr[count] = '\0';
  
  res = parse_template_file (clicon, sourcecon, fileptr, fd, variables);
  
  free (fileptr);
  fd_close (ffd);  
  
  return NULL;
}

/* FOREACH ident SOURCES|LISTENERS|ADMINS|FILES */
const char *
http_foreach (char *command, connection_t *clicon, connection_t *sourcecon, const char *ptr, int fd, vartree_t *variables)
{
  char ident[BUFSIZE];

  if (splitc (NULL, command, ' ') == NULL)
    return NULL;
  
  if (splitc (ident, command, ' ') == NULL)
    return NULL;
  
  xa_debug (2, "DEBUG: http_foreach: called with [%s] [%s]", command, ptr);
  
  if (strcasecmp (command, "SOURCES") == 0)
	  return http_loop_sources (ident, clicon, ptr, fd, variables);
  else if (strcasecmp (command, "LISTENERS") == 0)
	  return http_loop_listeners (ident, clicon, ptr, fd, variables);
  else if (strcasecmp (command, "ADMINS") == 0)
	  return http_loop_admins (ident, clicon, ptr, fd, variables);
  else if (strcasecmp (command, "FILES") == 0)
	  return http_loop_directory (ident, clicon, ptr, fd, variables);
  else {
	  xa_debug (1, "WARNING: Unknown Traverse type for FOREACH [%s]", command);
	  if (fd < 0)
		  sock_write (clicon->sock, "Unknown Traverse type [%s]", command);
	  else
		  fd_write (fd, "Unknown Traverse type [%s]", command);
	  return NULL;
  }
}

const char *
http_loop_sources (char *ident, connection_t *clicon, const char *ptr, int fd, vartree_t *variables)
{
  const char *runptr = ptr, *endptr = NULL;
  char buf[BUFSIZE];
  int i = 0;
  connection_t *travcon;

  avl_traverser trav = {0};
  
  xa_debug (2, "DEBUG: http_loop_sources(): Traversing sources");
  
  if (info.num_sources <= 0)
    {
      xa_debug (2, "DEBUG: http_loop_sources(): Empty tree");
      if (fd < 0)
	      sock_write (clicon->sock, "No sources available<br>");
      else
	      fd_write (fd, "No sources available<br>");
      sprintf (buf, "@ENDFOR %s@", ident);
      return skip_after (ptr, buf);
    }
  
  thread_mutex_lock (&info.source_mutex);
  
  while ((travcon = avl_traverse (info.sources, &trav)))
    {
      xa_debug (2, "DEBUG: http_loop_sources(): Running for source [%s]", con_host (travcon));
      runptr = ptr;
      
      add_varpair2 (variables, nstrdup (ident), ice_itoa (i));
      add_varpair2 (variables, ice_cat (ident, ".host"), nstrdup (con_host (travcon)));
      add_varpair2 (variables, ice_cat (ident, ".clients"), ice_utoa (travcon->food.source->num_clients));
      add_varpair2 (variables, ice_cat (ident, ".dumpfile"), nstrdup (travcon->food.source->dumpfile));
      add_varpair2 (variables, ice_cat (ident, ".streamurl"), nstrdup (travcon->food.source->streamurl));
      add_varpair2 (variables, ice_cat (ident, ".streamtitle"), nstrdup (travcon->food.source->streamtitle));
      add_varpair2 (variables, ice_cat (ident, ".name"), nstrdup (travcon->food.source->audiocast.name));
      add_varpair2 (variables, ice_cat (ident, ".genre"), nstrdup (travcon->food.source->audiocast.genre));
      add_varpair2 (variables, ice_cat (ident, ".url"), nstrdup (travcon->food.source->audiocast.url));
      add_varpair2 (variables, ice_cat (ident, ".mount"), nstrdup (travcon->food.source->audiocast.mount));
      add_varpair2 (variables, ice_cat (ident, ".description"), nstrdup (travcon->food.source->audiocast.description));
      add_varpair2 (variables, ice_cat (ident, ".public"), ice_itoa (travcon->food.source->audiocast.public));
      add_varpair2 (variables, ice_cat (ident, ".bitrate"), ice_itoa (travcon->food.source->audiocast.bitrate));
      add_varpair2 (variables, ice_cat (ident, ".connecttime"), nstrdup (nice_time (get_time() - travcon->connect_time, buf)));
      endptr = parse_template_file (clicon, NULL, runptr, fd, variables);
      i++;
      
    }
  
  thread_mutex_unlock (&info.source_mutex);
  
  return endptr;
}

const char *
http_loop_admins (char *ident, connection_t *clicon, const char *ptr, int fd, vartree_t *variables)
{
  const char *runptr = ptr, *endptr = NULL;
  char buf[BUFSIZE];
  int i = 0;
  connection_t *travcon;

  avl_traverser trav = {0};
  
  xa_debug (2, "DEBUG: http_loop_admins(): Traversing admins");
  
  if (info.num_admins <= 0)
    {
      xa_debug (2, "DEBUG: http_loop_admins(): Empty tree");
      if (fd < 0)
	      sock_write (clicon->sock, "No admins available<br>");
      else
	      fd_write (fd, "No admins available<br>");
      sprintf (buf, "@ENDFOR %s@", ident);
      return skip_after (ptr, buf);
    }
  
  thread_mutex_lock (&info.admin_mutex);
  
  while ((travcon = avl_traverse (info.admins, &trav)))
  {
	  xa_debug (2, "DEBUG: http_loop_admins(): Running for admins [%s]", con_host (travcon));
	  runptr = ptr;
	  
	  add_varpair2 (variables, nstrdup (ident), ice_itoa (i));
	  add_varpair2 (variables, ice_cat (ident, ".host"), nstrdup (con_host (travcon)));
	  add_varpair2 (variables, ice_cat (ident, ".connecttime"), nstrdup (nice_time (get_time() - travcon->connect_time, buf)));
	  endptr = parse_template_file (clicon, NULL, runptr, fd, variables);
	  i++;
	  
  }
  
  thread_mutex_unlock (&info.admin_mutex);
  
  return endptr;
      
}

const char *
http_loop_directory (char *ident, connection_t *clicon, const char *ptr, int fd, vartree_t *variables)
{
  const char *runptr = ptr, *endptr = NULL;
  char buf[BUFSIZE];
  char fullfilename[BUFSIZE*2];
  struct stat st;
  int i = 0;
  dir_t *od = NULL;
  const char *directoryname = get_variable (variables, "LISTED_DIRECTORY");

  if (directoryname)
	  od = dir_findfirst (directoryname);
  
  if (!directoryname || !od)
  { 
	  xa_debug (2, "DEBUG: http_loop_directory(): Could not open directory");
	  sock_write (clicon->sock, "No such directory<br>");
	  sprintf (buf, "@ENDFOR %s@", ident);
	  return skip_after (ptr, buf);	  
  }

  xa_debug (2, "DEBUG: http_loop_directory(): Traversing directory");
  
  while (dir_findnext (od))
  {
	  sprintf (fullfilename, "%s/%s", directoryname, od->filename);
	  if ((stat (fullfilename, &st) == 0) && wild_match ((unsigned char *)"*.mp3", (unsigned char *)od->filename))
	  {
		  add_varpair2 (variables, nstrdup (ident), ice_itoa (i));
		  add_varpair2 (variables, ice_cat (ident, ".name"), nstrdup (od->filename));
		  add_varpair2 (variables, ice_cat (ident, ".size"), ice_itoa (st.st_size));
		  endptr = parse_template_file (clicon, NULL, runptr, fd, variables);
		  i++;
	  }
  }

  dir_findclose (od);
  
  return endptr;
}

const char *
http_loop_listeners (char *ident, connection_t *clicon, const char *ptr, int fd, vartree_t *variables)
{
  const char *runptr = ptr, *endptr = NULL;
  char buf[BUFSIZE];
  int i = 0;
  connection_t *travclients, *travsources;

  avl_traverser trav = {0}, travc = {0};
  
  xa_debug (2, "DEBUG: http_loop_listeners(): Traversing clients");
  
  if (info.num_clients <= 0)
    {
      xa_debug (2, "DEBUG: http_loop_listeners(): Empty tree");
      if (fd < 0)
	      sock_write (clicon->sock, "No listeners available<br>");
      else
	      fd_write (fd, "No listeners available<br>");
      sprintf (buf, "@ENDFOR %s@", ident);
      return skip_after (ptr, buf);
    }
  
  thread_mutex_lock (&info.double_mutex);
  thread_mutex_lock (&info.source_mutex);
  
  while ((travsources = avl_traverse (info.sources, &trav)))
    {
      xa_debug (2, "DEBUG: http_loop_listeners(): Running for listeners for source [%s]", con_host (travsources));
      runptr = ptr;
      i = 0;

      thread_mutex_lock (&travsources->food.source->mutex);

      while ((travclients = avl_traverse (travsources->food.source->clients, &travc)))
	{
	  add_varpair2 (variables, nstrdup (ident), ice_itoa (i));
	  add_varpair2 (variables, ice_cat (ident, ".host"), nstrdup (con_host (travclients)));
	  add_varpair2 (variables, ice_cat (ident, ".user_agent"), nstrdup (get_con_variable (travclients, "User-Agent")));
	  add_varpair2 (variables, ice_cat (ident, ".writebytes"), ice_utoa (travclients->food.client->write_bytes));
	  add_varpair2 (variables, ice_cat (ident, ".connecttime"), nstrdup (nice_time (get_time() - travclients->connect_time, buf)));
	  endptr = parse_template_file (clicon, NULL, runptr, fd, variables);
	  i++;
	}
      
      thread_mutex_unlock (&travsources->food.source->mutex);

    }

  thread_mutex_unlock (&info.source_mutex);
  thread_mutex_unlock (&info.double_mutex);
  
  return endptr;
}

char *
ice_uptime ()
{
  char buf[BUFSIZE];
  return nstrdup (nice_time (get_time () - info.server_start_time, buf));
}

char *
ice_starttime ()
{
  /* Now isn't this pretty? :) */
  char *res, *ptr = get_string_time (info.server_start_time, REGULAR_TIME);
  res = nstrdup (ptr);
  nfree (ptr);
  return res;
}

const void *
get_http_variable (vartree_t *request_vars, const char *name)
{
  const char *out = get_variable (request_vars, name);

  if (out)
    return out;
  else 
    {
      const http_variable_t *var = find_http_variable (name, http_variables);
      if (!var)
	return NULL;
      return var->valueptr;
    }
}




