/* just prototypes for the moment */

void compress_audio(int *buffer,int *prebuf,int num,int len,float power , float vol , float gate);

void compress_audio2(int *buffer,float *prev,int num,int len,float power , float vol , float gate);

int clip_audio(int *buffer,short *clipped,int num,float threshold);

int get_max_level16(short *buffer,int num);

void change_time(short *in,short *out,unsigned int num_in,unsigned int num_out);

void stretch_samples(short *in, short *out,unsigned int num1,unsigned int num2);

void compress_samples(short *in, short *out,unsigned int num1,unsigned int num2);

void int_stretch_samples(short *in,short *out,int num,int grain);

void int_compress_samples(short *in, short *out,int num,int grain);

void mix_stereo(short *left,short *right,short *stereo,int num);

void sep_stereo(short *stereo,short *left,short *right,int num);

void make_stereo(short *mono,short *stereo,int num);

void make_mono(short *stereo,short *mono,int num);

void convert_audio(short *in,short *out,int ch1,int ch2,int n1,int n2);
