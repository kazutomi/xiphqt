/* move all the encoder related functions into this file */
#include "liveice.h"



/* OK.... this is the routine to launch the old l3enc encoder */
int exec_encoder_l3enc(enc_struct *e_stream){
	char sr[256], br[32],ch[32];
	int enc;
	switch(enc=fork()){
	case 0:
	  /*isolate the IO so it doesn't clobber the level meter*/
	  if(g_conf.debug<10){
	    close(0);
	    close(1);
	    close(2);
	    open("/dev/null", O_RDONLY);
	    open("/dev/null", O_WRONLY);
	    open("/dev/null", O_WRONLY);
	  }
	  nice(-10);
	  sprintf(sr, "%d", e_stream->sample_rate);
	  sprintf(br, "%d", e_stream->bitrate);
	  if(e_stream->stereo)
	    sprintf(ch,"2");
	  else
	    sprintf(ch,"1");
	  /* if quality is > 90% then use hq mode */
	  if (e_stream->encoding_quality>90) 
		  execlp(e_stream->encoder_cmd, e_stream->encoder_cmd, e_stream->sound_pipe, e_stream->mpeg_pipe, "-br", br, "-sr", sr, "-tfc", ch ,"-hq", NULL);
	  else 
		execlp(e_stream->encoder_cmd, e_stream->encoder_cmd, e_stream->sound_pipe, e_stream->mpeg_pipe, "-br", br, "-sr", sr, "-tfc", ch, NULL);
	  sprintf(sr,"execution of %s failed - make sure it's in your $PATH moron!",e_stream->encoder_cmd);
	  fatal(sr);
	  break;
	case -1:
	  fatal("unable to fork() a new process for the encoder");
	}
	e_stream->enc=enc;
	return enc;
}


/* OK.... this is the routine to launch the new Fraunhoffer code */
int exec_encoder_mp3enc(enc_struct *e_stream){
	char sr[256], br[32],ch[32],qual[32];
	int enc;
	switch(enc=fork()){
	case 0:
	  /*isolate the IO so it doesn't clobber the level meter*/
	  if(g_conf.debug<10){
	    close(2);
	    open("/dev/null", O_WRONLY);
	  }
	  close(0);
	  close(1);
	  open(e_stream->sound_pipe,O_RDONLY);
	  open(e_stream->mpeg_pipe,O_WRONLY);
	  nice(-10);
	  sprintf(sr, "%d", e_stream->sample_rate);
	  sprintf(br, "%d", e_stream->bitrate);
	  sprintf(qual, "%d", e_stream->encoding_quality/11);
	  if(e_stream->stereo)
	    sprintf(ch,"2");
	  else
	    sprintf(ch,"1");
	  execlp(e_stream->encoder_cmd, e_stream->encoder_cmd, "-br" , br , "-sr" , sr , "-nc" , ch , "-qual" , qual , "-sti", "-sto", NULL);
	  sprintf(sr,"execution of %s failed - make sure it's in your $PATH moron!",e_stream->encoder_cmd);
	  fatal(sr);
	  break;
	case -1:
	  fatal("unable to fork() a new process for the encoder");
	}
	e_stream->enc=enc;
	return enc;
}


/* this is the version of dist10 by Andreas Johansson */
/* wopr.campus.luth.se:/pub/mpeg_layer_3 */
int exec_encoder_AJ(enc_struct *e_stream){
	char sr[256], br[32],ch[32];
	int enc;
	/*isolate the IO so it doesn't clobber the level meter*/
	switch(enc=fork()){
	case 0:
	  if(g_conf.debug<10){
	    close(1);
	    close(2);
	    open("/dev/null", O_WRONLY);
	    open("/dev/null", O_WRONLY);
	  }
	  close(0);
	  /* if you run as superuser then increase the priority */
	  nice(-10);
	  open(e_stream->sound_pipe,O_RDONLY);
	  sprintf(sr, "%f", e_stream->sample_rate/1000.0);
	  sprintf(br, "%d", e_stream->bitrate/1000);
	  if(e_stream->stereo)
	    sprintf(ch,"s");
	  else
	    sprintf(ch,"m");
	  if(e_stream->copyright)
		  execlp(e_stream->encoder_cmd, e_stream->encoder_cmd, "-m" , ch , "-s" , sr , "-b" , br , "-c", "-" , e_stream->mpeg_pipe,  NULL);
	  else 
		  execlp(e_stream->encoder_cmd, e_stream->encoder_cmd, "-m" , ch , "-s" , sr , "-b" , br , "-" , e_stream->mpeg_pipe,  NULL);
	  sprintf(sr,"execution of %s failed - make sure it's in your $PATH moron!",e_stream->encoder_cmd);
	  fatal(sr);
	  break;
	case -1:
	  fatal("unable to fork() a new process for the encoder");
	  break;
	}
	e_stream->enc=enc;
	return enc;
}



/* LAME 3.01 support - LAME Ain't an Mp3 Encoder. */
/* Essentially a patch to dist 10 with a better psycho model */
/* http://www.sulaco.org/mp3  */
int exec_encoder_lame3(enc_struct *e_stream){
	char sr[256], br[32],ch[32];
	int enc;
	/*isolate the IO so it doesn't clobber the level meter*/
	switch(enc=fork()){
	case 0:
	  if(g_conf.debug<10){
	    close(1);
	    close(2);
	    open("/dev/null", O_WRONLY);
	    open("/dev/null", O_WRONLY);
	  }
	  /* if you run as superuser then increase the priority */
	  nice(-10);
	  sprintf(sr, "%f", e_stream->sample_rate/1000.0);
	  sprintf(br, "%d", e_stream->bitrate/1000);
	  if(e_stream->stereo)
	    sprintf(ch,"j");
	  else
	    sprintf(ch,"m");
	  if(e_stream->copyright)
		  execlp(e_stream->encoder_cmd, e_stream->encoder_cmd, "-m" , ch , "-s" , sr , "-b" , br , "-c", "-x" , e_stream->sound_pipe , e_stream->mpeg_pipe,  NULL);
	  else 
		  execlp(e_stream->encoder_cmd, e_stream->encoder_cmd, "-m" , ch , "-s" , sr , "-b" , br , "-x" ,e_stream->sound_pipe , e_stream->mpeg_pipe,  NULL);
	  sprintf(sr,"execution of %s failed - make sure it's in your $PATH moron!",e_stream->encoder_cmd);
	  fatal(sr);
	  break;
	case -1:
	  fatal("unable to fork() a new process for the encoder");
	  break;
	}
	e_stream->enc=enc;
	return enc;
}



/* the version of lamer which comes from Isaac Richard's Excellent Scream */
/* http://mizar.cwru.edu/screamer/                                        */
int exec_encoder_screamer(enc_struct *e_stream){
	char sr[256], br[32],ch[32];
	int enc;
	switch(enc=fork()){
	case 0:
	  /*isolate the IO so it doesn't clobber the level meter*/
	    if(g_conf.debug<10){
		    close(1);
		    close(2);
		    open("/dev/null", O_WRONLY);
		    open("/dev/null", O_WRONLY);	    
	    }
	  close(0);
	  open(e_stream->sound_pipe,O_RDONLY);
	  nice(-10);
	  sprintf(sr, "%f", e_stream->sample_rate/1000.0);
	  sprintf(br, "%f", e_stream->bitrate/1000.0);
	  if(e_stream->stereo)
	    sprintf(ch,"s");
	  else
	    sprintf(ch,"m");
	  if(e_stream->copyright)
		  execlp(e_stream->encoder_cmd, e_stream->encoder_cmd, "-b" , br , "-s" , sr ,  "-m" , ch , "-", e_stream->mpeg_pipe , NULL);
	  else 
		  execlp(e_stream->encoder_cmd, e_stream->encoder_cmd, "-c" , "-b" , br , "-s" , sr ,  "-m" , ch , "-", e_stream->mpeg_pipe , NULL);
	  sprintf(sr,"execution of %s failed - make sure it's in your $PATH moron!",e_stream->encoder_cmd);
	  fatal(sr);
	  break;
	case -1:
	  fatal("unable to fork() a new process for the encoder");
	}
	e_stream->enc=enc;
	return enc;
}



/* The Xing Technologies encoder, needs to be cheated by puting a .wav header*/
/* at the start, the programme still truies to seek past it but doesn't      */
/* instantly crash unlike other encoders */
/* the beta used bitrate per channel - but the produciton verison saw sense  */
/* since stereo is a bitch to work with in either version I've set it up for */
/* the produacion version fo the encoder */
/* the steroe mode is broken - but astute kernel hackers might want to try a */
/* special kernel patch I've created to fool this into doing what I want */
int exec_encoder_xing(enc_struct *e_stream)
{
  char br[256];
  char ch[32];
  char copyright[32];
  char algorithm[32];
  int enc;

  sprintf(br,"-B%d",e_stream->bitrate / 1000 );
  sprintf(ch,"-M%d",(e_stream->stereo ? 0 : 3));

  sprintf(copyright,"-C%d",(e_stream->copyright ? 1 : 0) );
  
  /* let the encoder choose the sample rate */
  if(e_stream->bitrate<=32000){
	  sprintf(algorithm,"-A2");
  } else if(e_stream->sample_rate<=24000){
	  sprintf(algorithm,"-A2");
  } else {
	  sprintf(algorithm,"-A1");
  }
	  
		  
  switch(enc=fork()){
  case 0:
	  /* close those fd's */
	  if(g_conf.debug<10){
		  close(0);
		  close(1);
		  close(2);
		  open("/dev/null", O_RDONLY);
		  open("/dev/null", O_WRONLY);
		  open("/dev/null", O_WRONLY);
	  }
	  if(e_stream->encoding_quality<30)
		  execlp(e_stream->encoder_cmd,e_stream->encoder_cmd,algorithm,"-Nhf",ch,br,copyright,e_stream->sound_pipe,e_stream->mpeg_pipe,NULL);
	  else
		  execlp(e_stream->encoder_cmd,e_stream->encoder_cmd,algorithm,ch,br,copyright,e_stream->sound_pipe,e_stream->mpeg_pipe,NULL);
	  
	  sprintf(br,"execution of %s failed - make sure it's in your $PATH moron!",e_stream->encoder_cmd);
	  fatal(br);
	  break;
  case -1:
	  fatal("unable to fork() new process for the encoder");
  }
  e_stream->enc=enc;
  return enc;
}


/* The Xing encoder in Variable bitrate mode */
int exec_encoder_xing_vbr(enc_struct *e_stream)
{
	
  char br[256];
  char ch[32];
  char copyright[32];
  char algorithm[32];
  int enc;

  sprintf(br,"-V%d",e_stream->vbr_quality);
  sprintf(ch,"-M%d",(e_stream->stereo ? 0 : 3));

  sprintf(copyright,"-C%d",(e_stream->copyright ? 1 : 0) );
  
  /* it can be a good idea to let the encoder choose the sample_rate */
  /*if(e_stream->bitrate<=32000){
	  sprintf(algorithm,"-A0");
  } else if(e_stream->sample_rate<=24000){
	  sprintf(algorithm,"-A0");
  } else {
	  sprintf(algorithm,"-A1");
	  }*/


  switch(enc=fork()){
  case 0:
	  /* close those fd's */
	  if(g_conf.debug<10){
		  close(0);
		  close(1);
		  close(2);
		  open("/dev/null", O_RDONLY);
		  open("/dev/null", O_WRONLY);
		  open("/dev/null", O_WRONLY);
	  }
	  if(e_stream->encoding_quality<30)
		  execlp(e_stream->encoder_cmd,e_stream->encoder_cmd,"-Nhf",ch,br,copyright,e_stream->sound_pipe,e_stream->mpeg_pipe,NULL);
	  else 
		execlp(e_stream->encoder_cmd,e_stream->encoder_cmd,ch,br,copyright,e_stream->sound_pipe,e_stream->mpeg_pipe,NULL);  
	  sprintf(br,"execution of %s failed - make sure it's in your $PATH moron!",e_stream->encoder_cmd);
	  fatal(br);
	  break;
  case -1:
	  fatal("unable to fork() new process for the encoder");
  }
  e_stream->enc=enc;
  return enc;
}





int spawn_encoder_process(enc_struct *e_stream){
	switch(e_stream->encoder){
	case L3ENC:
		return exec_encoder_l3enc(e_stream);
		break;
	case MP3ENC:
		return exec_encoder_mp3enc(e_stream);
		break;
	case AJ_ENCODER:
		return exec_encoder_AJ(e_stream);
		break;
	case SCREAMER:
		return exec_encoder_screamer(e_stream);
		break;
	case XING:
		return exec_encoder_xing(e_stream);
		break;
	case XING_VBR:
		return exec_encoder_xing_vbr(e_stream);
	case LAME3:
		return exec_encoder_lame3(e_stream);
		break;
	default:
		fatal("Selected encoder Not Currently Supported - Sorry\n supported encoders are -\n L3ENC, MP3ENC, XING, XING_VBR, LAME3, SREAMER and AJ_ENCODER");
		break;
	}
}

int check_encoder_l3enc(enc_struct *e_stream){
	if(e_stream->copyright)
		write_message("Warning: l3enc doesn't support copyright flag",0);
	switch(e_stream->bitrate){
	case 8000:
	case 16000:
	case 24000:
	case 32000:
	case 56000:
	case 64000:
	case 96000:
	case 112000:
	case 128000:
	case 192000:
	case 256000:
		break;
	default:
		write_message("Error: invalid bitrate for l3enc selected",0);
		return -1;
	}
	return 0;
}

int check_encoder_mp3enc(enc_struct *e_stream){
	if(e_stream->copyright)
		write_message("Warning: mp3enc doesn't support copyright flag",0);
	switch(e_stream->bitrate){
	case 8000:
	case 16000:
	case 18000:
		if(e_stream->stereo){
			write_message("Error: mp3enc stereo mode only works for bitrates >= 20Kbit/s",0);
			return -1;
		}
	case 20000:
	case 24000:
	case 32000:
	case 40000:
	case 48000:
	case 56000:
	case 64000:
	case 96000:
	case 112000:
	case 128000:
	case 160000:
	case 192000:
	case 256000:
		break;
	default:
		write_message("Error: invalid bitrate for mp3enc selected",0);
		return -1;
	}
	
	return 0;
}

int check_encoder_AJ(enc_struct *e_stream){
	switch(e_stream->bitrate){
	case 32000:
	case 40000:
	case 48000:
	case 56000:
	case 64000:
	case 80000:
	case 96000:
	case 112000:
	case 128000:
	case 160000:
	case 192000:
	case 224000:
	case 256000:
	case 320000:
		break;
	default:
		write_message("Error: invalid bitrate for encoder",0);
		return -1;
	}
	if(e_stream->sample_rate<32000){
		write_message("Error: AJ_ENCODER can't run at less than 32kHz",0);
		return -1;
	}
	return 0;
}


int check_encoder_screamer(enc_struct *e_stream){
	if(e_stream->sample_rate<=11025){
		write_message("Error: Screamer doesn't support sample rates <=11kHz",0);
		return -1;
	}
		
	switch(e_stream->bitrate){
	case 8000:
		if(e_stream->stereo){
			write_message("Error: Screamer only support mono for 8kbit/s streams",0);
			return -1;
		}
	case 16000:
	case 24000:
		if(e_stream->sample_rate>24000){
			write_message("Error: Screamer only supports sample rates <=24kHz for low bitrates",0);
			return -1;
		}
	case 32000:
	case 40000:
	case 48000:
	case 56000:
	case 64000:
	case 80000:
	case 96000:
	case 112000:
	case 128000:
	case 160000:
	case 192000:
	case 224000:
	case 256000:
	case 320000:
		break;
	default:
		write_message("Error: invalid bitrate for encoder",0);
		return -1;
	}
	return 0;
}


int check_encoder_lame3(enc_struct *e_stream){
	if(e_stream->sample_rate<=11025){
		write_message("Error: LAME3.x doesn't support sample rates <=11kHz",0);
		return -1;
	}
	if(e_stream->sample_rate<=24000){
		write_message("Warning: LAME3.x doesn't use GPsycho for low sample rates",0);
	}
		
	switch(e_stream->bitrate){
	case 8000:
	case 16000:
	case 24000:
		write_message("Warning: Low Bitrates only work in recent versions of LAME3.x",0);
		if(e_stream->sample_rate>24000){
			write_message("Error: LAME3.x only supports sample rates <=24kHz for low bitrates",0);
			return -1;
		}
	case 32000:
	case 40000:
	case 48000:
	case 56000:
	case 64000:
	case 80000:
	case 96000:
	case 112000:
	case 128000:
	case 160000:
	case 192000:
	case 224000:
	case 256000:
	case 320000:
		break;
	default:
		write_message("Error: invalid bitrate for encoder",0);
		return -1;
	}
	return 0;
}



int check_encoder_xing(enc_struct *e_stream){
	write_message("Warning: You have selected the Xing mp3 encoder,",0);
	write_message(" currently only the beta version works easily with liveice",0);
	write_message(" the production version has a numebr of bugs which have made",0);
	write_message(" using it with LiveIce a non-trivial task",0);
	write_message(" But of course you know all this because you've read the Documenation!",0);

	if(e_stream->stereo){
		write_message("Warning:",0);
		write_message(" Stereo mode only works with a special patch to the linux Kernel",0);
		write_message(" if you don't know what I'm talking about then read the docs",0);
	}
	/* now bitrates - different ones for different modes */
	switch(e_stream->bitrate){
	case 16000:
		if(e_stream->sample_rate>=44100){
			write_message("Error: Xing won't do >=44100KHz at 16Kbit",0);
			return -1;
		}
	case 24000:
	case 56000:
	case 80000:
		if(e_stream->stereo){
			write_message("Error: Invalid bitrate in stereo mode",0);
			return -1;
		}
		break;
	case 32000:
	case 48000:
	case 64000:
	case 96000:
	case 112000:
	case 128000:
	case 160000:
	case 192000:
	case 224000:
	case 256000:
	case 320000:
		break;
	default:
		write_message("Error: invalid bitrate for stereo xing_encoder",0);
		return -1;
	}


	if(e_stream->sample_rate<=11025){
		write_message("Error: Xing does not support <=11kHz streams",0);
		return -1;
	}

	return 0;
}



int check_encoder_xing_vbr(enc_struct *e_stream){
	write_message("Warning: You have selected the Xing mp3 encoder",0);
	write_message(" currently only the beta version works easily with liveice",0);
	write_message(" the production version has a numebr of bugs which have made",0);
	write_message(" using it with LiveIce a non-trivial task",0);
	write_message(" But of course you know all this because you've read the Documenation!",0);

	if(e_stream->stereo){
		write_message("Warning:",0);
		write_message(" Stereo mode only works with a special patch to the linux Kernel",0);
		write_message(" if you don't know what I'm talking about then read the docs",0);
	}
	
	if((e_stream->vbr_quality>150)||(e_stream->vbr_quality<0)){
		write_message("Error: Xing VBR quality setting should be between 0-150",0);
		write_message("       modify VBR_QUALITY in the config file",0);
		return -1;
	}

	if(e_stream->sample_rate<=11025){
		write_message("Error: Xing does not support <=11kHz streams",0);
		return -1;
	}

	return 0;
}




/* stupidity check on a per encoder basis */
int check_encoder_parameters(enc_struct *e_stream){

	switch(e_stream->encoder){
	case L3ENC:
		return check_encoder_l3enc(e_stream);
		break;
	case MP3ENC:
		return check_encoder_mp3enc(e_stream);
		break;
	case AJ_ENCODER:
		return check_encoder_AJ(e_stream);
		break;
	case SCREAMER:
		return check_encoder_screamer(e_stream);
		break;
	case XING:
		return check_encoder_xing(e_stream);
		break;
	case XING_VBR:
		return check_encoder_xing_vbr(e_stream);
	case LAME3:
		return check_encoder_lame3(e_stream);
		break;
	default:
		write_message("Error: Unsupported encoder selected",0);
		return -1;
	}

}



