/* liveice.h
 *
 * Copyright (c) 1999 Scott Manley, Barath Raghavan, Jack Moffitt, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License  
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netdb.h>
#include <netinet/in.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <netdb.h>
#include <arpa/inet.h>   
#include <sched.h>       
#include <unistd.h>
#include <termios.h>
#include <sys/wait.h>
#include <ctype.h>

/* curses interface support */

#ifdef HAVE_LIBCURSES
#include <curses.h>
#endif


/* Soundcard support */
/* If you don't have OSS then you should comment out this line and you can 
   only run the system in mixer mode. */
#define SOUNDCARD_SUPPORT

/* undefine this and the programme will be less paranoid about checking 
   the pipes it uses for talking with the encoder  - this allows you to 
   substitute more robust pipe devices to talk to those 'difficult' encoders
   - you might want to check out my liveice pipe linux kernel module
*/
#define PARANOID_PIPES



/* Define one or the other to choose your favourite mp3 encoder */
/* l3enc requires teh *registered* version of l3enc */
/* mp3enc is again the registered version from Fraunhofer */
/* http://www.iis.fhg.de/amm/download/mp3enc/            */
/* AJ_ENCODER uses the optomised version of DIST10 by Andreas Johansson */
/* You can Download this from wopr.campus.luth.se:/pub/mpeg_layer_3     */
/* The quality produuced by the fraunhofer code is much better than */
/* that standard ISO sources - if you're at all serious about this radio */
/* business then you'll get some of their code which is the best that I've*/
/* found */

enum { AJ_ENCODER, L3ENC, MP3ENC, BLADEENC, ENC_8HZ , LAME3 , SCREAMER, XING , XING_VBR};
#define DEFAULT_ENCODER L3ENC

#define MAX_ENCODER_STREAMS 8

/* not in use yet.... */
#define SOUNDCARD_MODE     0
#define MP3MIXER_MODE      1 
#define AUDIOPIPE_MODE     2


/* Default port */
#define PORT 8001

/* default bitrate and samplerate - differnet encoders need different settings*/

/* The Fraunhofer Codecs are best.... */
#if DEFAULT_ENCODER == L3ENC 
#define BITRATE 24000           
#define SAMPLE_RATE 22050       

#elif DEFAULT_ENCODER == MP3ENC
#define BITRATE 24000           
#define SAMPLE_RATE 22050       

/* Whie dist10 derived stuff is shite..... why doesnt' anyone fix LSF? */
#elif DEFAULT_ENCODER == AJ_ENCODER 
#define BITRATE 32000           
#define SAMPLE_RATE 32000      

/* Bladenc still doesn't work */
#elif DEFAULT_ENCODER == BLADEENC
#define BITRATE 32000           
#define SAMPLE_RATE 32000      

/* 8HZ might work... if I could get the source... */
#elif DEFAULT_ENCODER == ENC_8HZ 
#define BITRATE 32000           
#define SAMPLE_RATE 32000       

/* LAME needs hacked */
#elif DEFAULT_ENCODER == LAME3 
#define BITRATE 32000           
#define SAMPLE_RATE 32000       

/* Isaac Richard has done it - Congratulations */
#elif DEFAULT_ENCODER == SCREAMER
#define BITRATE 24000           
#define SAMPLE_RATE 22050       

/* Xing Technologies mp3 encoder .... cheap, but not easy to run */
#elif DEFAULT_ENCODER == XING
#define BITRATE 24000           
#define SAMPLE_RATE 22050       

/* Xing, using the Variable bitrate codec */
#elif DEFAULT_ENCODER == XING_VBR
#define BITRATE 24000      
#define SAMPLE_RATE 22050       

#endif

/* VBR is only used by Xing right now - but Lame is almost there */
#define VBR_QUALITY 75

/* General tag to let people alter the output quality and perhaps save some time */
#define ENCODING_QUALITY 30

#define MP_BUFF_SIZE 4096  /* make sure this is large enough */


/* Magic numebrs for random number generator */
#define RAND_MOD  714025
#define RAND_MULT 4096
#define RAND_ADD  150889



/* in theory we should be able to encode multiple streams */
/* need to work on the configuration system */
typedef struct Enc_struct {
	int enabled;           
	int port;
	char *server;
	char *password;
	char *mountpoint;
	char *name;
	char *genre;
	char *url;
	char *description;
      	char *sound_pipe;     /* name of pipe for sound processing */
	char *mpeg_pipe;      /* name of file used to store header */
	char *encoder_cmd;    /* possible string pointing to encoder bin */
	char *recording_file; /* recording file */
	int public;
	int bitrate;
	int vbr_quality;
	int encoding_quality;
	int sample_rate;
	int stereo;
	int header_format;
	int copyright;
	int encoder;           /* enumed variable */
	FILE  *pipe;            /* file descriptor for writing to pipe */
	pid_t tcp;             /* child processes associated with stream */
	pid_t enc;             /* ditto */
} enc_struct;

/* this started out as a config structure being passed around - but it's
really now become a general scratchpad for all the data I need to keep 
track of I want to keep enerything in this structure so that I don't end up
confilicting with anythign else */
typedef struct{
	enc_struct e_str[MAX_ENCODER_STREAMS]; /* I know... static allocation..you do better*/
	int port;
	char *server;
	char *sound_pipe;         /* name of pipe for sound processing */
	char *mpeg_pipe;      /* name of file used to store header */
	char *playlist;
	char *password;
	char *icy_name;
	char *icy_genre;
	char *icy_url;
	char *track_logfile;
	char *mountpoint;
	char *description;
	char *pipe_dir;       /* put exerything in a hidden dir... */
	char *recording_file;
	int sound_device;     /* set to 1 if the sound file is a device */
	int icy_public;
	int bitrate;
	int vbr_quality;
	int encoding_quality;
	int sample_rate;
	int stereo;
	int audio_fd;         /* only one soundcard - only one audiofd */
	int full_duplex;
	int soundcard;         /* Are we using the soundcard? */
	char *decoder_cmd;
	int hacked_decoder;    /* are we using a hacked decoder? */
	int encoder;           /* enumed variable */
	char *encoder_cmd;    /* possible string pointing to encoder bin */
	int copyright;        /* try and mark stream as copyrighted */
	int debug;            /* debug level  higer => more messages */
	int rw_size;
	int mixer;            /* Use mp3mixer instead of soundcard */
	/* now covering general Mode settings */
	int mix_control;      /* keyboard/logged keyboard/logfile */
	char *mix_control_file;   /* file for keylogging/control */
	int raw_fd;
	long random_seed;
	int header_format;         /* x-audiocast vs icy */
	int terminate_now;/* flag to remind processes thet they're terminted */
	int frontend; /* executed by a frontend ?*/
	time_t end_time;    /* on how long to broadcast for */
#ifdef HAVE_LIBCURSES
	WINDOW *icescreen;
	WINDOW *inputscreen;
	WINDOW *messagescreen;
	WINDOW *outputscreen;
#endif
} config;

config g_conf;           /*global configuration sturcture */

 

/* other functions */
void write_message(char *msg,int pri);
void fatal(char *text);
int valid(unsigned long); 
float random_number(long *irand);

int get_legal_rate(int rate);

void encoding(void);
void alarm_timeout(int signo);
void arm(unsigned int secs);
void mp3mixer(void);

int write_streams(short *buf,int num);

void check_soundcard(void);
void open_soundcard(int flags);
void close_soundcard(void);

void synchronise_time(long samples);

int format_of (const char *filename,int *channels);

void set_interface(void);
void restore_interface(void);
void fix_interface(void);
void draw_simple_display(void);
void draw_mixer_display(void);
void draw_volume_meter(short *data,int num,int stereo);
void mv_draw_volume(int x,int y,int vol);

char get_inp_char();

void write_wav_header(FILE *outfile,int sample_rate,int stereo);

int spawn_encoder_process(enc_struct *e_stream);
int check_encoder_parameters(enc_struct *e_stream);

/*int convert_audio(format *in,format *out,short *dat,int num);*/

