/* list of functions in playlist.c */

tptr add_track_data(tptr *t_list);
int remove_track_data(tptr *t_list,tptr old);
int add_mp3_track(tptr *t_list,char *filename);
void empty_playlist(tptr *t_list);
int load_playlist(tptr *t_list,char *filename);
int reread_playlist(tptr *t_list);
tptr get_relative_track(tptr curnt,int inc);
int count_tracks(tptr t_list);
