/* these are all teh messages which the control system uses */


#define NO_COMMAND         0
#define CHANGE_TRACK       1
#define SET_VOLUME         2
#define SET_SPEED          3
#define SEEK               4
#define START_STOP         5
#define SOUNDCARD_INPUT    6
#define STICKY_MODE        7
#define RESET_CONTROL_FILE 8
#define RE_READ_PLAYLIST   9
#define EFFECT_COMPRESSOR  10
#define OUTPUT_SET         11
#define TERMINATE          12

 
char do_mixer_control(void);
