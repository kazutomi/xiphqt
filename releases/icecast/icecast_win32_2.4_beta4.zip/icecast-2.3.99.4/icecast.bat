@echo OFF
echo.
echo.
echo|set /p=Starting
.\bin\icecast.exe -v
echo Using config from "etc/icecast.xml" ...
echo.
echo Please open http://localhost:8000 in your web browser to see the web interface.
.\bin\icecast.exe -c .\etc\icecast.xml
