The new mixer and related files are 'works in progress' just to show all 
you people that I'm not being lazy.

The Idea is to build a generalised audio generation and processing interface
which can simulate any number of effects, audio connections and whatever
else your sick mind wants to throw in.....

The mixer has a series of modules each with a number of inputs and outputs, 
a single mixer system will have one final output which will be linked via 
function calls to all the components of the mixer. Each module is represented
by a data structure with a few standard paramaters common to all modules
and a selection of floating point and integer parameters which have meanings
dependent upon the type of module. Each module also has a private data
structure which isn't acessible outside of the module's code because the
data is pretty much meaningless.

yes I know this would e much better if it were done in an OO language, but 
portability does mean a lot right now.

This is a visualisation of the kind of thing I'm looking to do - imagine
a gui for this where you could click on any of these modules and fine tune 
settings or bind certain actions to keyboard events.

			       Encoder
                               Output
                                 A
				 |
				 |
                               Mixer          
                               Module
                               /  \
                              /    \
                             /      \
                            /        \     
                           /          \    
                     compressor       Delay 
                        /             Return --\
                       /               |        |
                      /                ^        |
                  mixer                |        v
                  / \                  |        |
                 /   \               Filter ---/
                /     \                |
               /       \               |
              /         \           Soundcard
         MP3PLayer1  MP3Player2  


Every module has a volume control, and a set of tunable parameters which 
define a control interface. There are special devices which have extra hooks
not covered by the simple int/float parameters. Specifically the audio players
register themselves with the playlist manager which permits the playlist 
to have more directo control over the players. It should also be possible
to hook the audio output into different stages of the mixer process - this
is especially useful with mixers where each channel can be previewed while
not affecting the output to the encoder.
