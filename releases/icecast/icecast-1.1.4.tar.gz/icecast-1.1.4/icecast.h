/* icecast.h
 * - Configuration Information
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifndef _ICECAST_CONFIG_H
#define _ICECAST_CONFIG_H

#define VERSION "1.1.4"
#define CLIENT_BUFFSIZE 1024
#define DEFAULT_TOUCH_FREQ 5
#define MAX_ERRORS 50
#define TIMEOUT 1

/* Flags for the console */
#define CONSOLE_ADMIN_TAIL 0
#define CONSOLE_ADMIN 1
#define CONSOLE_LOG 2
#define CONSOLE_BACKGROUND 3

/* These five for the accepted flag */
#define PENDING 0
#define PASSWORD_ACCEPTED 1
#define ICY_ACCEPTED 2
#define TAILING 4
#define REMOTE_OPER 8

#define DEFAULT_CLIENT_TIMEOUT 30
#define DEFAULT_PORT 8000
#define DEFAULT_ENCODER_PORT DEFAULT_PORT + 1
#define DEFAULT_REMOTE_ADMIN_PORT DEFAULT_PORT + 2
#define LISTEN_QUEUE 5
#define DEFAULT_MAX_CLIENTS 25
#define DEFAULT_MAX_SOURCES 5
#define DEFAULT_MAX_ADMINS 5
#define DEFAULT_MAX_DIRECTORIES 10; /* Can't find a logical place to change this in the code */
#define DEFAULT_SERVER_NAME "Lame Server"
#define DEFAULT_GENRE "Lame"
#define DEFAULT_BITRATE 128
#define DEFAULT_URL "http://www.lame.org:8000/"
#define DEFAULT_PUBLIC 0
#define DEFAULT_ENCODER_PASSWORD "letmein"
#define DEFAULT_OPER_PASSWORD "breakin"
#define DEFAULT_CLIENT_PASSWORD "prettyplease"
#define DEFAULT_DIRECTORY_SERVER "icecast.org"
#define DEFAULT_LOGFILE "icecast.log"
#define DEFAULT_REMOTE_ADMIN_PASSWORD "letmein"
#define DEFAULT_REDIRECTION 0
#define DEFAULT_REDIRECTION_HOST "icecast.org"
#define DEFAULT_REDIRECTION_PORT 8000
#define DEFAULT_REDIRECTION_RETRIES 5
#define DEFAULT_CONFIG_FILE "icecast.conf"
#define DEFAULT_STATSFILE "stats.log"
#define DEFAULT_STATSTIME 120
#define DEFAULT_IGNORE_SOURCE 0

#define SELECT_QUIET 1 /* Listen to one source and let the other ones sit still */
#define SELECT_STOP 2 /* Listen to one source and don't accept() any more */
#define SELECT_READ 3 /* Listen to one source and read() the others into void */

/* Define these if you want a mess on the screen */
#undef DEBUG_BYTES
#undef DEBUG_DIRECTORY
#undef DEBUG_HEADERS
#undef DEBUG_SOCKET
#endif
