/* mixer.c
 *
 * Copyright (c) 1999 Scott Manley, Barath Raghavan, Jack Moffitt, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License  
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */


/* Mixer system..... */

#include "mixer.h"
#include "liveice.h"
#ifdef HAVE_SYS_SOUNDCARD_H
#include <sys/soundcard.h>
#else
#include <machine/soundcard.h>
#endif
#include <time.h>

extern void init_channel_display(cptr ch);
extern void update_channel_display(cptr ch,int num);


short audio_buffer[BUF_SIZE];  
int   process_buffer[BUF_SIZE];

m_dat mixer;    /* global data field for the mixer */

/* data structure management */

/*Attempt to register an mp3 file int he tracklisting */
int add_track(char *filename){
	tptr new;
	new=(tptr)(malloc(sizeof(track)));
	
	/* Insert into linked list */
	if(mixer.t_list==NULL){
		/* this is the first mp3 - so it's a closed loop */
		mixer.t_list=new;
		new->next=new;
		new->prev=new;
	} else {
		/* there are already some here... add it at the end */
		new->next=mixer.t_list;
		new->prev=mixer.t_list->prev;
		mixer.t_list->prev=new;
		new->prev->next=new;
	} 
	
	/* Allocate memory for the filename */
	new->filename=malloc(strlen(filename)+1);
	strcpy(new->filename,filename);
	
	/* Increment number of tracks */
	mixer.t_number++;
	return 0;
}

/* Remove an mp3 structure from the track listing */

int del_track(tptr old){
	free(old->filename);
	if(mixer.t_list == old){		
		if(old->prev==old->next)
			mixer.t_list=NULL;
		else
			mixer.t_list=old->next;
	}
	old->next->prev=old->prev;
	old->prev->next=old->next;
	free(old);
	mixer.t_number--;
	return 0;
}

/* add a channel to the channel list */

int add_channel(cptr *new,char name[]){
	char mesg[256];
	if(*new==NULL){
		sprintf(mesg,"Adding New Channel %s",name);
		write_message(mesg,0);
		*new=malloc(sizeof(channel));
		strncpy((*new)->name,name,63);
		(*new)->curnt=mixer.t_list;
		(*new)->volume=1.0;
		(*new)->speed=1.0;
		(*new)->rate=0;
		(*new)->channels=0;
		(*new)->on=0;
		(*new)->stayon=0;
		mixer.c_number++;
		return 0;
	} else {
		write_message("Channel already allocated",0);
		return -1;
	}
}

/* Remove a channel from teh channel list */
int del_channel(cptr *old){
	char mesg[256];
	sprintf(mesg,"Removing Channel %s",(*old)->name);
	write_message(mesg,0);
	free(*old);
	*old=NULL;
	mixer.c_number--;
	return 0;
}

/* initialise mixer structure */
void init_mixer(int rate,int channels){
	int i;
	mixer.t_number=0;
	mixer.c_number=0;
	mixer.rate=rate;
	mixer.channels=channels;
	mixer.soundcard=0;
	mixer.out_mode=0;       
	/* open the control file */
	if(g_conf.mix_control==1){
		if((mixer.control_file=fopen(g_conf.mix_control_file,"w"))==NULL) {
			g_conf.mix_control=0;
			write_message("can't open mixer command file",0);
			write_message("Commangs will not be logged",0);
		}
	} else if(g_conf.mix_control==2) {
		if((mixer.control_file=fopen(g_conf.mix_control_file,"r"))==NULL){
			g_conf.mix_control=0;
			write_message("can't open mixer command file",0);
			write_message("reverting to full manual control",0);
		}
	}
	mixer.time_resolution=BUF_SIZE/((float)(g_conf.sample_rate)*(g_conf.stereo ? 2 : 1));
	mixer.seq_time=0;
	for(i=0;i<MAX_CHANNELS;i++)
		mixer.c_list[i]=NULL;
	
	mixer.t_list=NULL;
}

void kill_channel(cptr ch){
	int i;
/*printf("killing channel %s\n",ch->name);*/
	if((*ch).pid>0){
		kill((*ch).pid,15);
		(*ch).pid=0;
		(*ch).on=0;
		if((*ch).stream>2){
			fclose((*ch).fstr);
			ch->stream=0;
		}
	} else {
		(*ch).pid=0;
		(*ch).on=0;
	}
	
	for(i=0;i<BUF_SIZE;i++) (*ch).inbuf[i]=0;
}


/* step up through the list of tracks */
void change_channel(cptr ch,int inc){
	int change=0; 
	if(inc>0){
		ch->curnt=ch->curnt->next;
		change=1;
	} else if(inc<0) {
		ch->curnt=ch->curnt->prev;
		change=1;
	}
	(*ch).speed=1;
	kill_channel(ch);
#ifdef HAVE_CURSES
	init_channel_display(ch);
#else
	fprintf(stderr,"Channel %s selecting \n %s\n",ch->name,ch->curnt->filename);
#endif
}

char *my_basename(char *wholefilename)
{
return strrchr (wholefilename, '/');
}

/* spawn mpg123 */

int spawn_stream(char *filename,cptr ch){
	int strm[2],rate,channels,bad=0;
	pid_t pid;
	char mesg[1024],name[1024];
	while(bad<mixer.t_number){
		rate=format_of (ch->curnt->filename,&channels);
		ch->rate=rate;
		ch->channels=channels;
		if(rate>0){
#ifdef HAVE_BASENAME
			sprintf(mesg,"%6dkHz %2d Ch %s",ch->rate,ch->channels,basename(ch->curnt->filename));
#else
			sprintf(mesg,"%6dkHz %2d Ch %s",ch->rate,ch->channels,my_basename(ch->curnt->filename));
#endif
			write_message(mesg,0);
			bad=mixer.t_number;
			if(ch->stayon)
				ch->on=1;
		} else {
			sprintf(mesg,"Unable to play %s",name);
			write_message(mesg,0);
			change_channel(ch,1);
			bad++;
		}
	}
	if(rate>0){ 
		pipe(strm);
		pid=fork();
		if(pid){
			(*ch).pid=pid;
			close(strm[1]);
			(*ch).stream=strm[0];
			(*ch).fstr=fdopen((*ch).stream,"rb");
		} else {
			close(strm[0]);
			close(1);
			dup(strm[1]);
			close(strm[0]);
			close(strm[1]);
			/* close audio too - don't use the close_soundcard because it causes glitches*/
			close(g_conf.audio_fd);
			execlp("mpg123","mpg123","-sq",filename,NULL);
		}
		return 0;
	} else {
		return -1;
	}
}



void init_data_structures(void){
	FILE *in;
	char trackname[4096];/* yes I know that this may be too short... tough luck */
	init_mixer(g_conf.sample_rate,1+g_conf.stereo);
	
	if((in=fopen(g_conf.playlist,"r"))==NULL){
		fatal("opening playlist file");
	}
	while(!feof(in)){
		fscanf(in,"%[^\n]c",trackname);
		fgetc(in);
		add_track(trackname);
	}
	fclose(in);
	sprintf(trackname,"%d tracks added to list\n",mixer.t_number);
	write_message(trackname,0);
	/* just add 2 channels.... because that's all the interface supports */
	if(!(mixer.t_number>0))
		fatal("No legal Mp3 tracks in playlist file");
	add_channel(&mixer.c_list[0],"1");
#ifdef HAVE_CURSES
	mixer.c_list[0]->c_display=newwin(2,COLS-2,10,1);
#endif
	/*spawn_stream(mixer.c_list[0]->curnt->filename,mixer.c_list[0]);*/
	add_channel(&mixer.c_list[1],"2");
#ifdef HAVE_CURSES
	mixer.c_list[1]->c_display=newwin(2,COLS-2,13,1); 
#endif
	/*spawn_stream(mixer.c_list[1]->curnt->filename,mixer.c_list[1]);*/
}

/* channel operations */

void reset_channel(cptr ch){
	int i;
	for(i=0;i<BUF_SIZE;i++) (*ch).inbuf[i]=0;
	(*ch).volume=1.0;
	(*ch).speed=1.0;
	(*ch).on=0;
	(*ch).stream=0;
	(*ch).pid=0;
	(*ch).stayon=0;
}


/* Throttle the sample rate by sleeping  */
/* this can get really bursty at high sample rates - but this is only
used when we're not reading or writing to the card so there's nothing
unbuffered waiting for data */
/* This will break if anyone chages the time... so dont do that */
void synchronise_time(long samples){
	static time_t start=0;
	static unsigned long tot_samples=0;
	time_t now;
	long samplespersec=g_conf.sample_rate*(g_conf.stereo ? 2 : 1);
 
	if(start==0)
		time(&start);
	
	time(&now);
	tot_samples+=samples;
	if((tot_samples/(now-start+1))>samplespersec)
		usleep(1000000*samples/samplespersec);
			
}


void make_mono(short *stereo,short *mono,int num){
	unsigned int i;
	for(i=0;i<num;i++)
		mono[i]=(short)(((int)stereo[i*2]+(int)stereo[i*2+1])/2);
	
}

void make_stereo(short *mono,short *stereo,int num){
	unsigned int i;
	for(i=0;i<num;i++)
		stereo[i*2]=stereo[i*2+1]=mono[i];
	
}

void sep_stereo(short *stereo,short *left,short *right,int num){
	unsigned int i;
	for(i=0;i<num;i++){
		left[i]=stereo[i*2];
		right[i]=stereo[i*2+1];
	}  
}

void mix_stereo(short *left,short *right,short *stereo,int num){
	unsigned int i;
	for(i=0;i<num;i++){
		stereo[i*2]=left[i];
		stereo[i*2+1]=right[i];
	}  
}

void int_compress_samples(short *in, short *out,int num,int grain){
	unsigned int i,j;
	int smpl;
	
	for(i=0;i<num;i++){
		smpl=in[i*grain];
		for(j=1;j<grain;j++)
			smpl+=in[i*grain+j];
		out[i]=(short)(smpl/grain);
	}
	
}

void int_stretch_samples(short *in,short *out,int num,int grain){
	unsigned int i,j;
	for(i=0;i<num;i++)
		for(j=0;j<grain;j++)
			out[i*grain+j]=in[i];
	
}


/* this is a quick routine just to get proper spped control working - needs
   to be updated to use something whihc is less noisy */
void compress_samples(short *in, short *out,unsigned int num1,unsigned int num2){
	float step=(float)(num1)/num2;
	int i;
	for(i=0;i<num2;i++){
		out[i]=in[(int)(i*step)];
	}
}

void stretch_samples(short *in, short *out,unsigned int num1,unsigned int num2){
	float step=(float)(num1)/num2;
	int i;
	for(i=0;i<num2;i++){
		out[i]=in[(int)(i*step)];
	}
}


/* changes the length of a buffer of samples uses fast shortcuts where possible */
void change_time(short *in,short *out,unsigned int num_in,unsigned int num_out){
	int i;
	
	if(num_in>num_out){
		/* compress samples */
		if(num_in==(num_out<<1)){
			int_compress_samples(in,out,num_out,2);
		} else if ( num_in==(num_out<<2)) {
			int_compress_samples(in,out,num_out,4);
		} else {
			compress_samples(in,out,num_in,num_out);
		}
	} else if(num_in<num_out) {
		/* stretch samples */
		if((num_in<<1)==num_out){
			int_stretch_samples(in,out,num_in,2);
		} else if ((num_in<<2)==num_out) {
			int_stretch_samples(in,out,num_in,4);
		} else {
			stretch_samples(in,out,num_in,num_out);
		}
	} else {
		for(i=0;i<num_out;i++)
			out[i]=in[i];
	}
}

/* get audio flls the current channel's buffer with the next chunk of audio */
/* because of differing sample rates I whacked a fairly hefty buffer into this
   routine */
void get_audio(cptr ch){
	static short inbuf[BUF_SIZE*40],work1[BUF_SIZE*40],work2[BUF_SIZE];
	int i;
	unsigned int num_samples;
	
	
	if(ch->on){
		/* if the channel is turned on but the pid==0 then mpg123 hasn't actually been launched */
		if(ch->pid==0)
			spawn_stream(ch->curnt->filename,ch);
		num_samples=(int)((BUF_SIZE*ch->rate*ch->speed)/(mixer.rate*mixer.channels));
		i=fread(inbuf,2,num_samples*ch->channels,ch->fstr);
		if(i<num_samples*ch->channels){
			while(i<num_samples*ch->channels){
				inbuf[i]=0;
				i++;
			}
			change_channel(ch,1);
			if(ch->stayon)
				ch->on=1;
		}
		if(mixer.channels==1){
			if(ch->channels==2){
				make_mono(inbuf,work1,num_samples);       
				change_time(work1,ch->inbuf,num_samples,BUF_SIZE);
			} else {
				change_time(inbuf,ch->inbuf,num_samples,BUF_SIZE);
			}
		} else {
			if(ch->channels==2){
				sep_stereo(inbuf,work1,work2,num_samples);
				change_time(work1,inbuf,num_samples,BUF_SIZE>>1);
				change_time(work2,work1,num_samples,BUF_SIZE>>1);
				mix_stereo(inbuf,work1,ch->inbuf,BUF_SIZE>>1);
			} else {
				change_time(inbuf,work1,num_samples,BUF_SIZE>>1);
				make_stereo(work1,ch->inbuf,BUF_SIZE>>1);
			}
		}
	} else {
		for(i=0;i<BUF_SIZE;i++)
			ch->inbuf[i]=0;
	}
#ifdef HAVE_CURSES
	/* ho hum - lazy display */
	update_channel_display(ch,BUF_SIZE);
#endif
}

void play_chunks(FILE *pipe){
	int i,j,num,max;
	int played;
	num=BUF_SIZE;
	
#ifndef HAVE_CURSES  
	printf("\r");
#endif
	played=0;   /* keeps track of whether the soundcard has been used */
	/* if we're in half duplex mode and using line in then we've already monopolised the device :-( */
	if((mixer.soundcard) && !(g_conf.full_duplex) )
		played=1;
	/* And of course if we#re not using the card at all */
	if(!g_conf.soundcard)
		played=1;

	if((mixer.soundcard)&&(g_conf.soundcard)){
		read(g_conf.audio_fd,audio_buffer,BUF_SIZE*2);
		for(i=0;i<BUF_SIZE;i++) process_buffer[i]=audio_buffer[i];
		max=0;
		for(i=0;i<BUF_SIZE;i++){
			if(abs(audio_buffer[i])>max)
				max=abs(audio_buffer[i]);
		}
#ifdef HAVE_CURSES
		mv_draw_volume(8,20,max);
#else
		printf("%6d      ",max);
#endif
	} else {
		for(i=0;i<BUF_SIZE;i++) process_buffer[i]=0;
#ifdef HAVE_CURSES
		mv_draw_volume(8,20,0);
#endif
	}
	
	for(i=0;i<MAX_CHANNELS;i++){
		if(mixer.c_list[i]!=NULL){
			if(mixer.c_list[i]->on){
				get_audio(mixer.c_list[i]);
				/* if the correct output mode is selected then ply this channel */
				if((mixer.out_mode==(i+1)) && (!played)) {
					played=1;
					write(g_conf.audio_fd,mixer.c_list[i]->inbuf,num*2);
				}
				for(j=0;j<num;j++)
					process_buffer[j] += mixer.c_list[i]->inbuf[j] * mixer.c_list[i]->volume;
			}
		}
	}
	
	
	for(i=0;i<num;i++) {
		if((process_buffer[i]<CLIP)&&(process_buffer[i]>-CLIP))
			audio_buffer[i]=(short)(process_buffer[i]);
		else if (process_buffer[i]>0) 
			audio_buffer[i]=MAX_SAMPLE-(CLIP_A/(CLIP_B+process_buffer[i]));
		else 
			audio_buffer[i]=-(MAX_SAMPLE-(CLIP_A/(CLIP_B-process_buffer[i])));
	}
	max=0;
	for(i=0;i<BUF_SIZE;i++){
		if(abs(audio_buffer[i])>max)
			max=abs(audio_buffer[i]);
	}
#ifdef HAVE_CURSES
	mv_draw_volume(16,20,max);
#else
	printf("%6d      ",max);
#endif
	fwrite(audio_buffer,2,num,pipe);
	if(!played)
		write(g_conf.audio_fd,audio_buffer,num*2);
	/* if soundcard is not being used we need to keep sync ourselves */
	synchronise_time(num);
}


/* current control system......*/
void controls(char inp){
	switch(inp){
	case '1': 
		change_channel(mixer.c_list[0],1);
		break;
	case 'q':
		change_channel(mixer.c_list[0],-1);
		break;
	case 'w':
		change_channel(mixer.c_list[0],0);
		break;
	case '2':
		mixer.c_list[0]->on=!mixer.c_list[0]->on;
#ifdef HAVE_CURSES
		init_channel_display(mixer.c_list[0]);
#else
		printf("Channel %s On: %d\n",mixer.c_list[0]->name,mixer.c_list[0]->on);
#endif
		break;
	case 'a': 
		change_channel(mixer.c_list[1],1);
		break;
	case 'z':
		change_channel(mixer.c_list[1],-1);
		break;
	case 'x':
		change_channel(mixer.c_list[1],0);
		break;
	case 's':
		mixer.c_list[1]->on=!mixer.c_list[1]->on;
#ifdef HAVE_CURSES
		init_channel_display(mixer.c_list[1]);
#else
		printf("Channel %s On: %d\n",mixer.c_list[1]->name,mixer.c_list[1]->on);
#endif
		break;
	case '3':
		mixer.c_list[0]->volume+=0.05;
#ifndef HAVE_CURSES
		printf("%f\n",mixer.c_list[0]->volume);
#endif
		break;
	case 'e':
		mixer.c_list[0]->volume-=0.05;
		if(mixer.c_list[0]->volume<0)
			mixer.c_list[0]->volume=0;
#ifndef HAVE_CURSES 
		printf("%f\n",mixer.c_list[0]->volume);
#endif
		break;
	case 'd':
		mixer.c_list[1]->volume+=0.05;
#ifndef HAVE_CURSES
		printf("%f\n",mixer.c_list[1]->volume);
#endif
		break;
	case 'c':
		mixer.c_list[1]->volume-=0.05;
		if(mixer.c_list[1]->volume<0)
			mixer.c_list[1]->volume=0;
#ifndef HAVE_CURSES
		printf("%f\n",mixer.c_list[1]->volume);
#endif
		break;
	case '4':
		mixer.c_list[0]->speed*=1.005;
#ifndef HAVE_CURSES
		printf("%f\n",mixer.c_list[0]->speed);
#endif
		break;
	case 'r':
		mixer.c_list[0]->speed*=0.99;
#ifndef HAVE_CURSES
		printf("%f\n",mixer.c_list[0]->speed);
#endif
		break;
	case 'f':
		mixer.c_list[1]->speed*=1.01;
#ifndef HAVE_CURSES
		printf("%f\n",mixer.c_list[1]->speed);
#endif
		break;
	case 'v':
		mixer.c_list[1]->speed*=0.99;
#ifndef HAVE_CURSES
		printf("%f\n",mixer.c_list[1]->speed);
#endif
		break;
	case 'g':
		mixer.c_list[1]->stayon= !mixer.c_list[1]->stayon;
#ifndef HAVE_CURSES
		printf("Channel %s Sticky Mode: %d\n",mixer.c_list[1]->name,mixer.c_list[1]->stayon);
#endif 
		break;
	case '5':
		mixer.c_list[0]->stayon = !mixer.c_list[0]->stayon;
#ifndef HAVE_CURSES
		printf("Channel %s Sticky Mode: %d\n",mixer.c_list[0]->name,mixer.c_list[0]->stayon);
#endif
		break;   
	case 't':
		if(mixer.out_mode==1)
			mixer.out_mode=0;
		else
			mixer.out_mode=1;
		break;
	case 'b':
		if(mixer.out_mode==2)
			mixer.out_mode=0;
		else 
			mixer.out_mode=2;
		break;
	case ' ':
		if(g_conf.soundcard){
			mixer.soundcard=!mixer.soundcard;
			if(!g_conf.full_duplex){
				write_message("Toggling Soundcard IO",0);
				close_soundcard();
				/* lazy - whatever is done next will determine read/write*/
				open_soundcard(O_RDWR);
			}
		} else {
			write_message("soundcard not enabled",0);
		}
		break;
	}
}

/* turns a keyboard command into an internal command */
int translate_command(char inp,int *channel,float *parms){
	int cmd;
	switch(inp){
	case '1': 
		*channel=0;
		parms[0]=1;
		cmd=CHANGE_TRACK;
		break;
	case 'q':
	        *channel=0;
		parms[0]=-1;
		cmd=CHANGE_TRACK;
		break;
	case 'w':
		*channel=0;
		parms[0]=0;
		cmd=CHANGE_TRACK;
		break;
	case '2':
		parms[0]=!mixer.c_list[0]->on;
		*channel=0;
		cmd=START_STOP;
		break;
	case 'a': 
		*channel=1;
		parms[0]=1;
		cmd=CHANGE_TRACK;
		break;
	case 'z':
		*channel=1;
		parms[0]=-1;
		cmd=CHANGE_TRACK;
		break;
	case 'x':
		*channel=1;
		parms[0]=0;
		cmd=CHANGE_TRACK;
		break;
	case 's':
		parms[0]=!mixer.c_list[1]->on;
		*channel=1;
		cmd=START_STOP;
		break;
	case '3':
		parms[0]=mixer.c_list[0]->volume+0.05;
		*channel=0;
		cmd=SET_VOLUME;
		break;
	case 'e':
		parms[0]=mixer.c_list[0]->volume-0.05;
		*channel=0;
		cmd=SET_VOLUME;
		break;
	case 'd':
		parms[0]=mixer.c_list[1]->volume+0.05;
		*channel=1;
		cmd=SET_VOLUME;
		break;
	case 'c':
		parms[0]=mixer.c_list[1]->volume-0.05;
		*channel=1;
		cmd=SET_VOLUME;
		break;
	case '4':
		parms[0]=mixer.c_list[0]->speed+0.01;
		*channel=0;
		cmd=SET_SPEED;
		break;
	case 'r':
		parms[0]=mixer.c_list[0]->speed-0.01;
		*channel=0;
		cmd=SET_SPEED;
		break;
	case 'f':
		parms[0]=mixer.c_list[1]->speed+0.01;
		*channel=1;
		cmd=SET_SPEED;
		break;
	case 'v':
		parms[0]=mixer.c_list[1]->speed-0.01;
		*channel=1;
		cmd=SET_SPEED;
		break;
	case 'g':
		parms[0]=!mixer.c_list[1]->stayon;
		*channel=1;
		cmd=STICKY_MODE;
		break;
	case '5':
		parms[0]=!mixer.c_list[0]->stayon;
		*channel=0;
		cmd=STICKY_MODE;
		break;   
	case 't':
		if(mixer.out_mode==1)
			parms[0]=0;
		else
			parms[0]=1;
		cmd=OUTPUT_SET;
		break;
	case 'b':
		if(mixer.out_mode==2)
			parms[0]=0;
		else 
			parms[0]=2;
		cmd=OUTPUT_SET;
		break;
	case ' ':
		parms[0]=(!mixer.soundcard) && g_conf.soundcard;
		cmd=SOUNDCARD_INPUT;
		break;
	default:
		cmd=NO_COMMAND;
		channel=0;
		parms[0]=0.0;
	}
	return cmd;
}

char * command_name(int cmd){
	char *c_str;
	switch(cmd){
	case(NO_COMMAND):
		c_str="NO_COMMAND";
		break;
	case(CHANGE_TRACK):
		c_str="CHANGE_TRACK";
		break;
	case(START_STOP):
		c_str="START_STOP";
		break;
	case(SET_VOLUME):
		c_str="SET_VOLUME";
		break;
	case(OUTPUT_SET):
		c_str="OUTPUT_SET";
		break;
	case(STICKY_MODE):
		c_str="STICKY_MODE";
		break;
	case(SOUNDCARD_INPUT):
		c_str="SOUNDCARD_INPUT";
		break;
	default:
		c_str="ooops";
	}
	return c_str;
}

/* actually performs the config change.... */
int exec_command(int cmd,int channel,float *parms){
	switch(cmd){
	case  CHANGE_TRACK:
		change_channel(mixer.c_list[channel],parms[0]);

		break;
	case START_STOP:
		mixer.c_list[channel]->on=parms[0];
#ifdef HAVE_CURSES
		init_channel_display(mixer.c_list[channel]);
#else
		printf("Channel %s On: %d\n",mixer.c_list[channel]->name,mixer.c_list[channel]->on);
#endif
		break;
	case SET_VOLUME:
		if(parms[0]<0.0) parms[0]=0.0;
		mixer.c_list[channel]->volume=parms[0];
#ifndef HAVE_CURSES
		printf("Ch: %d Vol: %f\n",channel,mixer.c_list[channel]->volume);
#endif
		break;
	case SET_SPEED:
		if(parms[0]<0.01) parms[0]=0.01;
		else if(parms[0]>4) parms[0]=4;
		mixer.c_list[channel]->speed=parms[0];
#ifndef HAVE_CURSES
		printf("Ch: %d Speed: %f\n",channel,mixer.c_list[channel]->speed);
#endif
		break;
	case OUTPUT_SET:
		mixer.out_mode=parms[0];
		break;
	case STICKY_MODE:
		mixer.c_list[channel]->stayon=parms[0];
#ifndef HAVE_CURSES
		printf("Channel %s Sticky Mode: %d\n",mixer.c_list[channel]->name,mixer.c_list[channel]->stayon);
#endif
		break;
	case SOUNDCARD_INPUT:
		if(g_conf.soundcard){
			mixer.soundcard=parms[0];
			if(!g_conf.full_duplex){
				write_message("Toggling Soundcard IO",0);
				close_soundcard();
				/* lazy - whatever is done next will determine read/write*/
				open_soundcard(O_RDWR);
			}
		} else {
			write_message("soundcard not enabled",0);
		}
		break;
	}
}

int check_command_file(int *channel,float *parms){
	double delta;
	static double next_time;
	static int start=1;
	int cmd;
	if(start) {
		start=0;
		fscanf(mixer.control_file,"%lg",&next_time);
	}
	if ( next_time < (mixer.seq_time + 0.5 * mixer.time_resolution)){
		write_message("execing command",0);
		fscanf(mixer.control_file,"%d %d",&cmd,channel);
		switch(cmd){
		case START_STOP:
		case CHANGE_TRACK:
		case SET_VOLUME:
		case SET_SPEED:
			fscanf(mixer.control_file,"%g",&parms[0]);
			break;
		}
	        fscanf(mixer.control_file,"%lg",&next_time);
		if(feof(mixer.control_file)){
			fclose(mixer.control_file);
			g_conf.mix_control=0;
			write_message("control file exhausted",0);
		}
		return cmd;
	} else {
		return NO_COMMAND;
	}
}

/* assumes teh output file is already open */
void log_command(int cmd,int channel,float *parms){
	int n_param,no_log,i;
	
	switch(cmd){
	case OUTPUT_SET:	
	case STICKY_MODE:
	case SOUNDCARD_INPUT:
	case NO_COMMAND:
		no_log=1;
		break;
	case START_STOP:
	case CHANGE_TRACK:
	case SET_VOLUME:
	case SET_SPEED:
		no_log=0;
		n_param=1;
		break;
	default:
		no_log=1;
	}
	if(!no_log){
		fprintf(mixer.control_file,"%f\t%d\t%d\t",mixer.seq_time,cmd,channel);
		for(i=0;i<n_param;i++) 
			fprintf(mixer.control_file,"%f\t",parms[i]);
		fprintf(mixer.control_file,"\n");
	}
}

/* new control system is required */
char do_mixer_control(void){
	char inp=0;
	int cmd;
	int channel;
	float parms[10];
	mixer.seq_time+=mixer.time_resolution;
	if(g_conf.mix_control!=2){
		inp=get_inp_char();
		cmd=translate_command(inp,&channel,parms);
	} else {
		cmd=check_command_file(&channel,parms);
	}
	if(g_conf.mix_control==1)
		log_command(cmd,channel,parms);
	/*fprintf(stderr,"%c %s %d %f\n",inp,command_name(cmd),channel,parms[0]);*/
	exec_command(cmd,channel,parms);
	return inp;
}


/* mp3mixer mode.... requires input file called playlist which lists mp3's */
/* try find / -name "*.mp3" > playlist */
/* in theory..... you can stream from other live sources by putting */
/* http: streams in the playlist file.....  */
void mp3mixer(void){
	char inp=0;
	FILE *pipe;
	
	signal(SIGCHLD,SIG_IGN);
	if(g_conf.soundcard)
		open_soundcard(O_RDWR);
	if((pipe=fopen(g_conf.sound_pipe,"wb"))==NULL)
		fatal("opening raw audio pipe for writing sound\n");
	draw_mixer_display();
	init_data_structures();
	change_channel(mixer.c_list[0],0);
	change_channel(mixer.c_list[1],0);
	/* a lot of people want this to go straight into playing the playlist */ 
	mixer.c_list[0]->stayon = !mixer.c_list[0]->stayon;
	mixer.c_list[0]->on=1;
#ifdef HAVE_CURSES
		init_channel_display(mixer.c_list[0]);
#endif

	while(inp!='+'){
		play_chunks(pipe);
		inp=do_mixer_control();
#ifdef HAVE_CURSES
		refresh();
		doupdate();
#endif
	}
	if(g_conf.mix_control)
		fclose(mixer.control_file);
	kill_channel(mixer.c_list[0]);
	kill_channel(mixer.c_list[0]);
	fclose(pipe);
	if(g_conf.soundcard)
		close_soundcard();
}







