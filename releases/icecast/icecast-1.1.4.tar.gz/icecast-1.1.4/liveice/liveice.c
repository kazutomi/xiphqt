/* liveice.c
 *
 * Copyright (c) 1999 Scott Manley, Barath Raghavan, Jack Moffitt, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License  
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "liveice.h"

extern int errno;

/* default names */
char sound_pipe_name[] = "raw.pipe";
char mpeg_pipe_name[] = "mpeg.pipe";
char default_server[] = "localhost";
char default_playlist[] = "playlist";
char default_password[]= "letmein";
char default_icy_name[]= "LiveCast";
char default_icy_genre[]= "live";
char default_icy_url[]= "localhost";
char default_mix_control_file[]="mix_command";

/* default encoder commands */
char AJ_encoder_command[]="encoder";
char L3ENC_encoder_command[]="l3enc";
char MP3ENC_encoder_command[]="mp3enc";
char SCREAMER_encoder_command[]="lamer";




void alarm_timeout(int signo){
	write_message("alarm timeout signal",1);
	signal (SIGALRM, SIG_IGN);
	signal (SIGPIPE, SIG_DFL);
	g_conf.terminate_now=1;
}


void arm ( unsigned int secs){
	if (secs == 0) {                      /* reset */
		signal (SIGALRM, SIG_IGN);
		alarm (0);
	} else {                              /* set */
		signal (SIGALRM, alarm_timeout);
		alarm (secs);
	} 
} 

/* Fatal error Handler */
void fatal(char *text)
{
	fix_interface();
	close_soundcard();
	fprintf(stderr, "%6d:Error: %s\n",getpid(),text);
	exit(1);
}



void default_config(void){
	/*defaults */
	g_conf.port=PORT;
	g_conf.server=default_server;
	g_conf.mpeg_pipe=mpeg_pipe_name;
	g_conf.sound_pipe=sound_pipe_name;
	g_conf.playlist=default_playlist;
	g_conf.password=default_password;
	g_conf.icy_name=default_icy_name;
	g_conf.icy_genre=default_icy_genre;
	g_conf.icy_url=default_icy_url;
	g_conf.icy_public=1;
	g_conf.bitrate=BITRATE;
	g_conf.sample_rate=SAMPLE_RATE; 
	g_conf.stereo=0;
	g_conf.full_duplex=0;
	g_conf.soundcard=1;           
	g_conf.encoder=DEFAULT_ENCODER;
#if DEFAULT_ENCODER==L3ENC
	g_conf.encoder_cmd=malloc(strlen(L3ENC_encoder_command)+2);
	strcpy(g_conf.encoder_cmd,L3ENC_encoder_command);
#elif DEFAULT_ENCODER==MP3ENC
	g_conf.encoder_cmd=malloc(strlen(MP3ENC_encoder_command)+2);
	strcpy(g_conf.encoder_cmd,MP3ENC_encoder_command);
#elif DEFAULT_ENCODER==AJ_ENCODER
	g_conf.encoder_cmd=malloc(strlen(AJ_encoder_command)+2);
	strcpy(g_conf.encoder_cmd,AJ_encoder_command);
#elif DEFAULT_ENCODER==SCREAMER
	g_conf.encoder_cmd=malloc(strlen(SCREAMER_encoder_command)+2);
	strcpy(g_conf.encoder_cmd,SCREAMER_encoder_command);
#else
	/* None of the other encoders work yet - Go and tell the authors! */
	g_conf.encoder_cmd=NULL;
#endif
	g_conf.copyright=0;
	g_conf.debug=0;
	g_conf.rw_size=4096;
	g_conf.mixer=0;	
	g_conf.mix_control=0; 
	g_conf.mix_control_file=default_mix_control_file;
	g_conf.terminate_now=0;
}

void read_config_file(char *file){
	FILE *in;
	char line[8192],cmd[8192];   /*So don't make any lines bigger....*/
	int i;
	if((in=fopen(file,"r"))==NULL){
		sprintf(line,"Could not open File %s",file);
		write_message(line,0);
		return;
	}
	
	while(!feof(in)){
		/* read fisrt CMD using scanf */
		fscanf(in,"%s",cmd);
		/* then deal with the rest character at a time */
		i=0;
		line[0]=fgetc(in);
		/* strip off leading spaces */
		while(((line[0]==' ') || (line[0]=='\t'))&&(!feof(in))){
			line[0]=fgetc(in);
		}
		while((line[i]!='\n')&&(!feof(in))){
			i++;
			line[i]=fgetc(in);
		}
		line[i]=0;
		/*printf("Cmd: %s Parm: %s\n",cmd,line);*/
		if(cmd[0]!='#'){
			/* make Everything Upper case */
			i=0;
			while(cmd[i]!=0) {
				cmd[i]=toupper(cmd[i]);
				i++;
			}
			if(!strcmp(cmd,"BITRATE"))
				sscanf(line,"%d",&(g_conf.bitrate));
			else if(!strcmp(cmd,"CONTROL_FILE")){
				if(g_conf.mix_control_file!=default_mix_control_file)
					free(g_conf.mix_control_file);
				g_conf.mix_control_file=malloc(strlen(line)+2);
				strcpy(g_conf.mix_control_file,line);
			}
			else if(!strcmp(cmd,"COPYRIGHT"))
				g_conf.copyright=1;
			else if(!strcmp(cmd,"DEBUG"))
				sscanf(line,"%d",&(g_conf.debug));
			else if(!strcmp(cmd,"FULL_DUPLEX"))
				g_conf.full_duplex=1;
			else if(!strcmp(cmd,"GENRE")){
				if(g_conf.icy_genre!=default_icy_genre)
					free(g_conf.icy_genre);
				g_conf.icy_genre=malloc(strlen(line)+2);
				strcpy(g_conf.icy_genre,line);
			} else if(!strcmp(cmd,"HALF_DUPLEX"))
				g_conf.full_duplex=0;
			else if(!strcmp(cmd,"MIX_CONTROL_AUTO"))
				g_conf.mix_control=2;
			else if(!strcmp(cmd,"MIX_CONTROL_LOGGED"))
				g_conf.mix_control=1;
			else if(!strcmp(cmd,"MIX_CONTROL_MANUAL"))
				g_conf.mix_control=0;		       
			else if(!strcmp(cmd,"MIXER"))
				g_conf.mixer=1;
			else if(!strcmp(cmd,"MONO"))
				g_conf.stereo=1;
			else if(!strcmp(cmd,"NAME")) {
				if(g_conf.icy_name!=default_icy_name)
					free(g_conf.icy_name);
				g_conf.icy_name=malloc(strlen(line)+2);
				strcpy(g_conf.icy_name,line);
			}
			else if(!strcmp(cmd,"NO_COPYRIGHT"))
				g_conf.copyright=0;
			else if(!strcmp(cmd,"NO_MIXER"))
				g_conf.mixer=0;
			else if(!strcmp(cmd,"NO_SOUNDCARD"))
				g_conf.soundcard=0;
			else if(!strcmp(cmd,"PASSWORD")) {
				if(g_conf.password!=default_password)
					free(g_conf.password);
				g_conf.password=malloc(strlen(line)+2);
				strcpy(g_conf.password,line);
			} else if(!strcmp(cmd,"PLAYLIST")) {
				if(g_conf.playlist!=default_playlist)
					free(g_conf.playlist);
				g_conf.playlist=malloc(strlen(line)+2);
				strcpy(g_conf.playlist,line); 
			} else if(!strcmp(cmd,"PORT"))
				sscanf(line,"%d",&(g_conf.port));
			else if(!strcmp(cmd,"PUBLIC"))
				sscanf(line,"%d",&(g_conf.icy_public));
			else if(!strcmp(cmd,"SAMPLE_RATE"))
				sscanf(line,"%d",&(g_conf.sample_rate));
			else if(!strcmp(cmd,"SERVER")) {
				if(g_conf.server!=default_server)
					free(g_conf.server);
				g_conf.server=malloc(strlen(line)+2);
				strcpy(g_conf.server,line);
			} else if (!strcmp(cmd,"SOUNDCARD"))
				g_conf.soundcard=1;
			else if(!strcmp(cmd,"STEREO"))
				g_conf.stereo=2;
			else if(!strcmp(cmd,"URL")) {
				if(g_conf.icy_url!=default_icy_url)
					free(g_conf.icy_url);
				g_conf.icy_url=malloc(strlen(line)+2);
				strcpy(g_conf.icy_url,line);
			} else if(!strcmp(cmd,"USE_AJ_ENCODER")) {
				g_conf.encoder=AJ_ENCODER;
				free(g_conf.encoder_cmd);
				if(line[0]!=0){
					g_conf.encoder_cmd=malloc(strlen(line+2));
					strcpy(g_conf.encoder_cmd,line);
				} else {
					g_conf.encoder_cmd=malloc(strlen(AJ_encoder_command)+2);
					strcpy(g_conf.encoder_cmd,AJ_encoder_command);
				}
			} else if(!strcmp(cmd,"USE_L3ENC")) {
				g_conf.encoder=L3ENC;
				free(g_conf.encoder_cmd);
				if(line[0]!=0){
					g_conf.encoder_cmd=malloc(strlen(line)+2);
					strcpy(g_conf.encoder_cmd,line);
				} else {
					g_conf.encoder_cmd=malloc(strlen(L3ENC_encoder_command)+2);
					strcpy(g_conf.encoder_cmd,L3ENC_encoder_command);
					
				}
			} else if(!strcmp(cmd,"USE_MP3ENC")) {
				g_conf.encoder=MP3ENC;
				free(g_conf.encoder_cmd);
				if(line[0]!=0){
					g_conf.encoder_cmd=malloc(strlen(line)+2);
					strcpy(g_conf.encoder_cmd,line);
				} else {
					g_conf.encoder_cmd=malloc(strlen(MP3ENC_encoder_command)+2);
					strcpy(g_conf.encoder_cmd,MP3ENC_encoder_command);
				}
			} else if(!strcmp(cmd,"USE_SCREAMER")) {
				g_conf.encoder=SCREAMER;
				free(g_conf.encoder_cmd);
				if(line[0]!=0){
					g_conf.encoder_cmd=malloc(strlen(line)+2);
					strcpy(g_conf.encoder_cmd,line);
				} else {
					g_conf.encoder_cmd=malloc(strlen(SCREAMER_encoder_command)+2);
					strcpy(g_conf.encoder_cmd,SCREAMER_encoder_command);
				}
			} else if(!strcmp(cmd,"VERBOSE"))
				sscanf(line,"%d",&(g_conf.debug));
			else {
				sprintf(line,"%s Configuration Option Not Understood",cmd);
				write_message(line,0);   
     }
   }
 }
 fclose(in);
}

/* Fix up the final params and bomb out if anything stupid is set */
/* should catch any brain-dead configurations */
/* this is going to get real messy if I try to fix everything... */
void check_config(void){
	int speed;
	
	/* select a sample rate we can use */
	speed=get_legal_rate(g_conf.sample_rate);
	if(speed != g_conf.sample_rate){
	        fprintf(stderr,"Using Sample Rate %d instead of %d\n",speed,g_conf.sample_rate);
		g_conf.sample_rate=speed;
	}

	/* Convert no. of channels to stereo mode */
	if(g_conf.stereo==2)
	        g_conf.stereo = 1;
	else
	        g_conf.stereo = 0;

	/* AJ_ENCODER can't do < 32KBPs or < 32Khz */
	if(g_conf.encoder==AJ_ENCODER){
		if(g_conf.sample_rate<32000) fatal("Doh! encoder can't do less than 32000 kHz");
		if(g_conf.bitrate<32000) fatal("Sorry - encoder doesn' compress below 32Kbps");
	}
	
	/* if you choose simple mode and switch of the soundcard then 
	   you won't get anything - Eeejit! */
	if((!g_conf.mixer)&&(!g_conf.soundcard))
		fatal("Line In mode *and* no soundcard??????? Eeejit!");

}

void do_config(int argc, char *argv[])
{
	int i;
	default_config();

	read_config_file("liveice.cfg");
	if(argc>1)
	  g_conf.server=argv[1];
	for(i=2;i<argc;i++){
		if(argv[i][0]=='-'){
			switch(argv[i][1]){
			case 'n':
			        i++;
			        g_conf.icy_name=argv[i];
			        break;
			case 'g':
			        i++;
				g_conf.icy_genre=argv[i];
			case 'x':
			        g_conf.icy_public=0;
				break;
			case 'P':
                                i++;
			        g_conf.password=argv[i];
				break;
		        case 'u':
			        i++;
				g_conf.icy_url=argv[i];
				break;
			case 'o':
				i++;
				g_conf.port=atoi(argv[i]);
				break;
			case 'b':
			        i++;
				g_conf.bitrate=atoi(argv[i]);
				break;
			case 'r':
				i++;
				g_conf.sample_rate=atoi(argv[i]);
				break;
			case 'c':
			        i++;
				g_conf.stereo=atoi(argv[i]);
				break;
			case 'C':
				g_conf.copyright=1;
		        case 'f':
			        g_conf.full_duplex=1;
				break;
			case 'h':
			        g_conf.full_duplex=0;
				break;
			case 'V':
			        g_conf.debug=1;
 				break;
			case 'w':
			        i++;
			        g_conf.rw_size=atoi(argv[i]);
				break;
			case 'M':
			        g_conf.mixer=1;
				break;
			case 'm':
			        g_conf.mixer=0;
				break;
			case 'F':
			        i++;
			        read_config_file(argv[i]);
				break;
			case 'k':
				i++;
				g_conf.mix_control=atoi(argv[i]);
				break;
			case 'K':
				i++;
				g_conf.mix_control_file=argv[i];
				break;
			default:
				write_message("Unrecognised command line switch",0);
				break;
			} 
		} else {
		  write_message("Unrecognised Command Line option",0);
		}
	}

	check_config();
}

/* General sort of paranoia check to ensure that we can do the thigns we */
/* want to with the files we've specified */
void setup_pipes(void)
{
	struct stat stats;
	if(mkfifo(g_conf.sound_pipe,S_IRUSR | S_IWUSR)) {
  		stat(g_conf.sound_pipe,&stats);
  		if(!(stats.st_mode|S_IFIFO))
    			fatal("Sound pipe file exists and is not a pipe");
  		if(!(stats.st_mode|(S_IWUSR|S_IRUSR)))
    			fatal("cannot read/write sound pipe");
	}

	if(mkfifo(g_conf.mpeg_pipe,S_IRUSR | S_IWUSR)) {
		stat(g_conf.mpeg_pipe,&stats);
		if(!(stats.st_mode|S_IFIFO))
			fatal("mpeg pipe file exists and is not a pipe");
		if(!(stats.st_mode|(S_IWUSR|S_IRUSR)))
			fatal("cannot read/write mpeg pipe");
	}
}

void shutdown_server(void){
  /* this will do something soon */
write_message("shutting Down",0);
wait(NULL);
}



int main(int argc, char *argv[])
{
        write_message("do_config()...",1);
	do_config(argc, argv);
	write_message("...... done",1);
        write_message("setup_pipes()...",1);
	setup_pipes();
        write_message(".... done.",1);
        write_message("encode()...",1);
	encoding();
        write_message("all done! Exiting.",0);
	exit(0);
}
