/* get_local_stream.c
 *
 * Copyright (c) 1999 Scott Manley, Barath Raghavan, Jack Moffitt, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License  
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */


/* this file spawns a process to write to a pipe and spwans l3enc to read */
/* from this pipe */
/* several encoders are listed..... */


#include "liveice.h"
#include "serverlib.h"
#ifdef HAVE_SYS_SOUNDCARD_H
#include <sys/soundcard.h>
#else
#include <machine/soundcard.h>
#endif
#include <sys/ioctl.h>
#define BUF_LENGTH 256
#define BUF_SIZE BUF_LENGTH*2
#define BUFLEN 1024*32

extern int errno;

/* suggested legal sample rates */
int legal_rates[7] = { 8000, 11025, 16000, 22050, 32000, 44100, 48000 };


int get_legal_rate(int rate)
{
        float diff,bdiff;
	int best,i;
	bdiff=fabs((float)(rate-legal_rates[0])/legal_rates[0]);
	best=0;
	for(i=1;i<7;i++){
	       diff=fabs((float)(rate-legal_rates[i])/legal_rates[i]);
	       if(diff<bdiff){
	               bdiff=diff;
		       best=i;
	       }
	}
	return legal_rates[best];
}



/* Open the soundcard with the right params */
void check_soundcard(void)
{
        int format,stereo,speed,caps;
	fprintf(stderr,"Initialising Soundcard\n");

	if((g_conf.audio_fd=open("/dev/dsp",O_RDWR))==-1)
	        fatal("Failed to open sound device");

        /* see if the card can do full_duplex */
        if(g_conf.full_duplex){
                ioctl(g_conf.audio_fd, SNDCTL_DSP_GETCAPS, &caps);
	        if(caps & DSP_CAP_DUPLEX){
#ifdef HAVE_SYS_SOUNDCARD_H
	                ioctl(g_conf.audio_fd, SNDCTL_DSP_SETDUPLEX, 0);  
#else
			ioctl(g_conf.audio_fd, DSP_CAP_DUPLEX, 0);
#endif
	        }
		else {
		        write_message("Sound Card Driver Can't Do Full Duplex",0);
			g_conf.full_duplex=0;
		}
	}

	ioctl(g_conf.audio_fd, SNDCTL_DSP_GETFMTS, &format);
	if(!(format&AFMT_S16_LE))
		fatal("16bit mode not supported by driver");

	format = AFMT_S16_LE;
	if(ioctl(g_conf.audio_fd,SNDCTL_DSP_SETFMT,&format)==-1)
		fatal("Failed to set data format\n");
	
	stereo = g_conf.stereo;
	if(ioctl(g_conf.audio_fd,SNDCTL_DSP_STEREO,&stereo)==-1)
		fatal("Something went wrong with the stereo setting\n");

	speed=g_conf.sample_rate;
	if(ioctl(g_conf.audio_fd,SNDCTL_DSP_SPEED,&speed)==-1)
		fatal("Speed Setting failed\n");

	
	fprintf(stderr,"16Bit %dHz ",g_conf.sample_rate);
	if(g_conf.stereo)
	          fprintf(stderr,"Stereo ");
	if(g_conf.full_duplex)
	 	  fprintf(stderr,"Full Duplex ");
	fprintf(stderr,"\n");
	close(g_conf.audio_fd);
	g_conf.audio_fd=0;
}

void open_soundcard(int flags){
       int format,stereo,speed;
       write_message("Opening Soundcard",1);
        
	if((g_conf.audio_fd=open("/dev/dsp",flags))==-1)
	        fatal("Failed to open sound device");
	
        if(g_conf.full_duplex)
#ifdef HAVE_SYS_SOUNDCARD_H
	        ioctl(g_conf.audio_fd, SNDCTL_DSP_SETDUPLEX, 0);  
#else
		ioctl(g_conf.audio_fd, DSP_CAP_DUPLEX, 0);
#endif

	format = AFMT_S16_LE;
	if(ioctl(g_conf.audio_fd,SNDCTL_DSP_SETFMT,&format)==-1)
		fatal("Failed to set data format\n");
	
	stereo = g_conf.stereo;
	if(ioctl(g_conf.audio_fd,SNDCTL_DSP_STEREO,&stereo)==-1)
		fatal("Something went wrong with the stereo setting\n");

	speed=g_conf.sample_rate;
	if(ioctl(g_conf.audio_fd,SNDCTL_DSP_SPEED,&speed)==-1)
		fatal("Speed Setting failed\n");
}

void close_soundcard(void)
{
  write_message("Closing Soundcard",1);
	ioctl(g_conf.audio_fd, SNDCTL_DSP_RESET, 0);
        close(g_conf.audio_fd);
}

void read_soundcard()
{
	short audiobuf[4096];
	FILE *pipe;

	if((pipe=fopen(g_conf.sound_pipe,"wb"))==NULL)
		fatal("opening raw audio pipe for writing sound\n");
	draw_simple_display();
	while(get_inp_char()!='+'){
		read(g_conf.audio_fd,audiobuf,2*g_conf.rw_size);
		if(g_conf.full_duplex)
		  write(g_conf.audio_fd,audiobuf,2*g_conf.rw_size);
		fwrite(audiobuf,2,g_conf.rw_size,pipe);
		draw_volume_meter(audiobuf,g_conf.rw_size,g_conf.stereo);
		}
	close_soundcard();
}
	
	
/* OK.... this is the routine to launch the old l3enc encoder */
int exec_encoder_l3enc(void){
	char sr[32], br[32],ch[32];
	int enc;
	switch(enc=fork()){
	case 0:
	  /*isolate the IO so it doesn't clobber the level meter*/
	  if(g_conf.debug<10){
	    close(0);
	    close(1);
	    close(2);
	    open("/dev/null", O_RDONLY);
	    open("/dev/null", O_WRONLY);
	    open("/dev/null", O_WRONLY);
	  }
	  nice(-10);
	  sprintf(sr, "%d", g_conf.sample_rate);
	  sprintf(br, "%d", g_conf.bitrate);
	  if(g_conf.stereo)
	    sprintf(ch,"2");
	  else
	    sprintf(ch,"1");
	  execlp(g_conf.encoder_cmd, g_conf.encoder_cmd, g_conf.sound_pipe, g_conf.mpeg_pipe, "-br", br, "-sr", sr, "-tfc", ch, NULL);
	  fatal("failed to launch l3enc");
	  break;
	case -1:
	  fatal("fork() - with encoder");
	}
	return enc;
}


/* OK.... this is the routine to launch the new Fraunhoffer code */
int exec_encoder_mp3enc(void){
	char sr[32], br[32],ch[32];
	int enc;
	switch(enc=fork()){
	case 0:
	  /*isolate the IO so it doesn't clobber the level meter*/
	  if(g_conf.debug<10){
	    close(2);
	    open("/dev/null", O_WRONLY);
	  }
	  close(0);
	  close(1);
	  open(g_conf.sound_pipe,O_RDONLY);
	  open(g_conf.mpeg_pipe,O_WRONLY);
	  nice(-10);
	  sprintf(sr, "%d", g_conf.sample_rate);
	  sprintf(br, "%d", g_conf.bitrate);
	  if(g_conf.stereo)
	    sprintf(ch,"2");
	  else
	    sprintf(ch,"1");
	  execlp(g_conf.encoder_cmd, g_conf.encoder_cmd, "-br" , br , "-sr" , sr , "-nc" , ch , "-sti", "-sto", NULL);
	  fatal("failed to launch mp3enc");
	  break;
	case -1:
	  fatal("fork() - with encoder");
	}
	return enc;
}


 
/* this is the version of dist10 by Andreas Johansson */
/* wopr.campus.luth.se:/pub/mpeg_layer_3 */
int exec_encoder_AJ(void){
	char sr[32], br[32],ch[32];
	int enc;
	/*isolate the IO so it doesn't clobber the level meter*/
	switch(enc=fork()){
	case 0:
	  if(g_conf.debug<10){
	    close(1);
	    close(2);
	    open("/dev/null", O_WRONLY);
	    open("/dev/null", O_WRONLY);
	  }
	  close(0);
	  /* if you run as superuser then increase the priority */
	  nice(-10);
	  open(g_conf.sound_pipe,O_RDONLY);
	  sprintf(sr, "%f", g_conf.sample_rate/1000.0);
	  sprintf(br, "%d", g_conf.bitrate/1000);
	  if(g_conf.stereo)
	    sprintf(ch,"s");
	  else
	    sprintf(ch,"m");
	  if(g_conf.copyright)
		  execlp(g_conf.encoder_cmd, g_conf.encoder_cmd, "-m" , ch , "-s" , sr , "-b" , br , "-c", "-" , g_conf.mpeg_pipe,  NULL);
	  else 
		  execlp(g_conf.encoder_cmd, g_conf.encoder_cmd, "-m" , ch , "-s" , sr , "-b" , br , "-" , g_conf.mpeg_pipe,  NULL);
	  fatal("failed to launch encoder");
	  break;
	case -1:
	  fatal("fork() - with encoder");
	  break;
	}
	return enc;
}

/* the version of lamer which comes from Isaac Richard's Excellent Scream */
/* http://mizar.cwru.edu/screamer/                                        */
int exec_encoder_screamer(void){
	char sr[32], br[32],ch[32];
	int enc;
	switch(enc=fork()){
	case 0:
	  /*isolate the IO so it doesn't clobber the level meter*/
		/*if(g_conf.debug<10){
	    close(1);
	    close(2);
	    open("/dev/null", O_WRONLY);
	    open("/dev/null", O_WRONLY);	    
	    }*/
	  close(0);
	  open(g_conf.sound_pipe,O_RDONLY);
	  nice(-10);
	  sprintf(sr, "%f", g_conf.sample_rate/1000.0);
	  sprintf(br, "%f", g_conf.bitrate/1000.0);
	  if(g_conf.stereo)
	    sprintf(ch,"s");
	  else
	    sprintf(ch,"m");
	  if(g_conf.copyright)
		  execlp(g_conf.encoder_cmd, g_conf.encoder_cmd, "-b" , br , "-s" , sr ,  "-m" , ch , "-", g_conf.mpeg_pipe , NULL);
	  else 
		  execlp(g_conf.encoder_cmd, g_conf.encoder_cmd, "-c" , "-b" , br , "-s" , sr ,  "-m" , ch , "-", g_conf.mpeg_pipe , NULL);
	  fatal("failed to launch lamer");
	  break;
	case -1:
	  fatal("fork() - with encoder");
	}
	return enc;
}



int exec_encoder(void) {
	switch(g_conf.encoder){
	case L3ENC:
		return exec_encoder_l3enc();
		break;
	case MP3ENC:
		return exec_encoder_mp3enc();
		break;
	case AJ_ENCODER:
		return exec_encoder_AJ();
		break;
	case SCREAMER:
		return exec_encoder_screamer();
		break;
	default:
		fatal("Selected encoder Not Currently Supported - Sorry");
		break;
	}

}

void send_livestream(int sd)
{
	unsigned char buffer[MP_BUFF_SIZE];
	int len;
	FILE *in;
#ifndef HAVE_CURSES
	fprintf(stderr, "opening pipe!...\n");
	fflush(stderr);

        fprintf(stderr, "writing password\n");
	fflush(stderr);
#endif
        sprintf(buffer, "%s\n",g_conf.password);
        write(sd, buffer, strlen(buffer));
        sprintf(buffer, "icy-br:%d\n", g_conf.bitrate / 1000);
        write(sd, buffer, strlen(buffer));
        sprintf(buffer, "icy-name:%s\n",g_conf.icy_name);
        write(sd, buffer, strlen(buffer));
        sprintf(buffer, "icy-genre:%s\n",g_conf.icy_genre);
        write(sd, buffer, strlen(buffer));
        sprintf(buffer, "icy-url:%s\n",g_conf.icy_url);
        write(sd, buffer, strlen(buffer));
        sprintf(buffer, "icy-pub:%d\n",g_conf.icy_public);
        write(sd, buffer, strlen(buffer));
        sprintf(buffer, "\n");
        write(sd, buffer, strlen(buffer));

	if ((in = fopen(g_conf.mpeg_pipe, "r")) == NULL)
		fatal("opening mpeg pipe");

	fread(buffer, 1, MP_BUFF_SIZE, in);
	while(!g_conf.terminate_now) {
	        arm(30);  /* timeout */
		len = write(sd, buffer, MP_BUFF_SIZE);
		if (len == -1)
			fatal("sending data to remote server");
		fread(buffer, 1, MP_BUFF_SIZE, in);
	}
}

/* open socket and send it.... */
pid_t send_stream(void)
{
	sckt *sp;
	int sd;
	pid_t child;
	
	/* need to set a proper signal handler for cleaning up */
	signal(SIGPIPE,alarm_timeout);
	/* can't use write message because this is a sub process */
	fprintf(stderr, "Opening Remote Connection\n");

	fprintf(stderr, "Getting socket...\n");
	fflush(stderr);
	/*generate a socket*/
	if ((sp = sopen()) == 0)
		fatal("sopen() - get remnote stream");

	fprintf(stderr, "connecting socket...\n");
	fflush(stderr);

	/* Make contact with server */ 
	if ((sd = sclient(sp, g_conf.server, g_conf.port)) == -1)
		fatal("sclient() - get remote stream");

	fprintf(stderr, "sending live stream...\n");
	fflush(stderr);
	switch(child=fork()){
	case 0:
		send_livestream(sd);
		fprintf(stderr,"Closing connection\n");
		sclose(sp);
		exit(0);
		break;
	case -1:
		sclose(sp);
		fatal("fork() with TCP stream");
		break;
	}
	signal (SIGPIPE, SIG_DFL);
	return child;
}


void encoding(void)
{
	pid_t enc,tcp;
	write_message("hola, encoding...",1);
	/* setting the interface params */

	fflush(stderr);
	if(g_conf.soundcard)
		check_soundcard();

	enc=exec_encoder();
	tcp=send_stream();

	set_interface();
	
	if(g_conf.mixer){
	  mp3mixer();
	} else {
	  open_soundcard(O_RDWR);
	  read_soundcard();
	  close_soundcard();
	}
	kill(enc,15);
	kill(tcp,SIGALRM);
	fix_interface();
}
