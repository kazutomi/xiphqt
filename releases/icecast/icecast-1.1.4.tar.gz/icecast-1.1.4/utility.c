/* utility.c
 * - General Utility Functions *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "utility.h"

int password_match (char *crypted, char *uncrypted)
{
#ifndef USE_CRYPT
  if (strcmp (crypted, uncrypted) == 0)
    return 1;
  return 0;
#else
  char salt[3];
  char *test_crypted;
  extern char *crypt (const char *, const char *);
  if (strncmp (crypted, "$1$", 3))
    {
      salt[0] = crypted[0];
      salt[1] = crypted[1];
    }
  else
    {
      salt[0] = crypted[3];
      salt[1] = crypted[4];
    }
  salt[2] = '\0';
  test_crypted = crypt (uncrypted, salt);
  if (strcmp (test_crypted, crypted) == 0)
    return 1;
  return 0;
#endif
}

char *splitc(char *first, char *rest, const char divider)
{
	char *p;

	p = strchr(rest, divider);
	if (p == NULL) {
		if (rest != NULL && rest[0] != 0) {
			strcpy(first, rest);
			rest[0] = 0;
			return rest;
		} else {
			return NULL;
		}
	}

	*p = 0;
	if (first != NULL) strcpy(first, rest);
	if (first != rest) strcpy(rest, p + 1);

	return rest;
}

char * makeasciihost (char *in)
{
  char *buf = (char *) malloc (16);
  unsigned char *s = (unsigned char *)in;
  int a, b, c, d;
  a = (int)*s++;
  b = (int)*s++;
  c = (int)*s++;
  d = (int)*s;
  sprintf (buf, "%d.%d.%d.%d", a, b, c, d);
  return buf;
}

/* Returns:
   -2 on overflow
   -1 on socket error
   0 on "not done"
   1 on "Password correct"
   2 on "Password incorrect"
   This is used when admins and sources connect, to check that the
   given password is correct. It might be called lots of times during
   the same connection, due to the nonblocking nature.
   We keep on calling this until we've read a \n
*/

int check_pass (int sockfd, char *pass, int *counter, char *string)
{
  int srl;
  
  srl = sock_read_line (sockfd, string, counter);

  switch (srl)
    {
      case -2:
      case -1:
      case 0:
	return srl;
	break;
    }
  
  /* If we got here, then we're ready to go */
  
  if (password_match (pass, string))
    return 1;
  return 2;
}

char *
nice_time (int seconds)
{
  static char buf[500];
  int hours = seconds / 3600;
  int remains = seconds % 3600;
  sprintf (buf, "%3d h %2d m %2d s", hours, remains / 60, remains % 60);
  return buf;
}

char *
clean_string (char *string)
{
  register int i;
  for (i = 0; i < strlen (string); i++)
    {
      if (string[i] == '\n')
	string[i] = '\0';
    }
  return string;
}



