/* icetypes.h
 * - General Type Declarations
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifndef _ICECAST_TYPES_H
#define _ICECAST_TYPES_H

typedef struct client_St
{
  int accepted;  /* This can be PENDING or ICY_ACCEPTED */
  int counter;   /* Used at first to mark position in buf, 
		    later to mark error */
  char *buf;     /* Used at first to store the client's request */
  int sock;      /* Client socket */
  unsigned long int write_bytes; /* Number of bytes written to client */
  time_t connect_time; /* Time when the client connected */
  char *host; /* Client hostname */
} client_t;

typedef struct source_St
{
  int accepted;  /* PENDING, PASSWORD_ACCEPTED, ICY_ACCEPTED */
  int counter;   /* Position in buf, and errors later */
  char *buf;     /* Header */
  int sock;      /* Encoder socket */
  unsigned long int read_bytes; /* Bytes read */
  time_t connect_time; /* Time when encoder connected */
  char *host; /* Encoder hostname */
} source_t;

typedef struct dirSt
{
  int counter; /* Number of touches */
  int id;      /* our id on this server */
  char *host;  /* Hostname of the directory server */
} directory_server_t;
  
typedef struct admin_St
{
  int accepted; /* PENDING, PASSWORD_ACCEPTED, TAILING, OPER */
  int counter;  /* Position in buf */
  char *buf;    /* Used to store headers */
  int sock;     /* Admin socket */
  time_t connect_time; /* Time when admin connected */
  int commands; /* Number of issued commands */
  char *host; /* Admin hostname */
} admin_t;

typedef struct {
  
  /* Client stuff */
  client_t *clients;	/* Client array */
  int num_clients;	/* Clients connected */
  char *client_pass;    /* not used, password for clients */
  int max_clients;	/* Maximum support clients */
  int port;		/* Port for listening */
  int client_lsock;	/* Socket descriptor for listen port */

  /* Encoder stuff */
  source_t *sources;	/* Source array */
  int num_sources;      /* Encoders connected */
  int max_sources;      /* Maximal number of encoders */
  int actual_encoder;   /* The fd of the encoder actually streaming */
  int encoder_port;     /* Port for encoding */
  int encoder_lsock;	/* Socket descriptor for encoder listen port */
  char *encoder_pass;	/* Password to verify encoder */
  
  /* Admin stuff */
  char *oper_pass;      /* Operator password (this one can do it all) */
  admin_t *admins;      /* Admin array */
  int num_admins;       /* Number of connected admins */
  int max_admins;       /* Maximal number of admins */
  int remote_admin_port;    /* Port for remote administration */
  int remote_admin_lsock;   /* Socket descriptor for remote administration listen port */
  char *remote_admin_pass;  /* Password for remote administration */

  /* Redirection stuff */
  int redirection;         /* Are we redirecting? */
  char *redirection_host;  /* Hostname or ip of server */
  int redirection_port;    /* Port of server */
  int redirection_retries; /* Number of times to retry before failing (currently not used) */
  
  /* ICY stuff */
  char *name;		/* Name of Server */
  char *genre;		/* Genre of music */
  int bitrate;		/* Bitrate of server */
  char *url;		/* Url for server */
  int public;		/* List on the directory? */
  int ignore_source;    /* Ignore the directory server information given by the source */

  /* Directory server stuff */
  directory_server_t *d_server; /* Directory servers to rat on */
  int touch_freq;	        /* Frequency to update directory (same touch_freq for all directories) */
  int max_directories;          /* Maximal number of directory servers */
  long lasttime;                /* Time of last touch() */
  
  /* Misc stuff */
  char *configfile;     /* Name of configuration file */
  char *logfilename;	/* Name of log file */
  FILE *logfile;	/* File to log to */
  char *statsfilename;  /* Name of stats logfile */
  FILE *statsfile;      /* File to dump stats to */
  int statstime;    /* How long between dumps to the stats file */
  long statslasttime;   /* Time since last dump */
  long server_start_time; /* The time the server started */
  char *myhostname;     /* NULL unless we want to bind to specific ip */
  int console_mode;     /* CONSOLE_BACKGROUND, CONSOLE_LOG or CONSOLE_ADMIN */

  /* Max errors to accept from clients */
  int max_errors;

  /* How to deal with secondary sources? */
  int select_mode;

  /* How to deal with clients when no encoder is connected
     Negative value means keep them forever.
     0 means kick them out instantly
     Other values are keep them X seconds */
  int client_timeout; 

  int time_lost_encoder; /* when did we lose our encoder? */

  /* Statistics */
  unsigned long int total_read; /* Total number of bytes read from the encoders */
  unsigned long int total_written; /* Total number of bytes written to clients */
  unsigned long int client_connections; /* Total number of client connections */
  unsigned long int client_connect_time; /* Total connect time for all clients */
  unsigned long int source_connections; /* Total number of source connections */
  unsigned long int source_connect_time; /* Total connect time for all sources */

} server_info_t;

#endif
