/* mixer.h
 *
 * Copyright (c) 1999 Scott Manley, Barath Raghavan, Jack Moffitt, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License  
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */


/* data structures used by mixer.c  and others */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif


#include <stdio.h>          /* for FILE type */
#include <sys/types.h>      /* for pid_t type */
#include <unistd.h>


#ifdef HAVE_LIBCURSES
#define HAVE_CURSES
#endif


#ifdef HAVE_CURSES
#include <curses.h>
#endif

#define BUF_SIZE    2048
#define MAX_SAMPLE  32766

#define CLIP        30000
#define CLIP_A      ((MAX_SAMPLE-CLIP)*(MAX_SAMPLE-CLIP))
#define CLIP_B      (MAX_SAMPLE-2*CLIP)



#define MAX_CHANNELS 8

typedef struct format {
	int rate;
	int channels;
	float speed;
} Format;



typedef struct track_list *tptr;

/* new track list structure doesn't care about the sample rate any more */
typedef struct track_list {
	char *filename;     
	tptr next;
	tptr prev;
} track;



typedef struct channel_list *cptr;

typedef struct channel_list {
	short inbuf[BUF_SIZE];
	char name[64];
	tptr curnt;
	float volume;
	float speed;
	int rate;            
	int channels;         
	int on;
	int stayon;          /* controls play behaviour */
	int stream;
	FILE *fstr;           /* use std buffering to simplify things */
	pid_t pid;
#ifdef HAVE_CURSES
	WINDOW *c_display;
#endif
} channel;

typedef struct mix_dat {
	int t_number;
	int c_number;
	int rate;
	int channels;
	int soundcard;
	int out_mode;                /* controls what you hear */
	cptr c_list[MAX_CHANNELS]; 
	tptr t_list;
} m_dat;




