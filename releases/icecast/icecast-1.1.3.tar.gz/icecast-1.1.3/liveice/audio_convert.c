/* audio_convert.c
 *
 * Copyright (c) 1999 Scott Manley, Barath Raghavan, Jack Moffitt, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License  
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include "mixer.h"
/* all these routines convert input data into a different output format */


void make_mono(short *stereo,short *mono,int num){
unsigned int i;
 for(i=0;i<num;i++)
   mono[i]=(short)(((int)stereo[i*2]+(int)stereo[i*2+1])/2);

}

void make_stereo(short *mono,short *stereo,int num){
unsigned int i;
 for(i=0;i<num;i++)
   stereo[i*2]=stereo[i*2+1]=mono[i];

}

void sep_stereo(short *stereo,short *left,short *right,int num){
unsigned int i;
 for(i=0;i<num;i++){
   left[i]=stereo[i*2];
   right[i]=stereo[i*2+1];
 }  
}

void mix_stereo(short *left,short *right,short *stereo,int num){
unsigned int i;
 for(i=0;i<num;i++){
   stereo[i*2]=left[i];
   stereo[i*2+1]=right[i];
 }  
}

void int_compress_samples(short *in, short *out,int num,int grain){
unsigned int i,j;
int smpl;

 for(i=0;i<num;i++){
   smpl=in[i*grain];
   for(j=1;j<grain;j++)
     smpl+=in[i*grain+j];
   out[i]=(short)(smpl/grain);
 }

}

void int_stretch_samples(short *in,short *out,int num,int grain){
unsigned int i,j;
 for(i=0;i<num;i++)
   for(j=0;j<grain;j++)
     out[i*grain+j]=in[i];
 
}


/* this is a quick routine just to get proper spped control working - needs
   to be updated to use something whihc is less noisy */
void compress_samples(short *in, short *out,unsigned int num1,unsigned int num2){
float step=(float)(num1)/num2;
int i;
 for(i=0;i<num2;i++){
   out[i]=in[(int)(i*step)];
 }
}

void stretch_samples(short *in, short *out,unsigned int num1,unsigned int num2){
float step=(float)(num1)/num2;
int i;
 for(i=0;i<num2;i++){
   out[i]=in[(int)(i*step)];
 }
}


/* changes the length of a buffer of samples uses fast shortcuts where possible */
void change_time(short *in,short *out,unsigned int num_in,unsigned int num_out){
int i;

 if(num_in>num_out){
   /* compress samples */
   if(num_in==(num_out<<1)){
     int_compress_samples(in,out,num_out,2);
   } else if ( num_in==(num_out<<2)) {
     int_compress_samples(in,out,num_out,4);
   } else {
     compress_samples(in,out,num_in,num_out);
   }
 } else if(num_in<num_out) {
   /* stretch samples */
   if((num_in<<1)==num_out){
     int_stretch_samples(in,out,num_in,2);
   } else if ((num_in<<2)==num_out) {
     int_stretch_samples(in,out,num_in,4);
   } else {
     stretch_samples(in,out,num_in,num_out);
   }
 } else {
   for(i=0;i<num_out;i++)
     out[i]=in[i];
   }
}

/* convert audio.... takes num samples in input format and converts them to */
/* the correct output format                                                */
/* this assumes you're only wirking with small audio fragments.....         */
int convert_audio(format *in,format *out,short *dat,int num){
static short work1[BUF_SIZE*40],work2[BUF_SIZE*40],work3[BUF_SIZE*40];
int i,j;
int grain;
unsigned int in_samples,out_samples;

in_samples=num/in->channels;
out_samples=in_samples*((out->rate*out->speed)/(in->rate*in->speed));


 if(out->channels==1){
   if(in->channels==2){
     make_mono(dat,work1,in_samples);       
     change_time(work1,dat,in_samples,out_samples);
   } else {
     change_time(dat,work1,in_samples,out_samples);
     change_time(work1,dat,out_samples,out_samples);
   }
 } else {
   if(in->channels==2){
     sep_stereo(dat,work1,work2,in_samples);
     change_time(work1,work3,num_samples,out_samples);
     change_time(work2,work1,num_samples,out_samples);
     mix_stereo(work3,work1,dat,out_samples);
   } else {
     change_time(dat,work1,num_samples,out_samples);
     make_stereo(work1,dat,out_samples);
   }
 }
return (out_samples*out->channels);
}

