/* main.c
 * - Main Program *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
# ifndef __USE_BSD
#  define __USE_BSD
# endif
#include <string.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#if HAVE_SYS_SELECT_H
#include <sys/select.h>
#endif

#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <ctype.h>
#include <sys/wait.h>
#include <errno.h>
#include "sock.h"
#include "icecast.h"
#include "icetypes.h"
#include "globals.h"
#include "directory.h"
#include "log.h"
#include "commands.h"
#include "logtime.h"
#include "main.h"
#include "utility.h"
#include "commandline.h"

#if !HAVE_GETDTABLESIZE
# ifdef HD_SETSIZE
#  define getdtablesize() FD_SETSIZE
# else
#  define getdtablesize() 200
# endif
#endif

/* We need this for perror and for various sanity checks */
extern int errno;
/* This is global, doh! */
server_info_t info;

int
main (int argc, char *argv[])
{
  int i;

  /* Statistics */
  info.total_read = info.total_written = info.client_connections 
    = info.client_connect_time = info.source_connections 
    = info.source_connect_time = 0;

  info.time_lost_encoder = 0;
  info.num_clients = 0;
  info.max_clients = DEFAULT_MAX_CLIENTS;
  info.port = DEFAULT_PORT;
  info.client_lsock = -1;
  
  info.client_timeout = DEFAULT_CLIENT_TIMEOUT;
  info.console_mode = CONSOLE_BACKGROUND;
  info.num_sources = 0;
  info.max_sources = DEFAULT_MAX_SOURCES;
  info.encoder_port = DEFAULT_ENCODER_PORT;
  info.encoder_lsock = -1;
  info.encoder_pass = strdup (DEFAULT_ENCODER_PASSWORD);
  info.actual_encoder = -1;
  
  info.num_admins = 0;
  info.max_admins = DEFAULT_MAX_ADMINS;
  info.remote_admin_pass = strdup (DEFAULT_REMOTE_ADMIN_PASSWORD);
  info.remote_admin_port = DEFAULT_REMOTE_ADMIN_PORT;
  info.remote_admin_lsock = -1;

  info.myhostname = NULL;
  info.select_mode = SELECT_READ;
  info.max_errors = MAX_ERRORS;
  info.client_pass = strdup (DEFAULT_CLIENT_PASSWORD);
  info.oper_pass = strdup (DEFAULT_OPER_PASSWORD);
  info.name = strdup (DEFAULT_SERVER_NAME);
  info.genre = strdup (DEFAULT_GENRE);
  info.bitrate = DEFAULT_BITRATE;
  info.public = DEFAULT_PUBLIC;
  info.url = strdup (DEFAULT_URL);
  info.touch_freq = DEFAULT_TOUCH_FREQ;
  info.configfile = DEFAULT_CONFIG_FILE;
  info.logfilename = strdup(DEFAULT_LOGFILE);
  info.logfile = NULL;
  info.statsfilename = strdup(DEFAULT_STATSFILE);
  info.statsfile = NULL;
  info.statstime = DEFAULT_STATSTIME;
  info.max_directories = DEFAULT_MAX_DIRECTORIES;
  info.server_start_time = get_time();
  info.redirection = DEFAULT_REDIRECTION;
  info.redirection_host = strdup (DEFAULT_REDIRECTION_HOST);
  info.redirection_port = DEFAULT_REDIRECTION_PORT;
  info.redirection_retries = DEFAULT_REDIRECTION_RETRIES;
  
  /* Time for some signal handling */
  /* ignore all broken pipe signals */
  signal(SIGPIPE, SIG_IGN);

  /* process the dying children */
#if (defined(SYSV) && !defined(hpux)) || defined(SVR4)
	sigset(SIGCHLD, sig_child);
#else
	signal(SIGCHLD, sig_child);
#endif

  /* ignore the hangup signal */
  signal(SIGHUP, SIG_IGN);

  /* process a term, kill, segmentation fault, interrupt , or bus signal */
  signal(SIGTERM, sig_die);
  signal(SIGSEGV, sig_die_hard);
  signal(SIGBUS, sig_die_hard);
  signal(SIGINT, sig_die);
  
  /* Allocate all the directory server entries */
  info.d_server = (directory_server_t *) malloc (sizeof (directory_server_t) 
						 * info.max_directories);
  for (i = 0; i < info.max_directories; i++)
    info.d_server[i].host = NULL;

  if (info.max_directories > 0)
    info.d_server[i].host = DEFAULT_DIRECTORY_SERVER;

  parse_config_file (info.configfile);

  /* Parse arguments */
  parse_args (&info, argc, argv);
  
  /* Allocate all the client structures */
  info.clients = (client_t *) malloc (sizeof (client_t) * info.max_clients);

  /* Make sure they are unused */
  for (i = 0; i < info.max_clients; i++)
    info.clients[i].sock = -1; 
  
  /* Allocate all the sources.
     If we're using redirection, then only the first socket will be used.
     Nevermind that */
  info.sources = (source_t *) malloc (sizeof (source_t) * info.max_sources);

  /* Make sure they're marked as unused */
  for (i = 0; i < info.max_sources; i++)
    info.sources[i].sock = -1;
  
  /* Allocate all the admin slots */
  info.admins = (admin_t *) malloc (sizeof (admin_t) * info.max_admins);
  
  /* Make sure they're marked as unused */
  for (i = 0; i < info.max_admins; i++)
    info.admins[i].sock = -1;

  if ((info.logfile = fopen(info.logfilename, "a")) == NULL)
    write_log (&info, "Could not open logfile %s for writing, damn!", info.logfilename);

  write_log(&info, "Icecast Version %s Starting...", VERSION);
  printf("Icecast Version %s Starting...\n", VERSION);
  printf("\nIcecast comes with NO WARRANTY, to the extent permitted by law.\nYou may redistribute copies of Icecast under the terms of the\nGNU General Public License.\nFor more information about these matters, see the file named COPYING.\n\n");
  
  /* Set the running flag */
  running = 1;
  info.lasttime = 0;
  info.statslasttime = 0;
  setup_admin_settings ();

  /* Perhaps drop into the background */
  if (info.console_mode == CONSOLE_BACKGROUND)
    {
      int icepid = fork ();
      if (icepid == -1)
	{
	  write_log (&info, "Can't fork, damn!\n");
	  clean_shutdown (&info);
	}
      if (icepid != 0)
	{
	  printf ("Light's out, going into the background, (pid: %d)\n\n",
		  icepid);
#if HAVE_SETPGID
	  setpgid (icepid, icepid);
#endif
	  exit (0);
	}
      else
	{
#if HAVE_SETPGID
	  setpgid (0, 0);
#endif
	  freopen ("/dev/null", "r", stdin);
	  freopen ("/dev/null", "w", stdout);
	  freopen ("/dev/null", "w", stderr);
	  close (0);
	  close (1);
	  close (2);
	}
    }
  else if ((info.console_mode == CONSOLE_ADMIN) || (info.console_mode ==CONSOLE_ADMIN_TAIL))
    {
      admin_t *adm = get_next_admin (&info);
      write_log (&info, "Using stdin as icecast operator console");
      adm->sock = 0; /* STDIN/STDOUT, we still need special cases */
      adm->host = "icecast console";
      adm->commands = 0;
      adm->accepted = PASSWORD_ACCEPTED + REMOTE_OPER;
      if (info.console_mode == CONSOLE_ADMIN_TAIL)
	{
	  write_log(&info, "Tailing file to icecast operator console");
	  adm->accepted += TAILING;
	}
      adm->counter = 0;
      adm->buf = (char *) malloc (1024);
      adm->connect_time = get_time ();
      fcntl (adm->sock, F_SETFL, O_NONBLOCK);
      info.num_admins++;
      sock_write (1, "-> ");
    }
  else
    write_log (&info, "Using stdout as icecast logging window");
  
  new_server_proc (&info);
  
  return 0;
}

/* Shutdown the server, make sure all sockets are closed, and
   free up the memory, now there's a good boy */
void 
clean_shutdown(server_info_t *info)
{
	int i;

	write_log(info, "cleanly shutting down...");

        /* Say bye-bye to the Directory Server */
	if (info->public)
	  {
	    for (i = 0; i < info->max_directories; i++)
		{
	      	  if (info->d_server[i].host == NULL)
		    continue;
	          directory_remove(&info->d_server[i]);
		}
	  }

	/* Next we dump all the clients */
	info->num_clients = 0;
	for (i = 0; i < info->max_clients; i++) 
	  {
	    if (info->clients[i].sock == -1)
	      continue;
	    shutdown (info->clients[i].sock, 2);
	    close (info->clients[i].sock);
	    info->clients[i].sock = -1;
	  }

	/* And the sources */
	for (i = 0; i < info->max_sources; i++)
	  {
	    if (info->sources[i].sock == -1)
	      continue;
	    shutdown (info->sources[i].sock, 2);
	    close (info->sources[i].sock);
	    info->sources[i].sock = -1;
	  }

	/* And the admins */
	for (i = 0; i < info->max_admins; i++)
	  {
	    if (info->admins[i].sock == -1)
	      continue;
	    shutdown (info->admins[i].sock, 2);
	    close (info->admins[i].sock);
	    info->admins[i].sock = -1;
	  }

	/* And the listen sockets */
	shutdown (info->client_lsock, 2);
	close (info->client_lsock);
	if (!info->redirection) {
	  shutdown (info->encoder_lsock, 2);
	  close (info->encoder_lsock);
	}
	shutdown (info->remote_admin_lsock, 2);
	close (info->remote_admin_lsock);

	/* Free client array */
        free (info->clients);
	free (info->admins);
	free (info->sources);

	exit(0);
}

int 
source_login (int sockfd, char *pass, int *counter, char *string)
{
	char buf[1024];
	char *ptr;
	int srl;
	srl = sock_read_lines(sockfd, string, counter);
	switch (srl) {
	case 0:
	case -1:
	case -2:
		return srl;
		break;
	}

	while (splitc(buf, string, '\n') != NULL) {
		ptr = strstr(buf, "icy-name:");
		if (ptr != NULL) {
			if (ptr[0] == ' ')
				info.name = strdup(ptr + 10);
			else
				info.name = strdup(ptr + 9);
			continue;
		}
		ptr = strstr(buf, "icy-genre:");
		if (ptr != NULL) {
			if (ptr[0] == ' ')
				info.genre = strdup(ptr + 11);
			else
				info.genre = strdup(ptr + 10);
			continue;
		}
		ptr = strstr(buf, "icy-url:");
		if (ptr != NULL) {
			if (ptr[0] == ' ')
				info.url = strdup(ptr + 9);
			else
				info.url = strdup(ptr + 8);
			continue;
		}
		ptr = strstr(buf, "icy-pub:");
		if (ptr != NULL) {
			if (ptr[0] == ' ')
				info.public = atoi(ptr + 9);
			else
				info.public = atoi(ptr + 8);
			continue;
		}
		ptr = strstr(buf, "icy-br:");
		if (ptr != NULL) {
			if (ptr[0] == ' ')
				info.bitrate = atoi(ptr + 8);
			else
				info.bitrate = atoi(ptr + 7);
			continue;
		}
	} 
	return 1;
}

/* This is the main engine */
void 
new_server_proc (server_info_t *info)
{
  int select_val, fds;
  register int i;
  fd_set readfds;
  struct timeval tv;

  client_t *client;
  source_t *source;
  admin_t *admin;

  write_log (info, "server started...");
  
  /* Setup listeners (listen for clients, admins and sources) */
  setup_listeners ();

  /* Main loop */
  for (;;)
    {
      if (!running)
	clean_shutdown (info);

      /* This value tells select() the highest ordered fd */
      fds = 0;

      /* Timeout value for the select()
	 This is so that we don't get stuck too long, user might press
	 ^C and we should probably talk to the directory server now
	 and then */
      tv.tv_sec = 1; /* one second */
      tv.tv_usec = 0;

      /* This is important, clear the fd_set */
      FD_ZERO (&readfds);

      /* Add client slots in use to the fd_set (they send a header) */
      for (i = 0; i < info->max_clients; i++)
	{
	  if (info->clients[i].sock != -1)
	    {
	      FD_SET (info->clients[i].sock, &readfds);

	      /* This looks out for the highest numbered fd */
	      if (info->clients[i].sock > fds)
		fds = info->clients[i].sock;
	    }
	}

      /* Add source slots in use to the fd_set
	 If we're using select_stop, don't accept anything but the actual
	 encoder. select_quiet, and select_reads go through */
      for (i = 0; i < info->max_sources; i++)
	if (info->sources[i].sock != -1)
	  {
	    if ((info->actual_encoder == -1)
		|| ((info->select_mode == SELECT_READ) || ((info->select_mode == SELECT_QUIET)
							   && info->sources[i].accepted != ICY_ACCEPTED))
		|| (info->sources[i].sock == info->actual_encoder))
	      {
		FD_SET (info->sources[i].sock, &readfds);
		if (info->sources[i].sock > fds)
		  fds = info->sources[i].sock;
	      }
	  }
      
      /* And admins slots in use to the fd_set */
      for (i = 0; i < info->max_admins; i++)
	if (info->admins[i].sock != -1)
	  {
	    FD_SET (info->admins[i].sock, &readfds);
	    if (info->admins[i].sock > fds)
	      fds = info->admins[i].sock;
	  }
      
      /* Now, sleep in the select() until one or more fd:s in the
	 set has spoken, or until one second has passed. */
      errno = 0;

      /* K, this is the shittiest part of this entire distribution.
	 Different systems have different ideas about what the first
	 argument to select actually does. So not to confuse any of 
	 the systems, we just take the maximum number of files a 
	 process can have open.
	 Because I use linux, I've verified that the fds semantics 
	 work, so using the highest numbered fd really does work, and
	 you can do the same if your system does the same. Please
	 let me know if this is so, and that way we can make it the
	 default for your system.
      */

#ifndef __linux__
      fds = getdtablesize();
# ifdef FD_SETSIZE
      if (fds > FD_SETSIZE)
	fds = FD_SETSIZE;
# endif
#else
      fds++;
#endif

#ifdef HPUX
      select_val = select (fds, (int *) &fd, (int *) NULL, (int *) NULL, &tv);
#else
      select_val = select (fds, &readfds, NULL, NULL, &tv);
#endif
      
      switch (select_val)
	{
	  case -1:
	    if (errno != EINTR)
	      {
		write_log (info, 
			   "Select() returned nonzero status, something is wicked!");
		my_perror ("select");
		write_log (info, "What I ran was select(%d...)", fds);
		clean_shutdown (info);
	      }
	    break;
	  
	  /* Timeout expired */
	  case 0:
	    break;

	  /* Handle the action */
	  default:
	    handle_action (info, &readfds);
	    break;
	}

      /* Check for new clients */
      if ((client = put_client (info->client_lsock)))
	{
#ifdef HAVE_LIBWRAP
	  if (check_libwrap (client->sock))
	    greet_client (client);
	  else
	    kick_client (client, "Denied tcp access");
#else
	  greet_client (client);
#endif
	}
      
      /* Skip the accept() if, and only if the select_mode is SELECT_STOP, and
	 we have an encoder */
      if ((info->select_mode != SELECT_STOP) || (info->actual_encoder == -1))
	{
	  /* Check for new sources */
	  if (!info->redirection && (source = put_source (info->encoder_lsock)))
	    {
#ifdef HAVE_LIBWRAP
	      if (check_libwrap (source->sock))
		greet_source (source);
	      else
		kick_source (source, "Denied tcp access");
#else
	      greet_source (source);
#endif
	    }
	}

      /* Check for new admins */
      if ((admin = put_admin (info->remote_admin_lsock)))
	{
#ifdef HAVE_LIBWRAP
	  if (check_libwrap (admin->sock))
	    greet_admin (admin);
	  else
	    kick_admin (admin, "Denied tcp access");
#else
	  greet_admin (admin);
#endif
	}
      
      /* Touch the directory server */
      if ((info->actual_encoder != -1) && (info->public))
	{
	  time_t time = get_time ();
	  if ((time - info->lasttime) >= info->touch_freq * 60)
	    {
	      info->lasttime = time;
	      if (fork () == 0)
		{
		  for (i = 0; i < info->max_directories; i++)
		    {
		      if (info->d_server[i].host == NULL)
			continue;
		      directory_touch (&info->d_server[i]);
		    }
		  exit (0);
		}
	    }
	}
      
      /* Dump stats file every once in a while */
      if ((info->statstime) > 0)
	{
	  time_t time = get_time();
	  if ((time - info->statslasttime) >= info->statstime)
	    {
	      info->statslasttime = time;
	      if (fork() == 0)
		{
		  stats_write(info);
		  exit(0);
		}
	    }
	}

      /* Perhaps it's time to kick clients */
      if ((info->actual_encoder == -1) && (info->client_timeout > 0) 
	  && (info->time_lost_encoder != 0))
	{
	  if (get_time () > (info->time_lost_encoder + info->client_timeout))
	    {
	      write_log (info, "Client timeout exceeded, kicking clients");
	      kick_clients ();
	      info->time_lost_encoder = 0;
	    }
	}
    }
}

/* This is called whenever there is action on a socket.
   At this point, we don't know which */
void
handle_action (server_info_t *info, fd_set *readfds)
{
  int write_bytes, read_source_bytes;
  register int i;
  char buffer[CLIENT_BUFFSIZE];
  char trash[CLIENT_BUFFSIZE];

  /* We check this later to see if we've got any new data for the 
     clients */
  read_source_bytes = 0;
  
  /* Check all sources */
  for (i = 0; i < info->max_sources; i++)
    {
      if (info->sources[i].sock < 0) /* Not in use */
	continue;
      if (FD_ISSET (info->sources[i].sock, readfds))
	{
	  if ((info->sources[i].sock != info->actual_encoder) 
	      && (info->actual_encoder != -1))
	    {
	      if (info->sources[i].accepted != ICY_ACCEPTED) /* Secondary source not fully accepted */
		{
		  greet_source (&info->sources[i]);
		  continue;
		}

	      /* Only select_read mode actually reads the data */
	      if (info->select_mode == SELECT_READ)
		{
		  /* Just pour it into the void */
		  errno = 0;
		  if ((recv (info->sources[i].sock, trash, CLIENT_BUFFSIZE, 0) <= 0) &&
		      (errno != EAGAIN))
		    {
		      kick_source (&info->sources[i], "Secondary source signed off");
		    }
		}
	    }
	  else
	    {
	      if (info->sources[i].accepted != ICY_ACCEPTED) /* Logged in? */
		{
		  greet_source (&info->sources[i]);
		  continue;
		}
	      /*	      memset (buffer, 0, CLIENT_BUFFSIZE); */
	      errno = 0;
	      read_source_bytes = recv (info->sources[i].sock, buffer, 
				 CLIENT_BUFFSIZE, 0);
	      
	      /* if EOF (0), or error other than EAGAIN, kill him off */
	      if ((read_source_bytes == 0) 
		  || ((read_source_bytes == -1) && errno != EAGAIN))
		{
		  kick_source (&info->sources[i], "Primary source signed off");
		  switch_encoder (info);

		  if (info->actual_encoder == -1)
		    {
		      /* No encoder, check info.client_timeout */
		      if (info->client_timeout == 0)
			kick_clients ();
		      info->time_lost_encoder = get_time ();
		    }
		}
	      else
		{
		  info->total_read += read_source_bytes;
		  info->sources[i].read_bytes += read_source_bytes;
#ifdef DEBUG_BYTES
		  write_log (info, "Read %d bytes from encoder", 
			     read_source_bytes);
#endif
		}
	    /* Now, if we read data from the encoder, send it to the clients */
	      if (read_source_bytes > 0)
		{
		  for (i = 0; i < info->max_clients; i++)
		    {
		      if ((info->clients[i].sock < 0) 
			  || (info->clients[i].accepted == PENDING))
			continue;
		      errno = 0;
		      write_bytes = send (info->clients[i].sock, buffer, 
					  read_source_bytes, 0);
		      if ((write_bytes <= 0) && (errno != EAGAIN)) 
			{
			  kick_client (&info->clients[i], "Client signed off");
			}
		      else
			{
			  info->clients[i].write_bytes += write_bytes;
			  info->total_written += write_bytes;
			}
		      if ((write_bytes > 0) 
			  && (read_source_bytes != write_bytes))
			{
			  info->clients[i].counter++;
			  if (info->clients[i].counter > MAX_ERRORS)
			    {
			      kick_client (&info->clients[i], 
					   "Too many write errors");
			    }
#ifdef DEBUG_BYTES
			  else 
			    write_log (info, "Incomplete write() to client %s",
				       info->clients[i].host ? 
				       info->clients[i].host : "(nuked)");
#endif
			}
#ifdef DEBUG_BYTES
		      write_log (info, "Wrote %lu bytes to client", 
				 write_bytes);
#endif
		    }
		}
	      
	    }
	  return; /* Speedup? */
	}
    }
  
  /* Check all clients */
  for (i = 0; i < info->max_clients; i++)
    {
      if (info->clients[i].sock < 0) /* Not in use */
	continue;
      if (FD_ISSET (info->clients[i].sock, readfds))
	{
	  if (info->clients[i].accepted == PENDING) /* Logged in? */
	    {
	      greet_client (&info->clients[i]);
	      continue;
	    }
	  else
	    kick_client (&info->clients[i], "Client signed off"); /* Client should be quiet! */
	}
    }
	  
  /* Check all admins */
  for (i = 0; i < info->max_admins; i++)
    {
      if (info->admins[i].sock < 0)
	continue;
      if (FD_ISSET (info->admins[i].sock, readfds))
	{
	  if (info->admins[i].accepted == PENDING) /* Logged in? */
	    {
	      greet_admin (&info->admins[i]);
	      continue;
	    }
	  switch (sock_read_line (info->admins[i].sock, 
				   info->admins[i].buf,
				   &info->admins[i].counter))
	    {
	      case -2:
		kick_admin (&info->admins[i], "Noisy admin");
		break;
	      case -1:
		kick_admin (&info->admins[i], "Socket error");
		break;
	      case 0:
		continue; /* EAGAIN */
		break;
	      case 1:
		/* Handle the command */
		handle_admin_command (&info->admins[i], 
				      info->admins[i].buf,
				      info->admins[i].counter);
		/* This is just for statistics */
		info->admins[i].commands++;
		
		/* Reset the buf pointer */
		info->admins[i].counter = 0;
		break;
	    }
	}
    }
  
}

/* Another nonblocking function that might be called a number of times
   before it's actuall done. Checks the admins password and makes him
   feel welcome */
void
greet_admin (admin_t *adm)
{
  if (info.num_admins >= info.max_admins)
    {
      kick_admin (adm, "Server is full");
      return;
    }

  switch (check_pass (adm->sock, info.remote_admin_pass, &adm->counter, adm->buf))
    {
      /* Overflow */
      case -2:
	kick_admin (adm, "Noisy admin");
	break;
      /* Net error */
      case -1:
	kick_admin (adm, "Socket error");
	break;
      /* EAGAIN */
      case 0:
	return;
      case 1:
	adm->accepted = PASSWORD_ACCEPTED; /* We're done here */
	adm->counter = 0;
	sock_write (adm->sock, 
		    "Welcome to icecast remote admin socket\nType help for a listing of commands\n-> ");
	info.num_admins++;
	write_log (&info, 
		   "Accepted admin client from %s, %d admins connected",
		   adm->host, info.num_admins);
	break;
      case 2:
	kick_admin (adm, "Invalid password");
	break;
    }
  return;
}

/* This does the same, but with clients.
   Doesn't really matter what the client says, he get's the stream
   anyway */
void
greet_client (client_t *cli)
{
  int pend_val;

  if (info.num_clients >= info.max_clients)
    {
      kick_client (cli, "Server full");
    }

  if (cli->accepted == PENDING)
    {
      /* sock_read_lines reads everything until it encounters \n\n */
      pend_val = sock_read_lines (cli->sock, cli->buf, &cli->counter);

      switch (pend_val)
	{
	  /* Overflow */
	  case -2:
	    kick_client (cli, "Noisy client");
	    break;
	  /* Net error */
	  case -1:
	    kick_client (cli, "Socket error");
	    break;
	  /* EAGAIN */
	  case 0:
	    return;
	  case 1:
	    if (cli->accepted == PENDING)
	      cli->accepted = ICY_ACCEPTED;
	    /* Free up the used memory, (we only use it for the header) */
	    if (cli->buf != NULL)
	      {
		free (cli->buf);
		cli->buf = NULL;
	      }
	    cli->counter = 0;

	    info.num_clients++;
	    info.client_connections++;

	    if (info.actual_encoder == -1 && (info.client_timeout >= 0))
	      {
		kick_client (cli, "No encoder");
		return;
	      }

	    write_log (&info,"Accepted client from %s, %d clients connected",
		       cli->host, info.num_clients);
	    sock_write (cli->sock, "HTTP/1.0 200 OK\nServer: icecast/%s\nContent-type: audio/mpeg\n", VERSION);
	    sock_write (cli->sock, "icy-name: %s\nicy-genre: %s\nicy-url: %s\nicy-br: %i\nicy-pub: %i\n\n", 
			info.name, info.genre, info.url, info.bitrate, info.public);
	    break;
	}
    }
}

/* Do the same with the source.
   This header has a number of lines, the first one being
   the password. So the accepted flag has two values, either
   PASSWORD_ACCEPTED, or ICY_ACCEPTED.
   When a source is ICY_ACCEPTED, we're done here */
void
greet_source (source_t *ser)
{
  register int i;
  int pend_val = 0;

  if (info.num_sources >= info.max_sources)
    {
      kick_source (ser, "Server is full");
      return;
    }

  if (ser->accepted == PENDING)
    pend_val = check_pass (ser->sock, info.encoder_pass, &ser->counter,
			   ser->buf);
  else if (ser->accepted == PASSWORD_ACCEPTED && info.num_sources < 1)
    pend_val = source_login (ser->sock, info.encoder_pass, &ser->counter,
			     ser->buf);
  else if (ser->accepted == PASSWORD_ACCEPTED && info.num_sources >= 1)
    pend_val = 1;
  else
    {
      write_log (&info, "greet_source called with accepted encoder, damn!");
      return;
    }
  
  switch (pend_val)
    {
      /* Overflow */
      case -2:
	kick_source (ser, "Noisy encoder");
	break;
	/* Net error */
      case -1:
	kick_source (ser, "Socket error");
	break;
	/* EAGAIN */
      case 0:
	return;
      case 1:
	if (ser->accepted == PENDING)
	  ser->accepted = PASSWORD_ACCEPTED;
	else
	  ser->accepted = ICY_ACCEPTED;
	if (ser->accepted == PASSWORD_ACCEPTED)
	  {
	    sock_write (ser->sock, "OK\n");
	    write_log (&info, 
	    "Correct password received from encoder at %s, checking headers",
		       ser->host);
	    ser->counter = 0;
	  }
	else
	  {
	    info.num_sources++;
	    info.source_connections++;
	    write_log (&info, 
		       "Accepted encoder from %s, %d sources connected",
		       ser->host, info.num_sources);
	    if (info.actual_encoder != -1)
	      return;
	    info.actual_encoder = ser->sock;
	    if (info.public) 
	      {
		/* Since we need the server id, in the real instance of this
		   process, we can't fork directory_add().
		   Seems like a likely reason to go nonblocking here too, but not now */
		for (i = 0; i < info.max_directories; i++)
		  {
		    if (info.d_server[i].host == NULL)
		      continue;
		    directory_add (&info.d_server[i]);
		  }
		if (fork() == 0)
		  {
		    for (i = 0; i < info.max_directories; i++)
		      {
			if (info.d_server[i].host == NULL)
			  continue;
			directory_touch (&info.d_server[i]);
		      }
		    exit (0);
		  }
		info.lasttime = get_time ();
	      }
	  }
	break;
      case 2:
	sock_write (ser->sock, "Invalid password, kicking you out!\n");
	kick_source (ser, "Invalid password");
	break;
    }
}

void
kick_client (client_t *cli, char *why)
{
  if (cli->sock == -1)
    return;
  write_log (&info, 
	     "Kicking client %s, connected for %s, %lu bytes transfered, reason: %s",
	     cli->host, nice_time (time (NULL) - cli->connect_time), cli->write_bytes, why);
  shutdown (cli->sock, 2);
  close(cli->sock);
  cli->sock = -1;
  if (cli->accepted == ICY_ACCEPTED)
    info.num_clients--;
  info.client_connect_time += (time (NULL) - cli->connect_time);
  if (cli->host != NULL)
    {
      free (cli->host);
      cli->host = NULL;
    }
  if (cli->buf != NULL)
    {
      free (cli->buf);
      cli->buf = NULL;
    }
}

void
kick_source (source_t *sor, char *why)
{
  if (sor->sock == -1)
    return;
  write_log (&info, 
	     "Kicking source %s, connected for %s, %lu bytes transfered, reason: %s",
	     sor->host, nice_time (time (NULL) - sor->connect_time), sor->read_bytes, why);
  shutdown (sor->sock, 2);
  close(sor->sock);
  sor->sock = -1;
  if (sor->accepted == ICY_ACCEPTED)
    info.num_sources--;
  info.source_connect_time += (time (NULL) - sor->connect_time);
  if (sor->host != NULL)
    {
      free (sor->host);
      sor->host = NULL;
    }
  if (sor->buf != NULL)
    {
      free (sor->buf);
      sor->buf = NULL;
    }
}

void
kick_admin (admin_t *adm, char *why)
{
  if (adm->sock == -1)
    return;
  if ((strcmp("icecast console", adm->host)) == 0) {
	  write_log (&info, "Attempted kick of console admin - not allowed");
	  return;
  }
  shutdown (adm->sock, 2);
  close(adm->sock);
  write_log (&info, 
	     "Kicking admin %s, connected for %s, %d commands executed, reason: %s",
	     adm->host, nice_time (time (NULL) - adm->connect_time), adm->commands, why);
  adm->sock = -1;
  if (adm->host != NULL)
    {
      free (adm->host);
      adm->host = NULL;
    }
  if (adm->buf != NULL)
    {
      free (adm->buf);
      adm->buf = NULL;
    }
  if (adm->accepted > PENDING)
    info.num_admins--;
}

client_t *
get_next_client (server_info_t *info)
{
  int i;
  for (i = 0; i < info->max_clients; i++)
    if (info->clients[i].sock == -1)
      return &info->clients[i];
  return NULL;
}

source_t *
get_next_source (server_info_t *info)
{
  int i;
  for (i = 0; i < info->max_sources; i++)
    if (info->sources[i].sock == -1)
      return &info->sources[i];
  return NULL;
}

admin_t *
get_next_admin (server_info_t *info)
{
  int i;
  for (i = 0; i < info->max_admins; i++)
    if (info->admins[i].sock == -1)
      return &info->admins[i];
  return NULL;
}

RETSIGTYPE
sig_child (int signo)
{
	pid_t pid;
	int stat;

	pid = wait(&stat);
#ifdef __linux__
	signal(SIGCHLD, sig_child);
#endif
	return;
}

RETSIGTYPE
sig_die (int signo)
{
  write_log (&info, "Caught signal %d, perhaps someone is at the door?", signo);
  running = 0;
}

RETSIGTYPE
sig_die_hard (int signo)
{
  printf ("Caught signal %d, shutting down!\n", signo);
  exit (1);
}

void
setup_listeners ()
{
  /* Listen for sources if not using redirection */
  if (info.redirection != 1)
    {
      info.encoder_lsock = get_server_socket (info.encoder_port);
      fcntl (info.encoder_lsock, F_SETFL, O_NONBLOCK);
      if (listen (info.encoder_lsock, LISTEN_QUEUE) < 0)
	{
	  write_log (&info, "Could not listen for encoder on port %d",
		     info.encoder_port);
	  my_perror ("listen");
	  clean_shutdown (&info);
	}
      write_log (&info, "Listening for encoders (%d) on port %i...",
		 info.max_sources, info.encoder_port);
    }
  
  /* Listen for clients */
  info.client_lsock = get_server_socket (info.port);
  fcntl (info.client_lsock, F_SETFL, O_NONBLOCK);
  if (listen (info.client_lsock, LISTEN_QUEUE) < 0)
    {
      write_log (&info, "Could not listen for clients on port %d",
		 info.port);
      clean_shutdown (&info);
    }

  write_log (&info, "Listening for clients (%d) on port %i...", 
	     info.max_clients, info.port);

  info.remote_admin_lsock = get_server_socket (info.remote_admin_port);
  fcntl (info.remote_admin_lsock, F_SETFL, O_NONBLOCK);
  if (listen (info.remote_admin_lsock, LISTEN_QUEUE) < 0)
    {
      write_log (&info, "Could not listen for remote admins on port %d",
		 info.remote_admin_port);
      clean_shutdown (&info);
    }
  
  write_log (&info, "Listening for remote admins (%d) on port %i...", 
	     info.max_admins, info.remote_admin_port);  

  if (info.redirection == 1) 
    {
      source_t *which = get_next_source (&info);
      int s, i;
      if (which == NULL)
	return;
      write_log (&info, "connecting to [%s:%d] for redirection", 
		 info.redirection_host, info.redirection_port);
      s = sock_connect (info.redirection_host, info.redirection_port);
      if (s < 0)
	{
	  write_log (&info, 
		     "could not connect to server to begin redirection");
	  clean_shutdown (&info);
	}
      which->sock = s;
      which->connect_time = get_time ();
      which->read_bytes = 0;
      which->host = info.redirection_host;
      which->accepted = ICY_ACCEPTED;
      which->counter = 0;
	if (which->buf == NULL) which->buf = (char *)malloc(1024);
      switch_encoder(&info);
      sock_write (which->sock, "GET / HTTP/1.0\n\n");
      source_login (which->sock, info.encoder_pass, &which->counter, which->buf);
      fcntl (s, F_SETFL, O_NONBLOCK);
      write_log (&info, "connected to [%s:%d]...beginning redirection", 
		info.redirection_host, info.redirection_port);
	if (info.public) 
	      {
		/* Since we need the server id, in the real instance of this
		   process, we can't fork directory_add().
		   Seems like a likely reason to go nonblocking here too, but not now */
		for (i = 0; i < info.max_directories; i++)
		  {
		    if (info.d_server[i].host == NULL)
		      continue;
		    directory_add (&info.d_server[i]);
		  }
		if (fork() == 0)
		  {
		    for (i = 0; i < info.max_directories; i++)
		      {
			if (info.d_server[i].host == NULL)
			  continue;
			directory_touch (&info.d_server[i]);
		      }
		    exit (0);
		  }
		info.lasttime = get_time ();
	      }

    }
}
  
void
switch_encoder (server_info_t *info)
{
  int i;

  info->actual_encoder = -1;

  for (i = 0; i < info->max_sources; i++)
    {
      if (info->sources[i].sock != -1)
	info->actual_encoder = info->sources[i].sock;
    }
}

void
kick_clients ()
{
  int i;
  for (i = 0; i < info.max_clients; i++)
    {
      kick_client (&info.clients[i], "kick_clients()");
    }
}







