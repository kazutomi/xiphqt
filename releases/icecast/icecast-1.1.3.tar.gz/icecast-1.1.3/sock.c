/* sock.c
 * - General Socket Functions
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif
#include <stdarg.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#include <netdb.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#ifdef HAVE_LIBWRAP
# include <tcpd.h>
# ifdef NEED_SYS_SYSLOG_H
#  include <sys/syslog.h>
# else
#  include <syslog.h>
# endif
int allow_severity = LOG_INFO;
int deny_severity = LOG_WARNING;
#endif
#include "sock.h"
#include "icecast.h"
#include "log.h"
#include "main.h"

/* accept() is a pain, it wants a socklen_t * as third argument on
   some systems */
#if !defined __GLIBC__ || __GLIBC__ < 2
typedef int socklen_t;
#endif

char *makeasciihost (char *in);
admin_t *get_next_admin (server_info_t *info);
source_t *get_next_source (server_info_t *info);
client_t *get_next_client (server_info_t *info);

extern int errno;
extern server_info_t info;

#define SOCKET_OPERATIONS 1

/* Never, ever, _ever_ ever _ever_ put a write_log or sock_write in here */
int sock_write(int sockfd, char *fmt, ...)
{
	char buff[1024];
	va_list ap;
	int write_bytes;

	va_start(ap, fmt);
#ifdef HAVE_VSNPRINTF
	vsnprintf(buff, 1024, fmt, ap);
#else
	vsprintf (buff, fmt, ap);
#endif

	if (sockfd == 0)
	  {
	    write_bytes = write (1, buff, strlen (buff));
	  }
	else
	  write_bytes = write(sockfd, buff, strlen(buff));

	return (write_bytes == strlen(buff) ? 1 : 0);
}

int sock_read(int sockfd, char **string)
{
  char c, buff[1024];
  int read_bytes, pos;

  memset(buff, 0, 1024);
  pos = 0;

  read_bytes = read(sockfd, &c, 1);
  while (c != '\n' && pos < 1024 && read_bytes == 1) {
    if (c != '\r')
      buff[pos++] = c;
    read_bytes = read(sockfd, &c, 1);
  }

  *string = (char *)malloc(strlen(buff)+1);
  strcpy(*string, buff);

  return (read_bytes == 1 ? 1 : 0);
}

/* 
   Nonblocking function called to read a line (until '\n') is read.
   Called until a '\n' is read, and then the result (without the \n) 
   is stored in string, and the number of bytes read is stored in counter.
   Returns:
   -2 on overflow
   -1 on error
   0 on "not done"
   1 on done
*/
int 
sock_read_line (int sockfd, char *string, int *counter)
{
  int rb;

  do
    {
      errno = 0;
      switch ((rb = read (sockfd, &string[*counter], 1)))
	{
	  case -1:
	    if (errno == EAGAIN)
	      return 0;
	    write_log (&info, "sock_read_line: Got error %d", errno);
	    my_perror ("read");
	    return -1;
	    break;
	  case 0:
	    return -1;
	    break;
	  case 1:
	    if (string[*counter] == '\r')
	      string[*counter] = '\0';
	    else if (string[*counter] == '\n')
	      {
		string[*counter] = '\0';
		return 1;
	      }
	    break;
	}
      *counter = *counter + 1;
    } while (*counter < 1023);
  return -2;
}


/* 
   Same as sock_read_line, but reads into string until _two_ \r\n or \n 
   sequences are read.
   Returns:
   -2 on overflow
   -1 on error
   0 on "not done"
   1 on done
*/
int 
sock_read_lines (int sockfd, char *string, int *counter)
{
  int read_bytes;

  do
    {
      errno = 0;
      switch (read_bytes = read (sockfd, &string[*counter], 1))
	{
	  case -1:
	    if (errno == EAGAIN)
	      return 0;
	    write_log (&info, "sock_read_lines: Got error %d", errno);
	    my_perror ("read");
	    return -1;
	    break;	    
	  case 0:
	    return -1;
	    break;
	  case 1:
	    if (string[*counter] == '\r')
	      *counter = *counter - 1; /* Don't include this */
	    else if (string[*counter] == '\n')
	      {
#ifdef DEBUG_HEADERS
		write_log (&info, "Source said [%s]", string);
#endif
		if (string[*counter - 1] == '\n')
		  {
#ifdef DEBUG_HEADERS
		    write_log (&info, "Got end of line");
#endif
		    string[*counter - 1] = '\0';
		    return 1;
		  }
	      }
	    break;
	}
      *counter = *counter + 1;
    } while (*counter < 1023);
  return -2;
}

/* Create a socket, and bind INADDR_ANY to it */
int get_server_socket(int port)
{
	struct sockaddr_in sin;
	int tmp = 1;
	int sin_len;
	int sockfd;
	int error;
	
	/* get socket descriptor */
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) return sockfd;

	/* Setup socket */
#ifdef SOCKET_OPERATIONS
	setsockopt (sockfd, SOL_SOCKET, SO_KEEPALIVE, (const void *)&tmp, 
		    sizeof (tmp));
	setsockopt (sockfd, SOL_SOCKET, SO_REUSEADDR, (const void *)&tmp, 
		    sizeof (tmp));
#endif

	/* setup sockaddr structure */
	sin_len = sizeof(sin);
	memset(&sin, 0, sin_len);
	sin.sin_family = AF_INET;
	if (info.myhostname != NULL)
	  {
	    struct hostent *hostinfo = gethostbyname (info.myhostname);
	    if (hostinfo == NULL)
	      {
		write_log (&info, "Unknown host %s.\n", info.myhostname);
		clean_shutdown (&info);
	      }
	    sin.sin_addr = *(struct in_addr *) hostinfo->h_addr;
	  }
	else
	  sin.sin_addr.s_addr = htonl(INADDR_ANY);
	sin.sin_port = htons(port);
	
	/* bind socket to port */
	error = bind(sockfd, (struct sockaddr *)&sin, sin_len);
	if (error < 0) 
	  {
	    my_perror ("bind");
	    return error;
	  }

	return sockfd;
}

/* Create a client_t structure and return it if the accept() call
   on fromsocket is valid */
client_t *
put_client (int fromsocket)
{
  struct sockaddr_in sinp;
  socklen_t sin_len;
  signed int sock;
  client_t *cli;

  sin_len = sizeof (sinp);
  memset (&sinp, 0, sin_len);

  sock = accept (fromsocket, (struct sockaddr *) &sinp, &sin_len);
  if (sock == -1)
    return NULL;

  cli = get_next_client (&info);
  if (cli == NULL)
    return NULL;
  cli->sock = sock;
  cli->host = makeasciihost ((char *)&sinp.sin_addr);
  cli->write_bytes = 0;
  cli->connect_time = get_time ();
  cli->accepted = PENDING;
  cli->counter = 0;
  cli->buf = (char *) malloc (1024);
  fcntl (cli->sock, F_SETFL, O_NONBLOCK);
  sin_len = 1;
#ifdef SOCKET_OPERATIONS
  {
    socklen_t before, before_len;
    setsockopt (cli->sock, SOL_SOCKET, SO_KEEPALIVE, (const void *)&sin_len, 
		sizeof (sin_len));
    getsockopt (cli->sock, SOL_SOCKET, SO_SNDBUF, (void *) &before, 
		&before_len);
    sin_len = 100000;
    setsockopt (cli->sock, SOL_SOCKET, SO_SNDBUF, (const void *)&sin_len, 
		sizeof (sin_len));
#ifdef DEBUG_SOCKET
    write_log (&info, "Changed client socket buffer from %d to %d", before, 
	       sin_len);
#endif
  }
#endif
  return cli;
}

/* Same as put_client but on source_t */
source_t *
put_source (int fromsocket)
{
  struct sockaddr_in sinp;
  int sock;
  socklen_t sin_len;
  source_t *ser;

  sin_len = sizeof (sinp);
  memset (&sinp, 0, sin_len);

  sock = accept (fromsocket, (struct sockaddr *) &sinp, &sin_len);
  if (sock == -1)
    return NULL;

  ser = get_next_source (&info);
  if (ser == NULL)
    return NULL;
  ser->sock = sock;
  ser->host = makeasciihost ((char *)&sinp.sin_addr);
  ser->read_bytes = 0;
  ser->accepted = PENDING;
  ser->counter = 0;
  ser->buf = (char *) malloc (1024);
  ser->connect_time = get_time ();
  fcntl (ser->sock, F_SETFL, O_NONBLOCK);
#ifdef SOCKET_OPERATIONS
  {
    socklen_t before, before_len;
    setsockopt (ser->sock, SOL_SOCKET, SO_KEEPALIVE, (const void *)&sin_len, 
		sizeof (sin_len));
    getsockopt (ser->sock, SOL_SOCKET, SO_RCVBUF, (void *)&before, 
		&before_len);
    sin_len = 100000;
    setsockopt (ser->sock, SOL_SOCKET, SO_RCVBUF, (const void *)&sin_len, 
		sizeof (sin_len));
#ifdef DEBUG_SOCKET
    write_log (&info, "Changed encoder socket buffer from %d to %d", before,
	       sin_len);
#endif
  }
#endif
  return ser;
}

/* Dito for admin_t */
admin_t *
put_admin (int fromsocket)
{
  struct sockaddr_in sinp;
  int sock;
  socklen_t sin_len;
  admin_t *adm;

  sin_len = sizeof (sinp);
  memset (&sinp, 0, sin_len);

  sock = accept (fromsocket, (struct sockaddr *) &sinp, &sin_len);
  if (sock == -1)
      return NULL;
  
  adm = get_next_admin (&info);
  if (adm == NULL)
    return NULL;
  adm->sock = sock;
  adm->host = makeasciihost ((char *)&sinp.sin_addr);
  adm->commands = 0;
  adm->accepted = PENDING;
  adm->counter = 0;
  adm->buf = (char *) malloc (1024);
  adm->connect_time = get_time ();
  fcntl (adm->sock, F_SETFL, O_NONBLOCK);
#ifdef SOCKET_OPERATIONS
  setsockopt (adm->sock, SOL_SOCKET, SO_KEEPALIVE, (const void *)&sin_len, 
	      sizeof (sin_len));
#endif
  return adm;
}

int get_client(int server) 
{
  struct sockaddr_in sin;
  int sockfd;
  socklen_t sin_len;
  
  /* setup sockaddr structure */
  sin_len = sizeof(sin);
  memset(&sin, 0, sin_len);
  
  /* try to accept a connection */
  sockfd = accept(server, (struct sockaddr *)&sin, &sin_len);
  
  return sockfd;
}

int sock_connect(char *hostname, int port)
{
	int sockfd;
	struct sockaddr_in sin;
	struct hostent *host;
	
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1) { return -1; }

	host = gethostbyname(hostname);
	if (host == NULL) { close(sockfd); return -1; }

	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(port);
	sin.sin_addr.s_addr = *(unsigned long *)host->h_addr_list[0];

	if (connect(sockfd, (struct sockaddr *)&sin, sizeof(sin)) == 0)
		return sockfd;
	else {
		close(sockfd);
		return -1;
	}
}

#ifdef HAVE_LIBWRAP
/* Checks whether the host connected to the sock socket is
   allowed in or not. */
int
check_libwrap (int sock)
{
  struct request_info req;
#ifdef DEBUG_LIBWRAP
  write_log (&info, "Checking socket %d for validation", sock);
#endif
  request_init (&req, RQ_DAEMON, "icecast", RQ_FILE, sock, NULL);
  fromhost (&req);
  if (!hosts_access (&req))
    return 0;
  return 1;
}
#endif
