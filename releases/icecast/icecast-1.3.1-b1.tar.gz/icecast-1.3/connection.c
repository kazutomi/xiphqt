/* connection.c
 * - Connection functions
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
# ifndef __USE_BSD
#  define __USE_BSD
# endif
#include <string.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <sys/types.h>
#include <ctype.h>
#include <errno.h>
#include <time.h>
#include <fcntl.h>

#ifndef _WIN32
#include <sys/socket.h> 
#include <sys/wait.h>
#include <netinet/in.h>
#else
#include <winsock.h>
#endif

#include "avl.h"
#include "threads.h"
#include "icetypes.h"
#include "icecast.h"
#include "utility.h"
#include "ice_string.h"
#include "connection.h"
#include "log.h"
#include "sock.h"
#include "client.h"
#include "source.h"
#include "admin.h"
#include "logtime.h"
#include "restrict.h"
#include "memory.h"
#include "http.h"

/* 
 * This is called to handle a brand new connection, in it's own thread.
 * We know nothing about the type of the connection.
 * Assert Class: 3
 */
void *
handle_connection (void *arg)
{
	connection_t *con = (connection_t *)arg;
	char line[BUFSIZE] = "";
	int res;

	init_thread(); 

	if (!con) {
		write_log (LOG_DEFAULT, "handle_connection: got NULL connection");
		thread_exit (0);
	}

	if (info.reverse_lookups)
		con->hostname = reverse (con->host);
	
	if (!allowed (con, unknown_connection_e))
	{
		write_http_header (con->sock, 403, "Forbidden");
		kick_not_connected(con, "Access Denied (internal acl list (generic connection))");
		thread_exit(0);
	}

	sock_set_blocking (con->sock, SOCK_BLOCK);
	
	/* Fill line[] with the user header, ends with \n\n */
	if ((res = sock_read_lines (con->sock, line, BUFSIZE)) <= 0)
	{
		write_log(LOG_DEFAULT, "Socket error on connection %d", con->id);
		kick_not_connected(con, "Socket error");
		thread_exit(0);
	}
  
	if (res == 2) /* stupid xaudio */
		strcpy (line, "GET / HTTP/1.0\nUser-Agent:stupid-xaudio\n\n");
	
	/* 
	 * Check if it's a client, admin or source.
	 * Client connections will return,
	 * Admin and source will run as its own thread
	 * and never return.
	 */
	if (strncmp(line, "GET", 3) == 0) {
		client_login(con, line);
	} else if (strncmp(line, "ADMIN", 5) == 0) {
		admin_login(con, line);
	} else if (strncmp(line, "SOURCE", 5) == 0) {
		source_login (con, line);
	} else if (strncmp(line, "PING", 4) == 0) {
		line[1] = 'O';
		sock_write_line (con->sock, line);
		xa_debug (1, "Replied to ping from [%s]", con_host(con));
		kick_silently(con);
		thread_exit(0);
	} else {
		char pass[BUFSIZE];
		if (splitc (pass, line, '\n') || (strcpy (pass, line)))
		{
			if (pass[strlen(pass) - 1] == '\n')
				pass[strlen(pass) - 1] = '\0';
			if (password_match(info.encoder_pass, pass)) {
				char newline[BUFSIZE + 20];
				sock_write_line (con->sock, "OK2");
				sock_write_line (con->sock, "icy-caps:11\r\n");
				if ((res = sock_read_lines_np(con->sock, line, BUFSIZE)) <= 0)
				{
					write_log(LOG_DEFAULT, "Socket error on connection %d", con->id);
					kick_not_connected(con, "Socket error");
					thread_exit(0);
				}
				put_source(con);
				con->food.source->protocol = icy_e;
				con->food.source->type = encoder_e;
				sprintf(newline, "SOURCE %s %s\n%s", pass, next_mount_point(), line);
				source_login(con, newline);
				thread_exit(0);
			}
		}
		/* Client said something we didn't recognize. */
		write_http_header (con->sock, 306, "Grow up");
		kick_not_connected(con, "Stupid headers");
	}
	
	thread_exit(0);
	return NULL;
}

connection_t *create_connection()
{
	connection_t *con = (connection_t *) nmalloc (sizeof (connection_t));
	con->type = unknown_connection_e;
	con->headervars = NULL;
	con->sin = NULL;
	con->hostname = NULL;
	con->headervars = NULL;
	return con;
}

connection_t *
get_connection (sock_t sock)
{
	struct sockaddr_in *sin = (struct sockaddr_in *) nmalloc (sizeof (struct sockaddr_in));
	int sockfd;
	socklen_t sin_len;
	connection_t *con;

	/* setup sockaddr structure */
	sin_len = sizeof(struct sockaddr_in);
	memset(sin, 0, sin_len);
  
	/* try to accept a connection */
	sockfd = accept(sock, (struct sockaddr *)sin, &sin_len);
  
	if (sockfd >= 0) {
		con = create_connection();
		if (!sin)
		{
			xa_debug (1, "ERROR: NULL sockaddr struct, wft???");
			return NULL;
		}
		con->host = create_malloced_ascii_host ((char *)&(sin->sin_addr));
		con->sock = sockfd;
		con->sin = sin;
		con->sinlen = sin_len;
		xa_debug (2, "DEBUG: Getting new connection on socket %d from host %s", sockfd, con->host ? con->host : "(null)");
		con->hostname = NULL;
		con->headervars = NULL;
		con->id = new_id ();
		con->connect_time = get_time ();
#ifdef HAVE_LIBWRAP
		if (!check_libwrap(sockfd, unknown_connection_e))
		{
			kick_not_connected (con, "Access Denied (tcp wrappers)");
			nfree (sin);
			return NULL;
		}
#endif
		return con; /* We got a one */
	}
	if (errno != EINTR && errno != EAGAIN)
		xa_debug (1, "WARNING: accept() failed with [%d]", errno);
	nfree (sin);
	return NULL;
}

void
describe_connection (const connection_t *con, const connection_t *describecon)
{
	char buf[BUFSIZE];
	avl_traverser trav = {0};
	const varpair_t *vp;

	if (!con || !describecon)
	{
		xa_debug (1, "WARNING: describe_connection() called with NULL pointers");
		return;
	}

	sock_write_line (con->sock, "Connection id: %lu", describecon->id);
	sock_write_line (con->sock, "Connection socket: %d", describecon->sock);
	sock_write_line (con->sock, "Connect time: %s", nice_time (get_time () - describecon->connect_time, buf));
	sock_write_line (con->sock, "Connection host and ip: %s [%s]", describecon->hostname ? describecon->hostname : "(null)", describecon->host);
	
	if (describecon->headervars)
	{
		sock_write_line (con->sock, "Header variables:");
		while ((vp = avl_traverse (describecon->headervars, &trav)))
			sock_write_line (con->sock, "'%s' = '%s'", vp->name, vp->value);
	}
}

