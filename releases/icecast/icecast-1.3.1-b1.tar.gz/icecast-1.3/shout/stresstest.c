/* StressIce 0.0.1
   980218 eel@musiknet.se
   
   -
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.
*/
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <netdb.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <sys/time.h>

#define inline 

inline void connect_client (int *s, struct sockaddr_in *name, int len, char *host);
inline void read_to_void (int *sock);
inline void handle_action (int *s, fd_set *readfds);
inline void px_shutdown (int res);

extern int errno;

/* Set this to something optimal */
#define LBUFSIZE 8192

#define HOST "localhost"
#define PORT 8000

int *s;
int num_sockets = 30;
char buf[LBUFSIZE];
char voidbuffer[LBUFSIZE];

void s1gnal (const int sig);

int
main (int argc, char **argv)
{
  register int i;
  fd_set readfds;
  int fds = 0, select_val, len;
  struct timeval tv;
  struct hostent *hp;
  struct sockaddr_in name;
  char *server = HOST;
  int port = PORT;

  /*  parse_args (argc, argv); */
  
  s = (int *) malloc (num_sockets * sizeof (int));
  
  printf ("Created %d sockets, connecting them to the server\n", num_sockets);
  
  if ((hp = gethostbyname (server)) == NULL)
    {
      fprintf (stderr, "unknown host: %s.\n", server);
      exit (1);
    }

  /* Create server adress */
  memset (&name, 0, sizeof (struct sockaddr_in));
  name.sin_family = AF_INET;
  name.sin_port = htons (port);
  memcpy (&name.sin_addr, hp->h_addr_list[0], hp->h_length);
  len = sizeof (struct sockaddr_in);

  for (i = 0; i < num_sockets; i++)
    connect_client (&s[i], &name, len, server);

  printf ("Setting sockets in nonblocking mode\n");
  for (i = 0; i < num_sockets; i++)
    fcntl (s[i], F_SETFL, O_NONBLOCK);

  printf ("Sockets connected, doing the best we can with reading\n");
  /*  fds = getdtablesize (); */
  fds = 0;
  printf ("Using %d as fds\n", fds);

  while (42)
    {
      FD_ZERO (&readfds);
      for (i = 0; i < num_sockets; i++)
	{
	  if (s[i] < 0)
	    continue;
	  FD_SET (s[i], &readfds);
	  if (s[i] > fds)
	    fds = s[i];
	}
      
      tv.tv_sec = 1;
      tv.tv_usec = 0;
      errno = 0;

      select_val = select (fds + 1, &readfds, NULL, NULL, &tv);
      
      switch (select_val)
	{
	  case -1:
	    if (errno != EINTR && errno != EAGAIN)
	      {
		perror ("select");
		px_shutdown (1);
	      }
	    break;
	  case 0:
	    break;
	  default:
	    handle_action (s, &readfds);
	    break;
	}
    }
}

inline void
connect_client (int *s, struct sockaddr_in *name, int len, char *host)
{
  /* Create socket */
  if ((*s = socket (AF_INET, SOCK_STREAM, 6)) < 0)
    {
      perror ("socket:");
      exit (1);
    }

  if (connect (*s, (struct sockaddr *) name, len) < 0)
    {
      fprintf (stderr, "Could not connect to server, exiting\n");
      perror ("connect:");
      exit (1);
    }
  
  sprintf (buf, "GET / HTTP/1.0\r\nHost: %s\r\nIcy-MetaData:1\r\nAccept: */*\r\n\r\n", host);
  send (*s, buf, strlen (buf), 0);
}

inline void
handle_action (int *s, fd_set *readfds)
{
  register int i;
  for (i = 0; i < num_sockets; i++)
    {
      if (s[i] < 0)
	continue;

      if (FD_ISSET (s[i], readfds))
	{
	  read_to_void (&s[i]);
	}
    }
}

inline void
read_to_void (int *sock)
{
  if (*sock == -1)
    return;
  if (read (*sock, voidbuffer, LBUFSIZE) <= 0 && errno != EAGAIN && errno != EINTR)
    {
      printf ("Socket %d got lost [%s]\n", *sock, strerror (errno));
      close (*sock);
      *sock = -1;
    }
}
      
inline void
px_shutdown (int res)
{
  register int i;
  for (i = 0; i < num_sockets; i++)
    {
      if (s[i] == -1)
	continue;
      close (s[i]);
    }
  exit (2);
}
