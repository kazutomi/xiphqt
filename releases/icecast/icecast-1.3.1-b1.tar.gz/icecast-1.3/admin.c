/* admin.c
 * - Admin Functions
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

/* Last overhauled: 990419 <eel@musiknet.se> */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#ifndef __USE_BSD
#define __USE_BSD
#endif
#include <string.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <sys/types.h>
#include <ctype.h>
#include <errno.h>

#if defined (_WIN32)
#include <windows.h>
#else
#include <sys/socket.h>
#include <sys/wait.h>
#endif

#include "avl.h"
#include "avl_functions.h"
#include "threads.h"
#include "icetypes.h"
#include "icecast.h"
#include "admin.h"
#include "utility.h"
#include "ice_string.h"
#include "log.h"
#include "commands.h"
#include "sock.h"
#include "connection.h"
#include "logtime.h"
#include "restrict.h"
#include "memory.h"
#include "source.h"
#include "directory.h"
#include "http.h"

extern int running;

/* 
 * Brand new admin, check the password and give him the prompt
 * in a new thread if it's valid 
 * Called from handle_connection, and the line should be something like
 * ADMIN <password>
*/
void 
admin_login(connection_t *con, char *expr)
{
	char line[BUFSIZE], command[BUFSIZE], arg[BUFSIZE];
	int go_on = 1, connected = 1;

	xa_debug (2, "DEBUG: admin_login: called with connection %d", con->id);

#ifdef HAVE_LIBWRAP
	if (!allowed(con, admin_e) || !check_libwrap (con->sock, admin_e)) {
#else
	if (!allowed(con, admin_e)) {
#endif
		write_http_header (con->sock, 403, "Forbidden");
		kick_not_connected(con, "Access Denied (internal acl list (admin connection))");
		thread_exit(0);
	}

	do {
		if (splitc(line, expr, '\n') == NULL) {
			strncpy(line, expr, BUFSIZE);
			go_on = 0;
		}

		if (splitc(command, line, ' ') == NULL) {
			strncpy(command, line, BUFSIZE);
			arg[0] = '\0';
		} else {
			strncpy(arg, line, BUFSIZE);
		}
      
		if (strncmp(command, "ADMIN", 5) == 0) {
			if (!password_match(info.remote_admin_pass, arg)) {
				sock_write_line (con->sock, "ERROR - Bad Password");
				kick_connection (con, "Invalid admin password");
				connected = 0;
				break;
			} else {
				if (info.num_admins > info.max_admins)
				{
					sock_write_line (con->sock, "ERROR - Too many connected admins");
					kick_connection (con, "Too many connected admins");
					connected = 0;
				}
				else
					write_log(LOG_DEFAULT, "Accepted admin pass from connection %d. %d admins connected", con->id, 
						  info.num_admins + 1);
			}
		}
	} while (go_on && connected);
      
	if (connected) {
		sock_write_line(con->sock, "OK");

		put_admin (con);
		
		thread_mutex_lock(&info.admin_mutex);
		avl_insert(info.admins, con);
		thread_mutex_unlock(&info.admin_mutex);
		handle_remote_admin (con);
	}

	thread_exit(0);
}

/* This is called, as a new thread, to handle remote admins */
void *
handle_admin (void *vcon)
{
	char line[BUFSIZE] = "";
	connection_t *con = (connection_t *) vcon;

	con->food.admin->thread = thread_self ();
	init_thread ();

	fd_write(con->sock, "-> ");

	while (con->food.admin->alive) {
		if (fd_read_line (con->sock, line, BUFSIZE))
			handle_admin_command(con, line, strlen (line));
		else
			break;
	}

	close_connection (con, &info);
	thread_exit(0);
	return NULL;
}

/* This is called, as a new thread, to handle remote admins */
void handle_remote_admin(connection_t *con)
{
	char line[BUFSIZE] = "";

	con->food.admin->thread = thread_self ();
	init_thread ();

	sock_write(con->sock, "-> ");

	while (con->food.admin->alive) {
		if (sock_read_line (con->sock, line, BUFSIZE))
			handle_admin_command(con, line, strlen (line));
		else
			break;
	}

	close_connection (con, &info);
	thread_exit(0);
}

admin_t *create_admin()
{
	admin_t *admin = (admin_t *)nmalloc(sizeof(admin_t));
	return admin;
}

void put_admin(connection_t *con)
{
	admin_t *adm = create_admin();
	con->food.admin = adm;
	con->type = admin_e;
	adm->commands = 0;
	adm->oper = 0;
	adm->tailing = 0;
	adm->status = 1;
	adm->alive = 1;
	adm->debuglevel = 0;
	add_admin ();
}

void add_admin()
{
	thread_mutex_lock(&info.misc_mutex);
	info.num_admins++;
	thread_mutex_unlock(&info.misc_mutex);
}

void del_admin()
{
	thread_mutex_lock(&info.misc_mutex);
	info.num_admins--;
	thread_mutex_unlock(&info.misc_mutex);
}

void add_icecast_console()
{
	connection_t *con;
	admin_t *adm;

	write_log(LOG_DEFAULT, "Using stdin as icecast operator console");
	con = create_connection();
	con->sock = 0; /* STDIN/STDOUT, we still need special cases */
	con->host = nstrdup("icecast console");
	con->hostname = NULL;
	con->connect_time = get_time();
	put_admin(con);
	adm = con->food.admin;
/*	adm = create_admin();
	con->food.admin = adm;
	
	con->type = admin_e; 
	adm->commands = 0; 
	adm->status = 1;
	adm->alive = 1;
	add_admin();
*/
	adm->oper = 1;
	if (info.console_mode == CONSOLE_ADMIN_TAIL) {
		write_log(LOG_DEFAULT, "Tailing file to icecast operator console");
		adm->tailing = 1;
	}
	sock_write(1, "-> ");
	con->id = new_id();
	
        /* No threads here, no need to lock */
	avl_insert(info.admins, con);
	thread_create ("Admin Console Thread", handle_admin, (void *)con);
}

void
describe_admin (const connection_t *con, const connection_t *admcon)
{
	const admin_t *admin;

	if (!con || !admcon)
	{
		xa_debug (1, "WARNING: describe_admin(): called with NULL pointers");
		return;
	}

	if (admcon->type != admin_e)
	{
		xa_debug (1, "WARNING: describe_admin(): called with invalid type");
		return;
	}

	describe_connection (con, admcon);
	
	admin = admcon->food.admin;

	sock_write_line (con->sock, "Misc admin info:");
	sock_write_line (con->sock, "Display regular status information: %s", admin->status ? "yes" : "no");
	sock_write_line (con->sock, "Icecast operator: %s", admin->oper ? "yes" : "no");
	sock_write_line (con->sock, "Tailing logfile: %s", admin->tailing ? "yes" : "no");
	sock_write_line (con->sock, "Commands executed: %d", admin->commands);
	sock_write_line (con->sock, "Debuglevel: %d", admin->debuglevel);
}







