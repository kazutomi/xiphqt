/* commands.c
 * - Admin Commands Handling *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#ifndef __USE_BSD
#define __USE_BSD
#endif
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <fcntl.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#ifdef _WIN32
#include <windows.h>
#else
#include <sys/socket.h>
#endif

#include "avl.h"
#include "threads.h"
#include "icetypes.h"
#include "icecast.h"
#include "commands.h"
#include "sock.h"
#include "log.h"
#include "main.h"
#include "directory.h"
#include "utility.h"
#include "ice_string.h"
#include "relay.h"
#include "logtime.h"
#include "source.h"
#include "client.h"
#include "avl_functions.h"
#include "timer.h"
#include "alias.h"
#include "restrict.h"
#include "memory.h"
#include "admin.h"
#include "authenticate/basic.h"
#include "authenticate/user.h"
#include "authenticate/group.h"
#include "authenticate/mount.h"

#include <time.h>

extern int errno;
extern int running;
server_info_t info;

typedef struct 
{
	char *name;                   /* User printable name of the function. */
	Function *func;               /* Function to call to do the job. */
	char *doc;                    /* Documentation for this function.  */
	int oper;                     /* Has to be oper? */
	char *doclong;                /* Long description of command */
} comp_element;

typedef struct
{
	char *name;                   /* Printable name of this setting */
	type_t type;                  /* Integer, string or float? */
	char *doc;                    /* What does this setting do? */
	void *setting;                /* The actual data affected by this setting */
} set_element;

/* Now list all the functions (*sigh*) */
int     com_admins(), com_help(), com_tail(), com_untail(),
	com_sources(), com_listeners(), com_rehash(), com_set(), com_sel(),
	com_uptime(), com_tell(), com_shutdown(), com_oper(),
	com_kick(), com_quit(), com_touch(), com_dir(), com_stats(),
	com_relay(), com_list(), com_alias(), com_threads(),
	com_status(), com_allow(), com_deny(), com_pause(),
	com_unpause(), com_modify(), com_dump(), com_locks(), com_ping(),
	com_debug (), com_mem (), com_streamtitle (), com_streamurl (),
	com_describe (), com_acl (), com_auth ();


/* All the remote admin commands */
comp_element commands[] = 
{
	{ "alias",   com_alias,    "Add an alias for a mount point", 1, 
	  "alias <add|del|list> [newmountpoint] [mountpoint] or [newmountpoint] [http://server:port/mountpoint]\r\n\tMakes mountpoint available on 2 places\r\n" },
	{ "allow",   com_allow,    "Add hostmask for allowed host", 1,
	  "allow <client|source|admin|all> <add|del|list> [hostmask]\r\n\tAdd, delete or list allowed hostmasks\r\n" },
	{ "deny",    com_deny,     "Add hostmask for denied host", 1,
	  "deny <client|source|admin|all> <add|del|list> [hostmask]\r\n\tAdd, delete or list denied hostmasks\r\n" },
	{ "acl",     com_acl, 	   "List all access controls", 1,
	  "acl\r\n\tList all access controls\r\n" },
	{ "admins",  com_admins,   "Show all connected admins", 0, 
	  "admins [pattern]\r\n\tDisplays all admins matching pattern, or all just all admins if no pattern is specified\r\n"},
	{ "dir",     com_dir,      "Add, delete or remove directory servers", 1, 
	  "dir [add|delete|list]\r\n\tAdd host[:port[/path]], del <host>, or list all directory servers\r\n"},
	{ "dump",    com_dump,     "Dump a source to a specified file", 1,
	  "dump <sourceid> <filename|close>\r\n\tDump source with id <sourceid> to a file specified with filename, or stop dumping if the filename is \"close\".\r\n"},
	{ "help",    com_help,     "Display this text", 0,
	  "help <command>\r\n\tDisplay general help, or help for a specific command.\r\n"},
	{ "kick",    com_kick,     "Kick client, admin, or source", 1,
	  "kick <options> <pattern|id>\r\n\t-c for clients, -a for admins, -s for sources, kicks specified pattern or id.\r\n"},
	{ "listeners", com_listeners, "Show connected listeners", 0,
	  "listeners <pattern>\r\n\tDisplay all listeners matching pattern, or all listeners if no pattern is specified\r\n" },
	{ "modify",  com_modify,   "Change the audiocast data for a source", 1,
	  "modify <source_id> <-mungdPpb> <argument>\r\n\tModify a audiocast field for the specified source\r\n" },
	{ "oper",    com_oper,     "Obtain operator privileges", 0,
	  "oper <password>\r\n\tIf correct password is specified, makes you a icecast operator and grants access to the operator commands\r\n" },
	{ "pause",   com_pause,    "Put a client or source on hold", 1,
	  "pause <client_id|source_id>\r\n\tEither pause a client (cutting the data), or a source (no data to its clients)\r\n"},
	{ "quit",    com_quit,     "Leave remote admin console", 0 ,
	  "quit <message>\r\n\tLeaves the remote admin console with message displayed for all other admins.\r\n"},
	{ "rehash",  com_rehash,   "Parse the config file", 1,
	  "rehash <configfile>\r\n\tOpen and parse the configfile, or the default configfile if not specified.\r\n"},
	{ "select",  com_sel,      "Select encoder for clients", 1,
	  "select <options> <sid> [pattern] <tid>\r\n\tEither select -a <sourceid> <targetid>, which moves all clients from sourceid to targetid. Or select -p <sourceid> <pattern> <targetid>, which moves all clients matching pattern from sourceid to targetid. Or select <clientid> <targetsourceid>, which moves client with id clientid to source with id targetsourceid.\r\n"},
	{ "sources", com_sources,  "Show connected encoders", 0,
	  "sources <pattern>\r\n\tShow connected sources matching pattern, or all sources if no pattern is specified.\r\n"},
	{ "shutdown", com_shutdown, "Shutdown the server", 1,
	  "shutdown <message>\r\n\tShutdown server, display message to all connected admins.\r\n"},
	{ "set",     com_set,      "Set <var> to <arg>", 1,
	  "set [variable] [argument]\r\n\tIf both variable and argument, set variable to argument. If just variable, show current setting. If just set, then show all current settings.\r\n"},
	{ "stats",   com_stats,    "Show server statistics", 0,
	  "stats <daily|hourly|clear>\r\n\tShow current server statistics, averages, uptime, etc.  Argument is optional - either gives daily stats, hourly stats, or clears all stats\r\n"},
	{ "tail",    com_tail,     "Start tailing the logfile", 0,
	  "tail\r\n\tIntercept icecast server log messages.\r\n"},
	{ "tell",    com_tell,     "Tell other admins", 0,
	  "tell <message>\r\n\tDisplay message for all connected admins.\r\n"},
	{ "touch",   com_touch,    "Touch the directory server", 1,
	  "touch\r\n\tForce all directory servers to be touched now.\r\n"},
	{ "unpause", com_unpause,  "Unpause a client or source", 1,
	  "unpause <client_id|source_id>\r\n\tRemove a lock on a client or source, making it run like normal again\r\n."},
	{ "untail",  com_untail,   "Stop tailing the logfile", 0,
	  "untail\r\n\tDon't display logfile messages.\r\n"},
	{ "uptime",  com_uptime,   "Show server uptime", 0, 
	  "uptime\r\n\tShow icecast server version and uptime.\r\n"},
	{ "list",    com_list,     "List all current connections", 0,
	  "list <pattern>\r\n\tList all connections matching pattern, or all connections if no pattern is specified.\r\n"},
	{ "relay",   com_relay,    "Pull or push a server relay", 1, 
	  "relay <push <id> <host[:port]> <options> | pull <url>>\r\n\tEither (push) relay a connected source to a remote server, or (pull) relay a source from a remove server.\r\n"},
	{ "threads", com_threads,  "Show all program threads", 0, 
	  "threads\r\n\tDisplay all the currently running threads in the program, and where and when they were created.\r\n"},
	{ "locks",   com_locks,    "Show status of all locks", 0, 
	  "locks\r\n\tDisplay all mutexes, and their status.\r\n"},
	{ "status",  com_status,   "Turn status info on/off (for you)", 0, 
	  "status [on|off|show]\r\n\tTurn on or off the periodic status information line.\r\n"},
	{ "debug",   com_debug,     "Set debugging output level for this connection.", 0,
	  "debug <integer>\r\n\tSets debugging level. Higher value is more debugging output.\r\n"},
	{ "mem", com_mem,          "Another debug function, shows mem usage.",0, 
	  "mem\r\n\tShows all alloced addresses.\r\n"},
	{ "streamtitle", com_streamtitle, "Set and/or lock streamtitle for a source.", 0,
	  "streamtitle <-a|sourceid> <message>\r\n\tSets and/or locks the stream title for source or [-a] all sources.\r\n"},
	{ "streamurl", com_streamurl, "Set and/or lock streamurl for a source.", 0,
	  "streamurl [-a] [sourceid] <message>\r\n\tSets the stream url for source or [-a] all sources.\r\n"},
	{ "describe", com_describe, "Show detailed view on a connection.", 0,
	  "describe <id>\r\n\tDisplay all information available for the specified connection id.\r\n"},
	{ "auth", com_auth, "Show authorization groups, users, or mountpoints.", 0,
	  "auth <groups|users|mounts>\r\n\tList all authentication entries for users, groups or mounts.\r\n"},
	{ (char *) NULL, (Function *)NULL, (char *)NULL, 0 }
};

/* All the settings for the remote admin */
set_element admin_settings[] = 
{
  { "encoder_password", string_e,  "The encoder password", NULL },
  { "client_password", string_e, "<unimplemented> Client password", NULL },
  { "admin_password", string_e, "The remote admin password", NULL },
  { "oper_password", string_e, "Operator Password", NULL },
  { "touch_freq", integer_e, "Touch frequency", NULL },
  { "client_timeout", integer_e, "When to kick out clients", NULL },
  { "max_clients", integer_e, "How many listeners to let in", NULL },
  { "max_clients_per_source", integer_e, "Max number of clients per source", NULL },
  { "max_sources", integer_e, "How many sources to let in", NULL },
  { "max_admins", integer_e, "How many admins to let in", NULL },
  { "reverse", integer_e, "Whether to reverse ip:s to hostnames", NULL},
  { "location", string_e, "Icecast server geographical location", NULL},
  { "rp_email", string_e, "Resposible person email", NULL},
  { "transparent_proxy", integer_e, "Whether to act as transparent proxy", NULL},
  { "stats_log", string_e, "File for dumping periodic stats", NULL},
  { "statshtml_log", string_e, "File for dumping periodic stats in html format", NULL},
  { "stats_time", integer_e,       "How often to write to the stats logfile, in seconds", NULL},
  { "acl_policy", integer_e, "Whether to allow (1), or deny (0) by default", NULL},
  { "throttle", real_e,      "At what bandwidth usage (MB/s) do we deny access?", NULL},
  { "kick_relays", integer_e, "Kick relays after how many seconds without listeners? (0 means keep forever)", NULL},
  { "kick_clients", integer_e, "0 means move clients to default source when their source dies, 1 means kick them out", NULL},
  { "status_time", integer_e, "Seconds between status line updates", NULL},
  { "logfiledebuglevel", integer_e,    "Debug level for logfile output", NULL},
  { "consoledebuglevel", integer_e, "Debug level for console output", NULL},
  { "server_url", string_e, "URL for this icecast server", NULL}, 
  { "use_meta_data", integer_e, "Whether to include metadata in the stream", NULL}, 
  { "streamurllock", integer_e, "Whether or not to allow sources to change the stream url", NULL},
  { "streamurl", string_e, "Server global stream url", NULL},
  { "streamtitletemplate", string_e, "Template string for stream title string", NULL},
  { "nametemplate", string_e, "Template string for stream name", NULL},
  { "desctemplate", string_e, "Template string for description template", NULL},
  { "logfile", string_e, "Main logfile", NULL},
  { "accessfile", string_e, "Access logfile", NULL},
  { "usagefile", string_e, "Usage logfile", NULL},
  { (char *) NULL, 0, (char *) NULL, NULL }
};

/* Make sure the array of admin settings point to the right data */
void
setup_admin_settings ()
{
	int x = 0;
	/* The order of these are IMPORTANT, get it? */
	admin_settings[x++].setting = &info.encoder_pass;
	admin_settings[x++].setting = &info.client_pass;
	admin_settings[x++].setting = &info.remote_admin_pass;
	admin_settings[x++].setting = &info.oper_pass;
	admin_settings[x++].setting = &info.touch_freq;
	admin_settings[x++].setting = &info.client_timeout;
	admin_settings[x++].setting = &info.max_clients;
	admin_settings[x++].setting = &info.max_clients_per_source;
	admin_settings[x++].setting = &info.max_sources;
	admin_settings[x++].setting = &info.max_admins;
	admin_settings[x++].setting = &info.reverse_lookups;
	admin_settings[x++].setting = &info.location;
	admin_settings[x++].setting = &info.rp_email;
	admin_settings[x++].setting = &info.transparent_proxy;
	admin_settings[x++].setting = &info.statsfilename;
	admin_settings[x++].setting = &info.statshtmlfilename;
	admin_settings[x++].setting = &info.statstime;
	admin_settings[x++].setting = &info.policy;
	admin_settings[x++].setting = &info.throttle;
	admin_settings[x++].setting = &info.kick_relays;
	admin_settings[x++].setting = &info.kick_clients;
	admin_settings[x++].setting = &info.statustime;
	admin_settings[x++].setting = &info.logfiledebuglevel;
	admin_settings[x++].setting = &info.consoledebuglevel;
	admin_settings[x++].setting = &info.server_url;
	admin_settings[x++].setting = &info.use_meta_data;
	admin_settings[x++].setting = &info.streamurllock;
	admin_settings[x++].setting = &info.streamurl;
	admin_settings[x++].setting = &info.streamtitletemplate;
	admin_settings[x++].setting = &info.nametemplate;
	admin_settings[x++].setting = &info.descriptiontemplate;
	admin_settings[x++].setting = &info.logfilename;
	admin_settings[x++].setting = &info.accessfilename;
	admin_settings[x++].setting = &info.usagefilename;
}

/* All the settings for the config file */
set_element configfile_settings[] = 
{
	{ "encoder_password", string_e,  "The encoder password", NULL },
	{ "client_password", string_e,   "<unimplemented> Client password", NULL },
	{ "admin_password", string_e,    "The remote admin password", NULL },
	{ "oper_password", string_e,     "Operator Password", NULL },
	{ "touch_freq", integer_e,       "Touch frequency", NULL },
	{ "port", integer_e,             "Port to listen on", NULL },
	{ "max_clients", integer_e,      "Highest number of client connectons",  NULL },
	{ "max_sources", integer_e,      "Highest number of source connections", NULL },
	{ "max_admins", integer_e,       "Highest number of admin connections", NULL },
	{ "logfile", string_e,           "Logfile to write to", NULL },
	{ "hostname", string_e,          "What host/ip to bind to", NULL},
	{ "server_name", string_e,	 "Server's hostname", NULL},
	{ "console_mode", integer_e,     "How to use the icecast console", NULL },
	{ "client_timeout", integer_e,   "When to kick out clients", NULL },
	{ "stats_log", string_e,         "Stats Logfile to write to", NULL},
	{ "statshtml_log", string_e, "File for dumping periodic stats in html format", NULL},
	{ "stats_time", integer_e,       "How often to write to the stats logfile, in seconds", NULL},
	{ "max_clients_per_source", integer_e, "Max number of clients listening on one source", NULL},
	{ "reverse_lookups", integer_e,  "Whether to reverse lookup hostnames", NULL},
	{ "location", string_e, "Icecast server geographical location", NULL},
	{ "rp_email", string_e, "Resposible person email", NULL},
	{ "transparent_proxy", integer_e, "Whether to act as transparent proxy", NULL},
	{ "acl_policy", integer_e,        "Whether to allow (1) or deny (0) by default", NULL},
	{ "throttle", real_e,      "At what bandwidth usage (MB/s) do we deny access?", NULL},
	{ "kick_relays", integer_e, "Kick relays after how many seconds without listeners? (0 means keep forever)", NULL},
	{ "kick_clients", integer_e, "0 means move clients to default source when their source dies, 1 means kick them out", NULL},
	{ "status_time", integer_e, "Seconds between status line updates", NULL},
	{ "static_dir", string_e, "Directory for static files", NULL},
	{ "logfiledebuglevel", integer_e,    "Debug level for logfile output", NULL},
	{ "consoledebuglevel", integer_e, "Debug level for console output", NULL},
        { "server_url", string_e, "URL for this icecast server", NULL}, 
	{ "use_meta_data", integer_e, "Whether to include metadata in the stream", NULL},
	{ "streamurllock", integer_e, "Whether or not to allow sources to change the stream url", NULL},
	{ "streamurl", string_e, "Server global stream url", NULL},
	{ "iceroot", string_e, "Directory where the icecast files reside", NULL},
	{ "streamtitletemplate", string_e, "Template string for stream title string", NULL},
	{ "nametemplate", string_e, "Template string for stream name", NULL},
	{ "desctemplate", string_e, "Template string for description template", NULL},
	{ "accessfile", string_e, "Access logfile", NULL},
	{ "usagefile", string_e, "Usage logfile", NULL},
	{ (char *) NULL, 0, (char *) NULL, NULL }
};

/* make sure the array of settings for the config file points to the right data */
void setup_config_file_settings()
{
	int x = 0;
	/* Don't change the order of these */
	configfile_settings[x++].setting = &info.encoder_pass;
	configfile_settings[x++].setting = &info.client_pass;
	configfile_settings[x++].setting = &info.remote_admin_pass;
	configfile_settings[x++].setting = &info.oper_pass;
	configfile_settings[x++].setting = &info.touch_freq;
	configfile_settings[x++].setting = &info.port;
	configfile_settings[x++].setting = &info.max_clients;
	configfile_settings[x++].setting = &info.max_sources;
	configfile_settings[x++].setting = &info.max_admins;
	configfile_settings[x++].setting = &info.logfilename;
	configfile_settings[x++].setting = &info.myhostname;
	configfile_settings[x++].setting = &info.server_name;
	configfile_settings[x++].setting = &info.console_mode;
	configfile_settings[x++].setting = &info.client_timeout;
	configfile_settings[x++].setting = &info.statsfilename;
	configfile_settings[x++].setting = &info.statshtmlfilename;
	configfile_settings[x++].setting = &info.statstime;
	configfile_settings[x++].setting = &info.max_clients_per_source;
	configfile_settings[x++].setting = &info.reverse_lookups;
	configfile_settings[x++].setting = &info.location;
	configfile_settings[x++].setting = &info.rp_email;
	configfile_settings[x++].setting = &info.transparent_proxy;
	configfile_settings[x++].setting = &info.policy;
	configfile_settings[x++].setting = &info.throttle;
	configfile_settings[x++].setting = &info.kick_relays;
	configfile_settings[x++].setting = &info.kick_clients;
	configfile_settings[x++].setting = &info.statustime;
	configfile_settings[x++].setting = &info.staticdir;
	configfile_settings[x++].setting = &info.logfiledebuglevel;
	configfile_settings[x++].setting = &info.consoledebuglevel;
	configfile_settings[x++].setting = &info.server_url;
	configfile_settings[x++].setting = &info.use_meta_data;
	configfile_settings[x++].setting = &info.streamurllock;
	configfile_settings[x++].setting = &info.streamurl;
	configfile_settings[x++].setting = &info.iceroot;
	configfile_settings[x++].setting = &info.streamtitletemplate;
	configfile_settings[x++].setting = &info.nametemplate;
	configfile_settings[x++].setting = &info.descriptiontemplate;
	configfile_settings[x++].setting = &info.accessfilename;
	configfile_settings[x++].setting = &info.usagefilename;
}

set_element *
find_set_element (char *name, set_element *el)
{
  register int i;
  for (i = 0; el[i].name; i++)
    if (strcmp (name, el[i].name) == 0)
      return (&el[i]);
  return ((set_element *)NULL);
}

comp_element *
find_comp_element (char *name, comp_element *el)
{
  register int i;
  for (i = 0; el[i].name; i++)
    if (strcmp (name, el[i].name) == 0)
      return (&el[i]);
  return ((comp_element *)NULL);
}

int
parse_default_config_file ()
{
	char *file = get_icecast_file (info.configfile, "etc", R_OK);
	
	if (file)
	{
		parse_config_file (file);
		nfree (file);
		return 1;
	}
	
	parse_config_file (info.configfile);
	return 1;
}
		
/* Parse the configfile pointed to by file.
   If it doesn't exist, no matter, just go on */
int 
parse_config_file(char *file)
{
	set_element *se;
	int lineno = 0;
	char word[BUFSIZE], line[BUFSIZE];
	int cf;
	
	xa_debug (1, "DEBUG: Parsing configuration file %s", file ? file : "(null)");

	if ((cf = open_for_reading (file)) == -1)
	  {
		write_log(LOG_DEFAULT, "No configfile found, using defaults.");
		return 1;
	}

	/* Clean up aliases, directories, and acl lists */
	free_acl_lists ();
	free_directory_servers ();
	free_aliases ();

	while (fd_read_line (cf, line, BUFSIZE) > 0)
	{
		lineno++;
		if ((strlen (line) < 2) || (line[0] == '#') || (line[0] == ' '))
			continue;
		
		if (line[strlen(line) - 1] == '\n')
			line[strlen(line) - 1] = '\0';
		if (splitc(word, line, ' ') == NULL) {
			write_log(LOG_DEFAULT, "ERROR: No argument given to setting %s on line %d", 
				   line, lineno);
			continue; 
		}
		
		se = find_set_element(word, configfile_settings);
		
		/* K, even though this looks wrong, it's not :) */
		
		if ((strncmp(word, "icydir", 6) == 0) || (strncmp (word, "dir", 3) == 0))
		{
			char host[BUFSIZE], port[BUFSIZE];
			directory_server_t *dir = create_directory();
			
			dir->type = (strncmp (word, "icydir", 6) == 0) ? icy_e : xaudiocast_e;
			dir->counter = 0;
			dir->id = -1;

			if (strchr (line, '/') != NULL && strchr (line, ':') == NULL)
			{
				write_log (LOG_DEFAULT, "ERROR: Path but no port specified in icy directory on line %d", lineno);
				continue;
			}

			if (splitc (host, line, ':') == NULL) /* No port, no path */
			{
				dir->port = 80;
				dir->path = nstrdup (DEFAULT_YP_TOUCH);
				strcpy (host, line);
			} else if (splitc (port, line, '/') == NULL) /* port, but no path */
			{
				dir->port = atoi (line);
				dir->path = nstrdup ("DEFAULT_YP_TOUCH");
			} else {
				dir->port = atoi (port);
				dir->path = nstrdup (line);
			}

			dir->host = nstrdup (host);

			thread_mutex_lock (&info.directory_mutex);
			if (avl_find (info.d_servers, dir) == NULL)
				avl_insert (info.d_servers, dir);
			thread_mutex_unlock (&info.directory_mutex);

			if (dir->type == icy_e)
				write_log (LOG_DEFAULT, "Using icy directory server [%s:%d]", dir->host, dir->port);
			else
				write_log (LOG_DEFAULT, "Using xaudiocast directory server [%s:%d/%s]", dir->host, dir->port, dir->path);
			continue;

		} else if (strncmp(word, "alias", 5) == 0)
		{
			char name[BUFSIZE];
			if (splitc(name, line, ' ') == NULL) {
				write_log(LOG_DEFAULT, "ERROR: Missing argument for alias on line %d", lineno);
			} else {
				request_t nameline, realline;
				
				zero_request(&nameline);
				zero_request(&realline);
				
				generate_request(name, &nameline);
				generate_request(line, &realline);
				
				if (!nameline.path[0] || !realline.path[0]) {
					write_log(LOG_DEFAULT, "ERROR: Invalid syntax for alias on line %d", lineno);
					continue;
				}
				add_alias(&nameline, &realline);
			}
			continue;
		} else if (strncmp(word, "include", 7) == 0) {
			parse_config_file(line);
			continue;
		} else if (strncmp(word, "allow", 5) == 0) {
			char type[BUFSIZE];
			restrict_t *res;
			if (splitc(type, line, ' ') == NULL) {
				write_log(LOG_DEFAULT, "ERROR: Invalid syntax for acl allow on line %d", lineno);
				continue;
			}
			res = add_restrict(get_acl_tree(type), line, allow);
			if (!res)
				write_log(LOG_DEFAULT, "ERROR: Acl addition for [%s] failed", line);
			continue;
		} else if (strncmp(word, "deny", 4) == 0) {
			char type[BUFSIZE];
			restrict_t *res;
			if (splitc(type, line, ' ') == NULL) {
				write_log(LOG_DEFAULT, "ERROR: Invalid syntax for acl deny on line %d", lineno);
				continue;
			}
			res = add_restrict(get_acl_tree(type), line, deny);
			if (!res)
				write_log(LOG_DEFAULT, "ERROR: Acl addition for [%s] failed", line);
			continue;
		}
		
		
		if (!se) {
			write_log(LOG_DEFAULT, "Unknown setting %s on line %d", word, lineno);
			continue;
		}
		
		if (se->type == integer_e) {
			*(int *)(se->setting) = atoi(line);
		} else if (se->type == real_e) {
			*(double *)(se->setting) = atof(line);
		} else {
			/* string, might have to free it first */
			if (*(char **)(se->setting) != NULL)
				nfree(*(char **)(se->setting));
			*((char **)(se->setting)) = clean_string(nstrdup(line));
		}      
	}
	fd_close(cf);
	return 0;
}

/* Top level remote admin console command parser */
void 
handle_admin_command (connection_t *con, char *command, int command_len)
{
  int flag = 0;
  register int i;
  comp_element *com;
  char comstr[BUFSIZE], *arg;
  admin_t *adm = con->food.admin;
  
  if (command_len < 2)
    {
      sock_write (con->sock, "-> ");
      return;
    }

  /* sanity check */
  for (i = 0; i <= command_len; i++)
    {
      if (command[i] == '\n' || command[i] == '\0')
	{
	  flag = 1;
	  command[i] = '\0';
	  break;
	}
    }
  
  if (!flag)
    {
      sock_write (con->sock, "-> ");
      return;
    }

  splitc (comstr, command, ' ');

  if (!comstr[0] || !command[0] || command[0] == ' ')
    {
      if (command[0] && command[0] != ' ')
	strcpy (comstr, command);
      arg = NULL;
    }
  else
    arg = command;

  /* Functions are now responsible for their own logging */
  com = find_comp_element (comstr, commands);

  if (!com)
    {
      com_help (con, comstr);
      sock_write (con->sock, "-> ");
      return;
    }
  if (com->oper && (!adm->oper))
	  sock_write_line (con->sock, "Only operators can use the %s command", com->name);
  else
    ((*(com->func)) (con, arg));
  sock_write (con->sock, "-> ");
}

int
com_admins (connection_t *con, char *arg)
{
	log_command (con, "admins", arg);

	if (arg && arg[0])
	{
		sock_write_line (con->sock, "Listing admins matching [%s]", arg);
		thread_mutex_lock (&info.admin_mutex);
		do_if_match_tree (info.admins, arg, print_admin, &con->sock, 0);
		thread_mutex_unlock (&info.admin_mutex);
	} else {
		sock_write_line (con->sock, "Listing admins (%d):", info.num_admins);
		thread_mutex_lock(&info.admin_mutex);
		avl_walk (info.admins, print_admin, &con->sock);
		thread_mutex_unlock (&info.admin_mutex);
	}
	return 1;
}

void
show_settings (connection_t *con)
{
  register int i;
  set_element *se = admin_settings;

  sock_write_line (con->sock, "Current settings:");
  for (i = 0; se[i].name; i++)
    {
      if (se[i].type == integer_e)
	sock_write_line (con->sock, "[%25s]\t [%d]", se[i].name, 
		    *(int *)(se[i].setting));
      else if (se[i].type == real_e)
	sock_write_line (con->sock, "[%25s]\t [%lf]", se[i].name, 
		    *(double *)(se[i].setting));
      else
	sock_write_line (con->sock, "[%25s]\t [%s]", se[i].name, 
		    *(char **)(se[i].setting));
    }
}

int
com_help (connection_t *con, char *arg)
{
  register int i;
  comp_element *ce;
  set_element *se;

  log_command (con, "help", NULL);

  if (!arg)
    {
      ce = commands;
      sock_write_line (con->sock, "Available commands:");
      for (i = 0; ce[i].name; i++)
	sock_write_line (con->sock, "%20s\t: %s", ce[i].name, ce[i].doc);
      sock_write_line (con->sock, "For slighly more detailed help on each command, try 'help <command>'");
      return 1;
    }
  
  if (strncmp (arg, "setti", 5) == 0)
    {
      se = admin_settings;
      sock_write_line (con->sock, "Available settings:");
      for (i = 0; se[i].name; i++)
	sock_write_line (con->sock, "%25s\t: %s", se[i].name, se[i].doc);
      return 1;
    }

  ce = find_comp_element (arg, commands);

  if (!ce)
    {
      sock_write_line (con->sock, "No such command [%s]", arg);
      return 1;
    }

  sock_write_line (con->sock, "Command: [%s]\r\nDescription: [%s]%s", ce->name, 
	      ce->doc, ce->doclong);
  return 1;
}
      

int
com_set (connection_t *con, char *arg)
{
  char argument[BUFSIZE] = "";
  set_element *s;

  log_command (con, "set", NULL);

  if (!arg || !arg[0])
    {
      show_settings (con); /* No setting, show all settings */
      return 1;
    }

  if (splitc (argument, arg, ' ') == NULL || argument[0] == ' ') 
    /* No argument, show setting */
    {
      s = find_set_element (arg, admin_settings);
      if (!s)
	{
	  sock_write_line (con->sock, "No such setting [%s]", arg);
	  return 1;
	}
      if (s->type == integer_e)
	sock_write_line (con->sock, "%s: %d", s->name, *(int *)(s->setting));
      else if (s->type == real_e)
	sock_write_line (con->sock, "%s: %lf", s->name, *(double *)(s->setting));
      else 
	sock_write_line (con->sock, "%s: %s", s->name, *(char **)(s->setting));
      return 1;
    }

  s = find_set_element (argument, admin_settings);
  if (!s)
    {
      sock_write_line (con->sock, "No such setting [%s]", argument);
      return 1;
    }

  /* Actually change something */
  {
	  char *oldlogfile = info.logfilename;
	  char *oldaccessfile = info.accessfilename;
	  char *oldusagefile = info.usagefilename;
	  
	  if (s->type == integer_e)
		  *(int *)(s->setting) = atoi (arg);
	  else if (s->type == real_e)
		  *(double *)(s->setting) = atof (arg);
	  else
	  {
		  /* string, might have to free it first */
		  if (*(char **)(s->setting) != NULL)
			  nfree (*(char **)(s->setting));
		  *((char **)(s->setting)) = nstrdup (arg);
	  }
	  
	  if ((oldlogfile != info.logfilename) || (oldusagefile != info.usagefilename) || (oldaccessfile != info.accessfilename))
	  {
		  open_log_files ();
	  }
  }
  return 1;
}
  
int
com_tail (connection_t *con, char *arg)
{
	log_command (con, "tail", NULL);
	sock_write_line (con->sock, "Now tailing logfile");
	
	con->food.admin->tailing = 1;
	return 1;
}

int
com_untail (connection_t *con, char *arg)
{
	log_command (con, "untail", NULL);
	sock_write_line (con->sock, "No longer tailing logfile");
	con->food.admin->tailing = 0;
	return 1;
}

int
com_sources (connection_t *con, char *arg)
{
	log_command (con, "sources", arg);

	if (arg && arg[0])
	{
		sock_write_line (con->sock, "Listing sources matching (%s):", arg);
		thread_mutex_lock (&info.source_mutex);
		do_if_match_tree (info.sources, arg, print_source_verbose, &(con->sock), 0);
		thread_mutex_unlock (&info.source_mutex);
	} else {
		sock_write_line (con->sock, "Listing sources (%d):", info.num_sources);
		thread_mutex_lock(&info.source_mutex);
		avl_walk (info.sources, print_source_verbose, &con->sock);
		thread_mutex_unlock(&info.source_mutex);
	}
	return 1;
}

int
com_listeners (connection_t *con, char *arg)
{
  log_command (con, "listeners", arg);

  if (arg && arg[0])
  {
	  sock_write_line (con->sock, "Listing listeners matching (%s):", arg);
	  thread_mutex_lock (&info.double_mutex);
	  thread_mutex_lock (&info.source_mutex);
	  do_if_match_tree (info.sources, arg, print_clients, &(con->sock), 0);
	  thread_mutex_unlock (&info.source_mutex);
	  thread_mutex_unlock (&info.double_mutex);
  } else {
	  sock_write_line (con->sock, "Listing listeners (%d):", info.num_clients);
	  thread_mutex_lock (&info.double_mutex);
	  thread_mutex_lock(&info.source_mutex);
	  avl_walk (info.sources, print_clients, &con->sock);
	  thread_mutex_unlock(&info.source_mutex);
	  thread_mutex_unlock (&info.double_mutex);
  }

  return 1;
}

int
com_rehash (connection_t *con, char *arg)
{
  char *oldlogfile = info.logfilename;
  char *oldaccessfile = info.accessfilename;
  char *oldusagefile = info.usagefilename;

  log_command (con, "rehash", arg);

  write_log (LOG_DEFAULT, "Reading configfile %s", arg ? arg : info.configfile);
  if (arg && arg[0])
	  parse_config_file (arg);
  else
	  parse_default_config_file ();
  
  if ((oldlogfile != info.logfilename) || (oldusagefile != info.usagefilename) || (oldaccessfile != info.accessfilename))
  {
	  open_log_files ();
  }

  return 1;
}

int
com_uptime (connection_t *con, char *arg)
{
	char timebuf[BUFSIZE];
	int i = get_time () - info.server_start_time;
	log_command (con, "uptime", NULL);
	sock_write_line (con->sock, 
		    "Icecast %s server uptime: %s", VERSION, nice_time (i, timebuf));
	return 1;
}

int
com_tell (connection_t *con, char *arg)
{
	char buf[BUFSIZE];
	avl_traverser trav = {0};
	connection_t *con2;

	if (!arg || !arg[0])
	{
		sock_write_line (con->sock, "Don't be so modest, spit it out :)");
		return 1;
	}
	
	sprintf (buf, "Admin %ld said: [%s]\r\n-> ", con->id, arg);

	thread_mutex_lock(&info.admin_mutex);

	while ((con2 = avl_traverse (info.admins, &trav)))
	{
		if (con2->id != con->id)
			tell_admins (con2, buf);
	}

	thread_mutex_unlock(&info.admin_mutex);
	return 1;
}

/* If things goes as planned, this should do no traversing of
   avl trees, just printing stuff put in the statistics struct by
   the stats thread */
int
com_stats (connection_t *con, char *arg)
{
  unsigned long int verb = 0;
  statistics_t stat;
  time_t t;
  unsigned long int extra_clientconnections = 0;
  unsigned long int extra_sourceconnections = 0;

  char timebuf[BUFSIZE];

  if (arg && (strncmp (arg, "-v", 2) == 0))
	  verb = 1;
  
  log_command (con, "stats", arg);

  zero_stats (&stat);

  if (arg && arg[0])
  {
	  if (strcmp (arg, "daily") == 0)
	  {
		  statistics_t cs;
		  get_current_stats (&cs);
		  add_stats (&stat, &cs, 0);

		  get_hourly_stats (&cs);
		  add_stats (&stat, &cs, 0);

		  get_daily_stats (&cs);
		  add_stats (&stat, &cs, 1000);

		  extra_sourceconnections = info.num_sources;
		  extra_clientconnections = info.num_clients;
		  sock_write_line (con->sock, "Following info is for the last day:");
	  } else if (strcmp (arg, "hourly") == 0)
	  {
		  statistics_t cs;
		  get_current_stats (&cs);
		  add_stats (&stat, &cs, 0);

		  get_hourly_stats (&cs);
		  add_stats (&stat, &cs, 0);
		  extra_sourceconnections = info.num_sources;
		  extra_clientconnections = info.num_clients;
		  sock_write_line (con->sock, "Following info is for the last hour:");
	  } else if (strcmp (arg, "clear") == 0)
	  {
		  sock_write_line (con->sock, "Clearing stats...");
		  write_log (LOG_DEFAULT, "Clearing stats...");
		  thread_mutex_lock (&info.misc_mutex);
		  zero_stats (&info.daily_stats);
	          zero_stats (&info.hourly_stats);
        	  zero_stats (&info.total_stats);
		  thread_mutex_unlock (&info.misc_mutex);
		  /* clear source stats - do we need a mutex? 
		     Yeah, we do :)		   */
		  thread_mutex_lock (&info.double_mutex);
		  thread_mutex_lock (&info.source_mutex);
		  avl_walk (info.sources, clear_source_stats, &info);
		  thread_mutex_unlock (&info.source_mutex);
		  thread_mutex_unlock (&info.double_mutex);
		  /* clear admin stats */
		  thread_mutex_lock (&info.admin_mutex);
		  avl_walk (info.admins, clear_admin_stats, &info);
		  thread_mutex_unlock (&info.admin_mutex);
	  } else {
		  sock_write_line (con->sock, "Unknown stats type %s", arg);
		  return 1;
	  }
  } else {
	  sock_write_line (con->sock, "Following info is server total:");
	  get_running_stats (&stat);
  }

  t = get_time ();

  sock_write_line (con->sock, "Icecast %s server uptime: %s", VERSION, nice_time (t - info.server_start_time, timebuf));
  
  sock_write_line (con->sock, "Admins (%d):", info.num_admins);
  if (verb)
	  avl_walk (info.admins, print_admin, &(con->sock));

  sock_write_line (con->sock, "Sources (%d):", info.num_sources);
  if (verb)
	  avl_walk (info.sources, print_source_verbose, &(con->sock));

  sock_write_line (con->sock, "Listeners (%d):", info.num_clients);
  if (verb)
	  avl_walk (info.sources, print_clients, &(con->sock));

  sock_write_line (con->sock, "Displaying server statistics:");
  sock_write_line (con->sock, "Total Mbytes read: %lu", stat.read_bytes);
  sock_write_line (con->sock, "Total Mbytes written: %lu", stat.write_bytes);
  sock_write_line (con->sock, "Number of source connects: %lu", stat.source_connections);
  sock_write_line (con->sock, "Number of client connects: %lu", stat.client_connections);

  if (stat.client_connections > 0)
  {
	  sock_write_line (con->sock, "Average listener time: %s", connect_average (stat.client_connect_time, 
										 stat.client_connections + extra_clientconnections, timebuf));
	  sock_write_line (con->sock, "Average listener transfer: %lu Mbytes", transfer_average (stat.write_bytes, 
											      stat.client_connections + extra_clientconnections));
  }
  
  if (stat.source_connections > 0)
  {
	  sock_write_line (con->sock,  "Average source connect time: %s", connect_average (stat.source_connect_time, 
											stat.source_connections + extra_sourceconnections, timebuf));
	  sock_write_line (con->sock,  "Average source transfer: %lu Mbytes", transfer_average (stat.read_bytes, 
											     stat.source_connections + extra_sourceconnections));
  }
  return 1;
}

int
com_shutdown (connection_t *con, char *arg)
{
  log_command (con, "shutdown", NULL);
  sock_write_line (con->sock, "Ok, killing server, bye!");
  if (arg && arg[0])
	  com_tell (con, arg);
  /* Think you have to do this to keep the main listen socket from blocking */
  sock_close(info.listen_sock);
  running = 0;
  return 1;
}

int
com_oper (connection_t *con, char *arg)
{
  admin_t *adm = con->food.admin;
  log_command (con, "oper", NULL);
  if (!arg)
    {
      sock_write_line (con->sock, "*hint* The password is longer than that :)");
      return 1;
    }
  if (password_match (info.oper_pass, arg))
    {
	    adm->oper = 1;
	    sock_write_line (con->sock, "You are now an icecast operator");
	    write_log (LOG_DEFAULT, "Admin %s[%i] is now an icecast operator", con_host (con), con->id);
    }
  else
    sock_write_line (con->sock, "Invalid password");
  return 1;
}

int
com_quit (connection_t *con, char *arg)
{
  if (con->sock == 0)
    {
      fd_write_line (1, "Sorry, you can't quit from the local admin console");
      fd_write_line (1, "Use 'shutdown' to bring the server down");
    }
  else
    {
	    char message[BUFSIZE+15];
	    sprintf (message, "Admin quit: %s", arg ? arg : "No message");
	    sock_write_line (con->sock, "Uh, ok, bye!");
	    kick_connection (con, message);
    }
  return 1;
}  

int
com_touch (connection_t *con, char *arg)
{
  log_command (con, "touch", NULL);

  info.directorylasttime = get_time ();

  thread_mutex_lock(&info.directory_mutex);
  avl_walk (info.d_servers, avl_touch_directory, &info);
  thread_mutex_unlock(&info.directory_mutex);
  return 1;
}

#define DIRHELP "dir <add|del|list> [options|number]\r\n"
int
com_dir (connection_t *con, char *arg)
{
  char *out;
  char type[BUFSIZE];

  if (!arg || !arg[0])
    {
      sock_write (con->sock, DIRHELP);
      return 1;
    }

  out = splitc (type, arg, ' ');

  log_command (con, "dir", NULL);

  if (!out)
    strcpy (type, arg);

  if (type[0] == 'a')
    {
	    char host[BUFSIZE], port[BUFSIZE];
	    directory_server_t *dir;

	    if (!out)
	    {
		    sock_write (con->sock, DIRHELP);
		    return 1;
	    }
	    
	    dir = create_directory ();
	    dir->counter = 0;
	    dir->id = -1;
	    dir->type = xaudiocast_e;
	    dir->host = NULL;
	    dir->path = NULL;

	    if (strchr (arg, '/') != NULL && strchr (arg, ':') == NULL)
	    {
		    sock_write_line (con->sock, "ERROR in directory syntax. Path but no port specified");
		    return 1;
	    }
	    
	    if (strstr (arg, " icy") != NULL)
	    {
		    dir->type = icy_e;
		    *(strchr (arg, ' ')) = '\0';
	    }
	    
	    if (splitc (host, arg, ':') == NULL) /* No port, no path */
	    {
		    dir->port = 80;
		    dir->path = nstrdup (DEFAULT_YP_TOUCH);
		    strcpy (host, arg);
	    } else if (splitc (port, arg, '/') == NULL) /* port, but no path */
	    {
		    dir->port = atoi (arg);
		    dir->path = nstrdup (DEFAULT_YP_TOUCH);
	    } else {
		    dir->port = atoi (port);
		    dir->path = nstrdup (arg);
	    }

	    dir->host = nstrdup (host);

	    if (dir->type == icy_e)
		    sock_write_line (con->sock, "Adding icy directory server [%s:%d]", dir->host, dir->port);
	    else
		    sock_write_line (con->sock, "Adding xaudiocast directory server [%s:%d/%s]", dir->host, dir->port, dir->path);

	    thread_mutex_lock (&info.directory_mutex);
	    avl_insert (info.d_servers, dir);
	    thread_mutex_unlock (&info.directory_mutex);

	    return 1;
    }

  if (type[0] == 'd')
    {
	    directory_server_t *out, ds;
	    char *ptr;

	    if ((ptr = strchr (arg, ':')))
	    {
		    *ptr = '\0';
		    ds.port = atoi (ptr + 1);
		    ds.host = &arg[0];
	    } else {
		    ds.port = 80;
		    ds.host = &arg[0];
	    }
	    
	    thread_mutex_lock (&info.directory_mutex);
	    out = avl_delete (info.d_servers, &ds);
	    thread_mutex_unlock (&info.directory_mutex);

	    if (out && out->id >= 0 && out->type == icy_e)
		    directory_remove (out);

	    if (out)
	    {
		    sock_write_line (con->sock, "Directory server [%s:%d] removed", out->host, out->port);
		    nfree (out->host);
		    nfree (out->path);
		    nfree (out);
	    } else {
		    sock_write_line (con->sock, "Directory removal failed.");
	    }
    }
  if (type[0] == 'l')
  {
      sock_write_line (con->sock, "Listing directories: ");

      thread_mutex_lock(&info.directory_mutex);
      avl_walk(info.d_servers, print_directory, &con->sock);
      thread_mutex_unlock(&info.directory_mutex);
    }
  return 1;
}

int
com_kick (connection_t *con, char *arg)
{
	char buf[BUFSIZE];

	if (!arg || !arg[0])
	{
		sock_write_line (con->sock, "kick <id>");
		return 1;
	}
	
	log_command (con, "kick", arg);

	if (splitc (buf, arg, ' ') == NULL)
		strcpy (buf, arg);
	
	if (buf[0] == '-')
	{
		connection_t *sourcecon;
		avl_traverser trav = {0};
		char reason[BUFSIZE];
		sprintf (reason, "Matching (%s)", arg);

		switch (buf[1])
		{
			case 'a':
				sock_write_line (con->sock, "Kicking all admins matching (%s)", arg);
				thread_mutex_lock (&info.admin_mutex);
				do_if_match_tree (info.admins, arg, kick_connection_not_me, reason, 1);
				thread_mutex_unlock (&info.admin_mutex);
				return 1;
				break;
			case 's':
				sock_write_line (con->sock, "Kicking all sources matching (%s)", arg);
				thread_mutex_lock (&info.source_mutex);
				do_if_match_tree (info.sources, arg, kick_connection, reason, 0);
				thread_mutex_unlock (&info.source_mutex);
				return 1;
				break;
			case 'c':
				sock_write_line (con->sock, "Kicking all clients matching (%s)", arg);

				thread_mutex_lock (&info.double_mutex);
				thread_mutex_lock (&info.source_mutex);
				while ((sourcecon = avl_traverse (info.sources, &trav)))
				{
					thread_mutex_lock (&sourcecon->food.source->mutex);
					do_if_match_tree (sourcecon->food.source->clients, arg, 
							  kick_connection, reason, 0);
					thread_mutex_unlock (&sourcecon->food.source->mutex);
				}
				thread_mutex_unlock (&info.source_mutex);
				thread_mutex_unlock (&info.double_mutex);
				return 1;
				break;
			default:
				sock_write_line (con->sock, "Try 'help kick'");
				return 1;
				break;
		}
	}
				
	if (is_pattern (buf))
	{
		sock_write_line (con->sock, "Kicking all connections matching (%s)", buf);
		kick_if_match (buf);
		return 1;
	} else {
		connection_t *kick = find_id (atoi (arg));

		if (!kick)
		{
			sock_write_line (con->sock, "No such id %d", atoi (arg));
			return 1;
		}
		
		if (kick->id == con->id)
		{
			sock_write_line (con->sock, "Some people kick theirselves, but please do it somewhere less public ;)");
			return 1;
		}
		kick_connection (kick, "Kicked by admin");
	}
	return 1;
}
  
void
log_command (connection_t *con, char *command, char *argument)
{
  if (argument)
    write_log (LOG_DEFAULT, "Admin [%s] said: %s %s", con_host (con), command, argument);
  else
    write_log (LOG_DEFAULT, "Admin [%s] said: %s", con_host (con), command);
}

/* Used either like:
   select -p <sourceid> <pattern> <newsourceid>
   select -a <sourceid> <newsourceid>
   select <clientid> <newsourceid> */
int
com_sel (connection_t *con, char *arg)
{
  char first[BUFSIZE], second[BUFSIZE];
  
  if (!arg || !arg[0] || (splitc (first, arg, ' ') == NULL))
  {
	  sock_write_line (con->sock, "Try 'help select'");
	  return 1;
  }
  
  if (first[0] == '-')
  {
	  if (splitc (second, arg, ' ') != NULL)
	  {
		  if (first[1] == 'a')
		  {
			  move_all_from (con, atoi (second), atoi (arg));
			  return 1;
		  }
		  else if (first[1] == 'p')
		  {
			  move_all_matching (con, atoi (second), arg);
			  return 1;
		  }
	  }
	  sock_write_line (con->sock, "Try 'help select'");
	  return 1;
  }
		  
  if (!isdigit ((int)first[0]))
  {
	  sock_write_line (con->sock, "Try 'help select'");
	  return 1;
  }

  move_id_to (con, atoi (first), atoi (arg));
  return 1;
}


void
move_to (void *clientarg, void *sourcetargetarg)
{
	connection_t *client = (connection_t *)clientarg;
	connection_t *sourcetarget = (connection_t *)sourcetargetarg;

	avl_delete (client->food.client->source->clients, client);
	del_client (client, client->food.client->source);
	client->food.client->virgin = 1;
	insert_client (sourcetarget->food.source, client);
	add_client ();
}

/* Move all clients from sourceid, matching pattern, to new id */
void
move_all_matching (connection_t *admcon, int sourceid, char *arg)
{
	char pattern[BUFSIZE];
	connection_t *sourcecon, *targetcon;

	sourcecon = find_source_with_id (sourceid);
	if (!sourcecon)
	{
		sock_write_line (admcon->sock, "Error in source id [%d]", sourceid);
		return;
	}

	if (splitc (pattern, arg, ' ') == NULL)
	{
		sock_write_line (admcon->sock, "Try 'help select'");
		return;
	}

	targetcon = find_source_with_id (atoi (arg));
	if (!targetcon)
	{
		sock_write_line (admcon->sock, "Error in target id [%d]", atoi (arg));
		return;
	}
	
	sock_write_line (admcon->sock, "Moving all clients matching pattern [%s] from source %s to source %s",
		    pattern, sourcecon->food.source->audiocast.mount, targetcon->food.source->audiocast.mount);

	thread_mutex_lock (&info.double_mutex);

	thread_mutex_lock (&sourcecon->food.source->mutex);
	thread_mutex_lock (&targetcon->food.source->mutex);

	do_if_match_tree (sourcecon->food.source->clients, pattern, move_to, targetcon, 1);
	
	thread_mutex_unlock (&sourcecon->food.source->mutex);
	thread_mutex_unlock (&targetcon->food.source->mutex);

	thread_mutex_unlock (&info.double_mutex);

	sock_write_line (admcon->sock, "Done, source now has %d clients, and target source has %d",
		    sourcecon->food.source->num_clients, targetcon->food.source->num_clients);
	return;
}
	

/* Move all client from source with id sourceid, to source with id targetid */
void 
move_all_from (connection_t *admcon, int sourceid, int targetid)
{
  connection_t *sourcecon, *targetcon, *clicon;

  sourcecon = find_source_with_id (sourceid);
  if (!sourcecon)
    {
      sock_write_line (admcon->sock, "Error in source id [%d]", sourceid);
      return;
    }

  targetcon = find_source_with_id (targetid);
  if (!targetcon)
    {
      sock_write_line (admcon->sock, "Error in target id [%d]", targetid);
      return;
    }

  sock_write_line (admcon->sock, "Moving all clients from source %s to source %s",
	      sourcecon->food.source->audiocast.mount, targetcon->food.source->audiocast.mount);
  
  thread_mutex_lock (&info.double_mutex);

  thread_mutex_lock (&sourcecon->food.source->mutex);
  thread_mutex_lock (&targetcon->food.source->mutex);
  
  while ((clicon = avl_get_any_node (sourcecon->food.source->clients)))
    {
      avl_delete (sourcecon->food.source->clients, clicon);
      del_client (clicon, sourcecon->food.source);
      clicon->food.client->virgin = 1;
      insert_client (targetcon->food.source, clicon);
      add_client ();
    }
  
  thread_mutex_unlock (&targetcon->food.source->mutex);
  thread_mutex_unlock (&sourcecon->food.source->mutex);
  
  thread_mutex_unlock (&info.double_mutex);

  sock_write_line (admcon->sock, "Done, old source has %d clients, new source has %d clients",
	      sourcecon->food.source->num_clients, targetcon->food.source->num_clients);
}


void
move_id_to (connection_t *admcon, int id, int newsourceid)
{
	connection_t *con = find_client_with_id (id);
	connection_t *newsourcecon = find_source_with_id (newsourceid);

	if (!con || con->type != client_e)
	{
		sock_write_line (admcon->sock, "Error in client id [%d]", id);
		return;
	}
	
	if (!newsourcecon || newsourcecon->type != source_e)
	{
		sock_write_line (admcon->sock, "Error in new source id [%d]", newsourceid);
		return;
	}

	sock_write_line (admcon->sock, "Moving client %d from source %s to source %s", 
		    con->id, con->food.client->source->audiocast.mount,
		    newsourcecon->food.source->audiocast.mount);

	thread_mutex_lock (&con->food.client->source->mutex);
	avl_delete (con->food.client->source->clients, con);
	thread_mutex_unlock (&con->food.client->source->mutex);
	del_client (con, con->food.client->source);

	con->food.client->virgin = 1;
	thread_mutex_lock (&newsourcecon->food.source->mutex);
	insert_client (newsourcecon->food.source, con);
	thread_mutex_unlock (&newsourcecon->food.source->mutex);
	add_client ();
	sock_write_line (admcon->sock, "Moved client %d to client tree of source %d", 
		    con->id, newsourcecon->id);
	return;
}

void
tell_admins (void *data, void *param)
{
	connection_t *con = (connection_t *) data;
	if (strcmp (con->host, "icecast console") == 0)
	{
		printf ("%s", (char *) param);
		fflush (stdout);
	} else
		sock_write (con->sock, (char *)param);
}
  
int
com_list (connection_t *con, char *arg)
{
	int pattern = arg && arg[0];
	connection_t *sourcecon;
	avl_traverser trav = {0};

	log_command (con, "list", arg);
	
	sock_write_line (con->sock, "Listing connections:");

	thread_mutex_lock(&info.admin_mutex);
	if (pattern)
		do_if_match_tree (info.admins, arg, print_connection, &(con->sock), 0);
	else
		avl_walk (info.admins, print_connection, &con->sock);
	thread_mutex_unlock(&info.admin_mutex);

	thread_mutex_lock (&info.double_mutex);

	thread_mutex_lock(&info.source_mutex);

	if (pattern)
		do_if_match_tree (info.sources, arg, print_connection, &(con->sock), 0);
	else
		avl_walk(info.sources, print_connection, &(con->sock));
	while ((sourcecon = avl_traverse (info.sources, &trav)))
	{
		thread_mutex_lock (&sourcecon->food.source->mutex);
		if (pattern)
			do_if_match_tree (sourcecon->food.source->clients, arg, print_connection, &(con->sock), 0);
		else
			avl_walk (sourcecon->food.source->clients, print_connection, &(con->sock));
		thread_mutex_unlock (&sourcecon->food.source->mutex);
	}
	thread_mutex_unlock(&info.source_mutex);

	thread_mutex_unlock (&info.double_mutex);

	return 1;
}

void
relay_usage (connection_t *con)
{
  sock_write_line (con->sock, "relay <pull|push> <arguments>");
  return;
}

int
com_relay (connection_t *con, char *arg)
{
	/* relay <pull> <host[:port]> [new_mount]
	   relay <push> <host[:port]> */
	char command[BUFSIZE];
	if (!arg || !arg[0])
	{
		relay_usage (con);
		return 1;
	}
	
	if (splitc (command, arg, ' ') == NULL)
	{
		strcpy (command, arg);
		arg[0] = '\0';
	}
	
	if (strncmp (command, "push", 4) == 0)
		relay_push (con, arg);
	
	else if (strncmp (command, "pull", 4) == 0)
		relay_pull (con, arg);
	else
		relay_usage (con);
	
	return 1;
}

#define ALIAS_USAGE "alias <add|del|list> [mountpoint] [real source]\r\n"

int
com_alias (connection_t *con, char *arg)
{
	char type[BUFSIZE];

	if (!arg || !arg[0])
	{
		sock_write (con->sock, ALIAS_USAGE);
		return 0;
	}

	if (splitc (type, arg, ' ') == NULL)
		strcpy (type, arg);
	
	if (strcmp (type, "list") == 0)
	{
		list_aliases (con);
		return 1;
	} else if (strcmp (type, "add") == 0)
	{
		char mountpoint[BUFSIZE];
		request_t nameline, realline;
		alias_t *res = NULL;

		zero_request (&nameline);
		zero_request (&realline);

		if (splitc (mountpoint, arg, ' ') == NULL)
		{
			sock_write (con->sock, ALIAS_USAGE);
			return 0;
		}

		generate_request (mountpoint, &nameline);
		generate_request (arg, &realline);

		if (!nameline.path[0] || !realline.path[0])
		{
			sock_write_line (con->sock, "Invalid alias syntax");
			return 0;
		}
			
		res = add_alias (&nameline, &realline);
		if (res)
		{
			sock_write_line (con->sock, "Added alias [%s] for [%s]", res->name, res->real);
			return 1;
		} else {
			sock_write_line (con->sock, "Alias add failed, alias not added");
			return 0;
		}
	} else if (strcmp (type, "del") == 0)
	{
		if (del_alias (arg))
		{
			sock_write_line (con->sock, "Removed alias [%s]", arg);
			return 1;
		} else {
			sock_write_line (con->sock, "Alias remove failed", arg);
			return 0;
		}
	} else {
		sock_write_line (con->sock, "Unknown command alias [%s] [%s]", type, arg);
		return 0;
	}
}

int 
com_threads(connection_t *con, char *arg)
{
	avl_traverser trav = {0};
	mythread_t *mt;
	char *freeme = NULL;

	thread_mutex_lock(&info.misc_mutex);
	
	while ((mt = avl_traverse(info.threads, &trav)))
		sock_write_line(con->sock, "%d\tType: [%s]\tStarted [File: %s Line: %d] Started: %s", mt->id, mt->name, mt->file, mt->line, freeme = get_string_time (mt->created, REGULAR_TIME));
	
	if (freeme != NULL)
		free (freeme);

	thread_mutex_unlock(&info.misc_mutex);

	return 1;
}

int
com_status (connection_t *con, char *arg)
{
	if (arg && arg[0])
	{
		if (strncmp (arg, "off", 3) == 0)
			con->food.admin->status = 0;
		else if (strncmp (arg, "on", 2) == 0)
			con->food.admin->status = 1;
		else if (strncmp (arg, "show", 4) == 0)
		{
			char *lt = get_log_time ();
			char timebuf[BUFSIZE];
			sock_write_line (con->sock, "[%s] [Bandwidth: %fMB/s] [Sources: %ld] [Clients: %ld] [Admins: %ld] [Uptime: %s]-> ", 
					 lt, info.bandwidth_usage, info.num_sources, info.num_clients, info.num_admins, 
					 nice_time (get_time () - info.server_start_time, timebuf));
			free (lt);
			return 1;
		}
		else
		{
			sock_write_line (con->sock, "Usage: status [off|on]");
			return 1;
		}
	}
	sock_write_line (con->sock, "Status information is [%s]", con->food.admin->status ? "on" : "off");
	return 1;
}

#define DUMP_USAGE "dump <sourceid> <filename|close>\r\n"
int
com_dump (connection_t *con, char *arg)
{
	char cid[BUFSIZE];
	connection_t *sourcecon;
	
	if (!arg || !arg[0])
	{
		sock_write (con->sock, DUMP_USAGE);
		return 0;
	}
	
	log_command (con, "dump", arg);

	if (splitc (cid, arg, ' ') == NULL)
	{
		sock_write (con->sock, DUMP_USAGE);
		return 0;
	}
	
	sourcecon = find_source_with_id (atoi (cid));
	if (!sourcecon)
	{
		sock_write_line (con->sock, "No source with id [%s] found.", cid);
		return 0;
	}
	
	thread_mutex_lock (&sourcecon->food.source->mutex);

	if (strncmp(arg, "close", 5) == 0) {
		fd_close(sourcecon->food.source->dumpfd);
		nfree(sourcecon->food.source->dumpfile);
		sourcecon->food.source->dumpfile = NULL;
		sourcecon->food.source->dumpfd = -1;

		thread_mutex_unlock(&sourcecon->food.source->mutex);
		
		sock_write_line (con->sock, "Ok, stopped and closed dumping for source %d", sourcecon->id);
		return 1;
	}

	sourcecon->food.source->dumpfile = my_strdup (arg);
	/* Don't use fopen().. it can only play with fd < 255 */
	sourcecon->food.source->dumpfd = open_for_writing (sourcecon->food.source->dumpfile);

	if (sourcecon->food.source->dumpfd < 0)	{
		sock_write_line (con->sock, "Failed opening dumpfile [%s] for source %d [%d]", sourcecon->food.source->dumpfile, sourcecon->id, errno);
		nfree(sourcecon->food.source->dumpfile);
		sourcecon->food.source->dumpfile = NULL;
		fd_close(sourcecon->food.source->dumpfd);

		thread_mutex_unlock(&sourcecon->food.source->mutex);
		return 0;
	}

	thread_mutex_unlock(&sourcecon->food.source->mutex);

	sock_write_line (con->sock, "Ok, dumping source %d to %s", sourcecon->id, sourcecon->food.source->dumpfile);

	return 1;
}

#define PAUSE_USAGE "pause <client_id|source_id>\r\n"
int
com_pause (connection_t *con, char *arg)
{
	char cid[BUFSIZE];

	connection_t *pausecon;

	if (!arg || !arg[0])
	{
		sock_write (con->sock, PAUSE_USAGE);
		return 0;
	}

	log_command (con, "pause", arg);

	if (splitc (cid, arg, ' ') == NULL)
		strcpy (cid, arg);

	pausecon = find_source_with_id (atoi (cid));
	if (!pausecon)
		pausecon = find_client_with_id (atoi (cid));

	if (!pausecon)
	{
		sock_write_line (con->sock, "No source or client with id [%s] found.", cid);
		return 0;
	}

	if (pausecon->type == source_e)
		pausecon->food.source->connected = SOURCE_PAUSED;
	else if (pausecon->type == client_e)
		pausecon->food.client->virgin = CLIENT_PAUSED;
	else {
		sock_write_line (con->sock, "Invalid type of paused id [%s].", cid);
		return 0;
	}

	return 1;
}

int
com_unpause (connection_t *con, char *arg)
{
	char cid[BUFSIZE];

	connection_t *pausecon;

	if (!arg || !arg[0])
	{
		sock_write (con->sock, PAUSE_USAGE);
		return 0;
	}

	log_command (con, "unpause", arg);

	if (splitc (cid, arg, ' ') == NULL)
		strcpy (cid, arg);

	pausecon = find_source_with_id (atoi (cid));
	if (!pausecon)
		pausecon = find_client_with_id (atoi (cid));

	if (!pausecon)
	{
		sock_write_line (con->sock, "No source or client with id [%s] found.", cid);
		return 0;
	}

	if (pausecon->type == source_e)
	{
		avl_traverser trav = {0};
		connection_t *client;

		thread_mutex_lock (&pausecon->food.source->mutex);

		while ((client = avl_traverse (pausecon->food.source->clients, &trav)))
			client->food.client->virgin = CLIENT_UNPAUSED;

		thread_mutex_unlock (&pausecon->food.source->mutex);

		pausecon->food.source->connected = SOURCE_CONNECTED;
	} else if (pausecon->type == client_e)
		pausecon->food.client->virgin = CLIENT_UNPAUSED;
	else {
		sock_write_line (con->sock, "Invalid type of unpaused id [%s].", cid);
		return 0;
	}

	return 1;
}

#define RESTRICT_USAGE "<deny|allow> <add|del|list> [mask]\r\n"
int
com_restrict (connection_t *con, char *arg, avl_tree *tree, acltype_t acl_type)
{
	char type[BUFSIZE];

	if (!arg || !arg[0])
	{
		sock_write (con->sock, RESTRICT_USAGE);
		return 0;
	}

	if (splitc (type, arg, ' ') == NULL)
		strcpy (type, arg);

	if (strcmp (type, "list") == 0)
	{
		list_restrict (con, tree, acl_type);
		return 1;
	} else if (strcmp (type, "add") == 0)
	{
		restrict_t *res = add_restrict (tree, arg, acl_type);

		if (res)
		{
			sock_write_line (con->sock, "Added acl rule [%s]", res->mask);
			return 1;
		} else {
			sock_write_line (con->sock, "Acl addition for [%s] failed", arg);
			return 0;
		}
	} else if (strcmp (type, "del") == 0)
	{
		if (del_restrict (tree, arg, acl_type))
		{
			sock_write_line (con->sock, "Acl rule [%s] removed", arg);
			return 1;
		} else {
			sock_write_line (con->sock, "Acl removal of [%s] failed", arg);
		}
	} else {
		sock_write_line (con->sock, "Unknown restrict command [%s] [%s]", type, arg);
		return 0;
	} 
	return 0;
}

avl_tree *
get_acl_tree (char *type)
{
	if (strncmp (type, "client", 5) == 0)
		return info.client_acl.all;
	if (strncmp (type, "source", 5) == 0)
		return info.source_acl.all;
	if (strncmp (type, "admin", 5) == 0)
		return info.admin_acl.all;
	if (strncmp (type, "all", 3) == 0)
		return info.all_acl.all;

	return NULL;
}

#define DENY_USAGE "deny <client|source|admin|all> <add|del|list> [hostmask]\r\n"
int
com_deny (connection_t *con, char *arg)
{
	char type[BUFSIZE];
	avl_tree *treetype; 
	if (splitc (type, arg, ' ') == NULL)
	{
		sock_write (con->sock, DENY_USAGE);
		return 0;
	}
	
	if ((treetype = get_acl_tree (type)) == NULL)
	{
		sock_write (con->sock, DENY_USAGE);
		return 0;
	}
	return com_restrict (con, arg, treetype, deny);
}

#define ALLOW_USAGE "allow <client|source|admin|all> <add|del|list> [hostmask]\r\n"
int
com_allow (connection_t *con, char *arg)
{
	char type[BUFSIZE];
	avl_tree *treetype; 
	if (splitc (type, arg, ' ') == NULL)
	{
		sock_write (con->sock, ALLOW_USAGE);
		return 0;
	}
	
	if ((treetype = get_acl_tree (type)) == NULL)
	{
		sock_write (con->sock, ALLOW_USAGE);
		return 0;
	}
	return com_restrict (con, arg, treetype, allow);
}

#define ACL_USAGE "acl []\r\n"
int
com_acl (connection_t *con, char *arg)
{
	avl_tree *treetype;

	if (arg) 
	{
		sock_write (con->sock, ACL_USAGE);
		return 0;
	}
	
	if ((treetype = get_acl_tree ("all")) == NULL)
	{
		sock_write (con->sock, ACL_USAGE);
		return 0;
	}
	
	return com_restrict (con, "list", treetype, all);
}

#define MODIFY_USAGE "modify <source_id> <-mungPdpb> <argument>\r\n"
int
com_modify (connection_t *con, char *arg)
{
	char cid[BUFSIZE], carg[BUFSIZE];

	connection_t *sourcecon;

	if (!arg || !arg[0] || (splitc (cid, arg, ' ') == NULL))
	{
		sock_write (con->sock, MODIFY_USAGE);
		return 0;
	}

	sourcecon = find_source_with_id (atoi (cid));
	if (!sourcecon)
	{
		sock_write_line (con->sock, "No source found with id [%s]", cid);
		return 0;
	}

	if (arg[0] != '-')
	{
		sock_write (con->sock, MODIFY_USAGE);
		return 0;
	}


	log_command (con, "modify", NULL);

	if (splitc (carg, arg, ' ') == NULL)
		strcpy (carg, arg);

	switch (carg[1])
	{
		case 'b':
			sourcecon->food.source->audiocast.bitrate = atoi (arg);
			break;
		case 'p':
			sourcecon->food.source->audiocast.public = atoi (arg);
			break;
		case 'P':
			sourcecon->food.source->priority = atoi (arg);
			break;
		case 'd':
			nfree (sourcecon->food.source->audiocast.description);
			sourcecon->food.source->audiocast.description = nstrdup (arg);
			break;
		case 'g':
			nfree (sourcecon->food.source->audiocast.genre);
			sourcecon->food.source->audiocast.genre = nstrdup (arg);
			break;
		case 'n':
			nfree (sourcecon->food.source->audiocast.name);
			sourcecon->food.source->audiocast.name = nstrdup (arg);
			break;
		case 'u':
			nfree (sourcecon->food.source->audiocast.url);
			sourcecon->food.source->audiocast.url = nstrdup (arg);
			break;
		case 'm':
			nfree (sourcecon->food.source->audiocast.mount);
			sourcecon->food.source->audiocast.mount = nstrdup (arg);
			break;
		default:
			sock_write (con->sock, MODIFY_USAGE);
			return 0;
	}
	sock_write_line (con->sock, "Value changed to [%s]", arg);
	return 1;
}

void show_lock_status (connection_t *con, char *name, mutex_t *mutex)
{
	sock_write_line (con->sock, "Mutex: [%s] Status: [%s] Thread: [%d]", name, mutex->thread_id >= 0 ? "locked" : "unlocked", mutex->thread_id);
}

int com_locks(connection_t *con, char *arg)
{
#ifdef OPTIMIZE
  sock_write_line (con->sock, "Server is compiled with optimization, no mutex information available");
  return 1;
#endif
  show_lock_status(con, "source mutex", &info.source_mutex);
  show_lock_status(con, "admin mutex", &info.admin_mutex);
  show_lock_status(con, "directory mutex", &info.directory_mutex);
  show_lock_status(con, "alias mutex", &info.alias_mutex);
  show_lock_status(con, "misc mutex", &info.misc_mutex);
  show_lock_status(con, "mount mutex", &info.mount_mutex);
  show_lock_status(con, "hostname mutex", &info.hostname_mutex);
  show_lock_status(con, "acl mutex", &info.acl_mutex);
  show_lock_status(con, "double mutex", &info.double_mutex);

  return 1;
}

int
com_ping (connection_t *con, char *arg)
{
	return 1;
}

#define DEBUGSYNTAX "debug <level>\r\n"

int
com_debug (connection_t *con, char *arg)
{
	if (!arg)
	{
		sock_write_line (con->sock, "Your debugging level is [%d]", con->food.admin->debuglevel);
		return 1;
	}

	con->food.admin->debuglevel = atoi (arg);
	
	sock_write_line (con->sock, "Your debugging level is now [%d]", con->food.admin->debuglevel);
	return 0;
}
	       
#define AUTHSYNTAX "auth <groups|users|mounts>\r\n"

int
com_auth (connection_t *con, char *arg)
{
	if (!arg || !arg[0])
	{
		sock_write (con->sock, AUTHSYNTAX);
		return 0;
	}
	
	rehash_authentication_scheme ();

	if (strcmp (arg, "users") == 0)
		con_display_users (con);
	else if (strcmp (arg, "groups") == 0)
		con_display_groups (con);
	else if (strcmp (arg, "mounts") == 0)
		con_display_mounts (con);
	else
		sock_write (con->sock, AUTHSYNTAX);
	return 1;
}

int
com_mem (connection_t *con, char *arg)
{
#ifndef MEMORY_DEBUG
	sock_write_line (con->sock, "No memory debug information available in this binary");
	return 1;
#else
	avl_traverser trav = {0};
	meminfo_t *go;
	char *freeme = NULL;

	unsigned long int totalbytes = 0;

	thread_mutex_lock (&info.memory_mutex);

	while ((go = avl_traverse (info.mem, &trav)))
	{
		sock_write (con->sock, "[%d bytes]\t[%p]\t[%d:%10s]\tthread: [%d]\ttime: %s", go->size, go->ptr, go->line, go->file, go->thread_id, freeme = get_string_time (go->time, REGULAR_TIME));
		totalbytes += go->size;
		if (freeme != NULL)
			free (freeme);
	}

	sock_write_line (con->sock, "Total bytes allocated: %u", totalbytes);

	thread_mutex_unlock (&info.memory_mutex);

	return 1;
#endif
}	

#define STREAMTITLE_SYNTAX "streamtitle <-a|source_id> <message>\r\n"

int
com_streamtitle (connection_t *con, char *arg)
{
	int all = 0;
	char id[BUFSIZE];
	char *ptr;
	avl_traverser trav = {0};
	connection_t *sourcecon = NULL;

	if (!arg || !arg[0])
	{
		sock_write (con->sock, STREAMTITLE_SYNTAX);
		return 0;
	}

	if (arg[0] == '-')
	{
		if (arg[1] == 'a')
			all = 1;
		splitc (NULL, arg, ' ');
	}

	if ((all == 0) && (splitc (id, arg, ' ') == NULL))
	{
		sock_write (con->sock, STREAMTITLE_SYNTAX);
		return 0;
	}

	if (all)
	{
		thread_mutex_lock (&info.source_mutex);
		
		while ((sourcecon = avl_traverse (info.sources, &trav)))
		{
			ptr = sourcecon->food.source->streamtitle;
			sourcecon->food.source->streamtitle = nstrdup (arg);
			nfree (ptr);
		}

		thread_mutex_unlock (&info.source_mutex);
		sock_write_line (con->sock, "Set all source titles to %s", arg);

	} else {
		sourcecon = find_source_with_id (atoi (id));

		if (sourcecon)
		{
			ptr = sourcecon->food.source->streamtitle;
			sourcecon->food.source->streamtitle = nstrdup (arg);
			nfree (ptr);
		} else {
			sock_write_line (con->sock, "No source with id %d", atoi (id));
			return 0;
		}
		sock_write_line (con->sock, "Set source title for source %d to %s", atoi (id), arg);
	}
	return 1;
}

#define STREAMURL_SYNTAX "streamurl [-a] <url>\r\n"
int
com_streamurl (connection_t *con, char *arg)
{
	int all = 0;
	char id[BUFSIZE];
	char *ptr;
	avl_traverser trav = {0};
	connection_t *sourcecon;

	if (!arg || !arg[0])
	{
		sock_write (con->sock, STREAMURL_SYNTAX);
		return 0;
	}

	if (arg[0] == '-')
	{
		if (arg[1] == 'a')
			all = 1;
		splitc (NULL, arg, ' ');
	}

	if ((all == 0) && (splitc (id, arg, ' ') == NULL))
	{
		sock_write (con->sock, STREAMURL_SYNTAX);
		return 0;
	}

	if (all)
	{
		thread_mutex_lock (&info.source_mutex);
		
		while ((sourcecon = avl_traverse (info.sources, &trav)))
		{
			ptr = sourcecon->food.source->streamurl;
			sourcecon->food.source->streamurl = nstrdup (arg);
			nfree (ptr);
		}

		thread_mutex_unlock (&info.source_mutex);
		sock_write_line (con->sock, "Set all source urls to %s", arg);

	} else {
		sourcecon = find_source_with_id (atoi (id));

		if (sourcecon)
		{
			ptr = sourcecon->food.source->streamurl;
			sourcecon->food.source->streamurl = nstrdup (arg);
			nfree (ptr);
		} else {
			sock_write_line (con->sock, "No source with id %d", atoi (id));
			return 0;
		}
		sock_write_line (con->sock, "Set source url for source %d to %s", atoi (id), arg);
	}
	return 1;
}

#define DESCRIBE_SYNTAX "describe <id>\r\n"
int
com_describe (connection_t *con, char *arg)
{
	int id;
	connection_t *idcon;

	if (!con)
		return 0;
	else if (!arg || !arg[0])
	{
		sock_write_line (con->sock, DESCRIBE_SYNTAX);
		return 0;
	}

	id = atoi (arg);
		
	idcon = find_id (id);

	if (!idcon)
	{
		sock_write_line (con->sock, "No connection found with id [%d]", id);
		return 0;
	}

	switch (idcon->type)
	{
		case client_e:
			describe_client (con, idcon);
			break;
		case source_e:
			describe_source (con, idcon);
			break;
		case admin_e:
			describe_admin (con, idcon);
			break;
		default:
			sock_write_line (con->sock, "Unknown connection type on connection id [%d]", id);
			break;
	}
	return 1;
}


