/* group.c
 * - group authentication file stuff
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#ifndef __USE_BSD
#define __USE_BSD
#endif
#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif

#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <stdlib.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#ifdef _WIN32
#define strcasecmp stricmp
#else
#include <sys/socket.h>
#endif

#include "avl.h"
#include "threads.h"
#include "icetypes.h"
#include "icecast.h"
#include "utility.h"
#include "ice_string.h"
#include "connection.h"
#include "log.h"
#include "sock.h"
#include "avl_functions.h"
#include "restrict.h"
#include "match.h"
#include "memory.h"
#include "basic.h"
#include "group.h"
#include "user.h"

extern server_info_t info;

extern mutex_t authentication_mutex;
extern mounttree_t *mounttree;
extern usertree_t *usertree;
extern grouptree_t *grouptree;

void
parse_group_authentication_file ()
{
	int fd;
	char *groupfile = get_icecast_file (info.groupfile, "etc", R_OK);
	group_t *group;
	char line[BUFSIZE];

	if (!groupfile || ((fd = open_for_reading (groupfile)) == -1))
	{
		if (groupfile)
			nfree (groupfile);
		xa_debug (1, "WARNING: Could not open group authentication file");
		return;
	}

	while (fd_read_line (fd, line, BUFSIZE))
	{
		if (line[0] == '#' || line[0] == ' ')
			continue;

		group = create_group_from_line (line);

		if (group)
			add_authentication_group (group);
	}

	if (groupfile)
		nfree (groupfile);
	fd_close (fd);
}

group_t *
create_group_from_line (char *line)
{
	group_t *group;
	user_t *user;
	char name[BUFSIZE], cuser[BUFSIZE];
	int go_on = 1;

	if (!line)
	{
		xa_debug (1, "WARNING: create_group_from_line() called with NULL pointer");
		return NULL;
	}

	if (!splitc (name, line, ':'))
	{
		xa_debug (1, "ERROR: Syntax error in group file, with line [%s]", line);
		return NULL;
	}

	
	group = create_group ();
	
	group->name = nstrdup (name);

	do
	{
		if (!splitc (cuser, line, ','))
		{
			strcpy (cuser, line);
			go_on = 0;
		}

		user = find_user_from_tree (usertree, clean_string (cuser));
		
		if (!user)
		{
			write_log (LOG_DEFAULT, "WARNING: Unrecognized user [%s] specified for group [%s]", 
				   cuser, name);
		} else {
			avl_insert (group->usertree, user);
		}
	} while (go_on);
	
	return group;
}

group_t *
create_group ()
{
	group_t *group = (group_t *) nmalloc (sizeof (group_t));
	group->usertree = create_user_tree ();
	group->name = NULL;
	return group;
}

grouptree_t *
create_group_tree ()
{
	grouptree_t *gt = avl_create (compare_groups, &info);
	return gt;
}

void
add_authentication_group (group_t *group)
{
	group_t *out;
	
	if (!group || !grouptree || !group->name || !group->usertree)
	{
		xa_debug (1, "ERROR: add_authentication_group() called with NULL pointers");
		return;
	}
	
	out = avl_replace (grouptree, group);

	if (out)
	{
		write_log (LOG_DEFAULT, "WARNING: Duplicate group record %s, using latter", group->name);
		nfree (out->name);
		free_user_tree (out->usertree);
		nfree (out);
	}
	
	xa_debug (1, "DEBUG: add_authentication_group(): Inserted group [%s]", group->name);
}

void
free_group_tree (grouptree_t *gt)
{
	avl_traverser trav = {0};
	group_t *group, *out;

	if (!gt)
		return;

	while ((group = avl_traverse (gt, &trav)))
	{
		out = avl_delete (gt, group);
		
		if (!out)
		{
			xa_debug (1, "WARNING: Weird ass things going on in grouptree!");
			continue;
		}
		
		nfree (group->name);
		avl_destroy (group->usertree, NULL);
		nfree (group);
	}
}

int
is_member_of (char *user, group_t *group)
{
	user_t *up;
	user_t search;
	
	if (!user || !group || !group->usertree)
	{
		xa_debug (1, "WARNING: is_member_of() called with NULL pointers");
		return 0;
	}
	
	search.name = user;
	
	up = avl_find (group->usertree, &search);
	
	return up ? 1 : 0;
}

group_t *
find_group_from_tree (grouptree_t *gt, char *name)
{
	const group_t search = {name};

	if (!gt || !name)
	{
		xa_debug (1, "WARNING: find_group_from_tree() called with NULL pointers");
		return NULL;
	}

	return avl_find (gt, &search);
}

void
con_display_groups (connection_t *con)
{
	avl_traverser trav = {0};
	avl_traverser usertrav = {0};
	group_t *group;
	user_t *user;

	thread_mutex_lock (&authentication_mutex);

	while ((group = avl_traverse (grouptree, &trav)))
	{
		zero_trav (&usertrav);

		sock_write (con->sock, "%s: ", group->name ? group->name : "(null)");
		
		while ((user = avl_traverse (group->usertree, &usertrav)))
			sock_write (con->sock, "%s ", user->name);
		sock_write_line (con->sock, "");
	}
	
	thread_mutex_unlock (&authentication_mutex);
}


