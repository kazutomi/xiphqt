/* user.h
 * - Function definitions for user.c
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

void parse_user_authentication_file ();
user_t *create_user_from_line (char *line);
user_t *create_user ();
void add_authentication_user (user_t *user);
usertree_t *create_user_tree ();
void free_user_tree (usertree_t *ut);
int user_authenticate (char *cuser, const char *password);
user_t *find_user_from_tree (usertree_t *ut, char *name);
user_t *con_get_user (connection_t *con, user_t *outuser);
void con_display_users (connection_t *con);
