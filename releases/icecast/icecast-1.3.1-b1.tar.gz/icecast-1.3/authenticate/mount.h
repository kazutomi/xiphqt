/* mount.h
 * - Function definitions for mount.c
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

void parse_mount_authentication_file ();
mount_t *create_mount_from_line (char *line);
mount_t *create_mount ();
mounttree_t *create_mount_tree ();
void add_authentication_mount (mount_t *mount);
void free_mount_tree (mounttree_t *mt);
grouptree_t *get_grouptree_for_mount (char *mountname);
void con_display_mounts (connection_t *con);
