/* restrict.c
 * - Functions to play with the acl lists
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#ifndef __USE_BSD
#define __USE_BSD
#endif
#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif

#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <stdlib.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#ifdef _WIN32
#define strcasecmp stricmp
#else
#include <sys/socket.h>
#endif

#include "avl.h"
#include "threads.h"
#include "icetypes.h"
#include "icecast.h"
#include "utility.h"
#include "ice_string.h"
#include "connection.h"
#include "log.h"
#include "sock.h"
#include "avl_functions.h"
#include "restrict.h"
#include "match.h"
#include "memory.h"

extern server_info_t info;

void
list_rule (connection_t *con, restrict_t *res)
{
	sock_write_line (con->sock, "%d\t%s\t[%s]", res->id, res->type ? "allow": "deny",  res->mask);
}

void
list_restrict (connection_t *con, avl_tree *tree, acltype_t type)
{
	avl_traverser trav = {0};
	restrict_t *res;

	thread_mutex_lock (&info.acl_mutex);
	while ((res = avl_traverse (tree, &trav)))
		if ( (type == all) || (res->type == type) )
			list_rule (con, res);
	thread_mutex_unlock (&info.acl_mutex);
}

void
list_acl_control (connection_t *con, acl_control_t *acl, acltype_t type)
{
	thread_mutex_lock (&info.acl_mutex);

	switch(type) {
		case deny:
			sock_write (con->sock, "Listing deny rules");
			break;
		case allow:
			sock_write (con->sock, "Listing allow rules");
			break;
		case all:
		default:	
			sock_write (con->sock, "Listing all control rules (%d)", avl_count(acl->all));
	}
	list_restrict (con, acl->all, type);

	thread_mutex_unlock (&info.acl_mutex);
}

void
list_all_acls (connection_t *con)
{
	sock_write_line (con->sock, "Rules affecting all connections:");
	list_acl_control (con, &info.all_acl, all);
	
	sock_write_line (con->sock, "Rules affecting admin connections:");
	list_acl_control (con, &info.admin_acl, all);

	sock_write_line (con->sock, "Rules affecting source connections:");
	list_acl_control (con, &info.source_acl, all);

	sock_write_line (con->sock, "Rules affecting client connections:");
	list_acl_control (con, &info.client_acl, all);
}

restrict_t *
create_restrict ()
{
	restrict_t *res = (restrict_t *) nmalloc (sizeof (restrict_t));
	return res;
}

restrict_t *
add_restrict (avl_tree *tree, char *mask, acltype_t type)
{
	restrict_t *res, *out;

	if (!mask || !mask[0])
		return NULL;

	res = create_restrict ();
	res->mask = nstrdup (mask);
	res->id = avl_count (tree);
	res->type = type;

	thread_mutex_lock (&info.acl_mutex);

	out = avl_replace (tree, res);

	thread_mutex_unlock (&info.acl_mutex);

	if (out)
	{
		nfree (out->mask);
		nfree (out);
	}

	return res;
}
			
int
del_restrict (avl_tree *tree, char *name, acltype_t type)
{
	avl_traverser trav = {0};

	restrict_t *res = NULL, *out;

	if (is_pattern (name))
	{
		thread_mutex_lock (&info.acl_mutex);

		while ((res = avl_traverse (tree, &trav)))
		{
			if ((strcasecmp (res->mask, name) == 0) && (type == res->type)) 
				break;
		}
	} else if (is_number (name)) {
		restrict_t search;

		search.id = atoi (name);

		thread_mutex_lock (&info.acl_mutex);

		res = avl_find (tree, &search);
	}

	if (res)
	{
		out = avl_delete (tree, res);
		if (out)
		{
			nfree (out->mask);
			nfree (out);
			thread_mutex_unlock (&info.acl_mutex);
			return 1;
		}
	}
	thread_mutex_unlock (&info.acl_mutex);
	return 0;
}

/* 0 for "Not allowed, 1 for "allowed", -1 for not decided */
int
allowed (connection_t *con, contype_t contype)
{
	int result;

	thread_mutex_lock (&info.acl_mutex);

	result = restrict_list (con, get_acl_list (contype));

	if (result != -1)
	{
		thread_mutex_unlock (&info.acl_mutex);
		return result ? 1 : 0;
	}

	thread_mutex_unlock (&info.acl_mutex);
	return info.policy;
}

acl_control_t *
get_acl_list (contype_t contype)
{
	switch (contype)
	{
		case client_e:
			return &info.client_acl;
			break;
		case source_e:
			return &info.source_acl;
			break;
		case admin_e:
			return &info.admin_acl;
			break;
		default:
			return &info.all_acl;
			break;
	}
}

int
restrict_list (connection_t *con, acl_control_t *list)
{
	avl_traverser trav = {0};
	restrict_t *res;
	
	/* First, we want to find him */
	while ((res = avl_traverse (list->all, &trav)))
	{
		if (wild_match ((unsigned char *)res->mask, (unsigned char *)con->host) 
		    || (con->hostname && wild_match ((unsigned char *)res->mask, (unsigned char *)con->hostname)))
			return res->type;
	}
	
	return -1;
}

void
free_acl_list (acl_control_t *list)
{
	restrict_t *res, *out;

	while ((res = avl_get_any_node (list->all)))
	{
		out = avl_delete (list->all, res);
		if (out)
		{
			nfree (out->mask);
			nfree (out);
		}
	}
}

void
free_acl_lists ()
{
	thread_mutex_lock (&info.acl_mutex);

	free_acl_list (get_acl_list (client_e));
	free_acl_list (get_acl_list (source_e));
	free_acl_list (get_acl_list (admin_e));
	free_acl_list (get_acl_list (unknown_connection_e));

	thread_mutex_unlock (&info.acl_mutex);
}	



