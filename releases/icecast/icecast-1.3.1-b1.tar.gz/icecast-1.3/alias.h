void list_aliases (connection_t *admcon);
alias_t *create_alias ();
alias_t *add_alias (request_t *name, request_t *real);
request_t *get_alias (request_t *req);
int del_alias (char *name);
void remove_alias (alias_t *alias);
void free_aliases ();
