#ifndef ICECAST_RESTRICT_H
#define ICECAST_RESTRICT_H

void list_rule (connection_t *con, restrict_t *res);
void list_restrict (connection_t *con, avl_tree *tree, acltype_t type);
void list_acl_control (connection_t *con, acl_control_t *acl, acltype_t type);
void list_all_acls (connection_t *con);
restrict_t *create_restrict ();
restrict_t *add_restrict (avl_tree *tree, char *mask, acltype_t type);
int del_restrict (avl_tree *tree, char *name, acltype_t type);
int allowed (connection_t *con, contype_t contype);
acl_control_t *get_acl_list (contype_t contype);
int restrict_list (connection_t *con, acl_control_t *list);
void free_acl_lists ();
#endif
