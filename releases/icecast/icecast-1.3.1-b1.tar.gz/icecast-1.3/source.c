/* source.c
 * - Source functions
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
# ifndef __USE_BSD
#  define __USE_BSD
# endif
#include <string.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <sys/types.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>

#ifndef _WIN32
#include <sys/socket.h> 
#include <sys/wait.h>
#else
#include <io.h>
#include <winsock.h>
#define write _write
#define read _read
#define close _close
#define strcasecmp stricmp
#endif

#include "avl.h"
#include "threads.h"
#include "icetypes.h"
#include "icecast.h"
#include "utility.h"
#include "ice_string.h"
#include "source.h"
#include "sock.h"
#include "log.h"
#include "connection.h"
#include "avl_functions.h"
#include "main.h"
#include "timer.h"
#include "alias.h"
#include "relay.h"
#include "client.h"
#include "commands.h"
#include "restrict.h"
#include "memory.h"
#include "http.h"

extern int running;

void
source_login (connection_t *con, char *expr)
{
	char line[BUFSIZE], command[BUFSIZE], arg[BUFSIZE];
	char pass[BUFSIZE] ="";
	int go_on = 2;
	int connected = 1;
	int password_accepted = 0;
	source_t *source;
	char *res;

	/* Normally, the type here is set to unknown,
	   and it's this function's job to set it
	   to encoder_e. But if we're called from
	   relay_pull, then that function has already
	   set the connection type to source_e, and
	   the source type to puller_e. In that case
	   we should neither change that, nor 
	   mess with put_source (); 
	   Also, a relay pull connection will not print
	   the SOURCE password /mount line, so we will only
	   get _one_ \n\n sequence, that's why we set go_on 
	   to 1. To get the mountname, the relay uses
	   the x-audiocast-mount. */
	if (con->type == unknown_connection_e)
	{
		if (info.throttle_on)
		{
			sock_write (con->sock, "HTTP/1.0 406 Not Acceptable (Bandwidth usage too high)");
			kick_connection (con, "Bandwidth usage too high (throttling)");
			return;
		}
		put_source(con);
		con->food.source->type = encoder_e;
		xa_debug (2, "DEBUG: Encoder logging in with [%s]", expr);

	} else if (con->food.source->type == puller_e)
	{
		xa_debug (2, "DEBUG: Puller loggin in with [%s]", expr);
		go_on = 1; /* Dealing with relay pull (all headers are already present)*/
	} else {
		xa_debug (2,"DEBUG: Icy encoder logging in with [%s]", expr);
	}
	
#ifdef HAVE_LIBWRAP
	if ((con->food.source->type == encoder_e) && (!allowed (con, source_e) || !check_libwrap (con->sock, source_e)))
#else
	if ((con->food.source->type == encoder_e) && !allowed (con, source_e))
#endif
	{
		write_http_header (con->sock, 403, "Forbidden");
		kick_connection (con, "Access Denied (internal acl list (source connection))");
		return;
	}

	source = con->food.source;

	do {
		command[0] = '\0';
		arg[0] = '\0';

		if (splitc(line, expr, '\n') == NULL) {
			strncpy (line, expr, BUFSIZE);
			go_on = go_on - 1;

			if (source->type == puller_e)
				go_on = 0;

			else if ((go_on > 0) && (!source->protocol == icy_e && source->type == encoder_e))
			{
				sock_read_lines_np (con->sock, expr, BUFSIZE);
			}
		}
		
		/* The delimiter on the first line is ' ', but on the following lines
		   we want the part after the colon */
		if (go_on == 2)
			res = splitc (command, line, ' ');
		else
			res = splitc (command, line, ':');
		
		if (!res)
		{
			strncpy (command, line, BUFSIZE);
			arg[0] = '\0';
		} else {
			strncpy (arg, line, BUFSIZE);
		}
		
		if (line[0])
			xa_debug (2, "DEBUG: Source line: [%s] [%s]", command, arg);

		/* The first line looks like this */
		if (strncmp(command, "SOURCE", 6) == 0)
		{
			if (splitc(pass, arg, ' ') == NULL) {
				sock_write_line (con->sock, "ERROR - Missing Mountpoint\r\n");
				kick_connection (con, "No Mountpoint supplied");
				connected = 0;
				return;
			}
			
			if (!password_match(info.encoder_pass, pass)) {
				sock_write_line (con->sock, "ERROR - Bad Password\r\n");
				kick_connection (con, "Bad Password");
				return;
			} else
				password_accepted = 1;
			
			if (!source->audiocast.mount)
				source->audiocast.mount = my_strdup(arg);

			{ /* Make sure it starts with / */
				char slash[BUFSIZE];
				if (source->audiocast.mount[0] != '/')
				{
					sprintf (slash, "/%s", source->audiocast.mount);
					nfree (source->audiocast.mount);
					source->audiocast.mount = my_strdup (slash);
				}
			}
			
			if (mount_exists (source->audiocast.mount) || (source->audiocast.mount[0] == '\0')) {
				sock_write_line (con->sock, "ERROR - Mount Point Taken or Invalid\r\n");
				kick_connection (con, "Invalid Mount Point");
				return;
				break;
			}

			if (source->protocol != icy_e)
				sock_write_line (con->sock, "OK");
			else if (source->type == encoder_e)
				go_on = 1;
		}
		
		else if (strncmp(command, "icy-name", 8) == 0)
		{
			if (!source->audiocast.name)
				source->audiocast.name = ice_sprintf (info.nametemplate, arg);
			if (!source->audiocast.description)
				source->audiocast.description = nstrdup ("Icy protocol in use");
		}

		else if (strncmp(command, "icy-genre", 9) == 0)
		{
			if (!source->audiocast.genre)
				source->audiocast.genre = my_strdup (arg);
		}

		else if (strncmp(command, "icy-url", 7) == 0)
		{
			if (!source->audiocast.url)
				source->audiocast.url = my_strdup (arg);
		}

		else if (strncmp(command, "icy-pub", 7) == 0)
			source->audiocast.public = atoi (arg);
		else if (strncmp(command, "icy-br", 6) == 0)
			source->audiocast.bitrate = atoi (arg);

		else if (strncmp(command, "x-audiocast-name", 16) == 0)
		{
			if (!source->audiocast.name)
				source->audiocast.name = ice_sprintf (info.nametemplate, arg);
		}

		else if (strncmp(command, "x-audiocast-description", 23) == 0)
		{
			if (!source->audiocast.description)
				source->audiocast.description = ice_sprintf (info.descriptiontemplate, arg);
		}

		else if (strncmp(command, "x-audiocast-url", 15) == 0)
		{
			if (!source->audiocast.url)
				source->audiocast.url = my_strdup (arg);
		}

		else if (strncmp(command, "x-audiocast-genre", 17) == 0)
		{
			if (!source->audiocast.genre)
				source->audiocast.genre = my_strdup (arg);
		}

		else if (strncmp(command, "x-audiocast-bitrate", 19) == 0)
			source->audiocast.bitrate = atoi (arg);
		else if (strncmp(command, "x-audiocast-public", 18) == 0)
			source->audiocast.public = atoi (arg);
		else if (strncmp(command, "x-audiocast-dumpfile", 20) == 0)
		{
			if (!source->dumpfile)
				source->dumpfile = my_strdup (arg);
		}

		else if (strncmp(command, "x-audiocast-mount", 17) == 0)
		{
			source->audiocast.mount = my_strdup (arg);
			if (arg[0] != '/')
			{
				char slash[BUFSIZE];
				sprintf (slash, "/%s", source->audiocast.mount);
				nfree (source->audiocast.mount);
				source->audiocast.mount = my_strdup (slash);
			}
		}

		else if (strncmp(command, "x-audiocast-directory", 21) == 0)
		{
			char host[BUFSIZE];
			relay_id_t *rid;

			if (avl_count (con->food.source->relay_tree) < info.max_directories)
			{
				if ((splitc (host, arg, ':') == NULL))
				{
					sock_write_line (con->sock, "ERROR - Invalid directory server specification");
					kick_connection (con, "Invalid directory server specification");
					return;
					break;
				}
				
				rid = (relay_id_t *) nmalloc (sizeof (relay_id_t));
				xa_debug (1, "DEBUG: Adding directory-server: [%s] with id [%s] for %d", host, arg, con->id);
				rid->host = my_strdup (host);
				rid->id = atoi (arg);
				avl_insert (con->food.source->relay_tree, rid);
			}
		}
		
	} while ((go_on > 0) && connected);
	
	/* Relay did not tell mountpoint */
	if (connected && source->audiocast.mount == NULL)
	{
		sock_write_line (con->sock, "ERROR - Mount Point Taken or Invalid\r\n");
		kick_connection (con, "Invalid Mount Point");
		return;
	}
		
	/* Make sure we got everything */
	if (connected)
	{
		if (!source->audiocast.name)
			source->audiocast.name = nstrdup ("");
		if (!source->audiocast.url)
			source->audiocast.url = nstrdup ("");
		if (!source->audiocast.genre)
			source->audiocast.genre = nstrdup ("");
		if (!source->audiocast.description)
			source->audiocast.description = nstrdup ("");
		if (source->audiocast.bitrate == -1)
			source->audiocast.bitrate = 128;
		if (source->audiocast.public == -1)
			source->audiocast.public = 0;
	}
	
	if (connected && !password_accepted && con->food.source->type != puller_e)
	{
		sock_write_line (con->sock, "Missing Password\r\n");
		kick_connection(con, "Missing Password");
		return;
	}
	    
	if (connected) {

		if (info.num_sources + 1> info.max_sources)
		{
			sock_write_line (con->sock, "ERROR - Too many sources\r\n");
			kick_connection (con, "Server Full (too many streams)");
			return;
		}

		add_source ();

		if (!con->food.source->type == puller_e)
			sock_write_line (con->sock, "OK");

		source->connected = SOURCE_CONNECTED;
		source->streamtitle = nstrdup (info.streamtitle);
		source->streamurl = nstrdup (info.streamurl);

		write_log (LOG_DEFAULT, "Accepted encoder on mountpoint %s from %s. %d sources connected", 
			   source->audiocast.mount, con_host (con), info.num_sources);

		thread_mutex_lock(&info.source_mutex);
		avl_insert(info.sources, con);
		thread_mutex_unlock(&info.source_mutex);

		{
			connection_t *clicon, *scon = get_pending_mount (source->audiocast.mount);
			
			if (scon)
			{
				write_log (LOG_DEFAULT, "Assigning listeners from pending source %d", scon->id);
				while ((clicon = avl_get_any_node (scon->food.source->clients)))
					move_to (clicon, con);
				scon->food.source->connected = SOURCE_KILLED;
			}
		}
			
			
		if (con->food.source->type == puller_e)
		{
			thread_create ("Source Thread", source_func, (void *)con);
			return;
		} else
			source_func (con);
	}
	thread_exit(0);
}

/* This function is started as a new thread for every connected
   and accepted source.
   A lot can be said about termination of this thread.
   Either it gets killed by another thread, using the kick_connection (thiscon,..), 
   which should set the connected value to SOURCE_KILLED, and let this thread
   exit on it's on with the close_connection at the end.
   Or it kills itself, when the encoder dies, and then it should call kick_connection (thiscon,..),
   on itself, setting the value of connected to SOURCE_KILLED, and exit through close_connection () */
void *
source_func(void *conarg)
{
	source_t *source;
	avl_traverser trav = {0};
	connection_t *clicon, *con = (connection_t *)conarg;
	client_t *client;

	source = con->food.source;
	con->food.source->thread = thread_self();
	init_thread();

	if (source->dumpfile) {
		source->dumpfd = open_for_writing (source->dumpfile);
		if (source->dumpfd == -1) {
			write_log (LOG_DEFAULT, "WARNING: Could not open dumpfile %s for source %d [%d]", source->dumpfile, con->id, errno);
			nfree(source->dumpfile);
			source->dumpfile = NULL;
		}
	}

	while (running && ((source->connected == SOURCE_CONNECTED) || (source->connected == SOURCE_PAUSED)))
	{
		add_chunk(con);
		
		if (source->connected == SOURCE_CONNECTED) {
			
			thread_mutex_lock(&source->mutex);
		
			while ((clicon = avl_traverse(source->clients, &trav)) != NULL) {

				client = (client_t *)clicon->food.client;

				if (source->connected == SOURCE_KILLED || source->connected == SOURCE_PAUSED)
					break;

				if (client->virgin == CLIENT_PAUSED)
					continue;

				if (client->virgin == CLIENT_UNPAUSED)
				{
					client->cid = source->cid > 0 ? source->cid - 1 : CHUNKLEN - 1;
					client->offset = find_frame_ofs (source);
					client->virgin = 0;
					client->errors = 0;
				}

				/* We haven't greeted this client yet */
				if (client->virgin == -1) 
					continue;

				if (client->virgin == 1) {
					client->cid = source->cid > 0 ? source->cid - 1 : CHUNKLEN - 1;
					client->offset = find_frame_ofs(source);
					client->virgin = 0;
					client->errors = 0;
					source->num_clients = source->num_clients + (unsigned long int)1;
				}
				
				write_chunk(source, clicon);
				
				if (source->connected == SOURCE_KILLED)
					break;
			}
			kick_dead_clients(source);
			thread_mutex_unlock(&source->mutex);
		}
	}
	
	thread_mutex_lock (&info.double_mutex);

	thread_mutex_lock (&info.source_mutex);
	thread_mutex_lock (&source->mutex);
	close_connection (con, &info);
	thread_mutex_unlock (&info.source_mutex);

	thread_mutex_unlock (&info.double_mutex);
	thread_exit (0);
	return NULL;
}

source_t *
create_source()
{
	source_t *source = (source_t *)nmalloc(sizeof(source_t));
	memset(source,0,sizeof(source_t));
	source->type = unknown_source_e;
	return source;
}

void 
put_source(connection_t *con)
{
	register int i;
	socklen_t sin_len;
	source_t *source = create_source();

	con->food.source = source;
	zero_stats (&source->stats);
	source->connected = SOURCE_UNUSED;
	source->type = unknown_source_e;
	thread_create_mutex(&source->mutex);
	source->dumpfile = NULL;
	source->dumpfd = -1;
	source->audiocast.name = NULL;
	source->audiocast.genre = NULL;
	source->audiocast.bitrate = -1;
	source->audiocast.url = NULL;
	source->audiocast.mount = NULL;
	source->audiocast.description = NULL;
	source->audiocast.public = -1;
	source->protocol = xaudiocast_e;
	source->cid = 0;
	source->clients = avl_create (compare_connection, &info);
	source->relay_tree = avl_create (compare_relays, &info);
	source->num_clients = 0;
	source->priority = 0;
	source->streamurl = NULL;
	source->streamtitle = NULL;
	for (i = 0; i < CHUNKLEN; i++)
	{
		source->chunk[i].clients_left = 0;
		source->chunk[i].len = 0;
	}
	sin_len = 1;
#ifdef SOCKET_OPERATIONS
	setsockopt(con->sock, SOL_SOCKET, SO_KEEPALIVE, (const void *)&sin_len, sizeof (sin_len));
#ifdef INCREASED_BUFFER
	getsockopt(con->sock, SOL_SOCKET, SO_SNDBUF, (void *) &before, &before_len);
	sin_len = 100000;
	setsockopt(con->sock, SOL_SOCKET, SO_SNDBUF, (const void *)&sin_len, sizeof (sin_len));
#ifdef DEBUG_SOCKET
	write_log(LOG_DEFAULT, "Changed source socket buffer from %d to %d", before, sin_len);
#endif
#endif
#endif
	con->type = source_e;
}

void
add_source ()
{
	info.num_sources++;
	info.hourly_stats.source_connections++;
}

void
del_source ()
{
	info.num_sources--;
}

void
insert_client (source_t *source, connection_t *clicon)
{
	if (!clicon || !source)
	{
		write_log (LOG_DEFAULT, "WARNING!!!! - Inserting NULL client!");
		clean_shutdown (&info);
	}
	avl_insert (source->clients, clicon);
	clicon->food.client->source = source;
}

connection_t *
find_mount_with_req (request_t *req)
{
	char pathbuf[BUFSIZE] = "";

	connection_t *con;
	request_t *alias;
	request_t search;

	int true = 0;

	avl_traverser trav = {0};
	
	if (!req || !req->path || !req->host)
	{
		write_log (LOG_DEFAULT, "WARNING: find_mount_with_req called with NULL request!");
		return NULL;
	}

	if (strcmp (req->path, "/list.cgi") == 0)
		return (connection_t *) &info;

	xa_debug (1, "DEBUG: Looking for [%s] on host [%s] on port %d", req->path, req->host, req->port);
	xa_debug (1, "DEBUG: Searching local aliases");

	/* We only want one thread traversing this at a time.. otherwize we will be in trouble
	   when using transparent proxies and relay pulls */
	thread_mutex_lock (&info.mount_mutex);

	/* First look for aliases */
	alias = get_alias (req);
	
	if (alias && hostname_local (req->host) && hostname_local (alias->host))
	{
		xa_debug (1, "DEBUG: Found alias [%s:%d%s] -> [%s:%d%s]", req->host, req->port, req->path,
			   alias->host, alias->port, alias->path);
		thread_mutex_unlock (&info.mount_mutex);
		return find_mount_with_req (alias);
	}

	xa_debug (1, "DEBUG: Search local mount points");

	sprintf (pathbuf, "%s:%d%s", req->host[0] ? req->host : "localhost", req->port, req->path);

	/* Now search for local mounts */
	thread_mutex_lock (&info.source_mutex);
	
	while ((con = avl_traverse(info.sources, &trav)) != NULL) 
	{
		true = 0; /* Sorry about this.. damn we've got many ugly cases */

		xa_debug (2, "DEBUG: Looking on mount [%s]", con->food.source->audiocast.mount);

		zero_request (&search);

		generate_http_request (con->food.source->audiocast.mount, &search);
		
		if (search.path[0] && (strcasecmp (search.host, req->host) == 0) && (search.port == req->port) && (strcmp (search.path, req->path) == 0))
			true = 1;

		else if (con->food.source->audiocast.mount[0] == '/')  /* regular mount */
		{
			if ((strcmp (con->food.source->audiocast.mount, pathbuf) == 0) || 
			    (hostname_local (req->host) && (strcmp (con->food.source->audiocast.mount, req->path) == 0)))
				true = 1;
		} else {
			if ((strcmp (con->food.source->audiocast.mount, pathbuf + 1) == 0) ||
			    (hostname_local (req->host) && (strcmp (con->food.source->audiocast.mount, req->path + 1) == 0)))
				true = 1;
		}
		
		if (true)
		{
			thread_mutex_unlock (&info.source_mutex);
			thread_mutex_unlock (&info.mount_mutex);
			xa_debug (1, "DEBUG: Found local mount for [%s]", req->path);
			return con;
		} 
	}
	
	thread_mutex_unlock (&info.source_mutex);
	
	xa_debug (1, "DEBUG: Searching remote aliases");

	/* Time for on demand relays */
	alias = get_alias (req);

	if (alias)
	{
		connection_t *sourcecon; 
		xa_debug (1, "DEBUG: Found alias [%s:%d%s] -> [%s:%d%s]", req->host, req->port, req->path,
			  alias->host, alias->port, alias->path);
		thread_mutex_unlock (&info.mount_mutex);
		sourcecon = find_mount_with_req (alias);
		if (!sourcecon) /* No trans */
		{
			if ((sourcecon = relay_pull_stream (alias)))
			{
				write_log (LOG_DEFAULT, "Found [%s:%d%s] -> [%s:%d%s], pulling relay", req->host, req->port, req->path,
					   alias->host, alias->port, alias->path);
				sourcecon->food.source->type = on_demand_pull_e;
				thread_mutex_unlock (&info.mount_mutex);
				return sourcecon;
			} else {
				write_log (LOG_DEFAULT, "On demand relay for [%s:%d%s] -> [%s:%d%s] failed, damn!", req->host, req->port, req->path,
					   alias->host, alias->port, alias->path);
				thread_mutex_unlock (&info.mount_mutex);
				return NULL;
			}
		} else {
			return sourcecon;
		}
	}

	if (info.transparent_proxy && !hostname_local (req->host))
	{
		connection_t *sourcecon;
		xa_debug (1, "DEBUG: Trying transparent proxy with host: [%s]", req->host);
		if ((sourcecon = relay_pull_stream (req)))
		{
			sourcecon->food.source->type = on_demand_pull_e;
			thread_mutex_unlock (&info.mount_mutex);
			return sourcecon;
		} else {
			write_log (LOG_DEFAULT, "Transparent proxy relay for [%s:%d%s] failed", req->host, req->port, req->path);
			thread_mutex_unlock (&info.mount_mutex);
			return NULL;
		}
	}

	thread_mutex_unlock (&info.mount_mutex);
	return NULL;
}

/* Just return the first source, or NULL if no sources are connected */
connection_t *
get_default_mount()
{
	avl_traverser trav = {0};
	connection_t *con, *max = NULL;

	thread_mutex_lock (&info.source_mutex);
	
	while ((con = avl_traverse(info.sources, &trav)))
	{
		if (con->food.source->connected == SOURCE_CONNECTED)
		{
			if (!max || con->food.source->priority > max->food.source->priority)
				max = con;
		}
	}
	
	thread_mutex_unlock (&info.source_mutex);
	
	return max;
}

void
add_chunk (connection_t *con)
{
	int read_bytes;
	int len;
	if (con->food.source->chunk[con->food.source->cid].clients_left > 0)
	{
#ifndef OPTIMIZE
		xa_debug (2, "DEBUG: Kicking trailing clients [%d] on id %d", con->food.source->chunk[con->food.source->cid].clients_left, 
			con->food.source->cid);
#endif
		thread_mutex_lock (&con->food.source->mutex);
		kick_clients_on_cid (con->food.source);
		thread_mutex_unlock (&con->food.source->mutex);
	}
	
	len = 0;
	read_bytes = 0;
	do {
		len = recv (con->sock, con->food.source->chunk[con->food.source->cid].data + read_bytes, BUFSIZE - read_bytes, 0);
		
		if (con->food.source->connected == SOURCE_KILLED)
			return;
		
		if (len <= 0) 
		{
			if (info.client_timeout > 0 && con->food.source->connected != SOURCE_KILLED)
			{
				/* Set this source as pending (not connected) */
				pending_connection (con);
				
				/* Sleep for client_timeout seconds. If during that time this source is set to
				SOURCE_KILLED, return false */
				if (pending_source_signoff (con))
				{
					thread_mutex_lock (&con->food.source->mutex);
					move_clients_to_default_mount (con);
					kick_connection (con, "Client timeout exceeded, removing source");
					thread_mutex_unlock (&con->food.source->mutex);
					return;
				} else {
					/* Someone has stolen all our clients, let's just die */
					thread_mutex_lock (&con->food.source->mutex);
					kick_connection (con, "Lost all clients to new source");
					thread_mutex_unlock (&con->food.source->mutex);
					return;
				}
			} else {
				/* This is where the current thread kills itself off, probably because 
				   the encoder signed off. */
				thread_mutex_lock (&con->food.source->mutex);
				write_log (LOG_DEFAULT, "Source %s signed off, moving clients to default mount", con->food.source->audiocast.mount);
				
				if (!info.kick_clients)
					move_clients_to_default_mount (con);
				kick_connection (con, "Source signed off (killed itself)");
				thread_mutex_unlock (&con->food.source->mutex);
				return;
			}
		} else {
			read_bytes += len;
			stat_add_read (&con->food.source->stats, len);
			info.hourly_stats.read_bytes += len;
		}
	} while (read_bytes < (BUFSIZE*3)/4); /* buffer some up! */
	
	
	thread_mutex_lock (&con->food.source->mutex);
	/* Dumpfile */
	if (con->food.source->dumpfile && con->food.source->dumpfd != -1)
	{
		errno = 0;
		if (write(con->food.source->dumpfd, con->food.source->chunk[con->food.source->cid].data, read_bytes) <= 0)	{
			write_log(LOG_DEFAULT, "Writing to dumpfile %s for source %d failed [%d] (closing file)", con->food.source->dumpfile, con->id, errno);
			fd_close(con->food.source->dumpfd);
			nfree(con->food.source->dumpfile);
			con->food.source->dumpfile = NULL;
			con->food.source->dumpfd = -1;
		}
	}
	thread_mutex_unlock (&con->food.source->mutex);
	
	con->food.source->chunk[con->food.source->cid].len = read_bytes;
	con->food.source->chunk[con->food.source->cid].clients_left = con->food.source->num_clients;
	con->food.source->cid = (con->food.source->cid + 1) % CHUNKLEN;
#ifndef OPTIMIZE
	xa_debug (3, "-------add_chunk: Chunk was [%d] bytes", read_bytes );
#endif
}

/* Don't even try understanding this.. it's probably a waste of time */
void 
write_chunk(source_t *source, connection_t *clicon)
{
	int i = 0, num_complete_writes = 0, write_meta_at = -1;
	long int write_bytes = 0, len = 0, next_meta;

	/* send until we cant */
	for (i = 0; i < 9; i++)
	{
		/* 
		 * There might be pending metadata from the previous write_chunk () 
		 * Which really has to get sent.. so let's try up to 9 times now, 
		 * and go on next time if needed.
		 * Note that the metadata is rather small, so resends are rather uncommon
		 */
		if (clicon->food.client->metadatalen > 0 && (clicon->food.client->metadatalen > clicon->food.client->metadataoffset))
		{
			write_bytes = finish_meta_frame (clicon);
			if (write_bytes == -1)
				break;
			continue; /* Don't count the metadata */
		}
		
		if (source->cid == clicon->food.client->cid) /* No more data available */
			break;

		/* This is how much we should be writing to the client */
		len = source->chunk[clicon->food.client->cid].len - clicon->food.client->offset;
		if (len <= 0)
		{
#ifndef OPTIMIZE
			xa_debug (2, "DEBUG: write_chunk: Empty chunk [%d] [%d]", source->chunk[clicon->food.client->cid].len,
				  clicon->food.client->offset );
#endif
			continue; /* Perhaps for some reason the source read a zero sized chunk but the next one is ok.. */
		}

		if (clicon->food.client->use_icy_metadata)
		{
			write_meta_at = -1;

			next_meta = ((info.metainterval) * (((clicon->food.client->write_bytes) / info.metainterval) + 1));

			if (clicon->food.client->write_bytes + len > next_meta)
				write_meta_at = next_meta - clicon->food.client->write_bytes;
			
#ifndef OPTIMIZE
			xa_debug (2, "DEBUG: wc: Writebytes == %u. Will write %u bytes, with meta at %u, after %d bytes", clicon->food.client->write_bytes, len, next_meta, 
				  write_meta_at);
#endif
		} else {
			write_meta_at = -1;
		}
		
		/* If we're switching sources (virgin == 2), finish exactly one frame */
		if (clicon->food.client->virgin == 2)
		{
			move_client (clicon, source, write_meta_at);
			return;
		}
		
		if (write_meta_at != -1 && info.use_meta_data)
			write_bytes = write_data_meta_data (clicon, source, len, write_meta_at);
		else
			write_bytes = write_data (clicon, source);

		if (write_bytes < 0)
		{
#ifndef OPTIMIZE
			xa_debug (3, "  --------err[%2d] [%3d] [%3d]",clicon->id, num_complete_writes ,clicon->food.client->errors);
#endif
			break; /* Safe to assume that the client is kicked out due to socket error */
		}

		clicon->food.client->write_bytes += write_bytes;
		info.hourly_stats.write_bytes += write_bytes;
		stat_add_write (&source->stats, write_bytes);
		
		if (write_bytes + clicon->food.client->offset >= source->chunk[clicon->food.client->cid].len) {
			source->chunk[clicon->food.client->cid].clients_left--;
			if (source->chunk[clicon->food.client->cid].len > 0)
			    num_complete_writes++;
			clicon->food.client->cid = (clicon->food.client->cid + 1) % CHUNKLEN;
			clicon->food.client->offset = 0;
		} else {
	
			clicon->food.client->offset += write_bytes;
#ifndef OPTIMIZE
			xa_debug (3, "  ---onlyread[%2d] [%3d] [%3d]",clicon->id, write_bytes, 
				  source->chunk[clicon->food.client->cid].len);
#endif
			break;
		}
		
	}

	if (clicon->food.client->alive == CLIENT_DEAD)
		return;
	
	if (num_complete_writes == 0) {
		clicon->food.client->errors += 1;
		if (clicon->food.client->errors >= CHUNKLEN) {
			kick_connection (clicon, "Too many errors");
			return;
		}
	} else if (num_complete_writes >= 2) {
		if (clicon->food.client->errors > 0)
			clicon->food.client->errors -= (num_complete_writes - 1);
		if (clicon->food.client->errors < 0)
			clicon->food.client->errors = 0;
	}
}
		
void kick_clients_on_cid(source_t *source)
{
	avl_traverser trav = {0};
	connection_t *clicon;

	xa_debug (2, "Clearing cid %d", source->cid);

	while (42)
	{
		clicon = avl_traverse (source->clients, &trav);
		if (!clicon)
			break;
		
		if (clicon->food.client->cid == source->cid && clicon->food.client->errors >= CHUNKLEN)
		{
			kick_connection (clicon, "Client cannot sustain sufficient bandwidth");
			zero_trav (&trav); /* Start from the top of the tree */
		}
	}
	source->chunk[source->cid].clients_left = 0;
}

/* 
 * Can't be removing clients inside the loop which handles all the
 * write_chunk()s, instead we kick all the dead ones for each chunk. 
 */
void 
kick_dead_clients(source_t *source)
{
	avl_traverser trav = {0};
	connection_t *clicon;

	while (42) {
		clicon = avl_traverse (source->clients, &trav);
		if (!clicon)
			break;

		if (clicon->food.client->alive == CLIENT_DEAD) {
			close_connection (clicon, &info);
			zero_trav (&trav);
		}
	}
}
			
void move_clients_to_default_mount(connection_t *con)
{
	connection_t *clicon, *default_source = get_default_mount ();

	/* This might look like a deadlock, but get_default_mount() can never return
	   this mountpoint since this one is PENDING.. still.. it doesn't hurt to check */
	if (con != default_source && default_source) {
		thread_mutex_lock(&default_source->food.source->mutex);
		while ((clicon = avl_get_any_node(con->food.source->clients)))
			move_to(clicon, default_source);
		thread_mutex_unlock(&default_source->food.source->mutex);
	}
}

int
originating_id (connection_t *sourcecon, char *dshost)
{
	avl_traverser trav = {0};
	relay_id_t *rip;

	if (!sourcecon || !dshost)
	{
		xa_debug (1, "WARNING: originating_id called with NULL pointers");
		return -1;
	}

	if (sourcecon->food.source->type == encoder_e)
	{
		xa_debug (2, "DEBUG: originating_id () return -1 cause type is encoder_e");
		return -1;
	}

	while ((rip = avl_traverse (sourcecon->food.source->relay_tree, &trav)))
	{
		if (!rip || !rip->host)
		{
			write_log (LOG_DEFAULT, "ERROR: Erroneous host in relay id");
			continue;
		}
		if (strcasecmp (dshost, rip->host) == 0)
		{
			xa_debug (2, "DEBUG: originating_id() returning %d, found hit", rip->id);
			return rip->id;
		}
	}

	xa_debug (2, "DEBUG: originating_id() for %s didn't match any hosts, returning -1", dshost);
	return -1;
}

int
write_meta_data (connection_t *clicon, source_t *source)
{
	unsigned char metabuf[MAXMETADATALENGTH];
	long int write_bytes, len;

	unsigned int bitrate = 16;

	if (source->streamtitle == clicon->food.client->streamtitle && source->streamurl == clicon->food.client->streamurl)
	{
		metabuf[1] = '\0';
		len = 0;
	} else {
		
		clicon->food.client->streamtitle = source->streamtitle;
		clicon->food.client->streamurl = source->streamurl;
		
		if (strlen (source->streamtitle) + strlen (source->streamurl) + 29 >= MAXMETADATALENGTH)
		{
			write_log (LOG_DEFAULT, "WARNING: Avoided buffer overrun in metadata. Metadata to long!");
			len = 0;
			metabuf[1] = '\0';
		} else {
			sprintf (&metabuf[1], "StreamTitle='%s';StreamUrl='%s';%c", source->streamtitle, source->streamurl, '\0');
			
			len = (1 + ((strlen ((char *) &metabuf[1]) + 1) / bitrate)) * bitrate;
		}
	}

	if (len == 0)
		metabuf[0] = (unsigned char) 0;
	else
		metabuf[0] = (unsigned char) (len / 16);
	
#ifndef OPTIMIZE
	xa_debug (2, "DEBUG: Sending metainfo [%s] %d + 1 bytes", &metabuf[1], len);
#endif

	write_bytes = sock_write_bytes_or_kick (clicon->sock, clicon, metabuf, len + 1);

#ifndef OPTIMIZE
	if (write_bytes < 0)
		xa_debug (1, "DEBUG: meta data write for [%s] failed failed", con_host (clicon));
	
	xa_debug (2, "DEBUG: Wrote %d bytes of meta info. %d bytes total", write_bytes, 
		  write_bytes + clicon->food.client->write_bytes);
#endif
	
	if (write_bytes < (len + 1))
	{
		memcpy (clicon->food.client->metadatatail, metabuf, MAXMETADATALENGTH);
		clicon->food.client->metadatalen = len + 1;
		clicon->food.client->metadataoffset = (write_bytes >= 0) ? write_bytes : 0;
#ifndef OPTIMIZE
		xa_debug (1, "DEBUG: Only wrote %d bytes of metadata to client [%s]", write_bytes, con_host (clicon));
#endif
		return 0;
	} else {
		clicon->food.client->metadatalen = 0;
		clicon->food.client->metadataoffset = 0;
	}
	
	if (write_bytes > 0)
	{
		info.hourly_stats.write_bytes += write_bytes;
		clicon->food.client->metadatawritten += write_bytes;
	}
	
	return 1;
}

/*
 * Finish sending the metadata to client.
 * Returns 0 if we should be called again and -1 if the client is kicked.
 * Assert Class: 3
 */
int
finish_meta_frame (connection_t *clicon)
{
	int len;
	int ok = 1;

#ifndef OPTIMIZE
	xa_debug (1, "DEBUG: Writing tail of %u bytes at offset %u", clicon->food.client->metadatalen, clicon->food.client->metadataoffset);
#endif
	
	if (clicon->food.client->metadataoffset >= clicon->food.client->metadatalen)
	{
#ifndef OPTIMIZE
		xa_debug (1, "DEBUG: finish_meta_frame() called without valid frame to send");
#endif
		return 1;
	}

	len = sock_write_bytes_or_kick (clicon->sock, clicon, &clicon->food.client->metadatatail[clicon->food.client->metadataoffset], 
					clicon->food.client->metadatalen - clicon->food.client->metadataoffset);
	if (len < 0) /* len == 0 would just mean we didn't write anything */
		return -1;
	
#ifndef OPTIMIZE
	xa_debug (1, "DEBUG: Wrote tail of %u bytes", len);
#endif
	
	if (len < (clicon->food.client->metadatalen - clicon->food.client->metadataoffset))
	{
		clicon->food.client->errors += 1;
		ok = 0;
		if (len > 0)
		{
			clicon->food.client->metadataoffset += len;
			info.hourly_stats.write_bytes += len;
		}
	} else {
		clicon->food.client->metadatalen = 0;
		clicon->food.client->metadataoffset = 0;
		clicon->food.client->errors -= 1;
		info.hourly_stats.write_bytes += len;
	}
	
	if (clicon->food.client->errors < 0)
		clicon->food.client->errors = 0;
	
	if (clicon->food.client->errors >= CHUNKLEN) {
		kick_connection (clicon, "Too many errors");
		return 0;
	}
	
	return ok;
}


void
move_client (connection_t *clicon, source_t *source, int meta_after)
{
	int olen = find_frame_ofs (source);
	int write_bytes;
	
	errno = 0;
	write_bytes = sock_write_bytes_or_kick (clicon->sock, clicon, &source->chunk[clicon->food.client->cid].data[clicon->food.client->offset], min (olen, meta_after));

	if (write_bytes < 0)
		return; /* It's dead */
	
	if (write_bytes > 0)
	{
		clicon->food.client->write_bytes += write_bytes;
		info.hourly_stats.write_bytes += write_bytes;
		source->stats.write_bytes += write_bytes;
	}
	
	avl_delete(source->clients, clicon);
	del_client(clicon, source);
	clicon->food.client->virgin = 1;
	insert_client(clicon->food.client->source, clicon);
	add_client();
	return;
}

int
write_data_meta_data (connection_t *clicon, source_t *source, int datalen, int write_meta_at)
{
	int write_bytes = 0, len;
	
	if (write_meta_at > 0)
	{
		write_bytes = sock_write_bytes_or_kick (clicon->sock, clicon, &source->chunk[clicon->food.client->cid].data[clicon->food.client->offset], write_meta_at);
		if (write_bytes < 0)
			return -1;
	}
	
#ifndef OPTIMIZE
	xa_debug (2, "DEBUG: Wrote %d bytes before metainfo", write_bytes);
#endif
	
	if (write_bytes > 0)
	{
		clicon->food.client->write_bytes += write_bytes;
		clicon->food.client->offset += write_bytes;
		info.hourly_stats.write_bytes += write_bytes;
		source->stats.write_bytes += write_bytes;
	}
	
	if (write_bytes < write_meta_at)
	{
#ifndef OPTIMIZE
		xa_debug (2, "DEBUG: Couldn't complete data before metadata, delaying");
#endif
		return 0;
	}

        /* 
	 *  0 means come back to play another day
	 * -1 means he's been kicked out 
	 */
	len = write_meta_data (clicon, source);
	if (len == -1 || len == 0)
		return len; 

	if (datalen > 0)
	{
		write_bytes = sock_write_bytes_or_kick (clicon->sock, clicon, &source->chunk[clicon->food.client->cid].data[clicon->food.client->offset], datalen 
							- write_bytes);
		if (write_bytes < 0)
			return -1;
	}
	
#ifndef OPTIMIZE
	xa_debug (2, "DEBUG: Wrote %d bytes before and after meta info", write_bytes);
#endif
	
	return write_bytes;
}
	
int
write_data (connection_t *clicon, source_t *source)
{
	int write_bytes;

	if (source->chunk[clicon->food.client->cid].len - clicon->food.client->offset <= 0)
		return 0;

	write_bytes = sock_write_bytes_or_kick(clicon->sock, clicon, &source->chunk[clicon->food.client->cid].data[clicon->food.client->offset], 
					     source->chunk[clicon->food.client->cid].len - clicon->food.client->offset);
	
#ifndef OPTIMIZE
	xa_debug (3, " ------write [%2d] [%3d]:[%3d] [%4d] ", clicon->id, source->cid, clicon->food.client->cid, write_bytes);
#endif

	if (write_bytes < 0)
		return -1;
	return write_bytes;
}

connection_t *
get_source_with_mount (const char *mount)
{
	avl_traverser trav = {0};
	connection_t *travcon;

	thread_mutex_lock (&info.source_mutex);
	
	while ((travcon = avl_traverse (info.sources, &trav)))
	{
		if ((strcmp (travcon->food.source->audiocast.mount, mount) == 0) ||
		    ((mount[0] != '/') && strcmp (&mount[0], &travcon->food.source->audiocast.mount[1]) == 0))
		{
			thread_mutex_unlock (&info.source_mutex);
			return travcon;
		}
	}
	
	thread_mutex_unlock (&info.source_mutex);
	return NULL;
}

connection_t *
get_source_from_host (connection_t *con)
{
	avl_traverser trav = {0};
	connection_t *travcon;

	thread_mutex_lock (&info.source_mutex);

	while ((travcon = avl_traverse (info.sources, &trav)))
	{
		if (hosteq (con, travcon))
		{
			thread_mutex_unlock (&info.source_mutex);
			return travcon;
		}
	}

	thread_mutex_unlock (&info.source_mutex);

	return NULL;
}

void
describe_source (const connection_t *con, const connection_t *sourcecon)
{
	const source_t *source;
	char buf[BUFSIZE];

	if (!con || !sourcecon)
	{
		xa_debug (1, "WARNING: describe_source(): called with NULL pointers");
		return;
	}

	if (sourcecon->type != source_e)
	{
		xa_debug (1, "WARNING: describe_source(): called with invalid type");
		return;
	}

	describe_connection (con, sourcecon);
	
	source = sourcecon->food.source;

	sock_write_line (con->sock, "Misc source info:");
	sock_write_line (con->sock, "Connected: %s", source->connected ? "yes" : "no");
	sock_write (con->sock, "Source Type: ");
	switch (source->type)
	{
		case encoder_e:
			sock_write_line (con->sock, "Encoder");
			break;
		case puller_e:
			sock_write_line (con->sock, "Pulling relay");
			break;
		case on_demand_pull_e:
			sock_write_line (con->sock, "On demand pull relay");
			break;
		case file_e:
			sock_write_line (con->sock, "Static stream");
			break;
		default:
			sock_write_line (con->sock, "Unknown source type");
			break;
	}
		
	sock_write_line (con->sock, "Protocol: %s", source->protocol == icy_e ? "ICY" : "x-audiocast");
	sock_write_line (con->sock, "Number of clients: %lu", source->num_clients);
	sock_write_line (con->sock, "Dumpfile and dumpfd: %s : %d", source->dumpfile ? source->dumpfile : "(null)", source->dumpfd);
	sock_write_line (con->sock, "Stream priority: %d", source->priority);
	sock_write_line (con->sock, "Stream title: %s", source->streamtitle ? source->streamtitle : "(null)");
	sock_write_line (con->sock, "Stream url: %s", source->streamurl ? source->streamurl : "(null)");
	sock_write_line (con->sock, "Source name: %s", source->audiocast.name ? source->audiocast.name : "(null)");
	sock_write_line (con->sock, "Source genre: %s", source->audiocast.genre ? source->audiocast.genre : "(null)");
	sock_write_line (con->sock, "Source bitrate: %d", source->audiocast.bitrate);
	sock_write_line (con->sock, "Source url: %s", source->audiocast.url ? source->audiocast.url : "(null)");
	sock_write_line (con->sock, "Source mount: %s", source->audiocast.mount ? source->audiocast.mount : "(null)");
	sock_write_line (con->sock, "Source description: %s", source->audiocast.description ? source->audiocast.description : "(null)");
	sock_write_line (con->sock, "Megabytes read: %lu", source->stats.read_megs);
	sock_write_line (con->sock, "Megabytes written: %lu", source->stats.write_megs);
	sock_write_line (con->sock, "Client connections: %lu", source->stats.client_connections);
	sock_write_line (con->sock, "Client connect time: %s", nice_time (source->stats.client_connect_time, buf));
	sock_write_line (con->sock, "Average client connect time: %s", connect_average (source->stats.client_connect_time, source->stats.client_connections, buf));
	sock_write_line (con->sock, "Average client transfer average: %lu", transfer_average (source->stats.write_megs, source->stats.client_connections));
}
