/* commands.h
 * - Command Function Headers
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifndef __ICECAST_COMMANDS_H
#define __ICECAST_COMMANDS_H

void handle_admin_command(connection_t *con, char *command, int command_len);
void show_settings(connection_t *con);
void setup_admin_settings();
void setup_config_file_settings();
int parse_config_file(char *file);
void log_command(connection_t *con, char *command, char *argument);
char *clean_string(char *string);
void tell_admins(void *data, void *param);
void move_id_to (connection_t *con, int id, int newsourceid);
void move_all_matching (connection_t *con, int sourceid, char *arg);
void move_all_from (connection_t *con, int sourceid, int targetid);
void move_to (void *clientarg, void *sourcetargetarg);
avl_tree *get_acl_tree (char *type);
int parse_default_config_file ();
#endif
