/* commandline.c
 * - Commandline parsing *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "commandline.h"

void usage()
{
	printf("i c e c a s t - Version %s\n", VERSION);
	printf(" ` ` ` ` ` `\n");
	printf("Usage:\n");
	printf("icecast [-P <port>] [-E <port>] [-d <hostname>] [-m <users>] [-A <port>]\n");
	printf("        [-p <password>] [-l <file>] [-r] [-H <hostname>] [-R <port>]\n");
	printf("        [-a <password>] [-o <password]\n");
	printf("\n");
	printf("\tOptions explained (compiled default in parenthesis):\n");
	printf("\t-c: Configuration file to use (%s)\n", DEFAULT_CONFIG_FILE);
	printf("\t-P: port on which the server will listen for client connections (%d)\n", DEFAULT_PORT);
	printf("\t-E: port on which the server will listen for encoder connections (%d)\n", DEFAULT_ENCODER_PORT);
	printf("\t-A: port on which the server will listen for a remote admin (%d)\n", DEFAULT_REMOTE_ADMIN_PORT);
	printf("\t-d: hostname of a directory server to use (%s) (can be repeated)\n", DEFAULT_DIRECTORY_SERVER);
	printf("\t-m: maximum number of clients to accept (%d)\n", DEFAULT_MAX_CLIENTS);
	printf("\t-p: password to validate encoders (%s)\n", DEFAULT_ENCODER_PASSWORD);
	printf("\t-a: password to validate admins (%s)\n", DEFAULT_REMOTE_ADMIN_PASSWORD);
	printf("\t-o: password to validate opers (%s)\n", DEFAULT_OPER_PASSWORD);
	printf("\t-l: file for logging (%s)\n", DEFAULT_LOGFILE);
	printf("\t-r: enable redirection\n");
	printf("\t-H: redirection: server hostname or ip\n");
	printf("\t-R: redirection: server port\n");
	printf("\n\n");
}

void parse_args(server_info_t *info, int argc, char *argv[])
{
        int d = 0;
	int arg;
	char *s;

	arg = 1;

	while (arg < argc) {
		s = argv[arg];

		if (s[0] == '-') {
			switch (s[1]) {
			case 'c':
			  arg++;
			  info->configfile = argv[arg];
			  parse_config_file (info->configfile);
			  break;
			case 'P':
				arg++;
				info->port = atoi(argv[arg]);
				break;
			case 'E':
				arg++;
				info->encoder_port = atoi(argv[arg]);
				break;
			case 'm':
				arg++;
				info->max_clients = atoi(argv[arg]);
				break;
			case 'd':
				arg++;
				if (d >= info->max_directories)
				  {
				    fprintf (stderr, "Too many directory servers, can't accept [%s]\n",
					     argv[arg]);
				    continue;
				  }
				info->d_server[d].host = argv[arg];
				info->d_server[d].counter = 0;
#ifdef DEBUG_DIRECTORY
				fprintf (stderr, "Added directory server %s in position %d\n",
					 argv[arg], d);
#endif
				d++;
				break;
			case 'p':
				arg++;
				info->encoder_pass = argv[arg];
				break;
			case 'a':
			        arg++;
				info->remote_admin_pass = argv[arg];
				break;
			case 'o':
			        arg++;
				info->oper_pass = argv[arg];
				break;
			case 'l':
				arg++;
				info->logfilename = argv[arg];
				break;
			case 'r':
				info->redirection = 1;
				break;
			case 'H':
				arg++;
				info->redirection_host = argv[arg];
				break;
			case 'R':
				arg++;
				info->redirection_port = atoi(argv[arg]);
				break;
			case 'A':
				arg++;
				info->remote_admin_port = atoi(argv[arg]);
				break;
			default:
				usage();
				exit(1);
			}
		} else {
			usage();
			exit(1);
		}
		arg++;
	}
}
