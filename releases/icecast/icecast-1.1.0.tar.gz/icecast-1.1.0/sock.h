/* sock.h
 * - General Socket Function Headers
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifndef _ICECAST_SOCK_H
#define _ICECAST_SOCK_H

#include "icetypes.h"

int sock_write(int sockfd, char *fmt, ...);
int sock_read_lines (int sockfd, char *string, int *counter);
int sock_read_line (int sockfd, char *string, int *counter);
int sock_read(int sockfd, char **string);
int get_server_socket(int port);
int get_client(int server);
int sock_connect(char *hostname, int port);
client_t *put_client (int fromsocket);
source_t *put_source (int fromsocket);
admin_t *put_admin (int fromsocket);
int check_libwrap (int sock);
#endif
