/* Whether to use crypted passwords */
#undef USE_CRYPT

/* Whether to use tcp_wrappers */
#undef HAVE_LIBWRAP

/* Some systems have sys/syslog.h */
#undef NEED_SYS_SYSLOG_H
