/* utility.h
 * - Utility Function Headers
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#ifndef _ICECAST_UTILITY_H
#define _ICECAST_UTILITY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "sock.h"
#include "icetypes.h"
#include "log.h"
#endif

int password_match (char *crypted, char *uncrypted);

char * splitc (char *first, char *rest, const char divider);

char * makeasciihost (char *in);

int check_pass (int sockfd, char *pass, int *counter, char *string);

char * nice_time (int seconds);

char * clean_string (char *string);

