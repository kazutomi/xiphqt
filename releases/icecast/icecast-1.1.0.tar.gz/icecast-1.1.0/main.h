/* main.h
 * - Main Function Headers
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */


/* main.c functions */
int check_pass (int sockfd, char *pass, int *counter, char *string);
int source_login (int sockfd, char *pass, int *counter, char *string);
void clean_shutdown(server_info_t *info);
void new_server_proc (server_info_t *info);
void handle_action (server_info_t *info, fd_set *readfds);
void usage();
void switch_encoder (server_info_t *info);
void setup_listeners ();
void sig_die(int signo);
void sig_die_hard (int signo);
void sig_child(int signo);
char *makeasciihost (char *in);
admin_t *get_next_admin (server_info_t *info);
source_t *get_next_source (server_info_t *info);
client_t *get_next_client (server_info_t *info);
void greet_source (source_t *ser);
void greet_admin (admin_t *adm);
void greet_client (client_t *cli);
void kick_source (source_t *sor, char *why);
void kick_client (client_t *cli, char *why);
void kick_clients ();
void kick_admin (admin_t *adm, char *why);
void parse_args(server_info_t *info, int argc, char *argv[]);
char *splitc (char *first, char *rest, const char divider);
int password_match (char *crypted, char *uncrypted);
