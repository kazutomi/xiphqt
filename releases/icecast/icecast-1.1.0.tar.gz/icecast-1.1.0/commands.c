/* commands.c
 * - Admin Commands Handling *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#ifndef __USE_BSD
#define __USE_BSD
#endif
#ifndef __EXTENSIONS__
#define __EXTENSIONS__
#endif
#include <string.h>
#include <time.h>
#include "icetypes.h"
#include "commands.h"
#include "icecast.h"
#include "sock.h"
#include "log.h"
#include "main.h"
#include "directory.h"
#include "utility.h"

extern int errno;
server_info_t info;

typedef int Function();
typedef enum type_e {integer_e, real_e, string_e} type_t;

typedef struct 
{
  char *name;                   /* User printable name of the function. */
  Function *func;               /* Function to call to do the job. */
  char *doc;                    /* Documentation for this function.  */
  int oper;                     /* Has to be oper? */
} comp_element;

typedef struct
{
  char *name;                   /* Printable name of this setting */
  type_t type;                  /* Integer, string or float? */
  char *doc;                    /* What does this setting do? */
  void *setting;                /* The actual data affected by this setting */
} set_element;

/* Now list all the functions (*sigh*) */
int com_admins(), com_help(), com_tail(), com_untail (), com_info (),
  com_sources(), com_listeners(), com_rehash (), com_set (), com_sel (),
  com_uptime (), com_tell (), com_shutdown (), com_oper (),
  com_kick (), com_quit (), com_touch (), com_dir (), com_stats ();

/* All the remote admin commands */
comp_element commands[] = 
{
  { "admins",  com_admins,   "Show all connected admins", 0 },
  { "dir",     com_dir,  "Add | Remove | List directories", 1 },
  { "help",    com_help,     "Display this text", 0 },
  { "info",    com_info, "Show server information", 0 },
  { "kick",    com_kick,     "Kick client, admin, or source", 1},
  { "listeners", com_listeners, "Show connected listeners", 0 },
  { "oper",    com_oper,     "Obtain operator privileges", 0 },
  { "quit",    com_quit,     "Leave remote admin console", 0 },
  { "rehash",  com_rehash,   "Parse the config file", 1 },
  { "select",  com_sel,  "Select the actual encoder", 1},
  { "sources", com_sources,  "Show connected encoders", 0 },
  { "shutdown", com_shutdown, "Shutdown the server", 1 },
  { "set",     com_set,      "Set <var> to <arg>", 1 },
  { "stats",   com_stats, "Show server statistics", 0},
  { "tail",    com_tail,     "Start tailing the logfile", 0 },
  { "tell",    com_tell,     "Tell other admins", 0 },
  { "touch",   com_touch,    "Touch the directory server", 1 },
  { "untail",  com_untail,   "Stop tailing the logfile", 0 },
  { "uptime",  com_uptime,   "Show server uptime", 0 },
  { (char *) NULL, (Function *)NULL, (char *)NULL, 0 }
};

/* All the settings for the remote admin */
set_element admin_settings[] = 
{
  { "name", string_e, "The icy name to send to the directory server", NULL },
  { "br", integer_e,  "The icy bitrate to send to the directory server", NULL },
  { "url", string_e,  "The url to send to the directory server", NULL},
  { "errors", integer_e,  "Number of errors to accept before kicking client", NULL },
  { "encoder_password", string_e,  "The encoder password", NULL },
  { "client_password", string_e, "<unimplemented> Client password", NULL },
  { "admin_password", string_e, "The remote admin password", NULL },
  { "oper_password", string_e, "Operator Password", NULL },
  { "public", integer_e, "The icy public flag", NULL },
  { "touch_freq", integer_e, "Touch frequency", NULL },
  { "source_mode", integer_e, "How to deal with secondary sources", NULL },
  { "client_timeout", integer_e, "When to kick out clients", NULL },
  { (char *) NULL, 0, (char *) NULL, NULL }
};

/* All the settings for the config file */
set_element configfile_settings[] = 
{
  { "name", string_e, "The icy name to send to the directory server", NULL },
  { "br", integer_e,  "The icy bitrate to send to the directory server", NULL },
  { "url", string_e,  "The url to send to the directory server", NULL},
  { "errors", integer_e,  "Number of errors to accept before kicking client", NULL },
  { "encoder_password", string_e,  "The encoder password", NULL },
  { "client_password", string_e, "<unimplemented> Client password", NULL },
  { "admin_password", string_e, "The remote admin password", NULL },
  { "oper_password", string_e, "Operator Password", NULL },
  { "public", integer_e, "The icy public flag", NULL },
  { "touch_freq", integer_e, "Touch frequency", NULL },
  { "admin_port", integer_e, "Port to listen for remote admin connections", NULL },
  { "client_port", integer_e, "Port to listen for clients on", NULL },
  { "source_port", integer_e, "Port to listen for encoder on", NULL },
  { "max_clients", integer_e, "Highest number of client connectons", NULL },
  { "max_sources", integer_e, "Highest number of source connections", NULL },
  { "max_admins", integer_e, "Highest number of admin connections", NULL },
  { "logfile", string_e, "Logfile to write to", NULL },
  { "redirect", integer_e, "Whether to redirect", NULL },
  { "redirection_host", string_e, "Icecast server to relay", NULL },
  { "redirection_port", integer_e, "Port to use on redirection server", NULL },
  { "source_mode", integer_e, "How to deal with secondary sources", NULL },
  { "hostname", string_e, "What host/ip to bind to", NULL},
  { "console_mode", integer_e, "How to use the icecast console", NULL },
  { "client_timeout", integer_e, "When to kick out clients", NULL },
  { "stats_log", string_e, "Stats Logfile to write to", NULL},
  { "stats_time", integer_e, "How often to write to the stats logfile, in seconds", NULL},
  { (char *) NULL, 0, (char *) NULL, NULL }
};

set_element *
find_set_element (char *name, set_element *el)
{
  register int i;
  for (i = 0; el[i].name; i++)
    if (strcmp (name, el[i].name) == 0)
      return (&el[i]);
  return ((set_element *)NULL);
}

comp_element *
find_comp_element (char *name, comp_element *el)
{
  register int i;
  for (i = 0; el[i].name; i++)
    if (strcmp (name, el[i].name) == 0)
      return (&el[i]);
  return ((comp_element *)NULL);
}

/* make sure the array of settings for the config file points to the right data */
void
setup_config_file_settings ()
{
  /* Don't change the order of these */
  configfile_settings[0].setting = &info.name;
  configfile_settings[1].setting = &info.bitrate;
  configfile_settings[2].setting = &info.url;
  configfile_settings[3].setting = &info.max_errors;
  configfile_settings[4].setting = &info.encoder_pass;
  configfile_settings[5].setting = &info.client_pass;
  configfile_settings[6].setting = &info.remote_admin_pass;
  configfile_settings[7].setting = &info.oper_pass;
  configfile_settings[8].setting = &info.public;
  configfile_settings[9].setting = &info.touch_freq;
  configfile_settings[10].setting = &info.remote_admin_port;
  configfile_settings[11].setting = &info.port;
  configfile_settings[12].setting = &info.encoder_port;
  configfile_settings[13].setting = &info.max_clients;
  configfile_settings[14].setting = &info.max_sources;
  configfile_settings[15].setting = &info.max_admins;
  configfile_settings[16].setting = &info.logfilename;
  configfile_settings[17].setting = &info.redirection;
  configfile_settings[18].setting = &info.redirection_host;
  configfile_settings[19].setting = &info.redirection_port;
  configfile_settings[20].setting = &info.select_mode;
  configfile_settings[21].setting = &info.myhostname;
  configfile_settings[22].setting = &info.console_mode;
  configfile_settings[23].setting = &info.client_timeout;
  configfile_settings[24].setting = &info.statsfilename;
  configfile_settings[25].setting = &info.statstime;
}

/* Parse the configfile pointed to by file.
   If it doesn't exist, no matter, just go on */
int
parse_config_file (char *file)
{
  set_element *se;
  int lineno = 0, d = 0;
  char word[1024], line[1024];
  FILE *cf;

  if ((cf = fopen (file, "r")) == NULL)
    {
      fprintf (stderr, "No configfile found, using defaults.\n");
      return 1;
    }

  setup_config_file_settings ();
  while (fgets (line, 1024, cf))
    {
      lineno++;
      if ((strlen (line) < 2) || (line[0] == '#') || (line[0] == ' '))
	continue;

      if (line[strlen (line) - 1] == '\n')
	line[strlen (line) - 1] = '\0';
      if (splitc (word, line, ' ') == NULL)
	{
	  fprintf (stderr, "No argument given to setting %s on line %d\n", 
		   line, lineno);
	  continue; 
	}

      se = find_set_element (word, configfile_settings);
      
      if (!se && (strncmp (word, "dir", 3) != 0))
	{
	  fprintf (stderr, "Unknown setting %s on line %d\n", word, lineno);
	  continue;
	}

      if (!se)
	{
	  if (d >= info.max_directories)
	    {
	      fprintf (stderr, "Too many directory servers, can't accept [%s]\n",
		       line);
	    }
	  info.d_server[d].host = strdup (line);
	  info.d_server[d].counter = 0;
#ifdef DEBUG_DIRECTORY
	  fprintf (stderr, "Added directory server %s in position %d\n",
		   line, d);
#endif
	  d++;
	  continue;
	}

      if (se->type == integer_e)
	*(int *)(se->setting) = atoi (line);
      else if (se->type == real_e)
	*(float *)(se->setting) = atof (line);
      else
	{
	  /* string, might have to free it first */
	  if (*(char **)(se->setting) != NULL)
	    free (*(char **)(se->setting));
	  *((char **)(se->setting)) = clean_string (strdup (line));
	}      
    }
  return 0;
}

/* Make sure the array of admin settings point to the right data */
void
setup_admin_settings ()
{
  /* The order of these are IMPORTANT, get it? */
  admin_settings[0].setting = &info.name;
  admin_settings[1].setting = &info.bitrate;
  admin_settings[2].setting = &info.url;
  admin_settings[3].setting = &info.max_errors;
  admin_settings[4].setting = &info.encoder_pass;
  admin_settings[5].setting = &info.client_pass;
  admin_settings[6].setting = &info.remote_admin_pass;
  admin_settings[7].setting = &info.oper_pass;
  admin_settings[8].setting = &info.public;
  admin_settings[9].setting = &info.touch_freq;
  admin_settings[10].setting = &info.select_mode;
  admin_settings[11].setting = &info.client_timeout;
}
    
/* Top level remote admin console command parser */
void 
handle_admin_command (admin_t *adm, char *command, int command_len)
{
  int flag = 0;
  register int i;
  comp_element *com;
  char comstr[1024], *arg;
  
  if (command_len < 2)
    {
      sock_write (adm->sock, "-> ");
      return;
    }

  /* sanity check */
  for (i = 0; i <= command_len; i++)
    {
      if (command[i] == '\n' || command[i] == '\0')
	{
	  flag = 1;
	  command[i] = '\0';
	  break;
	}
    }
  
  if (!flag)
    {
      sock_write (adm->sock, "-> ");
      return;
    }

  splitc (comstr, command, ' ');

  if (!comstr[0] || !command[0] || command[0] == ' ')
    {
      if (command[0] && command[0] != ' ')
	strcpy (comstr, command);
      arg = NULL;
    }
  else
    arg = command;

  /* Functions are now responsible for their own logging */
  com = find_comp_element (comstr, commands);

  if (!com)
    {
      com_help (adm, comstr);
      sock_write (adm->sock, "-> ");
      return;
    }
  if (com->oper && (adm->accepted < REMOTE_OPER))
    sock_write (adm->sock, "Only operators can use the %s command\n", com->name);
  else
    ((*(com->func)) (adm, arg));
  sock_write (adm->sock, "-> ");
}

int
com_admins (admin_t *adm, char *arg)
{
  register int i;
  log_command (adm, "admins", NULL);
  sock_write (adm->sock, "Listing admins (%d):\n", info.num_admins);
  for (i = 0; i < info.max_admins; i++)
    {
      if (info.admins[i].sock < 0)
	continue;
      sock_write (adm->sock, 
		  "%d)\tAdmin [%s], connected for %d seconds, commands: %d\n",
		  i, info.admins[i].host, 
		  get_time () - info.admins[i].connect_time,
		  info.admins[i].commands);
    }
  return 1;
}

void
show_settings (admin_t *adm)
{
  register int i;
  set_element *se = admin_settings;

  sock_write (adm->sock, "Current settings:\n");
  for (i = 0; se[i].name; i++)
    {
      if (se[i].type == integer_e)
	sock_write (adm->sock, "[%20s]\t [%d]\n", se[i].name, *(int *)(se[i].setting));
      else if (se[i].type == real_e)
	sock_write (adm->sock, "[%20s]\t [%f]\n", se[i].name, *(float *)(se[i].setting));
      else
	sock_write (adm->sock, "[%20s]\t [%s]\n", se[i].name, *(char **)(se[i].setting));
    }
}
		    
int
com_help (admin_t *adm, char *arg)
{
  register int i;
  comp_element *ce;
  set_element *se;

  log_command (adm, "help", NULL);

  if (!arg)
    {
      ce = commands;
      sock_write (adm->sock, "Available commands:\n");
      for (i = 0; ce[i].name; i++)
	sock_write (adm->sock, "%20s\t: %s\n", ce[i].name, ce[i].doc);
      return 1;
    }
  
  if (strncmp (arg, "setti", 5) == 0)
    {
      se = admin_settings;
      sock_write (adm->sock, "Available settings:\n");
      for (i = 0; se[i].name; i++)
	sock_write (adm->sock, "%20s\t: %s\n", se[i].name, se[i].doc);
      return 1;
    }

  ce = find_comp_element (arg, commands);

  if (!ce)
    {
      sock_write (adm->sock, "No such command [%s]\n", arg);
      return 1;
    }

  sock_write (adm->sock, "Command: [%s]\nDescription: [%s]\n", ce->name, ce->doc);
  return 1;
}
      

int
com_set (admin_t *adm, char *arg)
{
  char argument[1024];
  set_element *s;

  log_command (adm, "set", NULL);

  if (!arg)
    {
      show_settings (adm); /* No setting, show all settings */
      return 1;
    }

  if (splitc (argument, arg, ' ') == NULL) /* No argument, show setting */
    {
      s = find_set_element (arg, admin_settings);
      if (!s)
	{
	  sock_write (adm->sock, "No such setting [%s]\n", arg);
	  return 1;
	}
      if (s->type == integer_e)
	sock_write (adm->sock, "%s: %d\n", s->name, *(int *)(s->setting));
      else if (s->type == real_e)
	sock_write (adm->sock, "%s: %f\n", s->name, *(float *)(s->setting));
      else 
	sock_write (adm->sock, "%s: %s\n", s->name, *(char *)(s->setting));
      return 1;
    }

  s = find_set_element (argument, admin_settings);
  if (!s)
    {
      sock_write (adm->sock, "No such setting [%s]\n", argument);
      return 1;
    }
  if (s->type == integer_e)
    *(int *)(s->setting) = atoi (arg);
  else if (s->type == real_e)
    *(float *)(s->setting) = atof (arg);
  else
    {
      /* string, might have to free it first */
      if (*(char **)(s->setting) != NULL)
	free (*(char **)(s->setting));
      *((char **)(s->setting)) = strdup (arg);
    }
  return 1;
}
  
int
com_tail (admin_t *adm, char *arg)
{
  log_command (adm, "tail", NULL);
  sock_write (adm->sock, "Now tailing logfile\n");
  adm->accepted += TAILING;
  return 1;
}

int
com_untail (admin_t *adm, char *arg)
{
  log_command (adm, "untail", NULL);
  sock_write (adm->sock, "No longer tailing logfile\n");
  if (adm->accepted >= TAILING)
    adm->accepted -= TAILING;
  return 1;
}
  
int
com_info (admin_t *adm, char *arg)
{
  log_command (adm, "info", NULL);
  sock_write (adm->sock, 
  "Icy data:\nIcy Name: [%s]\nIcy Genre: [%s]\nIcy URL: [%s]\nIcy Public: %d\nIcy Bitrate: %d\n",
	      info.name, info.genre, info.url, info.public,  info.bitrate);
  return 1;
}

int
com_sources (admin_t *adm, char *arg)
{
  register int i;

  log_command (adm, "sources", NULL);

  sock_write (adm->sock, "Listing sources (%d):\n", info.num_sources);
  for (i = 0; i < info.max_sources; i++)
    {
      if (info.sources[i].sock == -1)
	continue;
      sock_write (adm->sock, 
		  "%d)\t[%s] connected for %d seconds, bytes transfered: %d %s",
		  i, info.sources[i].host, 
		  get_time () - info.sources[i].connect_time,
		  info.sources[i].read_bytes, 
		  info.actual_encoder == info.sources[i].sock ? "(streaming)\n" : "\n");
    }
  return 1;
}

int
com_listeners (admin_t *adm, char *arg)
{
  register int i;

  log_command (adm, "listeners", NULL);

  sock_write (adm->sock, "Listing listeners (%d):\n", info.num_clients);
  for (i = 0; i < info.max_clients; i++)
    {
      if (info.clients[i].sock < 0)
	continue;
      sock_write (adm->sock, 
		  "%d)\t[%s] connected for %d seconds, bytes transfered: %d errors: %d\n",
		  i, info.clients[i].host, 
		  get_time () - info.clients[i].connect_time,
		  info.clients[i].write_bytes, info.clients[i].counter);
    }
  return 1;
}

int
com_rehash (admin_t *adm, char *arg)
{
  log_command (adm, "rehash", NULL);
  sock_write (adm->sock, "Rereading config file\n");
  parse_config_file (info.configfile);
  return 1;
}

int
com_uptime (admin_t *adm, char *arg)
{
  int i = get_time () - info.server_start_time;
  log_command (adm, "uptime", NULL);
  sock_write (adm->sock, 
	      "Icecast %s server uptime: %d minutes, %d seconds\n",
	      VERSION, i / 60, i % 60);  
  return 1;
}

int
com_tell (admin_t *adm, char *arg)
{
  register int i;

  log_command (adm, "tell", NULL);

  if (!arg)
    {
      sock_write (adm->sock, "Don't be so modest, spit it out :)\n");
      return 1;
    }
  for (i = 0; i < info.max_admins; i++)
    {
      if ((info.admins[i].sock != -1) && 
	  (info.admins[i].sock != adm->sock))
	{
	  sock_write (info.admins[i].sock, "Admin [%s] said: %s\n",
		      adm->host, arg);
	}
    }
  return 1;
}

int
com_stats (admin_t *adm, char *arg)
{
  register int i;
  time_t ec = 0, t, cc = 0;

  log_command (adm, "stats", NULL);

  t = get_time ();

  for (i = 0; i < info.max_sources; i++)
    {
      if (info.sources[i].sock == -1)
	continue;
      ec = ec + (t - info.sources[i].connect_time);
    }

  for (i = 0; i < info.max_clients; i++)
    {
      if (info.clients[i].sock == -1)
	continue;
      cc = cc + (t - info.clients[i].connect_time);
    }
      
  sock_write (adm->sock, "Displaying server statistics:\n");
  sock_write (adm->sock, "Total bytes read: %lu\n", info.total_read);
  sock_write (adm->sock, "Total bytes written: %lu\n", info.total_written);
  sock_write (adm->sock, "Total time of source connected: %s\n", 
	      nice_time (info.source_connect_time + ec));
  sock_write (adm->sock, "Number of source connects: %lu\n", info.source_connections);
  sock_write (adm->sock, "Total time of clients connected: %s\n", 
	      nice_time (info.client_connect_time + cc));
  sock_write (adm->sock, "Number of client connects: %lu\n", info.client_connections);
  if (info.client_connections > 0)
    {
      sock_write (adm->sock, "Average listener time: %s\n", 
		  nice_time ((int) ((float) (cc + info.client_connect_time) /
				    (float) info.client_connections)));
      sock_write (adm->sock, "Average listener transfer: %lu bytes\n",
		  (unsigned long int) ((float)info.total_written / 
				       (float)info.client_connections));
    }
  if (info.source_connections > 0)
    {
      sock_write (adm->sock, "Average source connect time: %s\n",
		  nice_time ((int) ((float) (ec + info.source_connect_time) / 
				    (float) info.source_connections)));
      sock_write (adm->sock, "Average source transfer: %lu bytes\n",
		  (unsigned long int) ((float)info.total_read / 
				       (float) info.source_connections));
    }
  return 1;
}

int
com_shutdown (admin_t *adm, char *arg)
{
  log_command (adm, "shutdown", NULL);
  sock_write (adm->sock, "Ok, killing server, bye!\n");
  clean_shutdown (&info);
  return 1;
}

int
com_oper (admin_t *adm, char *arg)
{
  log_command (adm, "oper", NULL);
  if (!arg)
    {
      sock_write (adm->sock, "*hint* The password is longer than that :)\n");
      return 1;
    }
  if (password_match (info.oper_pass, arg))
    {
      adm->accepted += REMOTE_OPER;
      sock_write (adm->sock, "You are now an icecast operator\n");
      write_log (&info, "Admin %s is now an icecast operator\n", adm->host);
    }
  else
    sock_write (adm->sock, "Invalid password\n");
  return 1;
}

int
com_quit (admin_t *adm, char *arg)
{
  if (adm->sock == 0)
    {
      sock_write (1, "Sorry, you can't quit from the local admin console\n");
      sock_write (1, "Use 'shutdown' to bring the server down\n");
    }
  else
    {
      sock_write (adm->sock, "Uh, ok, bye!\n");
      kick_admin (adm, "Admin quit");
    }
  return 1;
}  

int
com_touch (admin_t *adm, char *arg)
{
  register int i;

  log_command (adm, "touch", NULL);

  if (info.actual_encoder == -1)
    {
      sock_write (adm->sock, "No encoder connected, I refuse to touch\n");
      return 1;
    }
  info.lasttime = get_time ();
  if (fork () == 0)
    {
      for (i = 0; i < info.max_directories; i++)
	{
	  if (info.d_server[i].host == NULL)
	    continue;
	  directory_touch (&info.d_server[i]);
	}
      exit (0);
    }
  return 1;
}

int
com_dir (admin_t *adm, char *arg)
{
  register int i;
  char *out;
  char type[1024];

  if (!arg)
    {
      sock_write (adm->sock, "dir <add|remove|list> [number]\n");
      return 1;
    }

  out = splitc (type, arg, ' ');

  log_command (adm, "dir", NULL);

  if (!out)
    strcpy (type, arg);

  if (type[0] == 'a')
    {
      if (!out)
	{
	  sock_write (adm->sock, "dir <add|remove|list> [number]\n");
	  return 1;
	}
      for (i = 0; i < info.max_directories; i++)
	{
	  if (info.d_server[i].host == NULL)
	    break;
	}
      if (info.d_server[i].host != NULL)
	{
	  sock_write (adm->sock, "Add directory slots taken, sorry\n");
	  return 1;
	}
      sock_write (adm->sock, "Added %s as directory server\n", arg);
      info.d_server[i].host = strdup (arg);
      info.d_server[i].counter = 0;
      return 1;
    }
  if (type[0] == 'd' || type[0] == 'r')
    {
      int which;
      if (!out)
	{
	  sock_write (adm->sock, "dir <add|remove|list> [number]\n");
	  return 1;
	}
      which = atoi (arg);
      if (info.d_server[which].host == NULL)
	{
	  sock_write (adm->sock, "Slot %d is not in use\n", which);
	  return 1;
	}
      sock_write (adm->sock, "Removing directory server %s from list\n", info.d_server[which].host);
      if (fork() == 0)
	{
	  directory_remove (&info.d_server[which]);
	  exit (0);
	}
      info.d_server[which].host = NULL;
      info.d_server[which].counter = 0;
      return 1;
    }
  if (type[0] == 'l')
    {
      sock_write (adm->sock, "Listing directories: \n");
      for (i = 0; i < info.max_directories; i++)
	{
	  if (info.d_server[i].host == NULL)
	    continue;
	  sock_write (adm->sock, "%d)\t [%s] id: %d\n", i, info.d_server[i].host, info.d_server[i].id);
	}
      return 1;
    }
  return 1;
}

int
com_kick (admin_t *adm, char *arg)
{
  register int i;
  char type[1024];
  int who = 0;
  if (!arg)
    {
      sock_write (adm->sock, "kick <source|client|admin> <number>\n");
      return 1;
    }

  if (splitc (type, arg, ' ') == NULL)
    {
      sock_write (adm->sock, "kick <source|client|admin> <number>\n");
      return 1;
    }

  log_command (adm, "kick", type);

  if (arg[0] == '-' || arg[0] == 'a')
    who = -1;

  if (type[0] == 's')
    {
      if (who == -1)
	for (i = 0; i < info.max_sources; i++)
	  {
	    if (info.sources[i].sock == -1)
	      continue;
	    kick_source (&info.sources[i], "Masskick by admin");
	  }
      else
	kick_source (&info.sources[atoi (arg)], "Kicked by admin");
     
      switch_encoder (&info);
      if (info.actual_encoder == -1)
	kick_clients ();
    }
  else if (type[0] == 'c')
    {
      if (who == -1)
	for (i = 0; i < info.max_clients; i++)
	  {
	    if (info.clients[i].sock == -1)
	      continue;
	    kick_client (&info.clients[i], "Masskick by admin");
	  }
      else
	kick_client (&info.clients[atoi (arg)], "Kicked by admin");
    }
  else
    {
      if (who == -1)
	for (i = 0; i < info.max_admins; i++)
	  {
	    if (info.admins[i].sock == -1 || adm->sock == info.admins[i].sock)
	      continue;
	    kick_admin (&info.admins[i], "Masskick by admin");
	  }
      else
	kick_admin (&info.admins[atoi (arg)], "Kicked by admin");
    }
  return 1;
}
  


void
log_command (admin_t *adm, char *command, char *argument)
{
  if (argument)
    write_log (&info, "Admin [%s] said: %s %s", adm->host, command, argument);
  else
    write_log (&info, "Admin [%s] said: %s", adm->host, command);
}

int
com_sel (admin_t *adm, char *arg)
{
  int num;

  if (!arg)
    {
      sock_write (adm->sock, "select <number>\n");
      return 1;
    }
  
  num = atoi (arg);

  if (num < 0)
    {
      sock_write (adm->sock, "select <number>\n");
      return 1;
    }

  log_command (adm, "select", arg);
  info.actual_encoder = info.sources[num].sock;
  return 1;
}


