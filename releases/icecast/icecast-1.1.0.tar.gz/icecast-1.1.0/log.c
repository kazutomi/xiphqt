/* log.c
 * - Logging Functions
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "log.h"

extern int errno;
extern server_info_t info;

void write_log(server_info_t *info, char *fmt, ...)
{
  register int i;
  char buf[1024];
  va_list ap;
  char *logtime;
  
  va_start(ap, fmt);
#ifdef HAVE_VSNPRINTF
  vsnprintf(buf, 1024, fmt, ap);
#else
  vsprintf (buf, fmt, ap);
#endif
  
  logtime = get_log_time();
  if (info->logfile != NULL)
    {
      fprintf(info->logfile, "[%s] %s\n", logtime, buf);
      fflush(info->logfile);
    }

  if (info->console_mode == CONSOLE_LOG)
    printf("\r[%s] %s\n", logtime, buf);

  for (i = 0; i < info->max_admins; i++)
    {
      if ((info->admins[i].sock != -1) 
	  && ((info->admins[i].accepted == PASSWORD_ACCEPTED + TAILING)
	      || (info->admins[i].accepted 
		  == (PASSWORD_ACCEPTED + REMOTE_OPER + TAILING))))
	{
	  if (info->admins[i].sock == 0) /* Local console */
	    sock_write (1, "[%s] %s\n-> ", logtime, buf);
	  else
	    sock_write (info->admins[i].sock, "[%s] %s\n-> ", logtime, buf);
	}
    }
}

void
my_perror (char *where)
{
  write_log (&info, "%s", strerror (errno));
}

void stats_write (server_info_t *info)
{
  register int i;
  time_t ec = 0, t, cc = 0;
  struct hostent *hostinfo;
  struct in_addr inp;
  if ((info->statsfile = fopen(info->statsfilename, "w")) == NULL)
    write_log (info, "Could not open stats logfile %s for writing", info->statsfilename);
  else
    {
      /* Dump uptime information */
      i = get_time () - info->server_start_time;
      fprintf(info->statsfile,
		  "Icecast %s server uptime: %d minutes, %d seconds\n",
	      VERSION, i / 60, i % 60);  
      /* Dump sources information */
      fprintf(info->statsfile,  "Listing sources (%d):\n", info->num_sources);
      for (i = 0; i < info->max_sources; i++)
	{
	  if (info->sources[i].sock == -1)
	    continue;
	  if (inet_aton(info->sources[i].host, &inp))
	    hostinfo = gethostbyaddr ((char *) &inp, sizeof(struct in_addr), AF_INET); 
	  else
	    hostinfo = NULL;
	  fprintf(info->statsfile, 
		  "%d)\t[%s:%s] connected for %ld seconds, bytes transfered: %lu %s",
		  i, info->sources[i].host, hostinfo == NULL ? info->sources[i].host : hostinfo->h_name,
		  get_time () - info->sources[i].connect_time,
		  info->sources[i].read_bytes, 
		  info->actual_encoder == info->sources[i].sock ? "(streaming)\n" : "\n");
	  }
      /* Dump listener information */
      fprintf(info->statsfile, "Listing listeners (%d):\n", info->num_clients);
      for (i = 0; i < info->max_clients; i++)
	{
	  if (info->clients[i].sock < 0)
	    continue;
	  if (inet_aton(info->clients[i].host, &inp))
	    hostinfo = gethostbyaddr ((char *) &inp, sizeof(unsigned long), AF_INET);
	  else
	    hostinfo = NULL;
	  fprintf(info->statsfile, 
		  "%d)\t[%s:%s] connected for %ld seconds, bytes transfered: %lu errors: %d\n",
		  i, info->clients[i].host, hostinfo == NULL ? info->clients[i].host : hostinfo->h_name,
		  get_time () - info->clients[i].connect_time,
		  info->clients[i].write_bytes, info->clients[i].counter);
	}
      
      /* Dump overall stats */
      t = get_time ();
      
      for (i = 0; i < info->max_sources; i++)
	{
	  if (info->sources[i].sock == -1)
	    continue;
	  ec = ec + (t - info->sources[i].connect_time);
	}
      
      for (i = 0; i < info->max_clients; i++)
	{
	  if (info->clients[i].sock == -1)
	    continue;
	  cc = cc + (t - info->clients[i].connect_time);
	}
      
      fprintf(info->statsfile, "Displaying server statistics:\n");
      fprintf(info->statsfile, "Total bytes read: %lu\n", info->total_read);
      fprintf(info->statsfile, "Total bytes written: %lu\n", info->total_written);
      fprintf(info->statsfile, "Total time of source connected: %s\n", 
	      nice_time (info->source_connect_time + ec));
      fprintf(info->statsfile, "Number of source connects: %lu\n", info->source_connections);
      fprintf(info->statsfile, "Total time of clients connected: %s\n", 
	      nice_time (info->client_connect_time + cc));
      fprintf(info->statsfile, "Number of client connects: %lu\n", info->client_connections);
      if (info->client_connections > 0)
	{
	  fprintf(info->statsfile, "Average listener time: %s\n", 
		  nice_time ((int) ((float) (cc + info->client_connect_time) /
				    (float) info->client_connections)));
	  fprintf(info->statsfile, "Average listener transfer: %lu bytes\n",
		  (unsigned long int) ((float)info->total_written / 
				       (float)info->client_connections));
	}
      if (info->source_connections > 0)
	{
	  fprintf(info->statsfile, "Average source connect time: %s\n",
		  nice_time ((int) ((float) (ec + info->source_connect_time) / 
				    (float) info->source_connections)));
	  fprintf(info->statsfile, "Average source transfer: %lu bytes\n",
		  (unsigned long int) ((float)info->total_read / 
				       (float) info->source_connections));
	}
    }
  fclose(info->statsfile);
  write_log(info, "writing to stats logfile %s...", info->statsfilename);
}

