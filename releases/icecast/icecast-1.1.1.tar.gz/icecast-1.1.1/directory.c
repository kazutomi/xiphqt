/* directory.c
 * - Directory Server Functions
 *
 * Copyright (c) 1999 Jack Moffitt, Barath Raghavan, and Alexander Hav�ng
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "directory.h"

extern server_info_t info;

char *url_encode(char *string)
{
	char *temp;
	int i;

	temp = (char *)malloc(strlen(string) + 1);
	strcpy(temp, string);

	for (i = 0; i < strlen(temp); i++)
		if (temp[i] == ' ') 
			temp[i] = '+';

	return temp;
}

void directory_add(directory_server_t *ds)
{
	int sockfd, error, err;
	char *s, *temp;
	char *response;

	error = err = 0;
	response = NULL;

	if (!ds || ds->host == NULL)
	  {
	    write_log (&info, "Refuse to connect to null hostname");
	    return;
	  }

	write_log (&info, "Adding server to directory server [%s]", ds->host);

#ifdef DEBUG_DIRECTORY
	write_log (&info, "Sending GET /cgi-bin/addsrc?v=1&m=%i&br=%i&p=%i&t=%s&g=%s&url=%s HTTP/1.0\n\n", info.max_clients, info.bitrate, info.port, url_encode(info.name), url_encode(info.genre), url_encode(info.url));
#endif

	if ((sockfd = sock_connect(ds->host, 80)) != -1) {
	  sock_write(sockfd, "GET /cgi-bin/addsrv?v=1&m=%i&br=%i&p=%i&t=%s&g=%s&url=%s HTTP/1.0\n\n", info.max_clients, info.bitrate, info.port, url_encode(info.name), url_encode(info.genre), url_encode(info.url));
	  
		/* Skip HTTP Header */
		do {
			err = sock_read(sockfd, &s);
		} while (err == 1 && strcmp(s, "") != 0);

		do {
			err = sock_read(sockfd, &s);

			temp = strstr(s, "icy-response:");
			if (temp != NULL) response = (char *)(temp + 13);
			temp = strstr(s, "icy-id:");
			if (temp != NULL) ds->id = atoi((char *)(temp + 7));
			temp = strstr(s, "icy-tchfrq:");
			if (temp != NULL) info.touch_freq = atoi((char *)(temp + 11));
			temp = strstr(s, "icy-error:");
			if (temp != NULL) error = atoi((char *)(temp + 10));
		} while (err == 1 && strcmp(s, "") != 0);

		if (response != NULL && strstr(response, "ack") != NULL) {
			write_log(&info, "directory_add() completed...server id = %i and touch frequency = %i", ds->id, info.touch_freq);
		} else {
			write_log(&info, "directory_add() failed... directory server error #%i...", error);
		}

		close(sockfd);
	} else {
		write_log(&info, "directory_add() failed");
	}
}

void directory_touch(directory_server_t *ds)
{
	int sockfd, error, err, avt, i, t, cc = 0;
	char *s, *temp;
	char *response;

	error = err = 0;
	response = NULL;
	
	if (!ds || ds->host == NULL)
	  {
	    write_log (&info, "Refuse to touch a NULL host");
	    return;
	  }

	/* Average listener time */

	t = get_time ();

	/* What's this for? Well, the connect time statistics does not
	   cover the current connections. So we need to extract that */
	for (i = 0; i < info.max_clients; i++)
	  {
	    if (info.clients[i].sock == -1)
	      continue;
	    cc = cc + (t - info.clients[i].connect_time);
	  }
	
	if (info.client_connections > 0)
		avt = (int)((float)(cc + info.client_connect_time) / (float)info.client_connections);
	else
		avt = 0;

#ifdef DEBUG_DIRECTORY
	write_log (&info, "Sending: GET /cgi-bin/tchsrc?id=%i&p=%i&li=%i&alt=%d HTTP/1.0\n\n", 
		   ds->id, info.port, info.num_clients, avt);
#endif

	if ((sockfd = sock_connect(ds->host, 80)) != -1) {
		sock_write(sockfd, "GET /cgi-bin/tchsrv?id=%i&p=%i&li=%i&alt=%d HTTP/1.0\n\n", ds->id, info.port, info.num_clients, avt);

		/* Skip HTTP Header */
		do {
			err = sock_read(sockfd, &s);
		} while (err == 1 && strcmp(s, "") != 0);

		do {
			err = sock_read(sockfd, &s);
			temp = strstr(s, "icy-response:");
			if (temp != NULL) response = (char *)(temp + 13);
			temp = strstr(s, "icy-error:");
			if (temp != NULL) error = atoi((char *)(temp + 10));
		} while (err == 1 && strcmp(s, "") != 0);

		if (response != NULL && strstr(response, "ack") != NULL) {
			write_log(&info, "directory_touch([%s]) completed...", ds->host);
		} else {
			write_log(&info, "directory_touch([%s]) failed... directory server error #%i...",
				  ds->host, error);
		}

		close(sockfd);
	} else {
		write_log(&info, "directory_touch([%s]) failed", ds->host);
	}
}

void directory_remove(directory_server_t *ds)
{
	int sockfd, error, err;
	char *s, *temp;
	char *response;

	error = err = 0;
	response = NULL;

	if (!ds || ds->host == NULL)
	  {
	    write_log (&info, "Refuse to remove null host");
	    return;
	  }

	if ((sockfd = sock_connect(ds->host, 80)) != -1) {
		sock_write(sockfd, "GET /cgi-bin/remsrv?id=%i&p=%i HTTP/1.0\n\n", ds->id, info.port);

		/* Skip HTTP Header */
		do {
			err = sock_read(sockfd, &s);
		} while (err == 1 && strcmp(s, "") != 0);

		do {
			err = sock_read(sockfd, &s);
			temp = strstr(s, "icy-response:");
			if (temp != NULL) response = (char *)(temp + 13);
			temp = strstr(s, "icy-error:");
			if (temp != NULL) error = atoi((char *)(temp + 10));
		} while (err == 1 && strcmp(s, "") != 0);

		if (response != NULL && strstr(response, "ack") != NULL) {
			write_log(&info, "directory_remove([%s]) completed...", ds->host);
		} else {
			write_log(&info, "directory_remove([%s]) failed... directory server error #%i...", ds->host, error);
		}

		close(sockfd);
	} else {
		write_log(&info, "directory_remove([%s]) failed", ds->host);
	}
}
