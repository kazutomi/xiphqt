/* listen to the shouting v 0.1.2.1
   980112 eel@musiknet.se
   Compile with: gcc -O<lots> -o listen listen.c
   Run with: listen <host> <port> | mpg123 -
   Or with: listen <host> <port> <proxy> <proxy_port> | mpg123 -
   The proxy modificates are done by Tim Jansen <tjansen@gmx.net>
   NOTE:
   Lately, mpg123 (version 0.59p-pre) has been handling http-streams
   very nicely. So this program is more or less obsolete, unless you
   want to dump the mp3-stream to a file.
   -
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.
*/
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <netdb.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <shout.h>

/* Set this to something optimal */
#define LBUFSIZE 8192

/* You want a truckload of debugging output? */
#undef DEBUG 0

int s;
char buf[LBUFSIZE];

void s1gnal (const int sig);
void strip_ice_header (char *buf, int len);
void strip_shout_header (char *buf, int len);

int
main (int argc, char **argv)
{
  int n, len, proxy = 0;
  char *contactport, *contacthost;	
  struct hostent *hp;
  struct sockaddr_in name;

  if ((argc < 3) || (argc == 4))
    {
     if ((argc > 1 ) && (strncmp (argv[1], "-v", 2) == 0))
       printf ("listen version 0.1.2 <eel@musiknet.se>\n");
     else
       fprintf (stderr, "Usage: %s <hostname> <port> [<proxy> <proxyport>].\n",
		argv[0]);	
     exit (1);
    }

  contacthost = argv[1];
  contactport = argv[2];

  if (argc == 5)
    {
      proxy = 1;
      contacthost = argv[3];
      contactport = argv[4];
      fprintf (stderr, "Using proxy %s:%s...\n", contacthost, contactport);
    }
  
  if ((hp = gethostbyname (contacthost)) == NULL)
    {
      fprintf (stderr, "unknown host: %s.\n", contacthost);
      exit (1);
    }

  /* Create socket */
  if ((s = socket (AF_INET, SOCK_STREAM, 6)) < 0)
    {
      perror ("socket:");
      exit (1);
    }

  /* Create server adress */
  memset (&name, 0, sizeof (struct sockaddr_in));
  name.sin_family = AF_INET;
  name.sin_port = htons (atoi (contactport));
  memcpy (&name.sin_addr, hp->h_addr_list[0], hp->h_length);
  len = sizeof (struct sockaddr_in);

  /* Connect to the server */
  fprintf (stderr, "Connecting to %s port %s\n", contacthost, contactport);
  if (connect (s, (struct sockaddr *) &name, len) < 0)
    {
      fprintf (stderr, "Could not connect to %s.\n", contacthost);
      perror ("connect:");
      exit (1);
    }
  
#ifdef USE_ASYNC_AND_NONBLOCK
  /* Set socker operations. Whether this is good or bad, you tell me :) */
  fprintf (stderr, "Setting socket operation\n");
  if (fcntl (s, F_SETFL, O_NONBLOCK) == -1)
    fprintf (stderr, "fcntl failed\n");
  if (fcntl (s, F_SETFL, O_ASYNC) == -1)
    fprintf (stderr, "fcntl 2 failed\n");
#endif

  signal (SIGPIPE, s1gnal);
  signal (SIGINT, s1gnal);

  setsockopt (s, SOL_SOCKET, SO_LINGER, NULL, 0);
  setsockopt (s, SOL_SOCKET, SO_KEEPALIVE, NULL, 0);

  /* Read from standard input and put on the socket */
  if (proxy)
#ifdef HAVE_SNPRINTF
    snprintf (buf, LBUFSIZE, "GET http://%s:%s/ HTTP/1.0\r\nHOST: %s\r\nAccept: */*\r\n\r\n", argv[1], argv[2], argv[1]);
#else
    sprintf (buf, "GET http://%s:%s/ HTTP/1.0\r\nHOST: %s\r\nAccept: */*\r\n\r\n", argv[1], argv[2], argv[1]);
#endif
  else
    {
      my_snprintf (buf, LBUFSIZE, 
		   "GET / HTTP/1.0\r\nHost: %s\r\nAccept: */*\r\n\r\n", 
		   argv[1]);
    }
  send (s, buf, strlen (buf), 0);
  if ((n = read (s, buf, LBUFSIZE)) < 0)
    {
      fprintf (stderr, "Error in read, damn.\n");
      perror ("read");
      exit (1);
    }

  if (n < LBUFSIZE)
    n += read (s, &buf[n], LBUFSIZE - n);

  /* The server should reply with, HTTP/1.0 200 OK\nServer: whatever/VERSION\n
     Content-type: audio/x-mpeg\n\n */
  /* or, if it's shoutcast, it says:
     ICY 200 OK^M
     icy-notice1:<BR>This stream requires <a href="http://www.winamp.com/">
     Winamp</a><BR>^M
     icy-notice2:SHOUTcast Distributed Network Audio Server/posix v1.0b<BR>^M
     icy-name:whatever^M
     icy-genre:whatever^M
     icy-url:whatever^M
     icy-pub:1^M
     icy-br:128^M
     ^M
  */
  if (buf[0] == 'H')
    strip_ice_header (buf, n);
  else
    strip_shout_header (buf, n);
  fprintf (stderr, "Reading from socket\n");
  while ((n = read (s, buf, LBUFSIZE)) > 0)
    {
#ifdef DEBUG
      fprintf (stderr, "%d\n", n); /* Tells us how much each read() read */
#endif
      write (1, buf, n);
    }
  fprintf (stderr, "No more data, closing down socket\n");
  close (s);
  exit (0);
}

void
strip_shout_header (char *buf, int n)
{
  int i;
  char reply[1024];
  for (i = 0; i < n; i++)
    {
      if (buf[i] == 10 && buf[i + 1] == 13)
	break;
    }
  memcpy (reply, buf, i + 2);
  reply[i + 2] = '\0';
  fprintf (stderr, "Server said:%s\n", reply);
  write (1, &buf[i + 2], n - (i + 2));
}

void
strip_ice_header (char *buf, int n)
{
  char reply[1024];
  int i;
  for (i = 0; i < n; i++)
    {
      if ((buf[i] == '\n') && (buf[i + 1] == '\n'))
	break;
    }
  memcpy (reply, buf, i + 2); /* including the last '\n' */
  reply[i + 2] = '\0';
  fprintf (stderr, "Server said:%s\n", reply);
  /* puke out the rest of buf */
  write (1, &buf[i + 2], n - (i + 2));
}

void 
s1gnal (const int sig)
{
  switch (sig)
    {
      case SIGPIPE:
	fprintf (stderr, 
		 "Caught signal %d, guess the player exited. Damn.\n", sig);
#ifdef DEBUG
	fprintf (stderr, "The last we fead it was:\n[%s]\n", buf);
	fprintf (stderr, "Which, in hex would be:\n[%p]\n", buf);
#endif
	exit (1);
	break;
      case SIGINT:
	fprintf (stderr, "Caught signal %d, exiting nicely.\n", sig);
	close (s);
	exit (0);
	break;
    }
}







