
extern char* convert_to_utf8(const char *);
extern char* convert_from_utf8(const char *);

