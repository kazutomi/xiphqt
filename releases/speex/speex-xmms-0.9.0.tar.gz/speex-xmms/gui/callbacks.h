#include <gtk/gtk.h>


void
on_config_useproxy_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_config_proxyauth_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_config_savestream_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

extern void spx_config_save (GtkButton *);

/*
void
spx_config_save                        (GtkButton       *button,
                                        gpointer         user_data);
*/


void
on_config_usetitle_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
