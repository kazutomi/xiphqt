#ifndef __HTTP_H__
#define __HTTP_H__

extern int speex_http_open(char *url);
extern int speex_http_read(gpointer data, gint length);
extern void speex_http_close(void);

/* Unused so far
gchar *vorbis_http_get_title(gchar *url);
gint vorbis_http_get_ice_bitrate(void);
*/

#endif  /* __HTTP_H__ */
