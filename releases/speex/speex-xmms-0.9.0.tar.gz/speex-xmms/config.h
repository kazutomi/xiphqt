
#ifndef __CONFIG_H__
#define __CONFIG_H__

extern void spx_config (void);
extern void spx_config_load (void);
extern void spx_config_save(GtkButton *);
#endif
