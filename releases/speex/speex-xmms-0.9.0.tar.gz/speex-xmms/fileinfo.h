/* Speex Xmms plugin
 * (c) Jens Burkal, license: GPL
 */

#ifndef __FILEINFO_H__
#define __FILEINFO_H__

extern void spx_fileinfo(char* filename);

#endif

