object DelphiTestForm: TDelphiTestForm
  Left = 192
  Top = 62
  BorderStyle = bsToolWindow
  Caption = 'Speex Audio in Delphi Demo'
  ClientHeight = 339
  ClientWidth = 348
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 8
    Top = 8
    Width = 78
    Height = 13
    Caption = 'Wave In Device'
  end
  object Label2: TLabel
    Left = 8
    Top = 40
    Width = 86
    Height = 13
    Caption = 'Wave Out Device'
  end
  object Label3: TLabel
    Left = 8
    Top = 72
    Width = 80
    Height = 13
    Caption = 'Encoding Quality'
  end
  object Label4: TLabel
    Left = 96
    Top = 96
    Width = 17
    Height = 13
    Caption = 'Min'
  end
  object Label5: TLabel
    Left = 320
    Top = 96
    Width = 20
    Height = 13
    Caption = 'Max'
  end
  object Label6: TLabel
    Left = 224
    Top = 114
    Width = 44
    Height = 13
    Caption = 'ByteRate'
  end
  object Label7: TLabel
    Left = 8
    Top = 216
    Width = 108
    Height = 13
    Caption = 'Simulated Packet Loss'
  end
  object Label8: TLabel
    Left = 8
    Top = 280
    Width = 134
    Height = 13
    Caption = 'Simulated Packet Corruption'
  end
  object Label9: TLabel
    Left = 4
    Top = 256
    Width = 26
    Height = 13
    Caption = 'None'
  end
  object Label10: TLabel
    Left = 328
    Top = 256
    Width = 11
    Height = 13
    Caption = 'All'
  end
  object Label11: TLabel
    Left = 4
    Top = 320
    Width = 26
    Height = 13
    Caption = 'None'
  end
  object Label12: TLabel
    Left = 328
    Top = 320
    Width = 11
    Height = 13
    Caption = 'All'
  end
  object WaveInDevBox: TComboBox
    Left = 108
    Top = 5
    Width = 229
    Height = 21
    Style = csDropDownList
    ItemHeight = 13
    TabOrder = 0
    OnChange = WaveInDevBoxChange
  end
  object WaveOutDevBox: TComboBox
    Left = 108
    Top = 37
    Width = 229
    Height = 21
    Style = csDropDownList
    ItemHeight = 13
    TabOrder = 1
    OnChange = WaveOutDevBoxChange
  end
  object QualityBar: TTrackBar
    Left = 96
    Top = 68
    Width = 246
    Height = 25
    Orientation = trHorizontal
    Frequency = 1
    Position = 10
    SelEnd = 0
    SelStart = 0
    TabOrder = 2
    ThumbLength = 15
    TickMarks = tmBottomRight
    TickStyle = tsAuto
    OnChange = QualityBarChange
  end
  object PerceptualPFCheck: TCheckBox
    Left = 8
    Top = 112
    Width = 201
    Height = 17
    Caption = 'Perceptual Post-Filter (Decoding Only)'
    TabOrder = 3
    OnClick = PerceptualPFCheckClick
  end
  object ByteRetEdit: TEdit
    Left = 272
    Top = 112
    Width = 65
    Height = 21
    ReadOnly = True
    TabOrder = 4
  end
  object VBRCheck: TCheckBox
    Left = 8
    Top = 136
    Width = 137
    Height = 17
    Caption = 'Variable Bit Rate (VBR)'
    TabOrder = 5
    OnClick = VBRCheckClick
  end
  object VADCheck: TCheckBox
    Left = 8
    Top = 160
    Width = 169
    Height = 17
    Caption = 'Voice Activity Detection (VAD)'
    TabOrder = 6
    OnClick = VADCheckClick
  end
  object DTXCheck: TCheckBox
    Left = 8
    Top = 184
    Width = 185
    Height = 17
    Caption = 'Discontinuous Transmission (DTX)'
    TabOrder = 7
    OnClick = DTXCheckClick
  end
  object PacketLossBar: TTrackBar
    Left = 6
    Top = 228
    Width = 335
    Height = 25
    Max = 100
    Orientation = trHorizontal
    Frequency = 10
    Position = 0
    SelEnd = 0
    SelStart = 0
    TabOrder = 8
    ThumbLength = 15
    TickMarks = tmBottomRight
    TickStyle = tsAuto
    OnChange = PacketLossBarChange
  end
  object PacketCorruptionBar: TTrackBar
    Left = 6
    Top = 292
    Width = 336
    Height = 25
    Max = 100
    Orientation = trHorizontal
    Frequency = 10
    Position = 0
    SelEnd = 0
    SelStart = 0
    TabOrder = 9
    ThumbLength = 15
    TickMarks = tmBottomRight
    TickStyle = tsAuto
    OnChange = PacketCorruptionBarChange
  end
  object Timer1: TTimer
    Enabled = False
    Interval = 1
    OnTimer = Timer1Timer
  end
end
