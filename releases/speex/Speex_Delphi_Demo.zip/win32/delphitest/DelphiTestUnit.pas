unit DelphiTestUnit;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Speex, MMSystem, StdCtrls, contnrs, ExtCtrls, WaveOutThread, ComCtrls;

type
  TDelphiTestForm = class(TForm)
    Label1: TLabel;
    WaveInDevBox: TComboBox;
    Label2: TLabel;
    WaveOutDevBox: TComboBox;
    Timer1: TTimer;
    Label3: TLabel;
    QualityBar: TTrackBar;
    Label4: TLabel;
    Label5: TLabel;
    PerceptualPFCheck: TCheckBox;
    Label6: TLabel;
    ByteRetEdit: TEdit;
    VBRCheck: TCheckBox;
    VADCheck: TCheckBox;
    DTXCheck: TCheckBox;
    PacketLossBar: TTrackBar;
    Label7: TLabel;
    PacketCorruptionBar: TTrackBar;
    Label8: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure WaveInDevBoxChange(Sender: TObject);
    procedure WaveOutDevBoxChange(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure QualityBarChange(Sender: TObject);
    procedure PerceptualPFCheckClick(Sender: TObject);
    procedure VADCheckClick(Sender: TObject);
    procedure VBRCheckClick(Sender: TObject);
    procedure DTXCheckClick(Sender: TObject);
    procedure PacketLossBarChange(Sender: TObject);
    procedure PacketCorruptionBarChange(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  DelphiTestForm: TDelphiTestForm;

  smpRt: integer = 8000; // The Sampling rate
  recordBuff: array of SmallInt;
  recording: boolean = false;
  simPacketLoss: single = 0;
  simPacketCorruption: single = 0;

  // Encoding //
  encbits: TSpeexBits;
  encstate: Pointer;
  encframe: integer;

  buffEnc: array of single;

  // Decoding //
  decbits: TSpeexBits;
  decstate: Pointer;
  decframe: integer;

  buffDec: array of single;

  // Wave In/Out //
  hWI: HWAVEIN = 0;
  hWO: HWAVEOUT = 0;

  inHdrs: array[0..2] of TWaveHdr;
  inBuffs: array[0..2] of array of SmallInt;

  outHdrs: array[0..2] of TWaveHdr;
  outBuffs: array[0..2] of array of SmallInt;

  woThread: TWaveOutThread;

  szLastFrame: integer = 0;

implementation

{$R *.DFM}

// Speex Stuff //

// Start the encoding subsystem //
procedure StartEncoding(q: integer);
begin
  speex_bits_init(@encbits);
  encstate := speex_encoder_init(SpeexNbMode);

  speex_encoder_ctl(encstate,SPEEX_SET_SAMPLING_RATE,@smpRt);
  speex_encoder_ctl(encstate,SPEEX_SET_QUALITY,@q);
  speex_encoder_ctl(encstate,SPEEX_SET_VBR_QUALITY,@q);
  speex_encoder_ctl(encstate,SPEEX_GET_FRAME_SIZE,@encframe);
end;

// Stop the encoding subsystem //
procedure StopEncoding;
begin
  speex_bits_destroy(@encbits);
  speex_encoder_destroy(encstate);
end;

// Start the decoding subsystem //
procedure StartDecoding(enh: integer);
begin
  speex_bits_init(@decbits);
  decstate := speex_decoder_init(SpeexNbMode);

  speex_decoder_ctl(decstate,SPEEX_GET_FRAME_SIZE,@decframe);
  //enh := 0; // 1 to turn on perceptual post-filtering
  speex_decoder_ctl(decstate,SPEEX_SET_ENH,@enh);
end;

// Stop the decoding subsystem //
procedure StopDecoding;
begin
  speex_bits_destroy(@decbits);
  speex_decoder_destroy(decstate);
end;

// Encode whatever is in recordBuff and leave it in strm //
// Begin in the ps-th block of encframe size
procedure EncodeRecordBuff(ps: integer; strm: TStream);
var
  sz,i,offs: integer;
  buffBytes: array of byte;
begin
  // Obtain and transform the next block //
  offs := ps*encframe;
  for i:=0 to encframe-1 do
    buffEnc[i] := recordBuff[offs+i]{/$7FFF};

  // Encode the sound data //
  speex_bits_reset(@encbits);
  speex_encode(encstate,@buffEnc[0],@encbits);
  sz := speex_bits_nbytes(@encbits);
  SetLength(buffBytes,sz);
  speex_bits_write(@encbits,@buffBytes[0],sz);

  // Write it to the Stream //
  strm.WriteBuffer(sz,sizeof(sz)); // The size of the packet
  strm.WriteBuffer(buffBytes[0],sz); // The packet itself
end;

// Decode the stream to recordBufff //
procedure DecodeStream(strm: TStream);
var
  sz,l,i: integer;
  buffBytes: array of byte;
begin
  while strm.Position<strm.Size do begin
    // Read how many bytes has this packet //
    strm.ReadBuffer(sz,sizeof(sz));

    // Prepare the temporal buffer for the packet //
    SetLength(buffBytes,sz);

    // Read the whole packet //
    strm.ReadBuffer(buffBytes[0],sz);

    // Decode the Data //
    speex_bits_read_from(@decbits,@buffBytes[0],sz);
    speex_decode(decstate,@decbits,@buffDec[0]);

    // Increment hte size of recordBuff by the size of the recordFrame //
    l := Length(recordBuff);
    SetLength(recordBuff,l+decframe);

    for i:=0 to decframe-1 do begin
      recordBuff[l+i] := Round(buffDec[i]{*$7FFF});
    end;
  end;
end;

// Wave In/Out Stuff //
procedure wiCback(wi: HWAVEIN; uMsg: LongWord;
                  dwInstance,dwParam1,dwParam2: LongWord); stdcall;
var
  sz,l,i,idx: integer;
  buffBytes: array of byte;
begin
  case uMsg of
    WIM_DATA: begin
      idx := PWaveHdr(dwParam1).dwUser;

{      if recording then begin
        l := Length(recordBuff);
        sz := Length(inBuffs[idx]);
        SetLength(recordBuff,l+sz);
        CopyMemory(@recordBuff[l],@inBuffs[idx,0],sz*Sizeof(inBuffs[idx,0]));
      end;}

      for i:=0 to High(inBuffs[idx]) do
        buffEnc[i] := inBuffs[idx,i];

      speex_bits_reset(@encbits);
      speex_encode(encstate,@buffEnc[0],@encbits);
      sz := speex_bits_nbytes(@encbits);
      SetLength(buffBytes,sz);
      speex_bits_write(@encbits,@buffBytes[0],sz);

      szLastFrame := sz;

      // This is a demo, okay! :) so let's decode it again //

      // Simulate packet loss //
      if random<simPacketLoss then
        speex_bits_read_from(@decbits,nil,0)
      else begin
        // Simulate packet corruption //
        if random<simPacketCorruption then begin
          for i:=0 to random(Length(buffBytes))-1 do
            buffBytes[random(Length(buffBytes))] := random(256);
        end;

        speex_bits_read_from(@decbits,@buffBytes[0],sz);
      end;
      speex_decode(decstate,@decbits,@buffDec[0]);

//      CopyMemory(@outBuffs[idx,0],@inBuffs[idx,0],decFrame*sizeof(outBuffs[idx,0]));
      buffBytes := nil;

      for i:=0 to High(outBuffs[idx]) do
        outBuffs[idx,i] := Round(buffDec[i]);

    end;
  end;
end;

{ TDelphiTestForm }

procedure TDelphiTestForm.FormCreate(Sender: TObject);
var
  i,ndevs: integer;
  wiCaps: TWaveInCaps;
  woCaps: TWaveOutCaps;
begin
  randomize;

  ndevs := waveInGetNumDevs;
  for i:=0 to ndevs-1 do begin
    if waveInGetDevCaps(i,@wiCaps,sizeof(wiCaps))=MMSYSERR_NOERROR then begin
      WaveInDevBox.Items.Add(wiCaps.szPname);
    end;
  end;

  ndevs := waveOutGetNumDevs;
  for i:=0 to ndevs-1 do begin
    if waveOutGetDevCaps(i,@woCaps,sizeof(woCaps))=MMSYSERR_NOERROR then begin
      WaveOutDevBox.Items.Add(woCaps.szPname);
    end;
  end;

  // Begin encoding SpeexAudio //
  StartEncoding(10);
  // Begin decoding SpeexAudio //
  StartDecoding(0);

  SetLength(buffEnc,encframe);
  SetLength(buffDec,decframe);

  WaveInDevBox.ItemIndex := 0;
  WaveOutDevBox.ItemIndex := 0;

  WaveInDevBoxChange(self);
  WaveOutDevBoxChange(self);

  woThread := TWaveOutThread.Create(false);

  Timer1.Enabled := true;
end;

procedure TDelphiTestForm.FormDestroy(Sender: TObject);
begin
  woThread.Terminate;
  woThread.free;
  
  waveInReset(hWI);
  waveInClose(hWI);
  waveOutClose(hWO);

  StopEncoding;
  StopDecoding;
end;

procedure TDelphiTestForm.WaveInDevBoxChange(Sender: TObject);
var
  wfx: TWaveFormatEx;
  i: integer;
begin
  with wfx do begin
    wFormatTag      := WAVE_FORMAT_PCM;
    nChannels       := 1;
    nSamplesPerSec  := smpRt;
    wBitsPerSample  := 16;
    nBlockAlign     := nChannels*wBitsPerSample div 8;
    nAvgBytesPerSec := nSamplesPerSec*nBlockAlign;
    cbSize          := 0;
  end;

  waveInReset(hWI);
  waveInClose(hWI);
  if waveInOpen(@hWI,WaveInDevBox.ItemIndex,@wfx,Cardinal(@wiCback),0,
                CALLBACK_FUNCTION or WAVE_MAPPED)<>MMSYSERR_NOERROR then begin
    raise Exception.Create('Cannot open WaveIn Device');
    exit;
  end;

  for i:=0 to High(inHdrs) do begin
    SetLength(inBuffs[i],encframe);
    inHdrs[i].lpData := @inBuffs[i,0];
    inHdrs[i].dwBufferLength := Length(inBuffs[i])*sizeof(inBuffs[i,0]);
    inHdrs[i].dwFlags := 0;
    inHdrs[i].dwUser := i;

    if waveInPrepareHeader(hWI,@inHdrs[i],sizeof(inHdrs[i]))<>
       MMSYSERR_NOERROR then begin
      raise Exception.Create('Cannot prepare WaveHdr record');
      exit;
    end;

    if waveInAddBuffer(hWI,@inHdrs[i],sizeof(inHdrs[i]))<>
       MMSYSERR_NOERROR then begin
      raise Exception.Create('Cannot add WaveHdr buffer');
      exit;
    end;
  end;

  if waveInStart(hWI)<>MMSYSERR_NOERROR then begin
    raise Exception.Create('Cannot start WaveIn Device');
    exit;
  end;
end;

procedure TDelphiTestForm.WaveOutDevBoxChange(Sender: TObject);
var
  wfx: TWaveFormatEx;
  i: integer;
begin
  with wfx do begin
    wFormatTag      := WAVE_FORMAT_PCM;
    nChannels       := 1;
    nSamplesPerSec  := smpRt;
    wBitsPerSample  := 16;
    nBlockAlign     := nChannels*wBitsPerSample div 8;
    nAvgBytesPerSec := nSamplesPerSec*nBlockAlign;
    cbSize          := 0;
  end;

  waveOutClose(hWO);
  if waveOutOpen(@hWO,WaveOutDevBox.ItemIndex,
                 @wfx,0,0,WAVE_MAPPED)<>MMSYSERR_NOERROR then begin
    raise Exception.Create('Cannot open WaveOut Device');
  end;

  for i:=0 to High(outHdrs) do begin
    SetLength(outBuffs[i],decframe);
    outHdrs[i].lpData := @outBuffs[i,0];
    outHdrs[i].dwBufferLength := Length(outBuffs[i])*sizeof(outBuffs[i,0]);
    outHdrs[i].dwFlags := 0;

    if waveOutPrepareHeader(hWO,@outHdrs[i],sizeof(outHdrs[i]))<>
       MMSYSERR_NOERROR then begin
      raise Exception.Create('Cannot prepare WaveHdr record');
      exit;
    end;

    if waveOutWrite(hWO,@outHdrs[i],sizeof(outHdrs[i]))<>
       MMSYSERR_NOERROR then begin
      raise Exception.Create('Cannot prepare WaveHdr record');
      exit;
    end;

  end;
end;

procedure TDelphiTestForm.Timer1Timer(Sender: TObject);
var
  i: integer;
begin
  ByteRetEdit.Text := IntToStr(szLastFrame);
  for i:=0 to High(inHdrs) do begin
    if (inHdrs[i].dwFlags and WHDR_DONE)<>0 then begin
      inHdrs[i].dwFlags := 0;

      if waveInPrepareHeader(hWI,@inHdrs[i],sizeof(inHdrs[i]))<>
         MMSYSERR_NOERROR then begin
        raise Exception.Create('Cannot prepare WaveHdr record');
        exit;
      end;

      if waveInAddBuffer(hWI,@inHdrs[i],sizeof(inHdrs[i]))<>
         MMSYSERR_NOERROR then begin
        raise Exception.Create('Cannot add WaveHdr buffer');
        exit;
      end;
    end;
  end;
end;

procedure TDelphiTestForm.QualityBarChange(Sender: TObject);
var
  q: integer;
begin
  q := QualityBar.Position;
  speex_encoder_ctl(encstate,SPEEX_SET_QUALITY,@q);
  speex_encoder_ctl(encstate,SPEEX_SET_VBR_QUALITY,@q);
end;

procedure TDelphiTestForm.PerceptualPFCheckClick(Sender: TObject);
var
  enh: integer;
begin
  if PerceptualPFCheck.Checked then enh := 1
  else enh := 0;

  speex_decoder_ctl(decstate,SPEEX_SET_ENH,@enh);
end;

procedure TDelphiTestForm.VADCheckClick(Sender: TObject);
var
  vad: integer;
begin
  if VADCheck.Checked then vad := 1
  else vad := 0;

  speex_encoder_ctl(encstate,SPEEX_SET_VAD,@vad);
end;

procedure TDelphiTestForm.VBRCheckClick(Sender: TObject);
var
  vbr: integer;
begin
  if VBRCheck.Checked then vbr := 1
  else vbr := 0;

  speex_encoder_ctl(encstate,SPEEX_SET_VBR,@vbr);
end;

procedure TDelphiTestForm.DTXCheckClick(Sender: TObject);
var
  dtx: integer;
begin
  if DTXCheck.Checked then dtx := 1
  else dtx := 0;

  speex_encoder_ctl(encstate,SPEEX_SET_DTX,@dtx);
end;

procedure TDelphiTestForm.PacketLossBarChange(Sender: TObject);
begin
  simPacketLoss := PacketLossBar.Position/PacketLossBar.Max;
end;

procedure TDelphiTestForm.PacketCorruptionBarChange(Sender: TObject);
begin
  simPacketCorruption := PacketCorruptionBar.Position/PacketCorruptionBar.Max;
end;

end.
