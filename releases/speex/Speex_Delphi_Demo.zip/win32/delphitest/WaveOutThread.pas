unit WaveOutThread;

interface

uses SysUtils, Classes;

type
  TWaveOutThread = class(TThread)
  private
    { Private declarations }
  protected
    procedure Execute; override;
  end;

implementation

uses DelphiTestUnit, MMSystem;

{ Important: Methods and properties of objects in VCL can only be used in a
  method called using Synchronize, for example,

      Synchronize(UpdateCaption);

  and UpdateCaption could look like,

    procedure TWaveOutThread.UpdateCaption;
    begin
      Form1.Caption := 'Updated in a thread';
    end; }

{ TWaveOutThread }

procedure TWaveOutThread.Execute;
var
  i: integer;
begin
  while not(self.Terminated) do begin

    for i:=0 to High(outHdrs) do begin
      if (outHdrs[i].dwFlags and WHDR_DONE)<>0 then begin
        outHdrs[i].dwFlags := 0;

       if waveOutPrepareHeader(hWO,@outHdrs[i],sizeof(outHdrs[i]))<>
           MMSYSERR_NOERROR then begin
          raise Exception.Create('Cannot prepare WaveHdr record');
          exit;
        end;

        if waveOutWrite(hWO,@outHdrs[i],sizeof(outHdrs[i]))<>
           MMSYSERR_NOERROR then begin
          raise Exception.Create('Cannot prepare WaveHdr record');
          exit;
        end;

      end;
    end;
  end;
end;

end.
