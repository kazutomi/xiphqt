program DelphiTest;

uses
  Forms,
  DelphiTestUnit in 'DelphiTestUnit.pas' {DelphiTestForm},
  WaveOutThread in 'WaveOutThread.pas';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TDelphiTestForm, DelphiTestForm);
  Application.Run;
end.
