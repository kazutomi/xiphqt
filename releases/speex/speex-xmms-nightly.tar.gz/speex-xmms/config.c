/* Speex Xmms plugin
 * (c) Jens Burkal, license: GPL
 * 
 * config.c: Configuration setup file
 *
 */


static void spx_config (void);
static void spx_config_save (GtkButton *);

static void spx_config_mod_proxy (GtkCheckButton *);
static void spx_config_mod_auth (GtkCheckButton *);
static void spx_config_mod_save (GtkCheckButton *);

static void spx_config_cleanup (void);
static void spx_config_load (void);

// Widgets
static GtkWidget *cfg_window, *cfg_enh_frame, *cfg_enh_check, *cfg_ok_button, *cfg_cancel_button;

static GtkWidget *cfg_buffer_frame, *cfg_buffer_box, *cfg_buffer_label_box, *cfg_buffer_widget_box, *cfg_buffer_label, *cfg_buffer_input, *cfg_buffer_adj, *cfg_prebuf_label, *cfg_prebuf_inp, *cfg_prebuf_adj;

static GtkWidget *cfg_proxy_options_box, *cfg_auth_options_box;
static GtkWidget *cfg_proxy_frame, *cfg_proxy_box, *cfg_use_proxy_check, *cfg_proxy_widget_box, *cfg_proxy_label_box, *cfg_proxy_host_label, *cfg_proxy_host_inp, *cfg_proxy_port_label, *cfg_proxy_port_inp;

static GtkWidget *cfg_proxy_auth_check, *cfg_proxy_auth_widget_box, *cfg_proxy_auth_label_box, *cfg_proxy_user_label, *cfg_proxy_user_inp, *cfg_proxy_pass_label, *cfg_proxy_pass_inp;

static GtkWidget *cfg_stream_frame, *cfg_stream_box, *cfg_stream_save_check;
static GtkWidget *cfg_stream_path_box, *cfg_stream_path_label, *cfg_stream_path_inp;


static void spx_config (void) {

	cfg_window = gtk_dialog_new();
	gtk_window_set_title(GTK_WINDOW(cfg_window), g_strdup("Speex configuration"));
	gtk_window_set_policy(GTK_WINDOW(cfg_window), FALSE, FALSE, TRUE);


	// Enhancer
	cfg_enh_frame = gtk_frame_new(g_strdup("Enhancer"));	
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(cfg_window)->vbox), GTK_WIDGET(cfg_enh_frame));


	cfg_enh_check = gtk_check_button_new_with_label(g_strdup("Enable enhancer"));
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cfg_enh_check), speex_cfg->use_enhancer);
	gtk_container_add(GTK_CONTAINER(cfg_enh_frame), GTK_WIDGET(cfg_enh_check));
	
	
	// Buffer frames
	cfg_buffer_frame = gtk_frame_new(g_strdup("Buffering"));
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(cfg_window)->vbox), GTK_WIDGET(cfg_buffer_frame));
	
	cfg_buffer_box = gtk_hbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(cfg_buffer_frame), GTK_WIDGET(cfg_buffer_box));

	cfg_buffer_label_box = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(cfg_buffer_box), GTK_WIDGET(cfg_buffer_label_box));

	cfg_buffer_widget_box = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(cfg_buffer_box), GTK_WIDGET(cfg_buffer_widget_box));


	// Buffer
	cfg_buffer_label = gtk_label_new(g_strdup("Buffer size (kb):"));
	gtk_label_set_justify(GTK_LABEL(cfg_buffer_label), GTK_JUSTIFY_LEFT);
	gtk_container_add(GTK_CONTAINER(cfg_buffer_label_box), GTK_WIDGET(cfg_buffer_label));
	
	cfg_buffer_adj = gtk_adjustment_new( ((gfloat)speex_cfg->buffersize), 0., 4096., 4., 4., 5.);
	
	cfg_buffer_input = gtk_spin_button_new(GTK_ADJUSTMENT(cfg_buffer_adj), 4., 0);
	if (speex_cfg->buffersize)
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(cfg_buffer_input), speex_cfg->buffersize);
	gtk_spin_button_set_numeric(GTK_SPIN_BUTTON(cfg_buffer_input), TRUE);
	gtk_container_add(GTK_CONTAINER(cfg_buffer_widget_box), GTK_WIDGET(cfg_buffer_input));
	

	// Prebuffer
	cfg_prebuf_label = gtk_label_new(g_strdup("Pre-buffer %:"));
	gtk_label_set_justify(GTK_LABEL(cfg_prebuf_label), GTK_JUSTIFY_LEFT);
	gtk_container_add(GTK_CONTAINER(cfg_buffer_label_box), GTK_WIDGET(cfg_prebuf_label));

	cfg_prebuf_adj = gtk_adjustment_new(speex_cfg->prebuffer, 0, 100, 1, 1, 1);

	cfg_prebuf_inp = gtk_spin_button_new(GTK_ADJUSTMENT(cfg_prebuf_adj), 1, 0);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(cfg_prebuf_inp), speex_cfg->prebuffer);
	gtk_spin_button_set_numeric(GTK_SPIN_BUTTON(cfg_prebuf_inp), TRUE);
	gtk_container_add(GTK_CONTAINER(cfg_buffer_widget_box), GTK_WIDGET(cfg_prebuf_inp));
	

	
	// Proxy frame
	cfg_proxy_frame = gtk_frame_new(g_strdup("Proxy"));
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(cfg_window)->vbox), GTK_WIDGET(cfg_proxy_frame));

	cfg_proxy_box = gtk_vbox_new(FALSE, 10);
	gtk_container_add(GTK_CONTAINER(cfg_proxy_frame), GTK_WIDGET(cfg_proxy_box));
	
	// Proxy configuration	
	cfg_use_proxy_check = gtk_check_button_new_with_label(g_strdup("Use proxy"));
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cfg_use_proxy_check), speex_cfg->use_proxy);
	gtk_signal_connect(GTK_OBJECT(cfg_use_proxy_check), "toggled", GTK_SIGNAL_FUNC(spx_config_mod_proxy), NULL);
	gtk_container_add(GTK_CONTAINER(cfg_proxy_box), GTK_WIDGET(cfg_use_proxy_check));


	// Proxy host
	cfg_proxy_options_box = gtk_hbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(cfg_proxy_box), GTK_WIDGET(cfg_proxy_options_box));
	
	cfg_proxy_label_box = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(cfg_proxy_options_box), GTK_WIDGET(cfg_proxy_label_box));

	cfg_proxy_widget_box = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(cfg_proxy_options_box), GTK_WIDGET(cfg_proxy_widget_box));
	
	if (!speex_cfg->use_proxy) {
		gtk_widget_set_sensitive(cfg_proxy_options_box, FALSE);
	}

	cfg_proxy_host_label = gtk_label_new(g_strdup("Host:"));
	gtk_container_add(GTK_CONTAINER(cfg_proxy_label_box), GTK_WIDGET(cfg_proxy_host_label));
	
	cfg_proxy_host_inp = gtk_entry_new();
	if (speex_cfg->proxy_host)
		gtk_entry_set_text(GTK_ENTRY(cfg_proxy_host_inp), speex_cfg->proxy_host);
	gtk_container_add(GTK_CONTAINER(cfg_proxy_widget_box), GTK_WIDGET(cfg_proxy_host_inp));

	// Proxy port
	cfg_proxy_port_label = gtk_label_new(g_strdup("Port:"));
	gtk_container_add(GTK_CONTAINER(cfg_proxy_label_box), GTK_WIDGET(cfg_proxy_port_label));

	cfg_proxy_port_inp = gtk_entry_new();
	if (speex_cfg->proxy_port)
		gtk_entry_set_text(GTK_ENTRY(cfg_proxy_port_inp), g_strdup_printf("%d", speex_cfg->proxy_port));
	gtk_entry_set_max_length(GTK_ENTRY(cfg_proxy_port_inp), 5);
	gtk_container_add(GTK_CONTAINER(cfg_proxy_widget_box), GTK_WIDGET(cfg_proxy_port_inp));


	// Proxy auth
	cfg_proxy_auth_check = gtk_check_button_new_with_label(g_strdup("Use authentication"));
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cfg_proxy_auth_check), speex_cfg->use_auth);
	gtk_signal_connect(GTK_OBJECT(cfg_proxy_auth_check), "toggled", GTK_SIGNAL_FUNC(spx_config_mod_auth), NULL);
	gtk_container_add(GTK_CONTAINER(cfg_proxy_box), GTK_WIDGET(cfg_proxy_auth_check));
	if (!speex_cfg->use_proxy)
		gtk_widget_set_sensitive(GTK_WIDGET(cfg_proxy_auth_check), FALSE);


	// Proxy username
	cfg_auth_options_box = gtk_hbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(cfg_proxy_box), GTK_WIDGET(cfg_auth_options_box));
	
	cfg_proxy_auth_label_box = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(cfg_auth_options_box), GTK_WIDGET(cfg_proxy_auth_label_box));

	cfg_proxy_auth_widget_box = gtk_vbox_new(FALSE,5);
	gtk_container_add(GTK_CONTAINER(cfg_auth_options_box), GTK_WIDGET(cfg_proxy_auth_widget_box));
	
	if (!speex_cfg->use_proxy || !speex_cfg->use_auth) 
		gtk_widget_set_sensitive(GTK_WIDGET(cfg_auth_options_box), FALSE);
	
	cfg_proxy_user_label = gtk_label_new(g_strdup("Username:"));
	gtk_container_add(GTK_CONTAINER(cfg_proxy_auth_label_box), GTK_WIDGET(cfg_proxy_user_label));
	
	cfg_proxy_user_inp = gtk_entry_new();
	if (speex_cfg->proxy_user)
		gtk_entry_set_text(GTK_ENTRY(cfg_proxy_user_inp), g_strdup(speex_cfg->proxy_user));
	gtk_container_add(GTK_CONTAINER(cfg_proxy_auth_widget_box), GTK_WIDGET(cfg_proxy_user_inp));


	// Proxy password
	cfg_proxy_pass_label = gtk_label_new(g_strdup("Password:"));
	gtk_container_add(GTK_CONTAINER(cfg_proxy_auth_label_box), GTK_WIDGET(cfg_proxy_pass_label));

	cfg_proxy_pass_inp = gtk_entry_new();
	if (speex_cfg->proxy_passwd)
		gtk_entry_set_text(GTK_ENTRY(cfg_proxy_pass_inp), g_strdup(speex_cfg->proxy_passwd));
	gtk_entry_set_visibility(GTK_ENTRY(cfg_proxy_pass_inp), FALSE);
	gtk_container_add(GTK_CONTAINER(cfg_proxy_auth_widget_box), GTK_WIDGET(cfg_proxy_pass_inp));



	// Stream save frame
	cfg_stream_frame = gtk_frame_new(g_strdup("Save stream"));
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(cfg_window)->vbox), GTK_WIDGET(cfg_stream_frame));

	cfg_stream_box = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(cfg_stream_frame), GTK_WIDGET(cfg_stream_box));

	cfg_stream_save_check = gtk_check_button_new_with_label(g_strdup("Save stream"));
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cfg_stream_save_check), speex_cfg->save_stream);
	gtk_container_add(GTK_CONTAINER(cfg_stream_box), GTK_WIDGET(cfg_stream_save_check));
	gtk_signal_connect(GTK_OBJECT(cfg_stream_save_check), "toggled", GTK_SIGNAL_FUNC(spx_config_mod_save), NULL);

	cfg_stream_path_box = gtk_hbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(cfg_stream_box), GTK_WIDGET(cfg_stream_path_box));
	if (!speex_cfg->save_stream)
		gtk_widget_set_sensitive(GTK_WIDGET(cfg_stream_path_box), FALSE);
	
	
	cfg_stream_path_label = gtk_label_new(g_strdup("Path:"));
	gtk_container_add(GTK_CONTAINER(cfg_stream_path_box), GTK_WIDGET(cfg_stream_path_label));

	cfg_stream_path_inp = gtk_entry_new();
	if (speex_cfg->save_path)
		gtk_entry_set_text(GTK_ENTRY(cfg_stream_path_inp), speex_cfg->save_path);

	gtk_container_add(GTK_CONTAINER(cfg_stream_path_box), GTK_WIDGET(cfg_stream_path_inp));
	


	

	// Ok button
	cfg_ok_button = gtk_button_new_with_label(g_strdup("Ok"));
	gtk_signal_connect(GTK_OBJECT(cfg_ok_button), "clicked", GTK_SIGNAL_FUNC(spx_config_save), NULL);
	gtk_signal_connect_object(GTK_OBJECT(cfg_ok_button), "clicked", GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(cfg_window));
	

	// Cancel button
	cfg_cancel_button = gtk_button_new_with_label(g_strdup("Cancel"));
	gtk_signal_connect(GTK_OBJECT(cfg_cancel_button), "clicked", GTK_SIGNAL_FUNC(spx_config_cleanup), NULL);
	gtk_signal_connect_object(GTK_OBJECT(cfg_cancel_button), "clicked", GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(cfg_window));
	

	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(cfg_window)->action_area), cfg_ok_button);
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(cfg_window)->action_area), cfg_cancel_button);

	gtk_widget_show_all(cfg_window);

	return;
}



static void spx_config_mod_proxy (GtkCheckButton *use_proxy) {

	gboolean status, s2;

	status =  gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(use_proxy));

	gtk_widget_set_sensitive(cfg_proxy_options_box, status);
	gtk_widget_set_sensitive(GTK_WIDGET(cfg_proxy_auth_check), status);

	s2 = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(cfg_proxy_auth_check));

	gtk_widget_set_sensitive(GTK_WIDGET(cfg_auth_options_box), (status && s2));
	
	return;
}

static void spx_config_mod_auth (GtkCheckButton *use_auth) {

	gboolean status;


	status = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(use_auth));
	
	gtk_widget_set_sensitive(GTK_WIDGET(cfg_auth_options_box), status);
	
	return;
}

static void spx_config_mod_save (GtkCheckButton *save) {

	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(save)))
		gtk_widget_set_sensitive(GTK_WIDGET(cfg_stream_path_box), TRUE);
	else
		gtk_widget_set_sensitive(GTK_WIDGET(cfg_stream_path_box), FALSE);

}
		

static void spx_config_save (GtkButton *button) {

	ConfigFile *config;

	char *tmp;


	speex_cfg->use_enhancer = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(cfg_enh_check));

	speex_cfg->buffersize = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cfg_buffer_input));
	speex_cfg->prebuffer = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cfg_prebuf_inp));

	speex_cfg->use_proxy = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(cfg_use_proxy_check));
	speex_cfg->use_auth = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(cfg_proxy_auth_check));

	if (speex_cfg->proxy_host)
		g_free(speex_cfg->proxy_host);
	speex_cfg->proxy_host = gtk_editable_get_chars(GTK_EDITABLE(cfg_proxy_host_inp), 0, -1);

	tmp = gtk_editable_get_chars(GTK_EDITABLE(cfg_proxy_port_inp), 0, -1);
	speex_cfg->proxy_port = atoi(tmp);
	g_free(tmp);

	if (speex_cfg->proxy_user)
		g_free(speex_cfg->proxy_user);
	speex_cfg->proxy_user = gtk_editable_get_chars(GTK_EDITABLE(cfg_proxy_user_inp), 0, -1);
	
	if (speex_cfg->proxy_passwd)
		g_free(speex_cfg->proxy_passwd);
	speex_cfg->proxy_passwd = gtk_editable_get_chars(GTK_EDITABLE(cfg_proxy_pass_inp), 0, -1);

	speex_cfg->save_stream = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(cfg_stream_save_check));

	if (speex_cfg->save_path)
		g_free(speex_cfg->save_path);
	speex_cfg->save_path = gtk_editable_get_chars(GTK_EDITABLE(cfg_stream_path_inp), 0, -1);
	
	
	config = xmms_cfg_open_default_file();

	if (config) {
	
		xmms_cfg_write_boolean(config, g_strdup("speex"), g_strdup("use_enhancer"), speex_cfg->use_enhancer);

		xmms_cfg_write_int(config, g_strdup("speex"), g_strdup("buffersize"), speex_cfg->buffersize);
		xmms_cfg_write_int(config, g_strdup("speex"), g_strdup("prebuffer"), speex_cfg->prebuffer);

		xmms_cfg_write_boolean(config, g_strdup("speex"), g_strdup("use_proxy"), speex_cfg->use_proxy);
		xmms_cfg_write_boolean(config, g_strdup("speex"), g_strdup("proxy_auth"), speex_cfg->use_auth);
		
		xmms_cfg_write_string(config, g_strdup("speex"), g_strdup("proxy_host"), speex_cfg->proxy_host);
		xmms_cfg_write_int(config, g_strdup("speex"), g_strdup("proxy_port"), speex_cfg->proxy_port);
		
		xmms_cfg_write_string(config, g_strdup("speex"), g_strdup("proxy_user"), speex_cfg->proxy_user);
		xmms_cfg_write_string(config, g_strdup("speex"), g_strdup("proxy_pass"), speex_cfg->proxy_passwd);
		
		xmms_cfg_write_boolean(config, g_strdup("speex"), g_strdup("save_stream"), speex_cfg->save_stream);
		xmms_cfg_write_string(config, g_strdup("speex"), g_strdup("save_path"), speex_cfg->save_path);

		
		if (!(xmms_cfg_write_default_file(config)))
			fprintf(stderr, SELF ": Error writing default configuration file.\n");
	}
	else
		fprintf(stderr, SELF ": Error opening default configuration file.\n");


	spx_config_cleanup();
	
	return;
}

static void spx_config_cleanup (void) {

	return;
	
}

static void spx_config_load (void) {

	ConfigFile *config;

	config = xmms_cfg_open_default_file();

	if (speex_cfg == NULL)
		speex_cfg = malloc(sizeof(Speex_Configuration));

	memset(speex_cfg, 0, sizeof(Speex_Configuration));
	
	
	if (config) {

		xmms_cfg_read_boolean(config, g_strdup("speex"), g_strdup("use_enhancer"), &speex_cfg->use_enhancer);
		
		xmms_cfg_read_int(config, g_strdup("speex"), g_strdup("buffersize"), &speex_cfg->buffersize);
		xmms_cfg_read_int(config, g_strdup("speex"), g_strdup("prebuffer"), &speex_cfg->prebuffer);

		xmms_cfg_read_boolean(config, g_strdup("speex"), g_strdup("use_proxy"), &speex_cfg->use_proxy);
		xmms_cfg_read_string(config, g_strdup("speex"), g_strdup("proxy_host"), &speex_cfg->proxy_host);
		xmms_cfg_read_int(config, g_strdup("speex"), g_strdup("proxy_port"), &speex_cfg->proxy_port);
		xmms_cfg_read_boolean(config, g_strdup("speex"), g_strdup("proxy_auth"), &speex_cfg->use_auth);
		xmms_cfg_read_string(config, g_strdup("speex"), g_strdup("proxy_user"), &speex_cfg->proxy_user);
		xmms_cfg_read_string(config, g_strdup("speex"), g_strdup("proxy_pass"), &speex_cfg->proxy_passwd);
		xmms_cfg_read_boolean(config, g_strdup("speex"), g_strdup("save_stream"), &speex_cfg->save_stream);
		xmms_cfg_read_string(config, g_strdup("speex"), g_strdup("save_path"), &speex_cfg->save_path);
		
	}
	else
		fprintf(stderr, SELF ": Error reading default configuration file.\n");

}


