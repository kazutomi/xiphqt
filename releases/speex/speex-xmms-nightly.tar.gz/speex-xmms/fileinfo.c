/* Speex Xmms plugin
 * (c) Jens Burkal, license: GPL
 * 
 * fileinfo.c: File information window
 * 
 */


static void spx_fileinfo(char *filename) {

	FILE *spxfile;
	gboolean found_header = FALSE;
	gboolean init = FALSE;
	gboolean streaming = FALSE;
	gchar *data;
	int read;
	gchar *comments = NULL;
	struct stat infostat;

	ogg_sync_state oy;
	ogg_page og;
	ogg_packet op;
	ogg_stream_state os;

	SpeexBits sbits;
	SpeexHeader *header = NULL;
	SpeexMode *mode;
	
	GtkWidget *window, *okbutton, *panel, *infolabel, *commentpanel, *commentlabel;
	int length;


	fprintf(stderr, SELF ": Req file info\n");
	

	if (strstr(filename, g_strdup("http://"))) // In case of a stream, lets show the dialog box anyway
		streaming = TRUE;

	if (streaming) goto show_window;
	
	
	if (!(spxfile = fopen(filename, "rb")))
		return;

	
	length = speex_get_time(filename);

	
	ogg_sync_init(&oy);

	speex_bits_init(&sbits);

	while (!found_header || feof(spxfile)) {
		
		data = ogg_sync_buffer(&oy, 200);

		read = fread(data, sizeof(char), 200, spxfile);

		ogg_sync_wrote(&oy, read);

		while (ogg_sync_pageout(&oy, &og) == 1) {

			if (!init) {
				ogg_stream_init(&os, ogg_page_serialno(&og));
				init = TRUE;
			}

			ogg_stream_pagein(&os, &og);

			while (ogg_stream_packetout(&os, &op) == 1) {

				if (op.b_o_s) {
					
					header = speex_packet_to_header((char*)op.packet, op.bytes);

					mode = speex_mode_list[header->mode];

				} else if (op.packetno == 1) {

					comments = malloc(op.bytes+1);
					
					memset(comments, 0, op.bytes+1);

					comments = memcpy(comments, op.packet, op.bytes);
					found_header = TRUE;
					
				}
					

			}

		}

	}

	if (header == NULL) {
		fprintf(stderr, SELF ": could not find header\n");
		return;
	}

	
	speex_bits_destroy(&sbits);
	ogg_stream_clear(&os);

	stat(filename, &infostat);

show_window:
	
	window = gtk_dialog_new();
	gtk_window_set_title(GTK_WINDOW(window), g_strdup_printf("File info - %s", (char*)generate_title(filename, TRUE)));

	panel = gtk_frame_new(g_strdup("Speex info"));
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(window)->vbox), panel);

	commentpanel = gtk_frame_new(g_strdup("Comment"));
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(window)->vbox), commentpanel);

	if (streaming)
		infolabel = gtk_label_new(g_strdup("\nVersion:\nMode:\nSamplerate:  Hz\nChannels:\nLength:\nFile size:\n"));
	else
		infolabel = gtk_label_new(g_strdup_printf("\nVersion: %s\nMode: %s\nSamplerate: %d Hz\nChannels: %d\nLength: %d:%02d\nFile size: %d B\n",
				header->speex_version, mode->modeName, header->rate, header->nb_channels, length / 60, length % 60, (int)infostat.st_size));
	
	gtk_label_set_justify(GTK_LABEL(infolabel), GTK_JUSTIFY_LEFT);
	gtk_container_add(GTK_CONTAINER(panel), infolabel);

	commentlabel = gtk_label_new(comments);
	gtk_label_set_justify(GTK_LABEL(commentlabel), GTK_JUSTIFY_LEFT);
	gtk_container_add(GTK_CONTAINER(commentpanel), commentlabel);
	if (comments)
		g_free(comments);

	if (streaming) {
		gtk_widget_set_sensitive(GTK_WIDGET(panel), FALSE);
		gtk_widget_set_sensitive(GTK_WIDGET(commentpanel), FALSE);
	}
	
	okbutton = gtk_button_new_with_label(g_strdup("Ok"));
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(window)->action_area), okbutton);
	gtk_signal_connect_object(GTK_OBJECT(okbutton), "clicked", GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(window));
	gtk_widget_grab_focus(GTK_WIDGET(okbutton));

	gtk_widget_show_all(window);


}
	
	

				

					
		
	
			

