/* Speex Xmms plugin
 * (c) Jens Burkal, license: GPL
 * 
 * config.c: Configuration setup file
 * 
 */


static int speex_seek(FILE* spxfile, int time, char direction, int freq) {
// time: time in seconds (as provided by xmms)
// direction: 0 for backward, 1 for forward
// returns the position (i msecs) where it seeked to
	
	char *data;
	int readbytes, result;
	
	ogg_sync_state oy;
	ogg_page og;

#ifdef DEBUG
	fprintf(stderr, SELF ": seek to: %d\n", time);
#endif

	if (direction == 0)
		fseek(spxfile, 0, SEEK_SET);
	
	ogg_sync_init(&oy);

	do {

		while (ogg_sync_pageout(&oy, &og) != 1) {
			
			data = ogg_sync_buffer(&oy, 200);
			
			readbytes = fread(data, 1, 200, spxfile);
			
			ogg_sync_wrote(&oy, readbytes);
		
		}
		

	} while (ogg_page_granulepos(&og) < time * freq);


	result = ogg_page_granulepos(&og) * 1000 / freq;
	
#ifdef DEBUG
	fprintf(stderr, SELF ": seeked to: %d.%d\n", result / 1000, result % 1000);
#endif

	ogg_sync_clear(&oy);

	return result;

}

	


static int speex_get_time (char* filename) {
// This could be simpler since we don't actually need stream_state and packets
// (just like when seeking). However we do need the samplerate, so we need to
// get the header-packet

	FILE *spxfile = NULL;
	int eof = FALSE;
	int rbytes;
	char init = 0;
	int maxsize = 0;
	char *data;

	ogg_sync_state oy;
	ogg_stream_state os;
	ogg_page og;
	ogg_packet op;

	SpeexHeader *header = NULL;

	ogg_sync_init(&oy);
	
	if (!(spxfile = fopen(filename, "rb"))) {
		fprintf(stderr, SELF ": could not open file\n");
		return -1;
	}
	

	while (!eof) {

		data = ogg_sync_buffer(&oy, 200);

		rbytes = fread(data, 1, 200, spxfile);

		ogg_sync_wrote(&oy, rbytes);

		if (rbytes < 200 || feof(spxfile))
			eof = TRUE;

		while (ogg_sync_pageout(&oy, &og) == 1) {

			if (init == 0) {
				ogg_stream_init(&os, ogg_page_serialno(&og));
				init = 1;
			}

			ogg_stream_pagein(&os, &og);

			while (ogg_stream_packetout(&os, &op) == 1) {

				if (op.b_o_s) {
					header = speex_packet_to_header((char*)op.packet, op.bytes);
					if (header == NULL) {
						fprintf(stderr, SELF ": no header found\n");
						return 0;
					}
					
				} else if (op.e_o_s) {

					ogg_stream_clear(&os);
					ogg_sync_clear(&oy);
					fclose(spxfile);

					if (header == NULL)  {
						fprintf(stderr, SELF ": no header found\n");
						return 0;
					}
					
					#ifdef DEBUG
					fprintf(stderr, SELF ": length: %d (eos)\n", maxsize / header->rate);
					#endif
				
					return maxsize / header->rate;
					
				} else if (op.granulepos != -1) {
					maxsize = op.granulepos;
				}


			}

		}

	}

	fclose(spxfile);
	ogg_stream_clear(&os);
	ogg_sync_clear(&oy);

	if (header == NULL) {
		fprintf(stderr, SELF ": no header found\n");
		return 0;
	}

	#ifdef DEBUG
	fprintf(stderr, SELF ": length: %d (eof)\n", maxsize / header->rate);
	#endif
	
	return maxsize / header->rate;

}


