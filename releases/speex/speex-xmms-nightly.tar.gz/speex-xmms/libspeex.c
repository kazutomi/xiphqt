/* Speex Xmms plugin
 * (c) Jens Burkal, license: GPL
 * 
 * libspeex.c: Main plugin file
 * 
 */


#include <glib.h>
#include <gtk/gtk.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <xmms/plugin.h>
#include <xmms/configfile.h>
#include <xmms/util.h>

#include <ogg/ogg.h>

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>

#include <speex.h>
#include <speex_header.h>

#include <pthread.h>

#define SPEEX_EXT ".spx"
#define SELF "libspeex.so"
#define VBR_UPDATE_FREQ 1000
#define BUFFER_LEN 200


static void init (void);

static void about_spx (void);
static int is_our_file (char*);
static void play (char *filename);

static void spx_play_loop (void);
static void *spx_parse_header(ogg_packet);

static void stop (void);
static void spx_pause (short);
static void seek (int);
static int get_time (void);
static void get_song_info (char *, char **, int *);
static void show_error (char *, char *);
static void *generate_title(char *, gboolean);

typedef struct
{
	FILE *spxfile;
	gboolean playing, streaming, eof, eos;
	int length, seek_to, framesize;
	char *filename, *title;
	SpeexMode mode;
	int freq, channels, vbr, nframes;
} Speex_File_State;

typedef struct
{
	gboolean use_enhancer;
	gint buffersize, prebuffer;
	gboolean use_proxy, use_auth;
	gchar *proxy_host;
	gint proxy_port;
	gchar *proxy_user, *proxy_passwd;
	gboolean save_stream;
	gchar *save_path;
} Speex_Configuration;


Speex_File_State *speex_fs = NULL;
Speex_Configuration *speex_cfg = NULL;

static pthread_t spx_decode_thread;

#include "speexutil.c"
#include "config.c"
#include "fileinfo.c"


InputPlugin speex_ip = {
	NULL,
	NULL,
	NULL,
	init,
	about_spx,
	spx_config,
	is_our_file,
	NULL,
	play,
	stop,
	spx_pause,
	seek,
	NULL,
	get_time,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	get_song_info,
	spx_fileinfo,
	NULL
};


#include "http.h"
#include "http.c"

InputPlugin *get_iplugin_info(void)
{
	speex_ip.description = g_strdup_printf(("Speex plugin %s"), VERSION);
	return &speex_ip;
}


static void init (void) {

	speex_cfg = malloc(sizeof(Speex_Configuration));
	memset(speex_cfg, 0, sizeof(Speex_Configuration));

	spx_config_load();
}

static void *generate_title (char *filename, gboolean extention) {

	// As long as there's no tagging method of speex-files,
	// lets just use the filename as title

	char *tmpstr, *tmp;

	tmpstr = g_strdup(filename);

	tmp = NULL;
	
	if (!extention)
	{
		tmp = strrchr(tmpstr, '.');
		if (tmp)
			*tmp = '\0';
	}

	return g_basename(tmpstr);
	

}


static void about_spx (void) {

	static GtkWidget *aboutwindow, *aboutlabel, *okbutton;

	aboutwindow = gtk_dialog_new();
	gtk_window_set_title(GTK_WINDOW(aboutwindow), g_strdup("About Speex"));
	gtk_window_set_policy(GTK_WINDOW(aboutwindow), FALSE, FALSE, TRUE);
	gtk_container_set_border_width(GTK_CONTAINER(GTK_DIALOG(aboutwindow)->vbox), 10);

	aboutlabel = gtk_label_new(g_strdup("Speex - open-source patent-free voice codec\nhttp://speex.sourceforge.net\n\nDeveloped by\nJean-Marc Valin <jean-marc.valin@hermes.usherb.ca>\n\nXMMS plugin by\nJens Burkal <jzb@rapanden.dk>"));
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(aboutwindow)->vbox), aboutlabel);

	okbutton = gtk_button_new_with_label(g_strdup("Ok"));
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(aboutwindow)->action_area), okbutton);
	gtk_widget_grab_focus(GTK_WIDGET(okbutton));
	gtk_signal_connect_object(GTK_OBJECT(okbutton), "clicked", GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(aboutwindow));

	gtk_widget_show_all(aboutwindow);

	return;
}

	


static int is_our_file (char *filename) {
	// Everything with our extention will be accepted

	char *ext;

	ext = (char*) strrchr(filename, '.');
	if (ext)
		if (strcmp(ext, SPEEX_EXT) == 0)
			return TRUE;
	return FALSE;

}


static void play (char *filename) {


	if (speex_fs == NULL)
		speex_fs = malloc(sizeof(Speex_File_State));
	
	memset(speex_fs, 0, sizeof(Speex_File_State));

	
	if (strstr(filename, g_strdup("http://")))
		speex_fs->streaming = TRUE;
	else
		speex_fs->streaming = FALSE;
	

	speex_fs->playing = TRUE;

	speex_fs->filename = filename;

	if (speex_fs->streaming)
		speex_fs->length = -1;
	else
		speex_fs->length = 1000 * speex_get_time(filename);

	speex_fs->title = g_strdup(generate_title(filename, FALSE));

	if (speex_fs->streaming) {
		fprintf(stderr, SELF ": opening url: %s\n", filename);
		speex_http_open(filename); // Will always return 0
	} else {
		if ((speex_fs->spxfile = fopen(filename, "rb")) == NULL) {
			fprintf(stderr, SELF ": error opening file\n");
			return;
		}
	}


	pthread_create(&spx_decode_thread, NULL, (void*)spx_play_loop, NULL);
}




static void spx_play_loop (void) {


	void *data;
	int readsize;
	float outbuff[2000];
	short output[2000];
	int i, i2, j, result, seeked_to;
	int enh;
	int last_page, last_granulepos, miss_frames, miss_samples;
	int packetbytes, last_poll;

	ogg_sync_state oy;
	ogg_page og;
	ogg_packet op;
	ogg_stream_state os;

	void *spx_decoder = NULL;
	SpeexBits sbits;


	#ifdef DEBUG
	fprintf(stderr, SELF ": thread created\n");
	#endif
	
	ogg_sync_init(&oy);
	
	speex_bits_init(&sbits);
	
	speex_fs->eof = FALSE;
	speex_fs->seek_to = -1;
	
	// Well, lets just play...
	while (speex_fs->playing) {

		while (1) {

			data = ogg_sync_buffer(&oy, BUFFER_LEN);

			if (speex_fs->streaming)
				readsize = speex_http_read(data, BUFFER_LEN);
			else
				readsize = fread(data, sizeof(char), BUFFER_LEN, speex_fs->spxfile);

			fprintf(stderr, "Read data\n");
			ogg_sync_wrote(&oy, readsize);

			if ((readsize < BUFFER_LEN) || (!speex_fs->streaming && feof(speex_fs->spxfile))) // Bad file
			{
				fprintf(stderr, SELF ": unexpected eof\n");
				return;
			}

			if (ogg_sync_pageout(&oy, &og) == 1)
				break;
			
		}

		ogg_stream_init(&os, ogg_page_serialno(&og));

		if (ogg_stream_pagein(&os, &og) < 0)
		{
			fprintf(stderr, SELF ": stream error\n");
			return;
		}

		if (ogg_stream_packetout(&os, &op) != 1)
		{
			fprintf(stderr, SELF ": cannot read header\n");
			return;
		}

		// op must now be the first packet/page and must be the header
		// *** HEADER ***
		
		spx_decoder = spx_parse_header(op);

		if (spx_decoder == NULL)
			return;


		#ifdef DEBUG
		if (speex_cfg->use_enhancer)
			fprintf(stderr, SELF ": enhancer enabled\n");
		else
			fprintf(stderr, SELF ": enhancer disabled\n");
		#endif
		
		enh = (speex_cfg->use_enhancer ? 1 : 0);
		speex_decoder_ctl(spx_decoder, SPEEX_SET_ENH, &enh);

		speex_ip.set_info(speex_fs->title, speex_fs->length, -1, speex_fs->freq, speex_fs->channels);
		
		if (speex_ip.output->open_audio(FMT_S16_LE, speex_fs->freq, speex_fs->channels) == 0)
		{
			fprintf(stderr, SELF ": audio error\n");
			return;
		}


		speex_fs->eos = FALSE;

		// we have now gotten through initialisation, and the next packet is the comment packet
		// for now, we'll assume that it has its own page and that its only one packet
		// *** COMMENT ***
	
		if (ogg_stream_packetout(&os, &op) == 1)
		{
			#ifdef DEBUG
			fprintf(stderr, SELF ": comment: %s\n",  (char*) op.packet);
			#endif
		}
		else 
		{
			while (ogg_sync_pageout(&oy, &og) < 1)
			{
				data = ogg_sync_buffer(&oy, BUFFER_LEN);

				if (speex_fs->streaming)
					readsize = speex_http_read(data, BUFFER_LEN);
				else
					readsize = fread(data, sizeof(char), BUFFER_LEN, speex_fs->spxfile);

				ogg_sync_wrote(&oy, readsize);

			}

			ogg_stream_pagein(&os, &og);

			if (ogg_stream_packetout(&os, &op) == 1)
			{
				#ifdef DEBUG
				fprintf(stderr, SELF ": comment: %s\n", (char*)op.packet);
				#endif
			}

		}

		// now we're all done with the headers
		// *** DECODE ***
		
		last_page = 0;
		last_granulepos = 0;

		packetbytes = 0;
		last_poll = speex_ip.output->output_time();

		while (speex_fs->playing)
		{
			while (speex_fs->playing)
			{
				result = ogg_sync_pageout(&oy, &og);

				if (result == -1) {
					// Sync error. Had to skip bytes.
					// This occurs when we seek, not a problem.
					break;
				}
				else if (result == 0) {
					// Read some more data
					break;
				}
				else if (result == 1) {

					// This is where we handle lost frames
					// There will be a jump in pageno when seeking, that's why were checking for !0
					if (ogg_page_pageno(&og) > last_page+1 && last_page != 0)
					{
						miss_samples = ogg_page_granulepos(&og) - last_granulepos;
						miss_frames = miss_samples / speex_fs->framesize;
						fprintf(stderr, SELF ": lost page. Recovering %d frames (%d samples)\n", miss_frames, miss_samples);

						for (i2 = 0; i2 < miss_frames; i2++) {

							#ifdef DEBUG
							fprintf(stderr, SELF ": interpolating frame %d / %d\n", i2+1, miss_frames);
							#endif

							// speex_bits_rewind(&sbits);
							speex_decode(spx_decoder, NULL, outbuff);
							
							// Converting and clipping check
							for (i = 0; i < speex_fs->framesize; i++) {
								if (outbuff[i] > 32000) output[i] = 32000;
								else if (outbuff[i] < -32000) output[i] = -32000;
								else output[i] = outbuff[i];
							}

							// While the output-buffer is too small to hold our data, sleep
							while (speex_ip.output->buffer_free() < (speex_fs->framesize * sizeof(short)) && speex_fs->playing)
								xmms_usleep(10000);

							speex_ip.add_vis_pcm(speex_ip.output->written_time(), FMT_S16_LE, speex_fs->channels, speex_fs->framesize * sizeof(short), &output);
							
							speex_ip.output->write_audio(&output, speex_fs->framesize * sizeof(short));

						}
					}

					last_page = ogg_page_pageno(&og);
					last_granulepos = ogg_page_granulepos(&og);

					// We have a page
					
					ogg_stream_pagein(&os, &og);

					while (speex_fs->playing)
					{
						result = ogg_stream_packetout(&os, &op);

						if (result < 1) {
							// We have either lost sync or we need more data
							break;
						}
						else if (op.e_o_s) // (ogg_page_eos(&og)) 
						{
							#ifdef DEBUG
							fprintf(stderr, SELF ": eos\n");
							#endif
							
							speex_fs->eos = TRUE;
							
						} else if (speex_fs->seek_to != -1) {
							break;

						}
						{


							// Vbr handling
							packetbytes += op.bytes;

							if (speex_ip.output->output_time() > last_poll + VBR_UPDATE_FREQ) {
								
								speex_ip.set_info(speex_fs->title, speex_fs->length, (packetbytes*8*1024) / (speex_ip.output->output_time() - last_poll), speex_fs->freq, speex_fs->channels);

								last_poll = speex_ip.output->output_time();
								packetbytes = 0;
							}
								
							
							// Decode
							
							speex_bits_read_from(&sbits, (char *)op.packet, op.bytes);


							// For multiple frames within packets
							for (j=0; j < speex_fs->nframes; j++)
							{
								speex_decode(spx_decoder, &sbits, outbuff);
								
								// Converting and clipping check
								for (i = 0; i < speex_fs->framesize; i++) {
									if (outbuff[i] > 32000) output[i] = 32000;
									else if (outbuff[i] < -32000) output[i] = -32000;
									else output[i] = outbuff[i];
								}

								// While the output-buffer is too small to hold our data, sleep
								while (speex_ip.output->buffer_free() < (speex_fs->framesize * sizeof(short)) && speex_fs->playing)
									xmms_usleep(10000);

								speex_ip.add_vis_pcm(speex_ip.output->written_time(), FMT_S16_LE, speex_fs->channels, speex_fs->framesize * sizeof(short), &output);
								speex_ip.output->write_audio(&output, speex_fs->framesize * sizeof(short));

							}

						}

					}

				}



			}
			
			
			if (speex_fs->eof || speex_fs->eos) break;

			if (speex_fs->seek_to != -1) {
			
				if (speex_ip.output->output_time() > speex_fs->seek_to * 1000) // backwards search
					seeked_to = speex_seek(speex_fs->spxfile, speex_fs->seek_to, 0, speex_fs->freq);
				else
					seeked_to = speex_seek(speex_fs->spxfile, speex_fs->seek_to, 1, speex_fs->freq);

				speex_ip.output->flush(seeked_to);
				
				speex_fs->seek_to = -1;
				last_page = 0;

			}
			
			if (!speex_fs->eof) {

				data = ogg_sync_buffer(&oy, BUFFER_LEN);

				if (speex_fs->streaming)
					readsize = speex_http_read(data, BUFFER_LEN);
				else
					readsize = fread(data, sizeof(char), BUFFER_LEN, speex_fs->spxfile);
				
				ogg_sync_wrote(&oy, readsize);
				
				if (readsize < BUFFER_LEN || (!speex_fs->streaming && feof(speex_fs->spxfile))) {
					#ifdef DEBUG
					fprintf(stderr, SELF ": eof\n");
					#endif
					speex_fs->eof = TRUE;
				}
			
			}


		} // while !eos

		// Cleanup for this logical bitstream
		ogg_stream_clear(&os);
		
		//If we've exited because of eof/eos, wait until the buffer is empty
		if (speex_fs->playing)
			while (speex_ip.output->buffer_playing())
				xmms_usleep(10000);

		// We have to close the audio output before playing the next stream
		speex_ip.output->close_audio();

		if (speex_fs->eof) break;
	} // while !eof


	ogg_sync_clear(&oy);

	speex_bits_destroy(&sbits);
	speex_decoder_destroy(spx_decoder);

	if (speex_fs->streaming)
		speex_http_close();
	else
		fclose (speex_fs->spxfile);
	

	speex_fs->seek_to = -1;

	pthread_exit(NULL);

}
		

		
static void *spx_parse_header(ogg_packet op) {

	SpeexHeader *header;
	SpeexMode *mode;
	void *spxdec;

	#ifdef DEBUG
	fprintf(stderr, SELF ": parsing header\n");
	#endif

	header = speex_packet_to_header((char*)op.packet, op.bytes);


	if (!header) {
		fprintf(stderr, SELF ": Cannot read header.\n");
		return NULL;
	}

	mode = speex_mode_list[header->mode];

	if (mode->bitstream_version > header->mode_bitstream_version) {
		fprintf(stderr, SELF ": Incorrect version.\n");
		show_error(g_strdup("Error"), g_strdup("\nThe file was encoded with an older version of Speex.\nYou need to downgrade the version in order to play it.\n"));
		return NULL;
	}

	if (mode->bitstream_version < header->mode_bitstream_version) {
		fprintf(stderr, SELF ": Incorrect version.\n");
		show_error(g_strdup("Error"), g_strdup("\nThe file was encoded with a newer version of Speex.\nYou need to upgrade in order to play it.\n"));
		return NULL;
	}
	
	speex_fs->freq = header->rate;
	speex_fs->channels = header->nb_channels;
	speex_fs->vbr = header->vbr;
	
	speex_fs->nframes = header->frames_per_packet;
	if (!speex_fs->nframes)
		speex_fs->nframes = 1;
	

	spxdec = speex_decoder_init(mode);

	if (spxdec == NULL)
	{
		fprintf(stderr, SELF ": decoder init failed\n");
		return NULL;
	}
	

	speex_decoder_ctl(spxdec, SPEEX_GET_FRAME_SIZE, &speex_fs->framesize);

	
	return spxdec;
}
		
		


static void spx_pause (short paused) {
	speex_ip.output->pause(paused);
}

static void stop (void) {
	speex_fs->playing = FALSE;

	// Wait for the thread to close
	pthread_join(spx_decode_thread, NULL);
	
	#ifdef DEBUG
	fprintf(stderr, SELF ": stop\n");
	#endif
}


static void seek (int time) {

	// The argument given to this function is the time in seconds

	if (speex_fs->streaming)
		return;
	
	speex_fs->seek_to = time;

	while (speex_fs->seek_to != -1)
		xmms_usleep(20000);

}

static int get_time (void) {
	
	if (speex_fs->playing)
		return speex_ip.output->output_time();
	
	return -1;
}

static void get_song_info (char *filename, char **title, int *length) {

	(*title) = g_strdup(generate_title(filename, FALSE));


	if (strstr(filename, g_strdup("http://")))
		*length = -1;
	else
		*length = 1000 * speex_get_time(filename);


}


static void show_error (char *title, char *error) {

	GtkWidget *window, *okbutton, *label;

	window = gtk_dialog_new();
	gtk_window_set_title(GTK_WINDOW(window), title);
	
	label = gtk_label_new(error);
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(window)->vbox), label);

	okbutton = gtk_button_new_with_label(g_strdup("Ok"));
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(window)->action_area), okbutton);
	gtk_signal_connect_object(GTK_OBJECT(okbutton), "clicked", GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(window));
	gtk_widget_draw_focus(GTK_WIDGET(okbutton));

	gtk_widget_show_all(window);

}


