#define VEZES_LF 15
#define VEZES_EB 15
#define VEZES_RF 15
#define VEZES_CR 15
#define VEZES_RR 15


/*#define LOOP_FILTER 1*/
/*#define EXP_BLK 1*/
/*#define RECON_FRAMES 1*/
#define COPY_RECON 1
/* #define RECON_REF_FRAMES 1 */


#define IN_EB_FILE "/home/leonardo/theora/rrf_docs_theora/expandblock/golden/in.tb"
#define IN2_EB_FILE "/home/leonardo/theora/rrf_docs_theora/expandblock/golden/in2.tb"
#define OUT_EB_FILE "/home/leonardo/theora/rrf_docs_theora/expandblock/golden/OUT.EXPECTED.TB"


#define IN_LF_FILE "/home/leonardo/theora/rrf_docs_theora/loopfilter/golden/in.tb"
#define IN2_LF_FILE "/home/leonardo/theora/rrf_docs_theora/loopfilter/golden/in2.tb"
#define OUT_LF_FILE "/home/leonardo/theora/rrf_docs_theora/loopfilter/golden/OUT.EXPECTED.TB"


#define IN_RF_FILE  "/home/leonardo/theora/rrf_docs_theora/reconframes/golden/in.tb"
#define IN2_RF_FILE "/home/leonardo/theora/rrf_docs_theora/reconframes/golden/in2.tb"
#define OUT_RF_FILE "/home/leonardo/theora/rrf_docs_theora/reconframes/golden/OUT.EXPECTED.TB"

#define IN_CR_FILE  "/home/leonardo/theora/rrf_docs_theora/copyrecon/golden/in.tb"
#define IN2_CR_FILE "/home/leonardo/theora/rrf_docs_theora/copyrecon/golden/in2.tb"
#define OUT_CR_FILE "/home/leonardo/theora/rrf_docs_theora/copyrecon/golden/OUT.EXPECTED.TB"

#define IN_RR_FILE  "/home/leonardo/theora/rrf_docs_theora/reconrefframes/golden/in.tb"
#define OUT_RR_FILE "/home/leonardo/theora/rrf_docs_theora/reconrefframes/golden/OUT.EXPECTED.TB"



#define MAXCOUNT 1100

#define START_RF -1
