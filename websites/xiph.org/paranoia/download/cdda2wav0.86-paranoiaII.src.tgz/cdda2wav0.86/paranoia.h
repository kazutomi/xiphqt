/***
 * CopyPolicy: GNU Public License 2 applies
 * Copyright (C) by Monty (xiphmont@mit.edu)
 *
 * paranoia.h
 */

#undef P_DEBUG
#define P_RETRY 30 /* Not bloody likely */
#define P_OVERLAP (SYNC_SIZE>>2)
#define P_CLIMIT P_OVERLAP
#define P_SKIP_AHEAD (1*CD_FRAMESAMPLES)
#define P_SCRATCH_KEEPALIVE 6

extern long paranoia_bi_find(long *test1, long *test2, long limit, 
			     long *overlapped);
extern long paranoia_uni_find(long *test1, long *test2, long verify, 
			      long sofar, long paralign, long limit, 
			      long *overlapped);
extern long paranoia_uni_find_tolerant(long *ref,long *rabble,long verify,
				       long sofar,long paralign,long rlimit);
extern long paranoia_overlap_tolerant(long *build,long *suspectbits,long *sc,
				      long pverify,long psofar,long alignment,
				      long plimit);
extern void paranoia_cull(long *paranoia,long *suspectbits,long limit);
extern void paranoia_spackle(long *paranoia,long *suspectbits,long limit);
extern void indicator(long sofar,long total,char happiness,const char *s);
