#include <unistd.h>
#include <fcntl.h>

int main(){
  long i,j,fd;
  char out[2];

  fd=open("test",O_RDWR|O_CREAT|O_TRUNC);
  for(i=1;i<100;i++){
    for(j=-32768;j<32768;j+=i){
      out[0]=j&0xff;
      out[1]=(j>>8)&0xff;
      write(fd,out,2);
    }
    for(j=32767;j>-32768;j-=i){
      out[0]=j&0xff;
      out[1]=(j>>8)&0xff;
      write(fd,out,2);
    }
  }
  close(fd);
  return(0);
}
