/* 
 * JNI wrappers for libspeex 1.0b3
 * Copyright Boyd Ebsworthy <bebsworthy@entreview.com> 2002
 * Part of the code are from speexenc and speexdec
 * copyright Jean-Marc Valin <jean-marc.valin@hermes.usherb.ca>
 *
 * This code is released under the BSD licence
 * 
 * Please send enhancement and bug fix to <bebsworthy@entreview.com>
 */
#include <jni.h>
/* Header for class speex_Speex */

#include "speex_SpeexLib.h"

#include "speex.h"

#include "speex_header.h"
#include "speex_stereo.h"
#include "speex_callbacks.h"
//#include "misc.h" // gives me unresolved symbol. to tired to find why, 
//so i copy/pasted the function i needed. (le_short and be_short)


//#define VERBOSE 0

/**
 *  JNI utils 
 */
void setLongField(JNIEnv* env, jlong value, jobject obj, char *szField) {
	jfieldID jfield = env->GetFieldID(env->GetObjectClass(obj), szField, "J");
	env->SetLongField(obj, jfield, value);
}

void setIntField(JNIEnv* env, jint value, jobject obj, char *szField) {
	jfieldID jfield = env->GetFieldID(env->GetObjectClass(obj), szField, "I");
	env->SetIntField(obj, jfield, value);
}

jlong getLongField(JNIEnv* env, jobject obj, char *szField) {
	jfieldID jfield =  env->GetFieldID(env->GetObjectClass(obj), szField, "J");
	return env->GetLongField(obj, jfield);
}

/***
 * speex util function i couldn't link for some reason
 */

unsigned short be_short(unsigned short s)
{
   unsigned short ret=s;
#ifndef WORDS_BIGENDIAN
   ret =  s>>8;
   ret += s<<8;
#endif
   return ret;
}

unsigned short le_short(unsigned short s)
{
   unsigned short ret=s;
#ifdef WORDS_BIGENDIAN
   ret =  s>>8;
   ret += s<<8;
#endif
   return ret;
}


/** ---------------------------------------------------------------------
 * get the SpeexBits memory object matching the java class 
 */

SpeexBits* getSpeexBits(JNIEnv* env, jobject jSpeexBits) {

	SpeexBits* sb = 0;
	jlong address = getLongField(env, jSpeexBits, "address");

	if(address) {
		sb = (SpeexBits*)address;
				
#ifdef VERBOSE 
		printf(" found - ");
		printf("nbBits=%d, ", sb->nbBits);
		printf("bytePtr=%d, ", sb->bytePtr);
		printf("bitPtr=%d, ",  sb->bitPtr);
		printf("owner=%d\n",  sb->owner);
#endif

	} else {

	}

	return sb;
}

/** ---------------------------------------------------------------------
 * Update the field of the java SpeexBits class
 */

void exportSpeexBits(JNIEnv* env, jobject jSpeexBits, SpeexBits* sb) {
	
	if(sb) {

#ifdef VERBOSE 
		printf("> native : setSpeexBits setting - ");
		printf("nbBits=%d, ", sb->nbBits);
		printf("bytePtr=%d, ", sb->bytePtr);
		printf("bitPtr=%d, ",  sb->bitPtr);
		printf("owner=%d\n ",  sb->owner);
#endif
		jlong address = (jlong)sb;
		
		setLongField(env, address,	jSpeexBits, "address");

		setIntField(env, sb->nbBits,	jSpeexBits, "nbBits");
		setIntField(env, sb->bytePtr,	jSpeexBits, "bytePtr");
		setIntField(env, sb->bitPtr,	jSpeexBits, "bitPtr");
		setIntField(env, sb->owner,	jSpeexBits, "owner");
	} else {

#ifdef VERBOSE 
		printf("> native : setSpeexBits null SpeexBits parameter");
#endif

	}
}

/** ------------------------------------------------------------------------
 * speex wrapper utils
 */
SpeexMode *getSpeexMode(jint mode) {

SpeexMode *smode = 0;

	switch(mode) {
		case speex_SpeexLib_speex_nb_mode :
			smode = &speex_nb_mode;
			break;
	
		case speex_SpeexLib_speex_wb_mode :
			smode = &speex_wb_mode;
			break;
	
		case speex_SpeexLib_speex_uwb_mode :
			smode = &speex_uwb_mode;
			break;
	
		default  : 
			smode = &speex_nb_mode;
			break;
	}
	return smode;
}

/**********************************************************
	//basic workflow of an encoder program in C
	st = speex_encoder_init(mode);
	speex_encoder_ctl(st, SPEEX_GET_FRAME_SIZE, &frame_size);
	speex_bits_init(&bits);
	speex_encode_stereo(input, frame_size, &bits);
	speex_encode(st, input, &bits);
	nbBytes = speex_bits_write(&bits, cbits, MAX_FRAME_BYTES);
	speex_bits_reset(&bits);

	speex_encoder_destroy(st);
	speex_bits_destroy(&bits);
    ************************************************************/

/* ------------------------------------------------------------------------
 * Class:     speex_Speex
 * Method:    speex_encoder_init
 * Signature: (I)J
 */
JNIEXPORT jlong JNICALL 
Java_speex_SpeexLib_speex_1encoder_1init (JNIEnv *env, jclass obj, jint mode) {
	
#ifdef VERBOSE 
	printf("> native : speex_encoder_init (%d)\n", mode);
#endif

	jlong state = 0;
	void *st;

	st = speex_encoder_init(getSpeexMode(mode));
	state = (jlong)st;

#ifdef VERBOSE 
	printf("          speex_encoder_init done - state == (%d)\n", state);
#endif

	return state;
}

/* ----------------------------------------------------------------------------------
 * Class:     speex_Speex
 * Method:    speex_encoder_destroy
 * Signature: (J)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1encoder_1destroy (JNIEnv *env, jclass obj, jlong state) {

#ifdef VERBOSE 
	printf("> native : speex_encoder_destroy - state == (%d)\n", state);
#endif
	
	void *st;
	st = (void*)state;
	
	if(st) {
		speex_encoder_destroy(st);
	}

#ifdef VERBOSE 
	printf("          speex_encoder_destroy done - state == (%d)\n", state);
#endif
}

/* ---------------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_encode enhanced
 * Signature: (J[BLspeex/SpeexBits;III)V
 */
#define MAX_FRAME_SIZE 2000
float in_float[MAX_FRAME_SIZE];

JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1encode__J_3BLspeex_SpeexBits_2III 
(JNIEnv *env, jclass obj, jlong state, jbyteArray in, jobject speexbits, jint bitsPerSample, jint channels, jint little_endian) {

#ifdef VERBOSE  
	printf("> native : speex_encode enhanced -\n");
#endif

	void *st;
	st = (void*)state;
	
	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);

	jsize len = env->GetArrayLength(in);
	int frame_size = len/2;
	
	unsigned char* input = (unsigned char*)env->GetByteArrayElements(in, 0);
	
#ifdef VERBOSE  
	/*
	printf("          in length	    = %d\n", len);
	printf("          frame size    = %d\n", frame_size);	
	printf("          bitsPerSample = %d\n", bitsPerSample);
	printf("          channels      = %d\n", channels);
	printf("          little_endian = %d\n", little_endian);
	*/
#endif
	
	// convert jbyte[] to float[] (hopefully)
	short* s;
	s=((short*)input);

	if(sb && st) {
		
		int i;
		
		if(bitsPerSample == 8) { // Convert 8->16 bits
			for(i = (frame_size*channels-1); i >= 0; i--) {
				s[i] = (input[i] << 8 ) ^ 0x8000;
			}
		} else {
			// convert to our endian format
			for(i = 0; i < (frame_size * channels); i++) {
				if(little_endian)
					s[i]=le_short(s[i]); 
				else
					s[i]=be_short(s[i]);

			}
			//so far i have the same value as in speexenc.c
			//so it must work :)
		
		}

		// copy to float input buffer
		for (i=0;i<frame_size*channels;i++) {
			in_float[i]= (short)s[i];
		}
		
#ifdef VERBOSE  
	printf("          encoding\n");
#endif
		// encode !
		speex_encode(st, in_float, sb);

		exportSpeexBits(env, speexbits, sb);

#ifdef VERBOSE  
	// printf("         sb->nbBits %d\n", sb->nbBits);
	// printf("         sb->bytePtr %d\n", sb->bytePtr);
	
#endif

	}

	env->ReleaseByteArrayElements(in, (jbyte*)input, 0);

}

/* ---------------------------------------------------------------------------------
 * Class:     speex_Speex
 * Method:    speex_encode
 * Signature: (J[FJ)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1encode__J_3FLspeex_SpeexBits_2
(JNIEnv *env, jclass obj, jlong state, jfloatArray in, jobject speexbits) {

#ifdef VERBOSE  
	printf("> native : speex_encode - \n");
#endif
	
	void *st;
	st = (void*)state;
	
	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);

	jsize len = env->GetArrayLength(in);

	jfloat* input = env->GetFloatArrayElements(in, 0);

	if(sb && st) {
		
#ifdef VERBOSE  
	printf("          encoding\n");
#endif
		speex_encode(st, input, sb);

		exportSpeexBits(env, speexbits, sb);
	}
	
	env->ReleaseFloatArrayElements(in, input, 0);

}

/* ---------------------------------------------------------------------------------
 * Class:     speex_Speex
 * Method:    speex_encoder_ctl
 * Signature: (JIJ)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1encoder_1ctl (JNIEnv *env, jclass obj, jlong state, jint request, jobject voidPtr) {
	
	void *st;
	st = (void*)state;
	
	/* get the long value */
	jlong value = getLongField(env, voidPtr, "value");

#ifdef VERBOSE  //must use printf multiple time otherwise windows printf() prints garbage.. ?!!
	printf("> native : speex_encoder_ctl - state/request/void = ");
	printf("(%d)", state);
	printf("(%d)", request);
	printf("(%d)\n", value);
#endif

	if(st) {
		speex_encoder_ctl(st, request, &value);
	}
	
	setLongField(env, value, voidPtr, "value");
	

#ifdef VERBOSE 
	printf("          speex_encoder_ctl - state/request/void = ");
	printf("(%d)", state);
	printf("(%d)", request);
	printf("(%d)\n", value);
#endif
}

/* ---------------------------------------------------------------------------------
 * Class:     speex_Speex
 * Method:    speex_decoder_init
 * Signature: (I)J
 */
JNIEXPORT jlong JNICALL 
Java_speex_SpeexLib_speex_1decoder_1init (JNIEnv *env, jclass obj, jint mode) {

#ifdef VERBOSE 
	printf("> native : speex_decoder_init (%d)\n", mode);
#endif

	jlong state = 0;
	void *st;

	st = speex_decoder_init(getSpeexMode(mode));
	
	/* debug : set some callback */
	//SpeexCallback callback;
	
	/* is it needed ?*/
	/*
	callback.callback_id = SPEEX_INBAND_CHAR;
	callback.func = speex_std_char_handler;
	callback.data = stderr;
	speex_decoder_ctl(st, SPEEX_SET_HANDLER, &callback);


	callback.callback_id = SPEEX_INBAND_MODE_REQUEST;
	callback.func = speex_std_mode_request_handler;
	callback.data = st;
	speex_decoder_ctl(st, SPEEX_SET_HANDLER, &callback);
	*/
/*
	SpeexStereoState stereo = SPEEX_STEREO_STATE_INIT;

	callback.callback_id = SPEEX_INBAND_STEREO;
    callback.func = speex_std_stereo_request_handler;
    callback.data = (void*)stereo;
    speex_decoder_ctl(st, SPEEX_SET_HANDLER, &callback);
*/   


	state = (jlong)st;

#ifdef VERBOSE 
	printf("          speex_decoder_init done - state == (%d)\n", state);
#endif

	return state;
}

/* ---------------------------------------------------------------------------------
 * Class:     speex_Speex
 * Method:    speex_decoder_destroy
 * Signature: (J)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1decoder_1destroy (JNIEnv *env, jclass obj, jlong state) {

#ifdef VERBOSE 
	printf("> native : speex_decoder_destroy - state == (%d)\n", state);
#endif
	
	void *st;
	st = (void*)state;
	
	if(st) {
		speex_decoder_destroy(st);
	}

#ifdef VERBOSE 
	printf("          speex_decoder_destroy done - state == (%d)\n", state);
#endif

}

/* ---------------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_decode byte
 * Signature: (JLspeex/SpeexBits;[B)I
 */
//#define MAX_FRAME_SIZE 2000
float out_float[MAX_FRAME_SIZE];

JNIEXPORT jint JNICALL 
Java_speex_SpeexLib_speex_1decode__JLspeex_SpeexBits_2_3B
(JNIEnv *env, jclass obj, jlong state, jobject speexbits, jbyteArray out) {
	
	void *st;
	st = (void*)state;

	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);
	
	jsize len = env->GetArrayLength(out);
	int frame_size = len/2;
	
	unsigned char* output = (unsigned char*)env->GetByteArrayElements(out, 0);
	
	short* s;
	s = (short*) output;

	int status = -2;
	if(st && sb) {
		
		status = speex_decode(st, sb, out_float);
		
		if(status == 0) {
			for(int i=0; i< frame_size; i++) {
				//FIXME ENDIANNESS ?
				s[i] = out_float[i];
			}
		}
	}
	

	env->ReleaseByteArrayElements(out, (jbyte*)output, 0);
	
	return status;
}

/* ---------------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_decode float
 * Signature: (JLspeex/SpeexBits;[F)I
 */
JNIEXPORT jint JNICALL 
Java_speex_SpeexLib_speex_1decode__JLspeex_SpeexBits_2_3F
(JNIEnv *env, jclass obj, jlong state, jobject speexbits, jfloatArray out) {
	
	void *st;
	st = (void*)state;

	/***************************************************************************
	 *
	 *
	 * ! WRITE ME !
	 *
	 *
	 */

	printf("speex_decode : NOT IMPLEMENTED!\n");
	return 0;
}

/* ---------------------------------------------------------------------------------
 * Class:     speex_Speex
 * Method:    speex_decoder_ctl
 * Signature: (JIJ)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1decoder_1ctl (JNIEnv *env, jclass obj, jlong state, jint request, jobject voidPtr) {

	void *st;
	st = (void*)state;
	
	/* get the long value */
	jlong value = getLongField(env, voidPtr, "value");

#ifdef VERBOSE  //must use printf multiple time otherwise windows printf() prints garbage.. ?!!
	printf("> native : speex_decoder_ctl - state/request/void = ");
	printf("(%d)", state);
	printf("(%d)", request);
	printf("(%d)\n", value);
#endif
	
	if(st) {
		speex_decoder_ctl(st, request, &value);
	}
	
	setLongField(env, value, voidPtr, "value");
	
#ifdef VERBOSE 
	printf("          speex_decoder_ctl - state/request/void = ");
	printf("(%d)", state);
	printf("(%d)", request);
	printf("(%d)\n", value);
#endif

}

/* ---------------------------------------------------------------------------------
 * Class:     speex_Speex
 * Method:    speex_mode_query
 * Signature: (IIJ)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1mode_1query (JNIEnv *env, jclass obj, jint mode, jint request, jobject voidPtr) {

	/* get the long value */
	jlong value = getLongField(env, voidPtr, "value");

#ifdef VERBOSE  //must use printf multiple time otherwise windows printf() prints garbage.. ?!!
	printf("> native : speex_mode_query - mode/request/void = ");
	printf("(%d)", mode);
	printf("(%d)", request);
	printf("(%d)\n", value);
#endif
		
	speex_mode_query(getSpeexMode(mode), request, &value);
	
	setLongField(env, value, voidPtr, "value");
	
#ifdef VERBOSE 
	printf("          speex_decoder_ctl - mode/request/void = ");
	printf("(%d)", mode);
	printf("(%d)", request);
	printf("(%d)\n", value);
#endif
}

/*******************************************************************************************************************
 * speex_bits function
 *******************************************************************************************************************/

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_init
 * Signature: (Lspeex/SpeexBits;)V
 */
JNIEXPORT void 
JNICALL Java_speex_SpeexLib_speex_1bits_1init (JNIEnv *env, jclass obj, jobject speexbits) {

#ifdef VERBOSE 
	printf("> native : speex_bits_init\n");
#endif

	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);
	
	printf("          sb = %d\n", sb);
	
	
	if(sb == 0) {

#ifdef VERBOSE 
	printf("          allocating new SpeexBits\n");
#endif
		sb = new SpeexBits();
	//	speex_bits_init(sb);
	} 
	
	if(sb) {

#ifdef VERBOSE 
	printf("         initializing\n");
#endif

		speex_bits_init(sb);
		exportSpeexBits(env, speexbits, sb);
	}
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_destroy
 * Signature: (Lspeex/SpeexBits;)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1bits_1destroy (JNIEnv *env, jclass obj, jobject speexbits) {
	
#ifdef VERBOSE 
	printf("> native : speex_bits_destroy\n");
#endif
	
	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);
	
	if(sb) {

#ifdef VERBOSE 
	printf("           destroying.\n");
#endif
	
		speex_bits_destroy(sb);
		
		exportSpeexBits(env, speexbits, sb);
		/* zero the address field */
		setLongField(env, 0, speexbits, "address");

		delete sb;
	}
	
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_reset
 * Signature: (Lspeex/SpeexBits;)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1bits_1reset (JNIEnv *env, jclass obj, jobject speexbits) {
	
#ifdef VERBOSE 
	printf("> native : speex_bits_reset\n");
#endif
	
	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);

	if(sb) {

#ifdef VERBOSE 
	printf("           reseting.\n");
#endif
		
		speex_bits_reset(sb);
		
		exportSpeexBits(env, speexbits, sb);
	}
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_rewind
 * Signature: (Lspeex/SpeexBits;)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1bits_1rewind (JNIEnv *env, jclass obj, jobject speexbits) {
	
#ifdef VERBOSE 
	printf("> native : speex_bits_rewind\n");
#endif
	
	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);

	if(sb) {

#ifdef VERBOSE 
	printf("           rewinding.\n");
#endif
	
		speex_bits_rewind(sb);
		
		exportSpeexBits(env, speexbits, sb);
	}
}

/*
 * Class:     speex_SpeexLib
 * Method:    speex_bits_read_from
 * Signature: (Lspeex/SpeexBits;[BI)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1bits_1read_1from 
(JNIEnv *env, jclass obj, jobject speexbits, jbyteArray input, jint length) {
  	
  	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);
	
	jsize len = env->GetArrayLength(input);
	jbyte* byte_array = env->GetByteArrayElements(input, 0);
		
	if(sb) {
		speex_bits_read_from(sb, (char*)byte_array, length);
	}
	
	env->ReleaseByteArrayElements(input, byte_array, 0);
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_write
 * Signature: (Lspeex/SpeexBits;[BI)I
 */
JNIEXPORT jint JNICALL
Java_speex_SpeexLib_speex_1bits_1write 
(JNIEnv *env, jclass obj, jobject speexbits, jbyteArray jarray, jint maxLength) {

#ifdef VERBOSE 
	printf("> native : speex_bits_write\n");
#endif
	int nbyte = 0;

	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);
	
	jsize len = env->GetArrayLength(jarray);
	jbyte* byte_array = env->GetByteArrayElements(jarray, 0);


	if(sb) {

#ifdef VERBOSE 
	printf("           writing bits.\n");
#endif
			
		nbyte = speex_bits_write(sb, (char*)byte_array, maxLength);
		
		exportSpeexBits(env, speexbits, sb);

	}
	
	env->ReleaseByteArrayElements(jarray, byte_array, 0);

	return nbyte;
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_write_whole_bytes
 * Signature: (Lspeex/SpeexBits;CI)I
 */
JNIEXPORT jint JNICALL 
Java_speex_SpeexLib_speex_1bits_1write_1whole_1bytes (JNIEnv *env, jclass obj, jobject speexbits, jbyteArray array, jint maxLength) {
	//FIXME arguments
	printf("speex_bits_write_whole_bytes : NOT IMPLEMENTED!\n");
	return 0;
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_pack
 * Signature: (Lspeex/SpeexBits;II)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1bits_1pack (JNIEnv *env, jclass obj, jobject speexbits, jint _int, jint _int2) {
	printf("speex_bits_pack : NOT IMPLEMENTED!\n");
	//FIXME arguments
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_unpack_signed
 * Signature: (Lspeex/SpeexBits;I)I
 */
JNIEXPORT jint JNICALL 
Java_speex_SpeexLib_speex_1bits_1unpack_1signed (JNIEnv *env, jclass obj, jobject speexbits, jint _int) {
	printf("speex_bits_unpack_signed : NOT IMPLEMENTED!\n");
	//FIXME arguments
	return 0;
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_unpack_unsigned
 * Signature: (Lspeex/SpeexBits;I)I
 */
JNIEXPORT jint JNICALL 
Java_speex_SpeexLib_speex_1bits_1unpack_1unsigned (JNIEnv *env, jclass obj, jobject speexbits, jint _int) {
	printf("speex_bits_unpack_unsigned : NOT IMPLEMENTED!\n");
	//FIXME arguments
	return 0;
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_nbytes
 * Signature: (Lspeex/SpeexBits;)I
 */
JNIEXPORT jint 
JNICALL Java_speex_SpeexLib_speex_1bits_1nbytes (JNIEnv *env, jclass obj, jobject speexbits) {
	
	jint nbytes = 0;

#ifdef VERBOSE 
	printf("> native : speex_bits_nbytes\n");
#endif
	
	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);

	if(sb) {

#ifdef VERBOSE 
	printf("           getting nbytes.\n");
#endif
	
		nbytes = speex_bits_nbytes(sb);
		
		exportSpeexBits(env, speexbits, sb);
	}

	return nbytes;
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_peek_unsigned
 * Signature: (Lspeex/SpeexBits;I)I
 */
JNIEXPORT jint JNICALL 
Java_speex_SpeexLib_speex_1bits_1peek_1unsigned (JNIEnv *env, jclass obj, jobject speexbits, jint _int) {
	//FIXME arguments
	printf("speex_bits_peek_unsigned : NOT IMPLEMENTED!\n");
	return 0;
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_peek
 * Signature: (Lspeex/SpeexBits;)I
 */
JNIEXPORT jint 
JNICALL Java_speex_SpeexLib_speex_1bits_1peek (JNIEnv *env, jclass obj, jobject speexbits) {
	printf("speex_bits_peek : NOT IMPLEMENTED!\n");
	return 0;
}

/* ------------------------------------------------------------------------
 * Class:     speex_SpeexLib
 * Method:    speex_bits_advance
 * Signature: (Lspeex/SpeexBits;I)V
 */
JNIEXPORT void JNICALL 
Java_speex_SpeexLib_speex_1bits_1advance (JNIEnv *env, jclass obj, jobject speexbits, jint n) {

#ifdef VERBOSE 
	printf("> native : speex_bits_advance\n");
#endif
	
	SpeexBits* sb = 0;
	sb = getSpeexBits(env, speexbits);

	if(sb) {

#ifdef VERBOSE 
	printf("           getting nbytes.\n");
#endif
	
		speex_bits_advance(sb, n);
		
		exportSpeexBits(env, speexbits, sb);
	}
}


