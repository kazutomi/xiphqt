Here's the mail i posted to the speex-dev mailing list.

Date: Sat, 14 Dec 2002 00:24:54 +0100
From: Boyd Ebsworthy <bebsworthy@entreview.com>
User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.1) Gecko/20020826
X-Accept-Language: en-us, en
MIME-Version: 1.0
To: speex-dev@xiph.org
Subject: [speex-dev] Java bindings
Content-Type: text/plain; charset=us-ascii; format=flowed
Content-Transfer-Encoding: 7bit
X-TMDA-Confirmed: Fri Dec 13 18:27:20 EST 2002
Sender: owner-speex-dev@xiph.org
Precedence: bulk
Reply-To: speex-dev@xiph.org
X-Spam-Status: No, hits=0.4 required=5.0
	tests=SUPERLONG_LINE
	version=2.31
X-Spam-Level: 

Hi,

I have writen a simple JNI wrapper for speex so i could use it from Java, so far i managed to record from a raw pcm file and from the javasound inputLine and to decode the output in narrowband CBR mode and play it back still using javasound.
And it sounds quite good.
I haven't tried anything else because my project has no use for wideband and ultra wideband.

VBR would be nice but i have troubles with it.. (explained near the end of this mail)

The native interface should compile on every plateform that has a jdk and libSpeex (or was it speexLib ?). I used the jdk1.4 and Windows but a friend of mine got it to work under FreeBSD and jdk1.3 without any modifications (That i'm aware of at least).

It still has a few flaws i could fix (if i was not so lazy).

1/bytesex
First It will probably have endianess problem, java is big endian by the spec,
while the host machine i've considered is little endian (x86). So everything 
that is received from java is converted to little endian. As far as i understand
speex (not much) it expects to receive byte (floats?) in the host machine order so it will probably fails under a big endianned architecture like powerpc or sparc.

Speexbits returns the bytes to java in little endian ordering.
Or does it depend on the host machine? Anyway in my case it's little endian.
Again it mights cause problems.

2/java
It's not a nice java class like someone used to java could expect.
It won't take an InputStream and give a nice OutputStream (or PushBufferDataSource) nor will it configure itself automagically based how it feels today like the Java Media Framework. (Although it could be easy nice to write a codec interface for it using speex based on my class)
So far it wraps some/most of Speex calls in a class i've called speex.SpeexLib and using it involves managing C pointers from the java side.
ie : I use jlong to pass around the encoder & SpeexBits pointer's address. 
It's not pretty but it's the only way i've found.
Oh and it's not "zero copy", i think there might be something to do with the new IO api of java 1.4 but i'm not sure and java 1.3 is still widely used.

I still have a few problem i can't fix by myself because i don't understand everything (if anything) in Speex. Any help will be appreciated.

On the same input (a file) while CBR is working just fine, VBR doesn't seem to work at all, the number of byte returned if not zero average 2 or 3 for an input of 256 (i think). And when decoded, well, it doesn't sounds like anything.

Encoding N "frame" in a speexbits without reseting it (like it's done in speexenc) "accelerate" the sound N time when playing it back. Is that the normal behaviour?

All this probably has to do with the fact i don't have any clue on how to use in-band signalling.

Anyway, if someone is interested by this, send me a mail as i have no place to host it.
The only "Licensing term" i put over the code is that you must send back to me/the speex user community any enhancement and bug fix for the rest BSD license applies.

That's all.
Thank you Jean Marc for this great audio codec.

Boyd.

--
Boyd Ebsworthy
Paris, France.



--- >8 ----
List archives:  http://www.xiph.org/archives/
Ogg project homepage: http://www.xiph.org/ogg/
To unsubscribe from this list, send a message to 'speex-dev-request@xiph.org'
containing only the word 'unsubscribe' in the body.  No subject is needed.
Unsubscribe messages sent to the list will be ignored/filtered.
