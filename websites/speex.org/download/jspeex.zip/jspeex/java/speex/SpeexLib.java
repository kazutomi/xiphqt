/* libspeex SpeexBits wrapper
 *  
 * Copyright (C) 2002 Boyd Ebsworthy 
 * This code is released under the terms of the BSD license
 * Please send enhancement and bug fix to <bebsworthy@entreview.com> 
 *
 * libspeex is Copyright (C) 2002 Jean-Marc Valin 
 * see : http://www.speex.org/ for more information about libspeex 
 *
 * User: boyd
 * Date: Nov 23, 2002
 * Time: 4:12:26 PM
 */

package speex;

/**
 * Java Interface to the speex Library
 */

public class SpeexLib {
	public static boolean jspeex_ok = false;

	static {
		try {
			System.loadLibrary("jspeex");
			jspeex_ok = true;
		} catch (Exception e) {
			jspeex_ok = false;
			e.printStackTrace();
		} catch (Error err) {
			jspeex_ok = false;
			err.printStackTrace();
		}
	}

	public static final boolean jspeex_init_ok() { return jspeex_ok; }
	/**
	 * speex_mode
	 **/
	/** Default narrowband mode */
	public static final int speex_nb_mode = 0;

	/** Default wideband mode */
	public static final int speex_wb_mode = 1;

	/** Default "ultra-wideband" mode */
	public static final int speex_uwb_mode = 2;


	/**
	 * Returns a handle to a newly created SpeexLib encoder state structure. For now,
	 * the "mode" arguent can be &nb_mode or &wb_mode . In the future, more modes
	 * may be added. Note that for now if you have more than one channels to
	 * encode, you need one state per channel.
	 *
	 * @param mode The mode to use (either speex_nb_mode or speex_wb_mode)
	 * @return the newly created encoder state (void*)
	 */
	public static native long speex_encoder_init(int mode);

	/** Frees all resources associated to an existing SpeexLib encoder state.
	 * @param state Encoder state to be destroyed */
	public static native void speex_encoder_destroy(long state);


	/**
	 *
	 * @param state         the encoder
	 * @param in            array of byte to encode size must be SPEEX_GET_FRAME_SIZE
	 * @param speexBits     SpeexBits object
	 * @param bitsPerSample    8 or 16 bits sample size
	 * @param channels      1=mono 2=stereo
	 * @param endian        0=big  1=little
	 */
	public static native void speex_encode(long state, byte[] in, SpeexBits speexBits, int bitsPerSample, int channels, int endian);

	/**
	 * Uses an existing encoder state to encode one frame of speech pointed to by
	 * "in". The encoded bit-stream is saved in "bits".
	 * @param state Encoder state
	 * @param in Frame that will be encoded with a +-2^16 range
	 * @param speexBits Bit-stream where the data will be written
	 */
	public static native void speex_encode(long state, float[] in, SpeexBits speexBits);
	//public static native void speex_encode(long state, float[] in, SpeexBits *bits);

	/** Used like the ioctl function to control the encoder parameters
	 *
	 * @param state Encoder state
	 * @param request ioctl-type request (one of the SPEEX_* macros)
	 * @param voidPtr Data exchanged to-from function
	 */
	public static native void speex_encoder_ctl(long state, int request, Long voidPtr); //xxx : void ptr
	//public static native void speex_encoder_ctl(long state, int request, void *ptr);

	/**
	 * Returns a handle to a newly created decoder state structure. For now,
	 * the mode arguent can be &nb_mode or &wb_mode . In the future, more modes
	 * may be added. Note that for now if you have more than one channels to
	 * decode, you need one state per channel.
	 *
	 * @param mode SpeexLib mode (one of speex_nb_mode or speex_wb_mode)
	 * @return A newly created decoder state
	 */
	public static native long speex_decoder_init(int mode);

	/** Frees all resources associated to an existing decoder state.
	 *
	 * @param state State to be destroyed
	 */
	public static native void speex_decoder_destroy(long state);

	/**
	 *
	 * @param state
	 * @param speexBits
	 * @param out
	 * @return
	 */
	public static native int speex_decode(long state, SpeexBits speexBits, byte[] out);

	/**
	 * Uses an existing decoder state to decode one frame of speech from
	 * bit-stream bits. The output speech is saved written to out.
	 *
	 * @param state Decoder state
	 * @param speexBits Bit-stream from which to decode the frame (NULL if the packet was lost)
	 * @param out Where to write the decoded frame
	 * @return return status (0 for no error, -1 for end of stream, -2 other)
	 */
	public static native int speex_decode(long state, SpeexBits speexBits, float[] out);
	//public static native int speex_decode(long state, SpeexBits *bits, float[] out);

	/** Used like the ioctl function to control the encoder parameters
	 *
	 * @param state Decoder state
	 * @param request ioctl-type request (one of the SPEEX_* #define)
	 * @param voidPtr Data exchanged to-from function
	 */
	public static native void speex_decoder_ctl(long state, int request, Long voidPtr);
	//public static native void speex_decoder_ctl(long state, int request, void *ptr);


	/** Query function for mode information
	 *
	 * @param mode SpeexLib mode
	 * @param request ioctl-type request (one of the SPEEX_* macros)
	 * @param voidPtr Data exchanged to-from function
	 */
	public static native void speex_mode_query(int mode, int request, Long voidPtr);
	//public static native void speex_mode_query(int mode, int request, void *ptr);

	/****************************************************************************************
	 * SpeexBits functions
	 */
	/** Initializes and allocates resources for a SpeexBits struct */
	public static native void speex_bits_init(SpeexBits bits);

	/** Initializes SpeexBits struct using a pre-allocated buffer*/
	//todo : implement me
	//public static native void speex_bits_init_buffer(SpeexBits bits, void *buff);
	//public static native void speex_bits_init_buffer(SpeexBits bits, Long buff);

	/** Frees all resources assiociated to a SpeexBits struct. Right now this does nothing since no resources are allocated, but this could change in the future.*/
	public static native void speex_bits_destroy(SpeexBits bits);

	/** Resets bits to initial value (just after initialization, erasing content)*/
	public static native void speex_bits_reset(SpeexBits bits);

	/** Rewind the bit-stream to the beginning (ready for read) without erasing the content */
	public static native void speex_bits_rewind(SpeexBits bits);

	/** Initializes the bit-stream from the data in an area of memory */
	//todo : implement me
	//public static native void speex_bits_read_from(SpeexBits bits, char *bytes, int len);
	public static native void speex_bits_read_from(SpeexBits bits, byte[] bytes, int len);

	/** Append bytes to the bit-stream
	 * @param bits Bit-stream to operate on
	 * @param bytes pointer to the bytes what will be appended
	 * @param len Number of bytes of append
	 */
	//todo : implement me
	//public static native void speex_bits_read_whole_bytes(SpeexBits bits, byte[] bytes, int len);

	/** Write the content of a bit-stream to an area of memory */
	public static native int speex_bits_write(SpeexBits bits, byte[] bytes, int max_len);

	/** Like speex_bits_write, but writes only the complete bytes in the stream. Also removes the written bytes from the stream */
	public static native int speex_bits_write_whole_bytes(SpeexBits bits, byte[] bytes, int max_len);

	/** Append bits to the bit-stream
	 * @param bits Bit-stream to operate on
	 * @param data Value to append as integer
	 * @param nbBits number of bits to consider in "data"
	 */
	//void speex_bits_pack(SpeexBits *bits, int data, int nbBits);
	public static native void speex_bits_pack(SpeexBits bits, int data, int nbBits);

	/** Interpret the next bits in the bit-stream as a signed integer
	 *
	 * @param bits Bit-stream to operate on
	 * @param nbBits Number of bits to interpret
	 * @return A signed integer represented by the bits read
	 */
	public static native int speex_bits_unpack_signed(SpeexBits bits, int nbBits);

	/** Interpret the next bits in the bit-stream as an unsigned integer
	 *
	 * @param bits Bit-stream to operate on
	 * @param nbBits Number of bits to interpret
	 * @return An unsigned integer represented by the bits read
	 */
	//xxx : how does unsigned works in java ? :)
	public static native int speex_bits_unpack_unsigned(SpeexBits bits, int nbBits);

	/** Returns the number of bytes in the bit-stream, including the last one even if it is not "full"
	 *
	 * @param bits Bit-stream to operate on
	 * @return Number of bytes in the stream
	 */
	public static native int speex_bits_nbytes(SpeexBits bits);

	/** Same as speex_bits_unpack_unsigned, but without modifying the cursor position */
	//xxx : unsigned ?
	public static native /*unsigned*/ int speex_bits_peek_unsigned(SpeexBits bits, int nbBits);

	/** Get the value of the next bit in the stream, without modifying the
	 * "cursor" position
	 *
	 * @param bits Bit-stream to operate on
	 */
	public static native int speex_bits_peek(SpeexBits bits);

	/** Advances the position of the "bit cursor" in the stream
	 *
	 * @param bits Bit-stream to operate on
	 * @param n Number of bits to advance
	 * */
	public static native void speex_bits_advance(SpeexBits bits, int n);
}
