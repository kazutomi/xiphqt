/* libspeex wrapper
 * 
 * This class wraps the speexbits struct so it's member values are accessible from
 * java.
 * 
 * Copyright (C) 2002 Boyd Ebsworthy 
 * This code is released under the terms of the BSD license
 * Please send enhancement and bug fix to <bebsworthy@entreview.com> 
 *
 * libspeex is Copyright (C) 2002 Jean-Marc Valin 
 * see : http://www.speex.org/ for more information about libspeex 
 *
 * User: boyd
 * Date: Nov 23, 2002
 * Time: 4:58:34 PM
 */
package speex;

public class SpeexBits {
	protected long address = 0;

	int nbBits;     // Total number of bits stored in the stream
	int bytePtr;    // Position of the byte "cursor"
	int bitPtr;     // Position of the bit "cursor" within the current byte
	int owner;      // Does the struct "own" the "raw" buffer (member "bytes")


	public String toString() {
		return " � SpeexBits : address=" + address + " | nbBits=" + nbBits + " | bytePtr=" + bytePtr + " | bitPtr=" + bitPtr + " | owner=" + owner;
	}
}
