/* libspeex wrapper
 *
 * This is my scratch pad test class, i don't think anyone will be able to use it
 * as is, but it should give a good idea of of to do simple stuff. 
 *  
 * Copyright (C) 2002 Boyd Ebsworthy 
 * This code is released under the terms of the BSD license
 * Please send enhancement and bug fix to <bebsworthy@entreview.com> 
 *
 * libspeex is Copyright (C) 2002 Jean-Marc Valin 
 * see : http://www.speex.org/ for more information about libspeex 
 *
 * You can find the AudioPlayStream class on jsresources.org 
 *
 * User: boyd Boyd Ebsworthy
 * Date: Nov 23, 2002
 * Time: 8:40:50 PM
 */
package speex;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class SpeexTest {

	public static void main(String[] argv) {
		AudioPlayStream audioPlayStream = new AudioPlayStream();
		SpeexEncoder encoder = new SpeexEncoder(8000, 16, 1, false);
		SpeexDecoder decoder = new SpeexDecoder(8000, 16);

		// open file
		FileInputStream in;
		try {
			File file = new File("c:/raw_8000_16_1_big.pcm");
			in = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace(); //xxx: do something with exception
			return;
		}

		// init sound
		try {
			audioPlayStream.open();
			audioPlayStream.start();
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}

		// loop
		try {
			int frame_size = 0;
			encoder.init(SpeexLib.speex_nb_mode);
			decoder.init(SpeexLib.speex_nb_mode);

			frame_size = encoder.getFrame_size();
			System.out.println("frame_size = " + frame_size);

			byte[] binput = new byte[2*frame_size];
			byte[] boutput = new byte[2*frame_size];
			byte[] decoutput = new byte[2*frame_size];

			boolean done = false;

			while (!done) {
				int read = in.read(binput, 0, 2 * frame_size);

				if (read < 0) {
					done = true;
					continue;
				}

				//encode
				encoder.encode(binput);

				int len = encoder.bitsWrite(boutput);

				System.out.println("len = " + len);

				//decode
					decoder.read(boutput, len);
					int decres = decoder.decode(decoutput);

					if(decres == 0) {
						audioPlayStream.write(decoutput, 0, decoutput.length);
					}
			}


		} catch (SpeexException e) {
			e.printStackTrace(); //xxx: do something with exception
		} catch (IOException e) {
			e.printStackTrace(); //xxx: do something with exception
		}

		audioPlayStream.setImmediateStop(true);

		try {
			encoder.destroy();
			decoder.destroy();
		} catch (SpeexException e) {
			e.printStackTrace(); //xxx: do something with exception
		}

	}

	/*
	public static void main(String[] argv) {
		AudioPlayStream audioPlayStream = new AudioPlayStream();

		try {
			audioPlayStream.open();
			audioPlayStream.start();
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}

		File f = new File("c:/raw_8000_16_1_big.pcm");
		FileInputStream in;
		try {
			in = new FileInputStream(f);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return;
		}
		// something seems wrong with VBR
		boolean vbr_enabled = false;
		int quality = -1;
		int vbr_quality = 9; //!!!!!!!
		int bitrate = 8000;
		// int nframes =    1; number of frame / packet
		int complexity = 3;
		boolean lsb = false;//false=>big endian   true=>little endian
		int fmt = 16;
		int chan = 1;
		int frame_size = 0;
		int dec_frame_size = 0;

		// init the encoder
		long encoder = SpeexLib.speex_encoder_init(SpeexLib.speex_nb_mode);
		System.out.println("encoder = " + encoder);

		long decoder = SpeexLib.speex_decoder_init(SpeexLib.speex_nb_mode);

		{ //init the decoder
			Long dec_enh = new Long(1);
			SpeexLib.speex_decoder_ctl(decoder, SpeexValue.SPEEX_SET_ENH, dec_enh);

			Long dec_vbr = new Long(0);
			SpeexLib.speex_decoder_ctl(decoder, SpeexValue.SPEEX_SET_VBR, dec_vbr);

			Long dec_rate = new Long(bitrate);
			SpeexLib.speex_decoder_ctl(decoder, SpeexValue.SPEEX_SET_SAMPLING_RATE, dec_rate);

			Long dec_fs = new Long(frame_size);
			SpeexLib.speex_decoder_ctl(decoder, SpeexValue.SPEEX_GET_FRAME_SIZE, dec_fs);
			dec_frame_size = dec_fs.intValue();
		}

		{ //init the encoder
			Long enc_fs = new Long(0);
			SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_GET_FRAME_SIZE, enc_fs);
			frame_size = enc_fs.intValue();

			Long enc_complex = new Long(complexity);
			SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_SET_COMPLEXITY, enc_complex);
			complexity = enc_complex.intValue();


			Long enc_rate = new Long(bitrate);
			SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_SET_SAMPLING_RATE, enc_rate);
		}

		System.out.println("frame_size 		= " + frame_size);
		System.out.println("dec_frame_size 	= " + dec_frame_size);
		System.out.println("complexity 		= " + complexity);
		System.out.println("bitrate 		= " + bitrate);

		if (vbr_enabled) {

			Long enc_vbr = new Long(1);
			SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_SET_VBR, enc_vbr);

			Long enc_quality = new Long(vbr_quality);
			SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_SET_VBR_QUALITY, enc_quality);

		}

		if (quality > 0) {
			Long enc_quality = new Long(quality);
			SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_SET_QUALITY, enc_quality);
		}


		SpeexBits bits = new SpeexBits();
		SpeexLib.speex_bits_init(bits);

		SpeexBits decbits = new SpeexBits();
		SpeexLib.speex_bits_init(decbits);
		//System.out.println("bits = " + bits);

		byte[] byte_input = new byte[2 * frame_size];
		byte[] byte_output = new byte[2 * frame_size];
		byte[] byte_decoded = new byte[2 * dec_frame_size];

		try {
			int total = 0;
			int size = 1;
			int COUNT = 0;
			//for(int i = 0; i< 1000; i++) {
			boolean done = false;
			while (!done) {
				int read = in.read(byte_input, 0, 2 * frame_size);
				if (read < 0) {
					done = true;
					continue;
				}

				SpeexLib.speex_encode(encoder, byte_input, bits, 16, 1, 0);
				int nbBytes = SpeexLib.speex_bits_write(bits, byte_output, byte_output.length);

				System.out.println("--------------" + COUNT++ + "--------------") ;
				for (int i = 0; i < byte_output.length; i++) {
					byte b = byte_output[i];
					System.out.print("," + b);
				}
				System.out.println("");

				SpeexLib.speex_bits_read_from(decbits, byte_output, nbBytes);

				int status = SpeexLib.speex_decode(decoder, decbits, byte_decoded);
				if (status == 0) {
					audioPlayStream.write(byte_decoded, 0, byte_decoded.length);
					System.out.println("");
				} else {
					done = true;
					continue;
				}
				SpeexLib.speex_bits_reset(decbits);
				SpeexLib.speex_bits_reset(bits);

			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		SpeexLib.speex_bits_destroy(bits);
		// cleanup
		SpeexLib.speex_decoder_destroy(decoder);
		SpeexLib.speex_encoder_destroy(encoder);

	}
	*/

}
