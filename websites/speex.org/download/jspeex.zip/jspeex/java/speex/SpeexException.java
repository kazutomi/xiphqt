/* Copyright (C) 2002 Boyd Ebsworthy */
/* Released under the terms of your favorite OSI approved license. */
/*
 * User: boyd
 * Date: Nov 25, 2002
 * Time: 3:22:30 PM
 */
package speex;

public class SpeexException extends Exception {

	public SpeexException() {
	}

	public SpeexException(String message) {
		super(message);
	}

	public SpeexException(String message, Throwable cause) {
		super(message, cause);
	}

	public SpeexException(Throwable cause) {
		super(cause);
	}

}
