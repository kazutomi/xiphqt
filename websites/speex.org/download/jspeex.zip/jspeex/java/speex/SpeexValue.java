/* libspeex wrapper
 * 
 * This class map the value used by libspeex
 * name, value and comments have been taken from various libspeex header files. 
 * 
 * Copyright (C) 2002 Boyd Ebsworthy 
 * This code is released under the terms of the BSD license
 * Please send enhancement and bug fix to <bebsworthy@entreview.com> 
 *
 * libspeex is Copyright (C) 2002 Jean-Marc Valin 
 * see : http://www.speex.org/ for more information about libspeex 
 *
 * User: boyd
 * Date: Nov 23, 2002
 * Time: 7:34:50 PM
 */
package speex;

public class SpeexValue {
	/**
	 *  Values allowed for *ctl() requests
	 **/
	/** Set enhancement on/off (decoder only) */
	public static final int SPEEX_SET_ENH = 0;
	/** Get enhancement state (decoder only) */
	public static final int SPEEX_GET_ENH = 1;

	/* Would be SPEEX_SET_FRAME_SIZE, but it's (currently) invalid*/
	/** Obtain frame size used by encoder/decoder */
	public static final int SPEEX_GET_FRAME_SIZE = 3;

	/** Set quality value */
	public static final int SPEEX_SET_QUALITY = 4;
	/** Get current quality setting */
	public static final int SPEEX_GET_QUALITY = 5;

	/** Set sub-mode to use */
	public static final int SPEEX_SET_MODE = 6;
	/** Get current sub-mode in use */
	public static final int SPEEX_GET_MODE = 7;

	/** Set low-band sub-mode to use (wideband only)*/
	public static final int SPEEX_SET_LOW_MODE = 8;
	/** Get current low-band mode in use (wideband only)*/
	public static final int SPEEX_GET_LOW_MODE = 9;

	/** Set high-band sub-mode to use (wideband only)*/
	public static final int SPEEX_SET_HIGH_MODE = 10;
	/** Get current high-band mode in use (wideband only)*/
	public static final int SPEEX_GET_HIGH_MODE = 11;

	/** Set VBR on (1) or off (0) */
	public static final int SPEEX_SET_VBR = 12;
	/** Get VBR status (1 for on, 0 for off) */
	public static final int SPEEX_GET_VBR = 13;

	/** Set quality value for VBR encoding (0-10) */
	public static final int SPEEX_SET_VBR_QUALITY = 14;
	/** Get current quality value for VBR encoding (0-10) */
	public static final int SPEEX_GET_VBR_QUALITY = 15;

	/** Set complexity of the encoder (0-10) */
	public static final int SPEEX_SET_COMPLEXITY = 16;
	/** Get current complexity of the encoder (0-10) */
	public static final int SPEEX_GET_COMPLEXITY = 17;

	/** Set bit-rate used by the encoder (or lower) */
	public static final int SPEEX_SET_BITRATE = 18;
	/** Get current bit-rate used by the encoder or decoder */
	public static final int SPEEX_GET_BITRATE = 19;

	/**Define a handler function for in-band SpeexLib request*/
	public static final int SPEEX_SET_HANDLER = 20;

	/**Define a handler function for in-band user-defined request*/
	public static final int SPEEX_SET_USER_HANDLER = 22;

	public static final int SPEEX_SET_SAMPLING_RATE = 24;
	public static final int SPEEX_GET_SAMPLING_RATE = 25;

	/* Used internally, not to be used in applications
	public static final int SPEEX_GET_PI_GAIN = 100;
	public static final int SPEEX_GET_EXC  = 101;
	public static final int SPEEX_GET_INNOV = 102;
	*/

	/* Preserving compatibility:*/
	/** Equivalent to SPEEX_SET_ENH */
	public static final int SPEEX_SET_PF = 0;
	/** Equivalent to SPEEX_GET_ENH */
	public static final int SPEEX_GET_PF = 1;


	/* Values allowed for mode queries */
	/** Query the frame size of a mode */
	public static final int SPEEX_MODE_FRAME_SIZE = 0;

	/** Query the size of an encoded frame for a particular sub-mode */
	public static final int SPEEX_SUBMODE_BITS_PER_FRAME = 1;

	/** Number of defined modes in SpeexLib */
	public static final int SPEEX_NB_MODES = 3;

}
