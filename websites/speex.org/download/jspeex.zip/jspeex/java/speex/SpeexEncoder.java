/* libspeex wrapper
 *
 * This is a class for easy initialisation of an encoder with the speex library.
 *  
 * Copyright (C) 2002 Boyd Ebsworthy 
 * This code is released under the terms of the BSD license
 * Please send enhancement and bug fix to <bebsworthy@entreview.com> 
 *
 * libspeex is Copyright (C) 2002 Jean-Marc Valin 
 * see : http://www.speex.org/ for more information about libspeex 
 * 
 * User: boyd
 * Date: Nov 25, 2002
 * Time: 2:48:30 PM
 */
package speex;
/*
 * todo : for java 1.4+ Exception should use Chained Exception instead of "+ e.toString()".
 */
/**
 * Java Style Speex Encoder (wrapper to the SpeexLib/jspeex.dll native encoder)
 */
public class SpeexEncoder {

	/* the encoding mode */
	private int mode = SpeexLib.speex_nb_mode;

	/* encoder settings */
	private int vbr_enabled = 0; // something seems wrong with VBR
	private int quality = -1;
	private int vbr_quality = 0; //FIXME: this should be a float but my wrapper doesn't support float params!
	private int complexity = 3;
	private int frame_size = 0;

	/* input stream settings */
	private int bitrate = 8000;
	private int bitsPerSample = 16;
	private int channels = 1;
	private int little_endian = 0; //0=>big endian   1=>little endian

	/* encoder pointer. Yeah, pointer in java... :) */
	private long encoder = 0;

	/* SpeexBits pointer... */
	SpeexBits bits = new SpeexBits();

	int total_byte_in = 0;
	int total_byte_out = 0;

	/**
	 *
	 * @param bitrate
	 * @param bitsPerSample
	 * @param channels
	 * @param little_endian
	 */
	public SpeexEncoder(int bitrate, int bitsPerSample, int channels, boolean little_endian) {
		this.bitrate = bitrate;
		this.bitsPerSample = bitsPerSample;
		this.channels = channels;
		this.little_endian = (little_endian) ? 1 : 0;
	}

	/**
	 * verify that encoder is a "valid" pointer
	 * @throws SpeexException
	 */
	private void check_encoder() throws SpeexException {
		if (encoder == 0) {
			throw new SpeexException("Invalid Encoder Pointer.");
		}
	}

	/* verify that bits is a "valid" SpeexBit pointer */
	private void check_bits() throws SpeexException {
		if (bits.address == 0) {
			throw new SpeexException("Invalid SpeexBits Pointer.");
		}
	}


	/**
	 * Encode a byte array.
	 *
	 * @param array array of byte : the length must be 2*frame_size
	 */
	public void encode(byte[] array) throws SpeexException {
		check_encoder();
		check_bits();

		if (array.length != (2 * frame_size)) {
			throw new SpeexException("byte array length must be 2*frame size!");
		}

		try {
			SpeexLib.speex_encode(encoder, array, bits, bitsPerSample, channels, little_endian);
			total_byte_in += array.length;
		} catch (Error e) { //catch library error
			//jdk 1.3
			throw new SpeexException("An Error occured while encoding data : " + e.toString());
			//jdk 1.4
			//throw new SpeexException("An Error occured while encoding data : ",  e);
		}

	}


	/**
	 * Write the encoded byte to the specified byte array
	 * @param output where to write the encoded data
	 * @return the amount of byte that have been written.
	 */
	public int bitsWrite(byte[] output) throws SpeexException {
		check_bits();

		int nbBytes;

		try {
			//write the bits stream
			nbBytes = SpeexLib.speex_bits_write(bits, output, output.length);

			//reset the speexbits
			SpeexLib.speex_bits_reset(bits);

			//store the total amount of byte encoded.
			total_byte_out += nbBytes;

			//return the amount of data written
			return nbBytes;

		} catch (Error e) {
			throw new SpeexException("An Error occured while reading data : " + e.toString());
			//throw new SpeexException("An Error occured while encoding data : ",  e);
		}
	}

	/**
	 *
	 * @throws SpeexException
	 */
	public void destroy() throws SpeexException  {
		Error e = null;
		/* cleanup */
		try {
			SpeexLib.speex_bits_destroy(bits);
		} catch (Error err) {
			e = err;
		}
		try {
			SpeexLib.speex_encoder_destroy(encoder);
		} catch (Error err) {
			e = err;
		}

		if(e!= null) {
			throw new SpeexException("An Error occured while destroying pointers : " + e.toString());
		}
	}

	/**
	 * Init the encoder
	 * @param mode the mode
	 */
	public void init(int mode) throws SpeexException {

		if(!SpeexLib.jspeex_init_ok()) {
			throw new SpeexException("jspeex is not loaded");
		}

		this.mode = mode;

		//init the encoder
		encoder = SpeexLib.speex_encoder_init(mode);

		check_encoder();

		try {
			/* get the frame size for this mode */
			Long enc_fs = new Long(0);
			SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_GET_FRAME_SIZE, enc_fs);
			frame_size = enc_fs.intValue();

			/* set the complexity */
			Long enc_complex = new Long(complexity);
			SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_SET_COMPLEXITY, enc_complex);
			//complexity = enc_complex.intValue();

			/* set the encoding rate */
			Long enc_rate = new Long(bitrate);
			SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_SET_SAMPLING_RATE, enc_rate);
			//bitrate = enc_rate.intValue();


			/* set the vbr option */
			if (vbr_enabled != 0) {

				Long enc_vbr = new Long(vbr_enabled);
				SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_SET_VBR, enc_vbr);

				Long enc_quality = new Long(vbr_quality);
				SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_SET_VBR_QUALITY, enc_quality);

			}

			/* set the quality */
			if (quality > 0) {
				Long enc_quality = new Long(quality);
				SpeexLib.speex_encoder_ctl(encoder, SpeexValue.SPEEX_SET_QUALITY, enc_quality);
			}

			/* init the SpeexBits */
			SpeexLib.speex_bits_init(bits);

			check_bits();

		} catch (Error e) { //catch library error

			throw new SpeexException("An Error occured while initializing the encoder : " + e.toString());
			//throw new SpeexException("An Error occured while encoding data : ",  e);
		}
	}

	/**
	 *  Bunch of getters and Setters (auto-generated by IDEA)
	 **/
	public int getMode() {
		return mode;
	}

	public int getVbr_enabled() {
		return vbr_enabled;
	}

	public void setVbr_enabled(int vbr_enabled) {
		this.vbr_enabled = vbr_enabled;
	}

	public int getQuality() {
		return quality;
	}

	public void setQuality(int quality) {
		this.quality = quality;
	}

	public int getVbr_quality() {
		return vbr_quality;
	}

	public void setVbr_quality(int vbr_quality) {
		this.vbr_quality = vbr_quality;
	}

	public int getComplexity() {
		return complexity;
	}

	public void setComplexity(int complexity) {
		this.complexity = complexity;
	}

	public int getFrame_size() {
		return frame_size;
	}

	public void setFrame_size(int frame_size) {
		this.frame_size = frame_size;
	}

	public int getBitrate() {
		return bitrate;
	}

	public void setBitrate(int bitrate) {
		this.bitrate = bitrate;
	}

	public int getBitsPerSample() {
		return bitsPerSample;
	}

	public void setBitsPerSample(int bitsPerSample) {
		this.bitsPerSample = bitsPerSample;
	}

	public int getChannels() {
		return channels;
	}

	public void setChannels(int channels) {
		this.channels = channels;
	}

	public int getLittle_endian() {
		return little_endian;
	}

	public void setLittle_endian(int little_endian) {
		this.little_endian = little_endian;
	}

	public long getEncoder() {
		return encoder;
	}

	public void setEncoder(long encoder) {
		this.encoder = encoder;
	}

	public SpeexBits getBits() {
		return bits;
	}

	public void setBits(SpeexBits bits) {
		this.bits = bits;
	}

	public int getTotal_byte_in() {
		return total_byte_in;
	}
}
