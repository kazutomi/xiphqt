/* libspeex wrapper
 *
 * This is a class for easy initialisation of a decoder with the speex library.
 *  
 * Copyright (C) 2002 Boyd Ebsworthy 
 * This code is released under the terms of the BSD license
 * Please send enhancement and bug fix to <bebsworthy@entreview.com> 
 *
 * libspeex is Copyright (C) 2002 Jean-Marc Valin 
 * see : http://www.speex.org/ for more information about libspeex 
 *
 * User: boyd
 * Date: Nov 25, 2002
 * Time: 3:49:10 PM
 */
package speex;

public class SpeexDecoder {
	/* the encoding mode */
	private int mode = SpeexLib.speex_nb_mode;

	/* encoder settings */
	private int enh_enabled 	= 0;
	private int vbr_enabled 	= 0; // something seems wrong with VBR
	private int frame_size 		= 0;

	/* input stream settings */
	private int bitrate 		= 8000;
	private int bitsPerSample 	= 16;
	/*  unused yet
		private int channels 		= 1;
		private int little_endian 	= 0; //false=>big endian   true=>little endian
	*/

	/* decoder pointer. */
	private long decoder = 0;

	/* SpeexBits pointer. */
	SpeexBits bits = new SpeexBits();

	int total_byte_in = 0;
	int total_byte_out = 0;

	/**
	 *
	 * @param bitrate
	 * @param bitsPerSample
	 */
	public SpeexDecoder(int bitrate, int bitsPerSample /*, int channels, boolean little_endian */) {
		this.bitrate = bitrate;
		this.bitsPerSample = bitsPerSample;
		/*
		this.channels = channels;
		this.little_endian = (little_endian) ? 1 : 0;
		*/
	}

	/**
	 * verify that encoder is a "valid" pointer (ie. non zero)
	 * @throws SpeexException
	 */
	private void check_decoder() throws SpeexException {
		if (decoder == 0) {
			throw new SpeexException("Invalid Encoder Pointer.");
		}
	}

	/**
	 *  verify that bits is a "valid" SpeexBit pointer (i.e : non zero)
	 **/
	private void check_bits() throws SpeexException {
		if (bits.address == 0) {
			throw new SpeexException("Invalid SpeexBits Pointer.");
		}
	}

	/**
	 *  Read bytes, into the decoder bitstream
	 * @param input
	 * @param length
	 * @throws SpeexException
	 */
	public void read(byte[] input, int length) throws SpeexException {
		check_decoder();
		check_bits();

		try {
			SpeexLib.speex_bits_read_from(bits, input, length);
		} catch (Error e) {
			throw new SpeexException("An Error occured while reading data : " + e.toString());
		}
	}

	/**
	 * decode the bitstream into the output
	 * @param output decoded byte
	 */
	public int decode(byte[] output) throws SpeexException {

		if(output.length != 2*frame_size) {
			throw new SpeexException("byte array length must be 2*frame size!");
		}
		check_decoder();
		check_bits();

		int status = 0;
		try {

			status = SpeexLib.speex_decode(decoder, bits, output);

			if(status < -1) {
				throw new SpeexException("decode returned " + status);
			}

		} catch (Error e) {
			throw new SpeexException("An Error occured while decoding data : " + e.toString());
		}

		return status;

	}

	/**
	 * destroy
	 * @throws SpeexException
	 */
	public void destroy() throws SpeexException  {
		Error e = null;
		/* cleanup */
		try {
			SpeexLib.speex_bits_destroy(bits);
		} catch (Error err) {
			e = err;
		}
		try {
			SpeexLib.speex_encoder_destroy(decoder);
		} catch (Error err) {
			e = err;
		}

		if(e!= null) {
			throw new SpeexException("An Error occured while destroying pointers : " + e.toString());
		}
	}

	/**
	 *
	 * @param mode
	 * @throws SpeexException
	 */
	public void init(int mode) throws SpeexException {
		if(!SpeexLib.jspeex_init_ok()) {
			throw new SpeexException("jspeex is not loaded");
		}

		this.mode = mode;

		decoder = SpeexLib.speex_decoder_init(mode);

		check_decoder();

		try {
			//init the decoder
			Long dec_enh = new Long(enh_enabled);
			SpeexLib.speex_decoder_ctl(decoder, SpeexValue.SPEEX_SET_ENH, dec_enh);

			Long dec_vbr = new Long(vbr_enabled);
			SpeexLib.speex_decoder_ctl(decoder, SpeexValue.SPEEX_SET_VBR, dec_vbr);

			Long dec_rate = new Long(bitrate);
			SpeexLib.speex_decoder_ctl(decoder, SpeexValue.SPEEX_SET_SAMPLING_RATE, dec_rate);
			// xxx : !?
			//SpeexValue.SPEEX_SET_BITRATE

			Long dec_fs = new Long(frame_size);
			SpeexLib.speex_decoder_ctl(decoder, SpeexValue.SPEEX_GET_FRAME_SIZE, dec_fs);
			frame_size = dec_fs.intValue();

			/* init the SpeexBits */
			SpeexLib.speex_bits_init(bits);

			check_bits();

		} catch (Error e) {
			throw new SpeexException("An Error occured while initializing decoder : " + e.toString());

		}
	}


	/*** auto generated getter & setters **/
	public int getMode() {
		return mode;
	}

	public void setMode(int mode) {
		this.mode = mode;
	}

	public int getEnh_enabled() {
		return enh_enabled;
	}

	public void setEnh_enabled(int enh_enabled) {
		this.enh_enabled = enh_enabled;
	}

	public int getVbr_enabled() {
		return vbr_enabled;
	}

	public void setVbr_enabled(int vbr_enabled) {
		this.vbr_enabled = vbr_enabled;
	}

	public int getFrame_size() {
		return frame_size;
	}

	public void setFrame_size(int frame_size) {
		this.frame_size = frame_size;
	}

	public int getBitrate() {
		return bitrate;
	}

	public void setBitrate(int bitrate) {
		this.bitrate = bitrate;
	}

	public int getBitsPerSample() {
		return bitsPerSample;
	}

	public void setBitsPerSample(int bitsPerSample) {
		this.bitsPerSample = bitsPerSample;
	}

	public long getDecoder() {
		return decoder;
	}

	public void setDecoder(long decoder) {
		this.decoder = decoder;
	}
}
