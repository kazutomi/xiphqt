Simple WIN32 project for visual C++ 6 to build jspeex.dll

You will need :

- libspeex 1.0b3 source code available from http://www.speex.org
- a JDK available from http://java.sun.com
- to edit the path in the project so they match your installation.


