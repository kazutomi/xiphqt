; speexDS_installer.nsi
; Copyright (C) 2003 Jean-Francois Emond
;
; This script is used to generate a nullsoft installer for the Speex
; DirectShow filters.
;

; The name of the installer
Name "Speex DirectShow filters"

; The file to write
OutFile "speexDS_setup.exe"

ShowInstDetails show
ShowUninstDetails show
SetOverwrite on
SetDateSave on

; The default installation directory
InstallDir $WINDIR\system32

; The stuff to install
Section "Install"
  MessageBox MB_YESNO "Do you want to install the Speex DirectShow filters,$\nContinue?" IDYES continueinst
  Abort "Install cancelled"
  continueinst:

  ; Set output path to the installation directory.
  SetOutPath $INSTDIR
  ; Put file there
  File Debug\speexDS.dll
  RegDLL $INSTDIR\speexDS.dll
SectionEnd ; end the section

Section -post
  Delete $INSTDIR\speexDS_uninst.exe
  WriteUninstaller $INSTDIR\speexDS_uninst.exe
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\SpeexDS" "DisplayName" "Speex Direct Show filters"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\SpeexDS" "UninstallString" '"$INSTDIR\speexDS_uninst.exe"'
SectionEnd

Section "Uninstall"
  MessageBox MB_YESNO "Do you really want to uninstall the Speex DirectShow filters$\nContinue" IDYES continueuninst
  Abort "Uninstall cancelled"
  continueuninst:

  IfFileExists $INSTDIR\speexDS.dll skip_confirmation
    MessageBox MB_YESNO "It does not appear that speexDS is installed in the directory '$INSTDIR'.$\r$\nContinue anyway (not recommended)" IDYES skip_confirmation
    Abort "Uninstall aborted by user"
  skip_confirmation:

  UnRegDLL $INSTDIR\speexDS.dll
  DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\SpeexDS"
  Delete $INSTDIR\speexDS_uninst.exe ; 
  Delete $INSTDIR\speexDS.dll
  RMDir $INSTDIR
SectionEnd



; eof