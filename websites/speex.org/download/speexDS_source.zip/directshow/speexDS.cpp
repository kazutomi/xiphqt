/* Copyright (C) 2003 Jean-Francois Emond
   File: speexDS.cpp
   Speex Direct Show filter

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <speex.h>
#include "speexDS.h"

// utility function used in the decoder
unsigned short le_short(unsigned short s);

// 9f5b9b7f-11be-4966-981b-6e564480cbdf
const CLSID CLSID_SpeexEnc = 
{0x9f5b9b7f, 0x11be, 0x4966, {0x98, 0x1b, 0x6e, 0x56, 0x44, 0x80, 0xcb, 0xdf}};

// 46edc0b7-cbf7-424e-a5d9-c6fcb75bc261
const CLSID CLSID_SpeexDec = 
{0x46edc0b7, 0xcbf7, 0x424e, {0xa5, 0xd9, 0xc6, 0xfc, 0xb7, 0x5b, 0xc2, 0x61}};

// 6a590332-661d-49bb-8723-a6f853cbdaeb
const CLSID CLSID_SpeexEncPropPage =  
{0x6a590332, 0x661d, 0x49bb, {0x87, 0x23, 0xa6, 0xf8, 0x53, 0xcb, 0xda, 0xeb}};

// {5aebf6b8-916a-4d7a-ae54-c598cee0e496}
const CLSID MEDIASUBTYPE_Speex = 
{0x5aebf6b8, 0x916a, 0x4d7a, {0xae, 0x54, 0xc5, 0x98, 0xce, 0xe0, 0xe4, 0x96}};

// 6bddfa7e-9f22-46a9-ab5e-884eff294d9f
const CLSID FORMAT_Speex = 
{0x6bddfa7e, 0x9f22, 0x46a9, {0xab, 0x5e, 0x88, 0x4e, 0xff, 0x29, 0x4d, 0x9f}};

//  Setup data

AMOVIESETUP_MEDIATYPE sudEncSpxInputType[] =
{
    { &MEDIATYPE_Audio, &MEDIASUBTYPE_PCM }
};
AMOVIESETUP_MEDIATYPE sudEncSpxOutputType[] =
{
    { &MEDIATYPE_Audio, &MEDIASUBTYPE_Speex }
};

AMOVIESETUP_PIN sudEncSpxPins[3] =
{
    { L"PCM Input",
      FALSE,                               // bRendered
      FALSE,                               // bOutput
      FALSE,                               // bZero
      FALSE,                               // bMany
      &CLSID_NULL,                         // clsConnectsToFilter
      NULL,                                // ConnectsToPin
      NUMELMS(sudEncSpxInputType),         // Number of media types
      sudEncSpxInputType
    },
    { L"Speex Output",
      FALSE,                               // bRendered
      TRUE,                                // bOutput
      FALSE,                               // bZero
      FALSE,                               // bMany
      &CLSID_NULL,                         // clsConnectsToFilter
      NULL,                                // ConnectsToPin
      NUMELMS(sudEncSpxOutputType),        // Number of media types
      sudEncSpxOutputType
    }
};

AMOVIESETUP_FILTER sudMpgAEnc =
{
    &CLSID_SpeexEnc,
    L"Speex encoder",
    MERIT_SW_COMPRESSOR,                   
    NUMELMS(sudEncSpxPins),
    sudEncSpxPins
};

AMOVIESETUP_MEDIATYPE sudDecSpxInputType[] =
{
    { &MEDIATYPE_Audio, &MEDIASUBTYPE_Speex }
};
AMOVIESETUP_MEDIATYPE sudDecSpxOutputType[] =
{
	{ &MEDIATYPE_Audio, &MEDIASUBTYPE_PCM }
};

AMOVIESETUP_PIN sudDecSpxPins[3] =
{
    { L"Speex Input",
      FALSE,                               // bRendered
      FALSE,                               // bOutput
      FALSE,                               // bZero
      FALSE,                               // bMany
      &CLSID_NULL,                         // clsConnectsToFilter
      NULL,                                // ConnectsToPin
      NUMELMS(sudDecSpxInputType),         // Number of media types
      sudDecSpxInputType
    },
    { L"PCM Output",
      FALSE,                               // bRendered
      TRUE,                                // bOutput
      FALSE,                               // bZero
      FALSE,                               // bMany
      &CLSID_NULL,                         // clsConnectsToFilter
      NULL,                                // ConnectsToPin
      NUMELMS(sudDecSpxOutputType),        // Number of media types
      sudDecSpxOutputType
    }
};

AMOVIESETUP_FILTER sudMpgADec =
{
    &CLSID_SpeexDec,
    L"Speex decoder",
    MERIT_SW_COMPRESSOR,                   // Don't use us for real!
    NUMELMS(sudDecSpxPins),                // 3 pins
    sudDecSpxPins
};

CFactoryTemplate g_Templates[2] = 
{
    { 
      L"Speex encoder",                     // Name
      &CLSID_SpeexEnc,                      // CLSID
      CSpeexEncodeFilter::CreateInstance,   // Method to create 
	                                        // an instance of MyComponent
      NULL,                                 // Initialization function
      &sudMpgAEnc                           // Set-up information (for filters)
    },
	{ 
      L"Speex Decoder",                     // Name
      &CLSID_SpeexDec,                      // CLSID
      CSpeexDecodeFilter::CreateInstance,   // Method to create 
	                                        // an instance of MyComponent
      NULL,                                 // Initialization function
      &sudMpgADec                           // Set-up information (for filters)
    }
};
int g_cTemplates = sizeof(g_Templates) / sizeof(g_Templates[0]);

///////////////////////////////////////////////////////////////////////////////
// Encoder
///////////////////////////////////////////////////////////////////////////////

CSpeexEncodeFilter::CSpeexEncodeFilter(LPUNKNOWN lpUnk, HRESULT *pHr) :
	CTransformFilter(NAME("Speex encoder"),
	lpUnk, CLSID_SpeexEnc),
	m_isinitialised(false),
	m_channels(1)
{
	/* initialising the speex encoder */
	speex_bits_init(&m_bits);
	m_enc_state = speex_encoder_init(&speex_nb_mode);
	speex_encoder_ctl(m_enc_state,SPEEX_GET_FRAME_SIZE,&m_frame_size); 
}

CUnknown * WINAPI CSpeexEncodeFilter::CreateInstance(LPUNKNOWN pUnk, HRESULT *pHr) 
{
    CSpeexEncodeFilter *pNewObject = new CSpeexEncodeFilter(pUnk, pHr );
    if (pNewObject == NULL) {
        *pHr = E_OUTOFMEMORY;
    }
    return pNewObject;
}

HRESULT CSpeexEncodeFilter::CheckInputType(const CMediaType *pmt)
{
	if (pmt->majortype == MEDIATYPE_Audio) {
		WAVEFORMATEX *pWavinfo = reinterpret_cast<WAVEFORMATEX*>(pmt->pbFormat);
		if(pWavinfo->nSamplesPerSec == 8000 &&
           pWavinfo->wBitsPerSample == 16 &&
		   pWavinfo->nChannels == 1) 
			return S_OK;
		else
			return S_FALSE;
   }
   else 
	   return S_FALSE;
}

HRESULT CSpeexEncodeFilter::Transform(IMediaSample *pIn, IMediaSample *pOut)
{
	HRESULT hr;
	int nbBytes;

   // Get pointers to the underlying buffers.
    BYTE  *pBufferIn; 
	BYTE  *pBufferOut;
	int buffer_size = pIn->GetActualDataLength();
	if( buffer_size != 0)
	{
		hr = pIn->GetPointer(&pBufferIn);
		if (FAILED(hr))
		{
			return hr;
		}
		hr = pOut->GetPointer(&pBufferOut);
		if (FAILED(hr))
		{
			return hr;
		}

		// Copy the sample times
		REFERENCE_TIME TimeStart, TimeEnd;
		if(SUCCEEDED(pIn->GetTime(&TimeStart, &TimeEnd))) {
			pOut->SetTime(&TimeStart, &TimeEnd);
		}

		int idx = 0;  // index
		int total_nbBytes = 0;

		SPEEXBUFFERCONTENT buffer_content;
		buffer_content.nbframes = 0;

		pBufferOut += SPEEX_BUFFER_CONTENT_LENGTH;

		while(idx * 2 < buffer_size)
		{
			/* copy to float input buffer */
			for (int i = 0; i < m_frame_size; i++)
			{ 
				m_current_spx_frame[i] = (short)((short *)(pBufferIn + (idx * 2)))[i]; 
			}
			
			speex_bits_reset(&m_bits);
			speex_encode(m_enc_state, m_current_spx_frame, &m_bits);
			nbBytes = speex_bits_write(&m_bits, 
									   (char *)(pBufferOut + total_nbBytes), 
				                       pOut->GetSize() - SPEEX_BUFFER_CONTENT_LENGTH);
			
			buffer_content.nbBytes[buffer_content.nbframes] = nbBytes;
			buffer_content.nbframes++;
			total_nbBytes += nbBytes;
			idx += m_frame_size;
		}

		memcpy(pBufferOut - SPEEX_BUFFER_CONTENT_LENGTH,
			   &buffer_content,
			   SPEEX_BUFFER_CONTENT_LENGTH);

		pOut->SetActualDataLength(total_nbBytes + SPEEX_BUFFER_CONTENT_LENGTH);
		idx = 0;
	}
    
	return NOERROR;
}

HRESULT CSpeexEncodeFilter::CheckTransform(const CMediaType *mtIn,
					                       const CMediaType *mtOut)
{
	// Check the major type.
    if (mtOut->majortype != MEDIATYPE_Audio
		&& mtOut->subtype != MEDIASUBTYPE_Speex)
    {
        return VFW_E_TYPE_NOT_ACCEPTED;
    }

	if (mtIn->majortype != MEDIATYPE_Audio) {
       return VFW_E_TYPE_NOT_ACCEPTED;
	}
	
    // Everything is good.
    return S_OK;
}

#define OUTPUT_BUFF_SIZE 16384      // Output buffer size
HRESULT CSpeexEncodeFilter::DecideBufferSize(IMemAllocator *pAlloc,
                                             ALLOCATOR_PROPERTIES *ppropInputRequest)
{
	HRESULT hr = S_OK;

	///
    ppropInputRequest->cBuffers = 4;
    ppropInputRequest->cbBuffer = OUTPUT_BUFF_SIZE;
	//

    ASSERT(ppropInputRequest->cbBuffer);
    
    ALLOCATOR_PROPERTIES Actual;
    hr = pAlloc->SetProperties(ppropInputRequest,&Actual);
    if(FAILED(hr)) 
        return hr;

    ASSERT(Actual.cbAlign == 1);
    ASSERT(Actual.cbPrefix == 0);

    if (Actual.cbBuffer < ppropInputRequest->cbBuffer ||
        Actual.cBuffers < ppropInputRequest->cBuffers) 
	{// can't use this allocator
		return E_INVALIDARG;
    }
    return S_OK;
}

HRESULT CSpeexEncodeFilter::GetMediaType(int iPosition,
                                         CMediaType *pMediaType)
{
	ASSERT(m_pInput->IsConnected());
    if (iPosition < 0)
    {
        return E_INVALIDARG;
    }

	if(iPosition == 0)
	{
		HRESULT hr = m_pInput->ConnectionMediaType(pMediaType);
        if (FAILED(hr))
        {
            return hr;
        }
		
		pMediaType->SetType(&MEDIATYPE_Audio);
		pMediaType->SetSubtype(&MEDIASUBTYPE_Speex);
		pMediaType->SetSampleSize(4096);
        pMediaType->SetTemporalCompression(FALSE);
		pMediaType->AllocFormatBuffer(sizeof(SPEEXFORMAT));
		pMediaType->SetFormat((LPBYTE)&m_sfmt, sizeof(SPEEXFORMAT));
		pMediaType->SetFormatType(&FORMAT_Speex);
		
		SPEEXFORMAT *pSpeexinfo = reinterpret_cast<SPEEXFORMAT*>(pMediaType->pbFormat);
		pSpeexinfo->bitrate = 8000;               // 8 kbps
		pSpeexinfo->frames_per_packet = 1;        // 1 frame per packet
		pSpeexinfo->vbr = 0;                      // vbr disabled;
		pSpeexinfo->nb_channels = 1;              // mono
		pSpeexinfo->mode = 0;                     // narrowband

        return S_OK;
	}
	else
	{
		return VFW_S_NO_MORE_ITEMS;
	}
	
	return NOERROR;
}

///////////////////////////////////////////////////////////////////////////////
// Decoder
///////////////////////////////////////////////////////////////////////////////
CSpeexDecodeFilter::CSpeexDecodeFilter(LPUNKNOWN lpUnk, HRESULT *pHr) :
	CTransformFilter(NAME("Speex decoder"), lpUnk, CLSID_SpeexDec),
	m_isinitialised(false),
	m_channels(1)
{
	/* initialising the speex Decoder */
	speex_bits_init(&m_bits); 
	m_dec_state = speex_decoder_init(&speex_nb_mode);
	speex_decoder_ctl(m_dec_state, SPEEX_GET_FRAME_SIZE, &m_frame_size);
}

// Public method that returns a new instance. 
CUnknown * WINAPI CSpeexDecodeFilter::CreateInstance(LPUNKNOWN pUnk, HRESULT *pHr) 
{
    CSpeexDecodeFilter *pNewObject = new CSpeexDecodeFilter(pUnk, pHr );
    if (pNewObject == NULL) {
        *pHr = E_OUTOFMEMORY;
    }
    return pNewObject;
}

HRESULT CSpeexDecodeFilter::CheckInputType(const CMediaType *pmt)
{
   if (pmt->majortype != MEDIATYPE_Audio
	   && pmt->subtype != MEDIASUBTYPE_Speex) {
       return S_FALSE;
   }
	
   else return S_OK;
}

HRESULT CSpeexDecodeFilter::Transform(IMediaSample *pIn, IMediaSample *pOut)
{
	HRESULT hr;

   // Get pointers to the underlying buffers.
    BYTE  *pBufferIn; 
	BYTE  *pBufferOut;
    hr = pIn->GetPointer(&pBufferIn);
    if (FAILED(hr))
    {
        return hr;
    }
    hr = pOut->GetPointer(&pBufferOut);
    if (FAILED(hr))
    {
        return hr;
    }

	REFERENCE_TIME TimeStart, TimeEnd;
	if(SUCCEEDED(pIn->GetTime(&TimeStart, &TimeEnd))) {
		pOut->SetTime(&TimeStart, &TimeEnd);
	}

	SPEEXBUFFERCONTENT *buffer_content = (SPEEXBUFFERCONTENT *)pBufferIn;
	pBufferIn += SPEEX_BUFFER_CONTENT_LENGTH;
	
	for(int j = 0; j < buffer_content->nbframes; j++)
	{
		speex_bits_read_from(&m_bits, 
			                 (char *) pBufferIn, 
							 buffer_content->nbBytes[j]);
		speex_decode(m_dec_state, &m_bits, m_current_spx_frame);

		/* Convert to short and save to output buffer */
		for (int i=0; i < m_frame_size * m_channels; i++)
			((short *)pBufferOut)[i]=(short) m_current_spx_frame[i]; 
		
		pBufferIn += buffer_content->nbBytes[j];
		pBufferOut += m_frame_size * 2; 
	}

	pOut->SetActualDataLength(buffer_content->nbframes * m_frame_size * 2);

	return NOERROR;
}

HRESULT CSpeexDecodeFilter::CheckTransform(const CMediaType *mtIn,
					                       const CMediaType *mtOut)
{
	// Check the major type.
    if (mtOut->majortype != MEDIATYPE_Audio
		&& mtOut->subtype != MEDIASUBTYPE_PCM)
    {
       return VFW_E_TYPE_NOT_ACCEPTED;
    }

	if (mtIn->majortype != MEDIATYPE_Audio) {
       return VFW_E_TYPE_NOT_ACCEPTED;
	}
	
    // Everything is good.
    return S_OK;
}

#define MAX_NB_FRAMES 1024

HRESULT CSpeexDecodeFilter::DecideBufferSize(IMemAllocator *pAlloc,
                                             ALLOCATOR_PROPERTIES *ppropInputRequest)
{
	HRESULT hr = S_OK;

	///
    ppropInputRequest->cBuffers = 4;
    ppropInputRequest->cbBuffer = MAX_NB_FRAMES * m_frame_size * m_channels * sizeof(short);
	//

    ASSERT(ppropInputRequest->cbBuffer);
    
    ALLOCATOR_PROPERTIES Actual;
    hr = pAlloc->SetProperties(ppropInputRequest,&Actual);
    if(FAILED(hr)) 
        return hr;

    ASSERT(Actual.cbAlign == 1);
    ASSERT(Actual.cbPrefix == 0);

    if (Actual.cbBuffer < ppropInputRequest->cbBuffer ||
        Actual.cBuffers < ppropInputRequest->cBuffers) 
	{// can't use this allocator
		return E_INVALIDARG;
    }
    return S_OK;
}

HRESULT CSpeexDecodeFilter::GetMediaType(int iPosition,
                                         CMediaType *pMediaType)
{
	ASSERT(m_pInput->IsConnected());
    if (iPosition < 0)
    {
        return E_INVALIDARG;
    }

	if(iPosition == 0)
	{
		HRESULT hr = m_pInput->ConnectionMediaType(pMediaType);
        if (FAILED(hr))
        {
            return hr;
        }
		
		pMediaType->SetType(&MEDIATYPE_Audio);
		pMediaType->SetSubtype(&MEDIASUBTYPE_PCM);
		pMediaType->SetSampleSize(2);
        pMediaType->SetTemporalCompression(FALSE);
		pMediaType->AllocFormatBuffer(sizeof(WAVEFORMATEX));
		pMediaType->SetFormat((LPBYTE)&m_wfmt, sizeof(WAVEFORMATEX));
		pMediaType->SetFormatType(&FORMAT_WaveFormatEx);
		
		WAVEFORMATEX *pWavinfo = reinterpret_cast<WAVEFORMATEX*>(pMediaType->pbFormat);
		pWavinfo->wFormatTag = WAVE_FORMAT_PCM;
		pWavinfo->nChannels = 1;
		pWavinfo->nSamplesPerSec = 8000;
		pWavinfo->nAvgBytesPerSec = 8000;
		pWavinfo->wBitsPerSample = 16;
		pWavinfo->nBlockAlign = pWavinfo->nChannels * pWavinfo->wBitsPerSample / 8;

        return S_OK;
	}
	else
	{
		return VFW_S_NO_MORE_ITEMS;
	}
	
	return NOERROR;
}

STDAPI DllRegisterServer()
{
	// Create entry in HKEY_CLASSES_ROOT\Filter
	OLECHAR szCLSID[CHARS_IN_GUID];
	TCHAR achTemp[MAX_PATH];
	HKEY hKey;

	HRESULT hr = StringFromGUID2(*g_Templates[0].m_ClsID, szCLSID, CHARS_IN_GUID);
	wsprintf(achTemp, TEXT("Filter\\%ls"), szCLSID);
	// create key
	RegCreateKey(HKEY_CLASSES_ROOT, (LPCTSTR)achTemp, &hKey);
	RegCloseKey(hKey);
	return AMovieDllRegisterServer2(TRUE);
}

STDAPI DllUnregisterServer()
{
	// Delete entry in HKEY_CLASSES_ROOT\Filter
	OLECHAR szCLSID[CHARS_IN_GUID];
	TCHAR achTemp[MAX_PATH];

	HRESULT hr = StringFromGUID2(*g_Templates[0].m_ClsID, szCLSID, CHARS_IN_GUID);
	wsprintf(achTemp, TEXT("Filter\\%ls"), szCLSID);
	// create key
	RegDeleteKey(HKEY_CLASSES_ROOT, (LPCTSTR)achTemp);
	return AMovieDllRegisterServer2(FALSE);
}

unsigned short le_short(unsigned short s)
{
   unsigned short ret=s;
#ifdef WORDS_BIGENDIAN
   ret =  s>>8;
   ret += s<<8;
#endif
   return ret;
}