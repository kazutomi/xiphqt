/* Copyright (C) 2003 Jean-Francois Emond
   File: speexDS.h
   Speex Direct Show filter

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <Streams.h>
#include <olectl.h>

#ifndef __SPEEXDS_H__
#define __SPEEXDS_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define MAX_FRAME_SIZE 2000         // Temporary speex float buffer size

typedef struct tagVORBISFORMAT
{
	WORD nChannels;
	DWORD nSamplesPerSec;
	DWORD nMinBitsPerSec;
	DWORD nAvgBitsPerSec;
	DWORD nMaxBitsPerSec;
	float fQuality;
} VORBISFORMAT, *PVORBISFORMAT, FAR *LPVORBISFORMAT;

typedef struct speexformat
{
	int rate;
	int mode;                   // 0 for narrowband, 1 for wideband
	int nb_channels;            
	int bitrate;
	int vbr;                    // 1 for a VBR encoding, 0 otherwise
	int frames_per_packet;
} SPEEXFORMAT, *PSPEEXFORMAT, FAR *LPSPEEXFORMAT;

#define SPEEX_MAX_FRAMES_PER_BUFFER 50
#define SPEEX_BUFFER_CONTENT_LENGTH (sizeof(int) + SPEEX_MAX_FRAMES_PER_BUFFER * sizeof(int))
typedef struct speexbuffercontent
{
	int nbframes;
	int nbBytes[SPEEX_MAX_FRAMES_PER_BUFFER];
} SPEEXBUFFERCONTENT;


STDAPI DllRegisterServer(void);
STDAPI DllUnregisterServer(void);

class CSpeexEncodeFilter: public CTransformFilter
{
public:
	static CUnknown * WINAPI CreateInstance(LPUNKNOWN pUnk, HRESULT *pHr);

	CSpeexEncodeFilter(LPUNKNOWN lpUnk, HRESULT *pHr);

	// ITransformFilter interface methods
	virtual HRESULT Transform(IMediaSample *pIn,
							  IMediaSample *pOut);
	virtual HRESULT CheckInputType(const CMediaType *mtIn);
	virtual HRESULT CheckTransform(const CMediaType *mtIn,
								   const CMediaType *mtOut);
	virtual HRESULT DecideBufferSize(IMemAllocator *pAlloc,
                                     ALLOCATOR_PROPERTIES *ppropInputRequest);
	virtual HRESULT GetMediaType(int iPosition,
                                 CMediaType *pMediaType);
	
private:

	bool        m_isinitialised;
	SpeexBits   m_bits;
	void	   *m_enc_state;
	int         m_frame_size;
	int			m_channels;
	SPEEXFORMAT m_sfmt;

	float       m_current_spx_frame[MAX_FRAME_SIZE];  
};

class CSpeexDecodeFilter: public CTransformFilter
{
public:
	static CUnknown * WINAPI CreateInstance(LPUNKNOWN pUnk, HRESULT *pHr);

	CSpeexDecodeFilter(LPUNKNOWN lpUnk, HRESULT *pHr);

	// ITransformFilter interface methods
	virtual HRESULT Transform(IMediaSample *pIn,
							  IMediaSample *pOut);
	virtual HRESULT CheckInputType(const CMediaType *mtIn);
	virtual HRESULT CheckTransform(const CMediaType *mtIn,
								   const CMediaType *mtOut);
	virtual HRESULT DecideBufferSize(IMemAllocator *pAlloc,
                                     ALLOCATOR_PROPERTIES *ppropInputRequest);
	virtual HRESULT GetMediaType(int iPosition,
                                 CMediaType *pMediaType);
	
private:

	bool         m_isinitialised;
	SpeexBits    m_bits;
	void	    *m_dec_state;
	int          m_frame_size;
	int			 m_channels;
	WAVEFORMATEX m_wfmt;
	void        *m_st;

	float        m_current_spx_frame[MAX_FRAME_SIZE];
};

#endif //__SPEEXDS_H__