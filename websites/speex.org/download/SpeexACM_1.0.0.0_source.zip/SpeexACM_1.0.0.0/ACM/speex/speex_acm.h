/* Copyright (C) 2003 Christian	Buchner
   File: speex_acm.h
   This file contains prototypes for the filtering routines.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _SPEEX_ACM_H_
#define _SPEEX_ACM_H_

#ifndef RC_INVOKED
#pragma pack(1)                     // assume byte packing throughout
#endif

#ifndef EXTERN_C
#ifdef __cplusplus
    #define EXTERN_C extern "C"
#else
    #define EXTERN_C extern 
#endif
#endif

#ifdef __cplusplus
extern "C"                          // assume C declarations for C++
{
#endif


//
//
//
//
#define MM_INDEPENDENT_CODEC_GROUP                  ((short)'I'+(short)'n'+(short)'d'+(short)'e'+(short)'p'+(short)'e'+(short)'n'+(short)'d'+(short)'e'+(short)'n'+(short)'t'+(short)' '+(short)'C'+(short)'o'+(short)'d'+(short)'e'+(short)'c'+(short)' '+(short)'G'+(short)'r'+(short)'o'+(short)'u'+(short)'p')
#define MM_INDEPENDENT_CODEC_GROUP_ACM_SPEEX        ((short)'S'+(short)'p'+(short)'e'+(short)'e'+(short)'x')

#define WAVE_FORMAT_SPEEX                           ((short)'I'+(short)'C'+(short)'G'+(short)' '+(short)'S'+(short)'p'+(short)'e'+(short)'e'+(short)'x')

//
//  SPEEX structure definitions
//
//      for WAVE_FORMAT_SPEEX
//
//

#define SPEEX_ACM_VERSION_MAJOR 1
#define SPEEX_ACM_VERSION_MAJOR_STR "1"
#define SPEEX_ACM_VERSION_MINOR 0
#define SPEEX_ACM_VERSION_MINOR_STR "0"
#define SPEEX_ACM_VERSION_RELEASE 0
#define SPEEX_ACM_VERSION_BUILD 0

#define FORMAT_NOTICE_SIZE 32

typedef struct speexwaveformat_tag {
        WAVEFORMATEX    wfx;
		unsigned char acm_version_major;
		unsigned char acm_version_minor;
		unsigned char sh_pkt[sizeof(SpeexHeader)];
		unsigned char fmtnotice[FORMAT_NOTICE_SIZE];
} SPEEXWAVEFORMAT;
typedef SPEEXWAVEFORMAT       *PSPEEXWAVEFORMAT;
typedef SPEEXWAVEFORMAT NEAR *NPSPEEXWAVEFORMAT;
typedef SPEEXWAVEFORMAT FAR  *LPSPEEXWAVEFORMAT;

#define SPEEX_MAX_CHANNELS       2
#define SPEEX_DEFAULT_BITS_PER_SAMPLE    8
#define SPEEX_WFX_EXTRA_BYTES    (sizeof(SPEEXWAVEFORMAT) - sizeof(WAVEFORMATEX))

#ifdef SPEEX_USECONFIG
#define SPEEX_CONFIG_UNCONFIGURED                        0x0999
#define SPEEX_CONFIG_DEFAULTKEY                          HKEY_CURRENT_USER
#define SPEEX_CONFIG_DEFAULT_ENCODERCOMPLEXITY           2  // add one for actual value
#define SPEEX_CONFIG_DEFAULT_PERCEPTUALENHANCEMENT       0
#define SPEEX_CONFIG_NUM_ENCODERCOMPLEXITIES             10
#endif


//
//  Conversion function prototypes.
//
DWORD FNGLOBAL speexDecode_M08
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
);

DWORD FNGLOBAL speexDecode_M16
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
);

DWORD FNGLOBAL speexDecode_S08
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
);

DWORD FNGLOBAL speexDecode_S16
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
);

DWORD FNGLOBAL speexEncode_M08
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
);

DWORD FNGLOBAL speexEncode_M16
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
);

DWORD FNGLOBAL speexEncode_S08
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
);

DWORD FNGLOBAL speexEncode_S16
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
);


//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ; 
//
//
//
//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ; 

#ifndef RC_INVOKED
#pragma pack()                      // revert to default packing
#endif

#ifdef __cplusplus
}                                   // end of extern "C" { 
#endif

#endif // _SPEEX_ACM_H_

