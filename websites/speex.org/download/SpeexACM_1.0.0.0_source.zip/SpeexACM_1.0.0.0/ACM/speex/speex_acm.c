/* Copyright (C) 2003 Christian Buchner
   File: speex_acm.c
   This file contains encode and decode routines for the SPEEX
   ACM payload format. 

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <msacm.h>
#include <msacmdrv.h>
#include <tchar.h>

#include "codec.h"
#include "speex_acm.h"
#include "debug.h"


#ifndef INLINE
    #define INLINE __inline
#endif



//--------------------------------------------------------------------------;
//  
//  DWORD pcmM08BytesToSamples
//  DWORD pcmM16BytesToSamples
//  DWORD pcmS08BytesToSamples
//  DWORD pcmS16BytesToSamples
//  
//  Description:
//      These functions return the number of samples in a buffer of PCM
//      of the specified format.  For efficiency, it is declared INLINE.
//      Note that, depending on the optimization flags, it may not
//      actually be implemented as INLINE.  Optimizing for speed (-Oxwt)
//      will generally obey the INLINE specification.
//  
//  Arguments:
//      DWORD cb: The length of the buffer, in bytes.
//  
//  Return (DWORD):  The length of the buffer in samples.
//  
//--------------------------------------------------------------------------;

INLINE DWORD pcmM08BytesToSamples(
    DWORD cb
)
{
    return cb;
}

INLINE DWORD pcmM16BytesToSamples(
    DWORD cb
)
{
    return cb / ((DWORD)2);
}

INLINE DWORD pcmS08BytesToSamples(
    DWORD cb
)
{
    return cb / ((DWORD)2);
}

INLINE DWORD pcmS16BytesToSamples(
    DWORD cb
)
{
    return cb / ((DWORD)4);
}



//==========================================================================;
//
//      DECODE ROUTINES
//
//==========================================================================;

//--------------------------------------------------------------------------;
//  
//  DWORD speexDecode_M08
//  DWORD speexDecode_M16
//  DWORD speexDecode_S08
//  DWORD speexDecode_S16
//  
//  Description:
//      These functions decode a buffer of data from SPEEX to PCM in the
//      specified format.  The appropriate function is called once for each
//      ACMDM_STREAM_CONVERT message received.  Note that since these
//      functions must share the same prototype as the encoding functions
//      (see acmdStreamOpen() and acmdStreamConvert() in codec.c for more
//      details), not all the parameters are used by these routines.
//  
//  Arguments:
//      HPBYTE pbSrc:  Pointer to the source buffer (SPEEX data).
//      DWORD cbSrcLength:  The length of the source buffer (in bytes).
//      HPBYTE pbDst:  Pointer to the destination buffer (PCM data).  Note
//                      that it is assumed that the destination buffer is
//                      large enough to hold all the encoded data; see
//                      acmdStreamSize() in codec.c for more details.
//      UINT nBlockAlignment:  The block alignment of the SPEEX data (in
//                      bytes).
//  
//  Return (DWORD):  The number of bytes used in the destination buffer.
//  
//--------------------------------------------------------------------------;

DWORD FNGLOBAL speexDecode_M08
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
)
{
    HPBYTE                  pbDstStart;
	BYTE *pSample;

	int frame_size = psi->frame_size;
	int frames_per_block = psi->speex_header.frames_per_packet;
	int remaining;

	pbDstStart = pbDst;

	remaining = cbSrcLength;
	pSample = (BYTE*)pbDst;

	while (remaining > 0 || speex_bits_remaining(&psi->bits) >= psi->bits_per_frame)
	{
		if (psi->block % frames_per_block == 0)
		{
			// skip padding bits, forward to next full byte
			if (psi->bits.bitPtr != 0)
			{
				psi->bits.bitPtr = 0;
				psi->bits.bytePtr++;
			}
		}

		if ((UINT)remaining >= nBlockAlignment)
		{
			speex_bits_read_whole_bytes(&psi->bits, pbSrc, nBlockAlignment);
			pbSrc += nBlockAlignment;
			remaining -= nBlockAlignment;
		}
		else
		{
			speex_bits_read_whole_bytes(&psi->bits, pbSrc, remaining);
			pbSrc += remaining;
			remaining = 0;
		}

		while (speex_bits_remaining(&psi->bits) >= psi->bits_per_frame) 
		{
			int ret;
			int i;

			ret = speex_decode(psi->dec_state, &psi->bits, psi->fp_tmp);

			if (ret < 0 || 
                speex_bits_remaining(&psi->bits)<0)
			{
				speex_bits_reset(&psi->bits);
				psi->block = 0;
				break;
			}

			for (i=0; i<frame_size; i++) {
				*pSample++ = (BYTE)(((SHORT)max(min(psi->fp_tmp[i],32767.0),-32768.0)>>8));
			};

			psi->block++;
			psi->block = psi->block % frames_per_block;

			if (psi->block == 0) break;
		}
	}

	pbDst = (HPBYTE)pSample;

    //
    //  We return the number of bytes used in the destination.  This is
    //  simply the difference in bytes from where we started.
    //
    return (DWORD)(pbDst - pbDstStart);

} // speexDecode_M08()



//--------------------------------------------------------------------------;
//--------------------------------------------------------------------------;

DWORD FNGLOBAL speexDecode_M16
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
)
{
    HPBYTE                  pbDstStart;
	SHORT *pSample;

	int frame_size = psi->frame_size;
	int frames_per_block = psi->speex_header.frames_per_packet;
	int remaining;

	pbDstStart = pbDst;

	remaining = cbSrcLength;
	pSample = (SHORT*)pbDst;

	while (remaining > 0 || speex_bits_remaining(&psi->bits) >= psi->bits_per_frame)
	{
		if (psi->block % frames_per_block == 0)
		{
			// skip padding bits, forward to next full byte
			if (psi->bits.bitPtr != 0)
			{
				psi->bits.bitPtr = 0;
				psi->bits.bytePtr++;
			}
		}

		if ((UINT)remaining >= nBlockAlignment)
		{
			speex_bits_read_whole_bytes(&psi->bits, pbSrc, nBlockAlignment);
			pbSrc += nBlockAlignment;
			remaining -= nBlockAlignment;
		}
		else
		{
			speex_bits_read_whole_bytes(&psi->bits, pbSrc, remaining);
			pbSrc += remaining;
			remaining = 0;
		}

		while (speex_bits_remaining(&psi->bits) >= psi->bits_per_frame) 
		{
			int ret;
			int i;

			ret = speex_decode(psi->dec_state, &psi->bits, psi->fp_tmp);

			if (ret < 0 || 
                speex_bits_remaining(&psi->bits)<0)
			{
				speex_bits_reset(&psi->bits);
				psi->block = 0;
				break;
			}

			for (i=0; i<frame_size; i++) {
				*pSample++ = (SHORT)le_short((SHORT)max(min(psi->fp_tmp[i],32767.0),-32768.0));
			};

			psi->block++;
			psi->block = psi->block % frames_per_block;

			if (psi->block == 0) break;
		}
	}

	pbDst = (HPBYTE)pSample;

    //
    //  We return the number of bytes used in the destination.  This is
    //  simply the difference in bytes from where we started.
    //
    return (DWORD)(pbDst - pbDstStart);

} // speexDecode_M16()



//--------------------------------------------------------------------------;
//--------------------------------------------------------------------------;

DWORD FNGLOBAL speexDecode_S08
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
)
{
    HPBYTE                  pbDstStart;
	BYTE *pSample;

	int frame_size = psi->frame_size;
	int frames_per_block = psi->speex_header.frames_per_packet;
	int remaining;

	pbDstStart = pbDst;

	remaining = cbSrcLength;
	pSample = (BYTE*)pbDst;

	while (remaining > 0 || speex_bits_remaining(&psi->bits) >= psi->bits_per_frame)
	{
		if (psi->block % frames_per_block == 0)
		{
			// skip padding bits, forward to next full byte
			if (psi->bits.bitPtr != 0)
			{
				psi->bits.bitPtr = 0;
				psi->bits.bytePtr++;
			}
		}

		if ((UINT)remaining >= nBlockAlignment)
		{
			speex_bits_read_whole_bytes(&psi->bits, pbSrc, nBlockAlignment);
			pbSrc += nBlockAlignment;
			remaining -= nBlockAlignment;
		}
		else
		{
			speex_bits_read_whole_bytes(&psi->bits, pbSrc, remaining);
			pbSrc += remaining;
			remaining = 0;
		}

		while (speex_bits_remaining(&psi->bits) >= psi->bits_per_frame) 
		{
			int ret;
			int i;

			ret = speex_decode(psi->dec_state, &psi->bits, psi->fp_tmp);

			if (ret < 0 || 
                speex_bits_remaining(&psi->bits)<0)
			{
				speex_bits_reset(&psi->bits);
				psi->block = 0;
				break;
			}

			speex_decode_stereo(psi->fp_tmp, frame_size, &psi->speex_stereo);

			// 2x because of Stereo
			for (i=0; i<2*frame_size; i++) {
				*pSample++ = (BYTE)(((SHORT)max(min(psi->fp_tmp[i],32767.0),-32768.0)>>8));
			};

			psi->block++;
			psi->block = psi->block % frames_per_block;

			if (psi->block == 0) break;
		}
	}

	pbDst = (HPBYTE)pSample;

    //
    //  We return the number of bytes used in the destination.  This is
    //  simply the difference in bytes from where we started.
    //
    return (DWORD)(pbDst - pbDstStart);

} // speexDecode_S08()



//--------------------------------------------------------------------------;
//--------------------------------------------------------------------------;

DWORD FNGLOBAL speexDecode_S16
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
)
{
    HPBYTE                  pbDstStart;
	SHORT *pSample;

	int frame_size = psi->frame_size;
	int frames_per_block = psi->speex_header.frames_per_packet;
	int remaining;

	pbDstStart = pbDst;

	remaining = cbSrcLength;
	pSample = (SHORT*)pbDst;

	while (remaining > 0 || speex_bits_remaining(&psi->bits) >= psi->bits_per_frame)
	{
		if (psi->block % frames_per_block == 0)
		{
			// skip padding bits, forward to next full byte
			if (psi->bits.bitPtr != 0)
			{
				psi->bits.bitPtr = 0;
				psi->bits.bytePtr++;
			}
		}

		if ((UINT)remaining >= nBlockAlignment)
		{
			speex_bits_read_whole_bytes(&psi->bits, pbSrc, nBlockAlignment);
			pbSrc += nBlockAlignment;
			remaining -= nBlockAlignment;
		}
		else
		{
			speex_bits_read_whole_bytes(&psi->bits, pbSrc, remaining);
			pbSrc += remaining;
			remaining = 0;
		}

		while (speex_bits_remaining(&psi->bits) >= psi->bits_per_frame) 
		{
			int ret;
			int i;

			ret = speex_decode(psi->dec_state, &psi->bits, psi->fp_tmp);

			if (ret < 0 || 
                speex_bits_remaining(&psi->bits)<0)
			{
				speex_bits_reset(&psi->bits);
				psi->block = 0;
				break;
			}

			speex_decode_stereo(psi->fp_tmp, frame_size, &psi->speex_stereo);

			// 2x because of Stereo
			for (i=0; i<2*frame_size; i++) {
				*pSample++ = (SHORT)le_short((SHORT)max(min(psi->fp_tmp[i],32767.0),-32768.0));
			};

			psi->block++;
			psi->block = psi->block % frames_per_block;

			if (psi->block == 0) break;
		}
	}

	pbDst = (HPBYTE)pSample;

    //
    //  We return the number of bytes used in the destination.  This is
    //  simply the difference in bytes from where we started.
    //
    return (DWORD)(pbDst - pbDstStart);

} // speexDecode_S16()



//==========================================================================;
//
//     ENCODE ROUTINES
//
//==========================================================================;

//--------------------------------------------------------------------------;
//  
//  DWORD speexEncode_M08
//  DWORD speexEncode_M16
//  DWORD speexEncode_S08
//  DWORD speexEncode_S16
//  
//  Description:
//      These functions encode a buffer of data from PCM to SPEEX in the
//      specified format.  The appropriate function is called once for each
//      ACMDM_STREAM_CONVERT message received.  Note that since these
//      functions must share the same prototype as the decoding functions
//      (see acmdStreamOpen() and acmdStreamConvert() in codec.c for more
//      details), not all the parameters are used by these routines.
//  
//  Arguments:
//      HPBYTE pbSrc:  Pointer to the source buffer (PCM data).
//      DWORD cbSrcLength:  The length of the source buffer (in bytes).
//      HPBYTE pbDst:  Pointer to the destination buffer (SPEEX data).  Note
//                      that it is assumed that the destination buffer is
//                      large enough to hold all the encoded data; see
//                      acmdStreamSize() in codec.c for more details.
//      UINT nBlockAlignment:  The block alignment of the SPEEX data (in
//                      bytes);  not used for encoding.
//  
//  Return (DWORD):  The number of bytes used in the destination buffer.
//  
//--------------------------------------------------------------------------;

DWORD FNGLOBAL speexEncode_M08
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
)
{
    HPBYTE                  pbDstStart;
    DWORD                   cSrcSamples;
	BYTE *pSample;

	int frame_size = psi->frame_size;
	int frames_per_block = psi->speex_header.frames_per_packet;
	int remaining;

    pbDstStart = pbDst;
    cSrcSamples = pcmM08BytesToSamples(cbSrcLength);

	remaining = cSrcSamples;
	pSample = (BYTE*)pbSrc;

	while(remaining > 0)
	{
		int i;

		// can we fill up the sample buffer entirely?
		if (remaining >= (frame_size - psi->samples))
		{
			// fill up the sample buffer entirely
			for (i=psi->samples; i<frame_size; i++) psi->fp_tmp[i] = ((*pSample++)<<8)^0x8000; 
			remaining -= (frame_size - psi->samples);
			psi->samples = frame_size;
		}
		else
		{
			// continue filling the sample buffer with all we got
			for (i=psi->samples; i<remaining; i++) psi->fp_tmp[i] = ((*pSample++)<<8)^0x8000;
			psi->samples += remaining;
			remaining = 0;

			// zero-pad the sample buffer if fEnd signals end of stream
			if (fEnd)
			{
				for (i=psi->samples; i<frame_size; i++) psi->fp_tmp[i] = 0.0; 
				psi->samples = frame_size;
			}
		}

		// is the samplebuffer full?
		if (psi->samples == frame_size)
		{
			speex_encode(psi->enc_state, psi->fp_tmp, &psi->bits);

			psi->samples = 0;

			psi->block++;

			// write out the data we've collected if we filled the
			// block with frames or if this is the end of stream
			if (psi->block == frames_per_block || fEnd)
			{
				pbDst += speex_bits_write(&psi->bits, pbDst, 65536);
				speex_bits_reset(&psi->bits);

				psi->block = 0;
			}
		}
	}

    //
    //  We return the number of bytes used in the destination.  This is
    //  simply the difference in bytes from where we started.
    //
    return (DWORD)(pbDst - pbDstStart);

} // speexEncode_M08()


//--------------------------------------------------------------------------;
//--------------------------------------------------------------------------;

DWORD FNGLOBAL speexEncode_M16
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
)
{
    HPBYTE                  pbDstStart;
    DWORD                   cSrcSamples;
	SHORT *pSample;

	int frame_size = psi->frame_size;
	int frames_per_block = psi->speex_header.frames_per_packet;
	int remaining;

    pbDstStart = pbDst;
    cSrcSamples = pcmM16BytesToSamples(cbSrcLength);

	remaining = cSrcSamples;
	pSample = (SHORT*)pbSrc;

	while(remaining > 0)
	{
		int i;

		// can we fill up the sample buffer entirely?
		if (remaining >= (frame_size - psi->samples))
		{
			// fill up the sample buffer entirely
			for (i=psi->samples; i<frame_size; i++) psi->fp_tmp[i] = (SHORT)le_short(*pSample++); 
			remaining -= (frame_size - psi->samples);
			psi->samples = frame_size;
		}
		else
		{
			// continue filling the sample buffer with all we got
			for (i=psi->samples; i<remaining; i++) psi->fp_tmp[i] = (SHORT)le_short(*pSample++);
			psi->samples += remaining;
			remaining = 0;

			// zero-pad the sample buffer if fEnd signals end of stream
			if (fEnd)
			{
				for (i=psi->samples; i<frame_size; i++) psi->fp_tmp[i] = 0.0; 
				psi->samples = frame_size;
			}
		}

		// is the samplebuffer full?
		if (psi->samples == frame_size)
		{
			speex_encode(psi->enc_state, psi->fp_tmp, &psi->bits);

			psi->samples = 0;

			psi->block++;

			// write out the data we've collected if we filled the
			// block with frames or if this is the end of stream
			if (psi->block == frames_per_block || fEnd)
			{
				pbDst += speex_bits_write(&psi->bits, pbDst, 65536);
				speex_bits_reset(&psi->bits);

				psi->block = 0;
			}
		}
	}

    //
    //  We return the number of bytes used in the destination.  This is
    //  simply the difference in bytes from where we started.
    //
    return (DWORD)(pbDst - pbDstStart);

} // speexEncode_M16()



//--------------------------------------------------------------------------;
//--------------------------------------------------------------------------;

DWORD FNGLOBAL speexEncode_S08
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
)
{
    HPBYTE                  pbDstStart;
    DWORD                   cSrcSamples;
	BYTE *pSample;

	int frame_size = psi->frame_size;
	int frames_per_block = psi->speex_header.frames_per_packet;
	int remaining;

    pbDstStart = pbDst;
    cSrcSamples = pcmS08BytesToSamples(cbSrcLength);

	remaining = cSrcSamples;
	pSample = (BYTE*)pbSrc;

	while(remaining > 0)
	{
		int i;

		// can we fill up the sample buffer entirely?
		if (remaining >= (frame_size - psi->samples))
		{
			// fill up the sample buffer entirely
			// 2x because of Stereo
			for (i=2*psi->samples; i<2*frame_size; i++) psi->fp_tmp[i] = ((*pSample++)<<8)^0x8000; 
			remaining -= (frame_size - psi->samples);
			psi->samples = frame_size;
		}
		else
		{
			// continue filling the sample buffer with all we got
			for (i=2*psi->samples; i<2*remaining; i++) psi->fp_tmp[i] = ((*pSample++)<<8)^0x8000;
			psi->samples += remaining;
			remaining = 0;

			// zero-pad the sample buffer if fEnd signals end of stream
			if (fEnd)
			{
				for (i=2*psi->samples; i<2*frame_size; i++) psi->fp_tmp[i] = 0.0; 
				psi->samples = frame_size;
			}
		}

		// is the samplebuffer full?
		if (psi->samples == frame_size)
		{
			speex_encode_stereo(psi->fp_tmp, frame_size, &psi->bits);
			speex_encode(psi->enc_state, psi->fp_tmp, &psi->bits);

			psi->samples = 0;

			psi->block++;

			// write out the data we've collected if we filled the
			// block with frames or if this is the end of stream
			if (psi->block == frames_per_block || fEnd)
			{
				pbDst += speex_bits_write(&psi->bits, pbDst, 65536);
				speex_bits_reset(&psi->bits);

				psi->block = 0;
			}
		}
	}

    //
    //  We return the number of bytes used in the destination.  This is
    //  simply the difference in bytes from where we started.
    //
    return (DWORD)(pbDst - pbDstStart);

} // speexEncode_S08()



//--------------------------------------------------------------------------;
//--------------------------------------------------------------------------;

DWORD FNGLOBAL speexEncode_S16
(
    HPBYTE                  pbSrc,
    DWORD                   cbSrcLength,
    HPBYTE                  pbDst,
    UINT                    nBlockAlignment,
	LPSTREAMINSTANCE        psi,
	BOOL					fStart,
	BOOL					fEnd,
	BOOL					fBlockAlign
)
{
    HPBYTE                  pbDstStart;
    DWORD                   cSrcSamples;
	SHORT *pSample;

	int frame_size = psi->frame_size;
	int frames_per_block = psi->speex_header.frames_per_packet;
	int remaining;

    pbDstStart = pbDst;
    cSrcSamples = pcmS16BytesToSamples(cbSrcLength);

	remaining = cSrcSamples;
	pSample = (SHORT*)pbSrc;

	while(remaining > 0)
	{
		int i;

		// can we fill up the sample buffer entirely?
		if (remaining >= (frame_size - psi->samples))
		{
			// fill up the sample buffer entirely
			// 2x because of Stereo
			for (i=2*psi->samples; i<2*frame_size; i++) psi->fp_tmp[i] = (SHORT)le_short(*pSample++); 
			remaining -= (frame_size - psi->samples);
			psi->samples = frame_size;
		}
		else
		{
			// continue filling the sample buffer with all we got
			for (i=2*psi->samples; i<2*remaining; i++) psi->fp_tmp[i] = (SHORT)le_short(*pSample++);
			psi->samples += remaining;
			remaining = 0;

			// zero-pad the sample buffer if fEnd signals end of stream
			if (fEnd)
			{
				for (i=2*psi->samples; i<2*frame_size; i++) psi->fp_tmp[i] = 0.0; 
				psi->samples = frame_size;
			}
		}

		// is the samplebuffer full?
		if (psi->samples == frame_size)
		{
			speex_encode_stereo(psi->fp_tmp, frame_size, &psi->bits);
			speex_encode(psi->enc_state, psi->fp_tmp, &psi->bits);

			psi->samples = 0;

			psi->block++;

			// write out the data we've collected if we filled the
			// block with frames or if this is the end of stream
			if (psi->block == frames_per_block || fEnd)
			{
				pbDst += speex_bits_write(&psi->bits, pbDst, 65536);
				speex_bits_reset(&psi->bits);

				psi->block = 0;
			}
		}
	}

    //
    //  We return the number of bytes used in the destination.  This is
    //  simply the difference in bytes from where we started.
    //
    return (DWORD)(pbDst - pbDstStart);

} // speexEncode_S16()


