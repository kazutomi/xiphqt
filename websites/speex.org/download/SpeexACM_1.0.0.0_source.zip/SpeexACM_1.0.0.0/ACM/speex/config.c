/* Copyright (C) 2003 Christian	Buchner
   File: config.c
   SPEEX codec configuration init and dialog

   Redistribution and use in source	and	binary forms, with or without
   modification, are permitted provided	that the following conditions
   are met:
   
   - Redistributions of	source code	must retain	the	above copyright
   notice, this	list of	conditions and the following disclaimer.
   
   - Redistributions in	binary form	must reproduce the above copyright
   notice, this	list of	conditions and the following disclaimer	in the
   documentation and/or	other materials	provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors	may	be used	to endorse or promote products derived from
   this	software without specific prior	written	permission.
   
   THIS	SOFTWARE IS	PROVIDED BY	THE	COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS	IS'' AND ANY EXPRESS OR	IMPLIED	WARRANTIES,	INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR	PURPOSE	ARE	DISCLAIMED.	 IN	NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS	BE LIABLE FOR ANY DIRECT, INDIRECT,	INCIDENTAL,	SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;	LOSS OF	USE, DATA, OR
   PROFITS;	OR BUSINESS	INTERRUPTION) HOWEVER CAUSED AND ON	ANY	THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR	TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE)	ARISING	IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF	THE	POSSIBILITY	OF SUCH	DAMAGE.
*/

//	Description:
//
//	The	configuration parameters for this codec	are:
//
//	<currently none>
//
//	These parameters may be	set	in the registry, using the speex subkey
//	(which corresponds to the alias	name used for installation)	under
//	the	following key:
//
//		HKEY_CURRENT_USER\Software\Microsoft\Multimedia
//
// 
//	Note:  The configuration dialog	is only	compiled into the code if the
//		SPEEX_USECONFIG	symbol is defined.	
//
//==========================================================================;

#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <msacm.h>
#include <msacmdrv.h>

#include "codec.h"
#include "speex_acm.h"

#include "debug.h"

#ifndef	INLINE
	#define	INLINE __inline
#endif

#ifdef WIN32
#include <tchar.h>
#else
#define	_tcstoul strtoul
#define	_tcsncpy _fstrncpy
#endif

#include <string.h>
#include <stdlib.h>


#ifndef	WIN32
#error Win16 support has been dropped from this	codec!	Compile	for	Win32.
#endif


#ifdef SPEEX_USECONFIG


//
//	Strings	required to	access configuration information in	the	registry.
//
const TCHAR	BCODE gszEncoderComplexity[]   = TEXT("EncoderComplexity");
const TCHAR	BCODE gszPerceptualEnhancement[]   = TEXT("PerceptualEnhancement");
const TCHAR	gszMultimediaKey[] = TEXT("Software\\Microsoft\\Multimedia\\");


//--------------------------------------------------------------------------;
//	
//	VOID configWriteConfiguration
//	
//	Description:
//
//		This routine writes	the	configuration data in PDI to the registry.
//	
//	Arguments:
//		PDRIVERINSTANCE		pdi
//	
//	Return (VOID):	None.
//	
//--------------------------------------------------------------------------;

VOID configWriteConfiguration
(
	PDRIVERINSTANCE		pdi
)
{
	DWORD				dw;

	if(	NULL !=	pdi->hkey )
	{
		dw	 = (DWORD)pdi->nConfigEncoderComplexity;
		(void)RegSetValueEx( pdi->hkey,	(LPTSTR)gszEncoderComplexity, 0,
								REG_DWORD, (LPBYTE)&dw,	sizeof(DWORD) );

		dw	 = (DWORD)pdi->nConfigPerceptualEnhancement;
		(void)RegSetValueEx( pdi->hkey,	(LPTSTR)gszPerceptualEnhancement, 0,
								REG_DWORD, (LPBYTE)&dw,	sizeof(DWORD) );
	}
}


//--------------------------------------------------------------------------;
//	
//	DWORD dwReadRegistryDefault
//	
//	Description:
//
//		This routine reads a given value from the registry,	and	returns	a
//		default	value if the read is not successful.
//	
//	Arguments:
//		HKEY	hkey:				Registry key to	read from.
//		LPTSTR	lpszEntry:
//		DWORD	dwDefault:
//	
//	Return (DWORD):
//	
//--------------------------------------------------------------------------;

INLINE DWORD dwReadRegistryDefault
(
	HKEY				hkey,
	LPTSTR				lpszEntry,
	DWORD				dwDefault
)
{
	DWORD	dwType = (DWORD)~REG_DWORD;	 //	Init to	anything but REG_DWORD.
	DWORD	cbSize = sizeof(DWORD);
	DWORD	dwRet;
	LONG	lError;

	lError = RegQueryValueEx( hkey,
							  lpszEntry,
							  NULL,
							  &dwType,
							  (LPBYTE)&dwRet,
							  &cbSize );

	if(	ERROR_SUCCESS != lError	 ||	 REG_DWORD != dwType )
		dwRet =	dwDefault;

	return dwRet;
}


//--------------------------------------------------------------------------;
//	
//	VOID configSetDefaults
//	
//	Description:
//
//		This routine sets the configuration	parameters to their	default
//		values.
//	
//	Arguments:
//		PDRIVERINSTANCE	pdi:
//	
//--------------------------------------------------------------------------;

VOID configSetDefaults
(
	PDRIVERINSTANCE		pdi
)
{
	pdi->nConfigEncoderComplexity =	
			SPEEX_CONFIG_DEFAULT_ENCODERCOMPLEXITY;

	pdi->nConfigPerceptualEnhancement =
			SPEEX_CONFIG_DEFAULT_PERCEPTUALENHANCEMENT;
}


//--------------------------------------------------------------------------;
//	
//	INT_PTR	acmdDlgProcConfigure
//	
//	Description:
//		This routine handles the configuration dialog box.
//	
//	Arguments:
//		HWND hwnd:
//	
//		UINT uMsg:
//	
//		WPARAM wParam:
//	
//		LPARAM lParam:
//	
//	Return (BOOL):
//
//--------------------------------------------------------------------------;

INT_PTR	FNWCALLBACK	acmdDlgProcConfigure
(
	HWND					hwnd,
	UINT					uMsg,
	WPARAM					wParam,
	LPARAM					lParam
)
{
	PDRIVERINSTANCE		pdi;
	
	HWND				hctrlEncCpl;
	HWND				hctrlPerEnh;
	UINT				uCmdId;
	UINT				u;
	int					n;
	TCHAR				szOutput[32];

	UINT				nConfigEncoderComplexity;
	UINT				nConfigPerceptualEnhancement;

	switch (uMsg)
	{
		case WM_INITDIALOG:

			pdi	= (PDRIVERINSTANCE)(UINT_PTR)lParam;

			SetWindowLongPtr(hwnd, DWLP_USER, lParam);

			nConfigEncoderComplexity = pdi->nConfigEncoderComplexity;
			nConfigPerceptualEnhancement = pdi->nConfigPerceptualEnhancement;

			hctrlEncCpl	= GetDlgItem(hwnd, IDC_COMBO_ENCODERCOMPLEXITY);
			hctrlPerEnh	= GetDlgItem(hwnd, IDC_COMBO_PERCEPTUALENHANCEMENT);
			for( u=0; u<SPEEX_CONFIG_NUM_ENCODERCOMPLEXITIES ; u++ )
			{
				wsprintf( szOutput,	_T("Level %d"),	u+1	);
				ComboBox_AddString(hctrlEncCpl,	szOutput);
			}
			ComboBox_AddString(hctrlPerEnh,	_T("Disabled"));
			ComboBox_AddString(hctrlPerEnh,	_T("Enabled"));

			ComboBox_SetCurSel(	hctrlEncCpl, nConfigEncoderComplexity );
			ComboBox_SetCurSel(	hctrlPerEnh, nConfigPerceptualEnhancement );

			return (TRUE);

	case WM_DESTROY:

			pdi	= (PDRIVERINSTANCE)GetWindowLongPtr(hwnd, DWLP_USER);

			//
			// Let dialog box process this message
			//
			//
			return (FALSE);

		case WM_HELP:
			return (FALSE);

		case WM_COMMAND:

			pdi	= (PDRIVERINSTANCE)GetWindowLongPtr(hwnd, DWLP_USER);

			uCmdId = (UINT)	wParam;

			switch (uCmdId)
			{
				case IDOK:
					n =	DRVCNF_CANCEL;

					//
					//	If we changed something, write the data	to the
					//	registry.
					//
					hctrlEncCpl	= GetDlgItem(hwnd, IDC_COMBO_ENCODERCOMPLEXITY);
					hctrlPerEnh	= GetDlgItem(hwnd, IDC_COMBO_PERCEPTUALENHANCEMENT);
					nConfigEncoderComplexity = ComboBox_GetCurSel( hctrlEncCpl );
					nConfigPerceptualEnhancement = ComboBox_GetCurSel( hctrlPerEnh );
					if (nConfigEncoderComplexity !=	pdi->nConfigEncoderComplexity)
					{
						pdi->nConfigEncoderComplexity =	nConfigEncoderComplexity;
						n =	DRVCNF_OK;
					}
					if (nConfigPerceptualEnhancement !=	pdi->nConfigPerceptualEnhancement)
					{
						pdi->nConfigPerceptualEnhancement =	nConfigPerceptualEnhancement;
						n =	DRVCNF_OK;
					}

					//
					//	If we changed something, write the data	to the
					//	registry.
					//
					if(	DRVCNF_OK == n )
					{
						configWriteConfiguration( pdi );
					}

					EndDialog(hwnd,	DRVCNF_OK);
					break;


				case IDCANCEL:
					EndDialog(hwnd,	DRVCNF_CANCEL);
					break;
			}
			return (TRUE);
	}

	return (FALSE);
} // acmdDlgProcConfigure()


//--------------------------------------------------------------------------;
//	
//	BOOL acmdDriverConfigInit
//	
//	Description:
//		This routine initializes the configuration parameters by reading them
//		from the registry.	If there are no	entries	in the registry, this
//		codec auto-configures itself and writes	the	results	to the registry.
//		If the auto-configure fails, or	if we don't	know our alias name,
//		then we	set	the	configuration to default values.
//	
//	Arguments:
//		PDRIVERINSTANCE	pdi:
//	
//		LPCTSTR	pszAliasName:
//	
//	Return (BOOL):
//	
//	
//--------------------------------------------------------------------------;

BOOL FNGLOBAL acmdDriverConfigInit
(
	PDRIVERINSTANCE			pdi,
	LPCTSTR			pszAliasName
)
{
	HKEY	hkey;
	UINT	nConfigEncoderComplexity;
	UINT	nConfigPerceptualEnhancement;
	UINT	uErrorIDS;

	//
	//	If pszAliasName	is NULL	then just set all defaults
	//
	//
	if (NULL ==	pszAliasName)
	{
		configSetDefaults( pdi );
		return (TRUE);
	}

	//
	//	If we haven't got an open hkey,	then open it.  Note	that this routine
	//	may	be called more than	once; on the second	time, we should	not
	//	re-open	the	key.
	//
	if(	NULL ==	pdi->hkey )
	{
		RegCreateKeyEx(	SPEEX_CONFIG_DEFAULTKEY, gszMultimediaKey, 0,
						NULL, 0, KEY_CREATE_SUB_KEY, NULL, &hkey, NULL );

		if(	NULL !=	hkey )
		{
			RegCreateKeyEx(	hkey, pszAliasName,	0, NULL, 0,
					KEY_SET_VALUE |	KEY_QUERY_VALUE	| KEY_ENUMERATE_SUB_KEYS,
					NULL, &pdi->hkey, NULL );

			RegCloseKey( hkey );
		}
	}


	//
	//	Read configuration data	from registry.
	//
	if(	NULL ==	pdi->hkey )
	{
		configSetDefaults( pdi );
	}
	else
	{
		pdi->nConfigEncoderComplexity =
					(UINT)dwReadRegistryDefault( pdi->hkey,
					(LPTSTR)gszEncoderComplexity,
					SPEEX_CONFIG_UNCONFIGURED );

		pdi->nConfigPerceptualEnhancement =
					(UINT)dwReadRegistryDefault( pdi->hkey,
					(LPTSTR)gszPerceptualEnhancement,
					SPEEX_CONFIG_UNCONFIGURED );
	}

	//
	//	If any setting is out of range,	then use defaults.
	//	This should	only happen	the	first time the codec is	run.
	//
	if(	pdi->nConfigEncoderComplexity >= SPEEX_CONFIG_NUM_ENCODERCOMPLEXITIES ||
		pdi->nConfigPerceptualEnhancement >	1 )
	{
		nConfigEncoderComplexity = SPEEX_CONFIG_DEFAULT_ENCODERCOMPLEXITY;
		pdi->nConfigEncoderComplexity =	nConfigEncoderComplexity;

		nConfigPerceptualEnhancement = SPEEX_CONFIG_DEFAULT_PERCEPTUALENHANCEMENT;
		pdi->nConfigPerceptualEnhancement =	nConfigPerceptualEnhancement;

		//
		//	Always write the results to	the	registry, even if we hit an
		//	error, so we won't hit the automatic auto-config next
		//	time we	run.  One failure is enough!
		//
		configWriteConfiguration( pdi );
	}

	return (TRUE);
} // acmdDriverConfigInit()

#endif // SPEEX_USECONFIG

