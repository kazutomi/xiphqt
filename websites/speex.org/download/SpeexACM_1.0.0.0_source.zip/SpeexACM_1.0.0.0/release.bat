del speex-1.0.1\win32\libspeex\Debug
del speex-1.0.1\win32\findrates\Debug
del speex-1.0.1\win32\speexdec\Debug
del speex-1.0.1\win32\speexdec_wav\Debug
del speex-1.0.1\win32\speexenc\Debug
del speex-1.0.1\win32\testenc\Debug
del speex-1.0.1\win32\testenc_wb\Debug
del speex-1.0.1\win32\testenc_uwb\Debug
del libogg-1.0\win32\Static_Debug
del mmedia\speex\Debug

del speex-1.0.1\win32\libspeex\Release\*.obj
del speex-1.0.1\win32\findrates\Release\*.obj
del speex-1.0.1\win32\speexdec\Release\*.obj
del speex-1.0.1\win32\speexdec_wav\Release\*.obj
del speex-1.0.1\win32\speexenc\Release\*.obj
del speex-1.0.1\win32\testenc\Release\*.obj
del speex-1.0.1\win32\testenc_wb\Release\*.obj
del speex-1.0.1\win32\testenc_uwb\Release\*.obj
del libogg-1.0\win32\Static_Release\*.obj
del mmedia\speex\Release\*.obj

del speex-1.0.1\win32\libspeex\Release\*.pdb
del speex-1.0.1\win32\findrates\Release\*.pdb
del speex-1.0.1\win32\speexdec\Release\*.pdb
del speex-1.0.1\win32\speexdec_wav\Release\*.pdb
del speex-1.0.1\win32\speexenc\Release\*.pdb
del speex-1.0.1\win32\testenc\Release\*.pdb
del speex-1.0.1\win32\testenc_wb\Release\*.pdb
del speex-1.0.1\win32\testenc_uwb\Release\*.pdb
del libogg-1.0\win32\Static_Release\*.pdb
del mmedia\speex\Release\*.pdb

del speex-1.0.1\win32\libspeex\Release\*.pch
del speex-1.0.1\win32\findrates\Release\*.pch
del speex-1.0.1\win32\speexdec\Release\*.pch
del speex-1.0.1\win32\speexdec_wav\Release\*.pch
del speex-1.0.1\win32\speexenc\Release\*.pch
del speex-1.0.1\win32\testenc\Release\*.pch
del speex-1.0.1\win32\testenc_wb\Release\*.pch
del speex-1.0.1\win32\testenc_uwb\Release\*.pch
del libogg-1.0\win32\Static_Release\*.pch
del mmedia\speex\Release\*.pch

del speex-1.0.1\win32\libspeex\Release\*.idb
del speex-1.0.1\win32\findrates\Release\*.idb
del speex-1.0.1\win32\speexdec\Release\*.idb
del speex-1.0.1\win32\speexdec_wav\Release\*.idb
del speex-1.0.1\win32\speexenc\Release\*.idb
del speex-1.0.1\win32\testenc\Release\*.idb
del speex-1.0.1\win32\testenc_wb\Release\*.idb
del speex-1.0.1\win32\testenc_uwb\Release\*.idb
del libogg-1.0\win32\Static_Release\*.idb
del mmedia\speex\Release\*.idb

del speex-1.0.1\win32\libspeex\*.ncb
del speex-1.0.1\win32\findrates\*.ncb
del speex-1.0.1\win32\speexdec\*.ncb
del speex-1.0.1\win32\speexdec_wav\*.ncb
del speex-1.0.1\win32\speexenc\Release\*.ncb
del speex-1.0.1\win32\testenc\Release\*.ncb
del speex-1.0.1\win32\testenc_wb\Release\*.ncb
del speex-1.0.1\win32\testenc_uwb\Release\*.ncb
del libogg-1.0\win32\Static_Release\*.ncb
del mmedia\speex\Release\*.ncb

del speexacm.ncb
del /A:H speexacm.suo

rem copy speex-1.0.1\win32\speexdec\Release\*.exe SpeexACM_1.0.0.0\
copy speex-1.0.1\win32\speexdec_wav\Release\*.exe SpeexACM_1.0.0.0\
rem copy speex-1.0.1\win32\speexenc\Release\*.exe SpeexACM_1.0.0.0\
copy mmedia\speex\Release\*.acm SpeexACM_1.0.0.0\
copy mmedia\speex\Release\*.inf SpeexACM_1.0.0.0\
