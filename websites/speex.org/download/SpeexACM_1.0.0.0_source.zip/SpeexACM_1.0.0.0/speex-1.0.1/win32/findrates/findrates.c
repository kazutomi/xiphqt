#include "speex.h"
#include "speex_stereo.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_FRAME_SIZE 640

int findrate(int rate, int nchan, int quality, int *framesize)
{
   int tmp;

   short in[2*MAX_FRAME_SIZE];
   float input[2*MAX_FRAME_SIZE];

   char cbits[200];
   int nbBits;
   int i;
   void *st = NULL;
   SpeexBits bits;
   int bitCount=0;
   SpeexMode *speex_mode = NULL;

   *framesize = 0;

   if (rate == 32000)
	   speex_mode = &speex_uwb_mode;
   else
	   if (rate == 16000)
		   speex_mode = &speex_wb_mode;
	   else
		   if (rate == 8000)
			   speex_mode = &speex_nb_mode;
		   else return 0;

   speex_mode_query(speex_mode, SPEEX_MODE_FRAME_SIZE, &tmp);
   *framesize = tmp;

   /* white noise */
   for (i=0;i<nchan* (*framesize);i++)
      in[i]=(65535 * (rand()-RAND_MAX/2)) / RAND_MAX;

   st = speex_encoder_init(speex_mode);

   tmp=quality;
   speex_encoder_ctl(st, SPEEX_SET_QUALITY, &tmp);

   tmp=0;
   speex_encoder_ctl(st, SPEEX_SET_COMPLEXITY, &tmp);

   speex_bits_init(&bits);
   for (i=0;i<nchan* (*framesize);i++)
      input[i]=in[i];

   speex_bits_reset(&bits);

   if (nchan == 2)
      speex_encode_stereo(input, (*framesize), &bits);
   speex_encode(st, input, &bits);

   nbBits = speex_bits_write(&bits, cbits, 200);
   bitCount+=bits.nbBits;

   speex_bits_rewind(&bits);
      
   speex_bits_reset(&bits);

   speex_encoder_destroy(st);
   speex_bits_destroy(&bits);

//   return nbBits * 8;
   return bitCount;
}


int __cdecl main(int argc, char **argv)
{
   int i,j,k;

   fprintf(stderr, "struct tagQualityInfo {\n\tUINT nBitsPerFrame;\n\tUINT nSamplesPerFrame;\n\tUINT nFramesPerBlock;\n\tUINT nEffectiveBitrate;\n} QualityInfo[3][2][11] = {\n");

   for (i=0; i<=2; i++)
   {
	   int rate = 8000 << i;
	   for (j=1; j<=2; j++)
	   {
		   int nchan = j;

		   for (k=0; k<=10; k++)
		   {
			   int quality = k;
			   int framesize = 0;

			   int bits = findrate(rate, nchan, quality, &framesize);
			   int alignedbits = (bits + 7)/8*8;

			   int bitrate = bits * rate / framesize;
			   int alignedbitrate = alignedbits * rate / framesize;

			   int pad = 1000 * (alignedbitrate-bitrate) / alignedbitrate;

			   int framesperblock = 1;

//			   fprintf(stderr, "rate: %d, nchan: %d, quality: %d, bitrate: %d, aligned: %d, pad: %d.%d%%\n",
//				   rate, nchan, quality, bitrate, alignedbitrate, pad/10, pad%10);

			   if (pad != 0)
			   {
				   for (;;)
				   {
					    int bits_;
						framesperblock++;
						
						bits_ = bits * framesperblock;
						alignedbits = (bits_+7)/8*8;
						
						alignedbitrate = alignedbits * rate / (framesize * framesperblock);
						pad = 1000 * (alignedbitrate-bitrate) / alignedbitrate;

//						fprintf(stderr, " -> %d aligned: %d, pad: %d.%d%%\n",
//							framesperblock, alignedbitrate, pad/10, pad%10);

						if (pad < 1) break;
				   }
			   }

			   fprintf(stderr, "\t%5d, %3d, %1d, %5d,   // %5d %d %d\n",
				   bits, framesize, framesperblock, alignedbitrate,
				   rate, nchan, quality);
		   }
	   }
   }
   fprintf(stderr, "};\n");

   return 0;
}
