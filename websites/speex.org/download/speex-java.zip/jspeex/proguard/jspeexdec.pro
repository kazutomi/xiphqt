-libraryjars <java.home>/lib/rt.jar
-injars      ../lib/jspeex.jar
-outjar      ../lib/jspeexdec-obf.jar
-overloadaggressively
-defaultpackage ''

-keep public class JSpeexDec {
    public static void main(java.lang.String[]);
}