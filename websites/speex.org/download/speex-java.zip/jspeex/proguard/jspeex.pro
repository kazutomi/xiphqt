-libraryjars <java.home>/lib/rt.jar
-injars      ../lib/jspeex.jar
-outjar      ../lib/jspeex-obf.jar
-overloadaggressively
-defaultpackage ''

-keep public class JSpeexEnc {
    public static void main(java.lang.String[]);
}
-keep public class JSpeexDec {
    public static void main(java.lang.String[]);
}