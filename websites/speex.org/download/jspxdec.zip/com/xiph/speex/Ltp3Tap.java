/* Copyright (C) 2002 Jean-Marc Valin 

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.xiph.speex;

/**
 *
 */
class Ltp3Tap extends Ltp {
 
   /*  ================================================
         PRIVATE DATA MEMBERS
       ================================================ */
    float   m_gain[];
    int     m_gain_cdbk[];
    int     m_gain_bits;
    int     m_pitch_bits;
    float   m_e[][];
    
    /**
     *
     */
    Ltp3Tap(int gain_cdbk[], int gain_bits, int pitch_bits)
    {
        m_gain       = new float[3];
        m_gain_cdbk  = gain_cdbk;
        m_gain_bits  = gain_bits;
        m_pitch_bits = pitch_bits;
        m_e          = new float[3][128];
    }
    
    /**
     *
     */
    int unquant(float exc[], int es, int start, float pitch_coef,  
        int nsf, float gain_val[], Bits bits)
    {
        int i, pitch, gain_index;
   
        pitch       = bits.unpack(m_pitch_bits);
        pitch      += start;
        gain_index  = bits.unpack(m_gain_bits);
    
        m_gain[0] = 0.015625f*(float)m_gain_cdbk[gain_index*3]+.5f;
        m_gain[1] = 0.015625f*(float)m_gain_cdbk[gain_index*3+1]+.5f;
        m_gain[2] = 0.015625f*(float)m_gain_cdbk[gain_index*3+2]+.5f;
   
        gain_val[0]=m_gain[0];
        gain_val[1]=m_gain[1];
        gain_val[2]=m_gain[2];

        for (i=0;i<3;i++)
        {
            int j, tmp1, tmp2, pp=pitch+1-i;

            tmp1=nsf;
            if (tmp1>pp)
                tmp1=pp;
        
            for (j=0;j<tmp1;j++)
                m_e[i][j]=exc[es+j-pp];

            tmp2=nsf;
            if (tmp2>pp+pitch)
                tmp2=pp+pitch;
        
            for (j=tmp1;j<tmp2;j++)
                m_e[i][j]=exc[es+j-pp-pitch];
        
            for (j=tmp2;j<nsf;j++)
                m_e[i][j]=0;
        }

        for (i=0;i<nsf;i++)
            exc[es+i]=m_gain[0]*m_e[2][i]+m_gain[1]*m_e[1][i]+m_gain[2]*m_e[0][i];

        return (pitch);
    }
    
}
