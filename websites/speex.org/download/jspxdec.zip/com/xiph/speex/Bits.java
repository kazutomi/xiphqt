/* Copyright (C) 2002 Jean-Marc Valin 

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.xiph.speex;

/**
 *
 */
class Bits {
 
   /*  ================================================
         PRIVATE DATA MEMBERS
       ================================================ */
 
    /**< "raw" data */
    private byte m_bytes[];
   
    /**< Position of the byte "cursor" */
    private int  m_bytePtr;
   
    /**< Position of the bit "cursor" within the current byte */
    private int  m_bitPtr;  
 
   /*  ================================================
         PUBLIC STATIC DATA MEMBERS
       ================================================ */
    /**
     *
     */
    Bits() {
    }

    /**
     *
     */
    void advance(int n)
    {
        int nbytes= n >> 3, nbits= n & 7;
   
        m_bytePtr += nbytes;
        m_bitPtr += nbits;
   
        if (m_bitPtr>7)
        {
            m_bitPtr-=8;
            m_bytePtr++;
        }
    }

    /**
     *
     */
    void init()
    {
        m_bytes = new byte[2000];
        m_bytePtr=0;
        m_bitPtr=0;
    }

    /**
     *  
     */
    void setBuffer(byte[] pBuffer){
        m_bytes = pBuffer;
    }  
    
    /**
     *
     */
    int peek()
    {
        return ((m_bytes[m_bytePtr] & 0xFF)>>(7-m_bitPtr))&1;
    }

    /**
     *
     */
    void read_from(byte bytes[], int offset, int len)
    {
 
        for (int i=0;i<len;i++)
            m_bytes[i]=bytes[offset+i];
        m_bytePtr=0;
        m_bitPtr=0;
    }

    /**
     *
     */
    int unpack(int nbBits)  
    {
        int d=0;
        while(nbBits!=0)
        {
            d<<=1;
            d |= ((m_bytes[m_bytePtr] & 0xFF)>>(7-m_bitPtr))&1;
            m_bitPtr++;
            if (m_bitPtr==8)
            {
                m_bitPtr=0;
                m_bytePtr++;
            }
            nbBits--;
        }
        return d;
    }
 
}
