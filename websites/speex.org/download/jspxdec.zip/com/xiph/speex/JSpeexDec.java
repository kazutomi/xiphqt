/* Copyright (C) 2002 Jean-Marc Valin 

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.xiph.speex;

import java.io.*;


/**
 *
 *    Decodes SPX files created by Speex's speexenc utility to WAV entirely in pure java.  
 *    Currently this code is based off of Release Candidate #2. 
 *
 *    NOTE!!! A number of advanced options are NOT supported. 
 *  
 *    --  DTX in any shape or form. 
 *    --  Stereo, should be easy to add though. 
 *    --  SPX files with more than one comment. 
 *    --  Perceptual Enhancement is always on. 
 *    --  Can't force decoder to run at another rate, mode, or channel count. 
 *    --  No packet loss support. 
 *
 *      
 *    @author Jim Lawrence, helloNetwork.com
 */
public class JSpeexDec {


	/**
	 * //"D:\\spx\\cgd8.spx", "D:\\spx\\cgd8r.wav"
	 */
	static public void main(String[] args) {
	
	    /* make sure we have command args */
	    if (args.length < 2)
	    {
	        System.out.println("usage: [input.spx] [output.wav]");
	        return;
	    }
	    
	    /* decode the spx */
	    try {
		    decode(args[0], args[1]);
		}catch (IOException ioe)
		{
		    ioe.printStackTrace();
		}
	}
	
	/**
	 *  decodes a spx to wave. 
	 */
	static public void decode(String inputPath, String outputPath) throws IOException {
	   
		byte[] header    = new byte[2048];
		byte[] payload   = new byte[65536];
		byte[] decdat    = new byte[44100*2*2];
		final int    HEADERSIZE = 27;
		final int    SEGOFFSET  = 26;
		final String OGGID      = "OggS";
		int segments=0, curseg=0, i=0, bodybytes=0, decsize=0; 
		int packetCount = 0;
		
		/* construct a wave writer */
	    PcmWaveWriter waveWriter   = new PcmWaveWriter();
		
		/* construct a new decoder */
	    SpeexDecoder  speexDecoder = new SpeexDecoder();

        /* open the input stream */
		DataInputStream dis =  new DataInputStream(new FileInputStream(inputPath));

		try {
		    /* read until we get to EOF */
		    while(true)
		    {
		        /* read the OGG header */
                dis.readFully(header, 0, HEADERSIZE);
                
                /* make sure its a OGG header */
                if (!OGGID.equals(new String(header, 0, 4)))
                {
                    System.err.println("missing ogg id!");
                    return;
                }
                
                /* how many segments are there? */
                segments = header[SEGOFFSET] & 0xFF;
                dis.readFully(header, HEADERSIZE, segments);
                
                /* decode each segment, writing output to wav */
                for (curseg=0; curseg < segments; curseg++)
                {
                    /* get the number of bytes in the segment */
                    bodybytes = header[HEADERSIZE+curseg] & 0xFF;
                    if (bodybytes==255)
                    {
                        System.err.println("sorry, don't handle 255 sizes!"); 
                        return;
                    }
                    dis.readFully(payload, 0, bodybytes);
                    
                    /* decode the segment */
                    speexDecoder.processData(payload, 0, bodybytes);
                    
                    /* if first packet, initialize the wave writer with output format */
                    if (packetCount==0)
                    {
                        waveWriter.Open(outputPath);  
                        waveWriter.SetFormat(speexDecoder.getChannels(),
                                             speexDecoder.getSampleRate());
                        waveWriter.WriteHeader();                     
                        packetCount++;
                    }
                    
                    /* get the amount of decoded data */
                    if ((decsize=speexDecoder.getProcessedDataByteSize()) > 0)
                    {
                        speexDecoder.getProcessedData(decdat, 0);
                        waveWriter.WriteData(decdat, 0, decsize);
                    }
                    
                    packetCount++;
                }
            }
		}catch (EOFException eof)
		{
		
		}
		
		/* close the output file */
		waveWriter.Close();
	}
	
}
