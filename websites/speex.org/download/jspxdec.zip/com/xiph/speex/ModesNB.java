/* Copyright (C) 2002 Jean-Marc Valin 

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.xiph.speex;


/**
 *
 */
class ModesNB {

   /*  ================================================
         PACKAGE DATA MEMBERS
       ================================================ */

    static SubMode s_nbsubmodes[];
    
   /*  ================================================
         PACKAGE INSTANCE METHODS
       ================================================ */
    ModesNB(){
    }
    
    /**
     *
     */
    void init()
    {

        Tables.exc_10_16_table = TestTablesData.exc_10_16_table;
        Tables.exc_10_32_table = TestTablesData.exc_10_32_table;
        Tables.exc_5_256_table = TestTablesData.exc_5_256_table;
        Tables.exc_5_64_table  = TestTablesData.exc_5_64_table;
        Tables.exc_8_128_table = TestTablesData.exc_8_128_table;
        Tables.exc_20_32_table = TestTablesData.exc_20_32_table;   
        Tables.gain_cdbk_nb    = TestTablesData.gain_cdbk_nb;
        Tables.gain_cdbk_lbr   = TestTablesData.gain_cdbk_lbr;
        Tables.cdbk_nb         = TestTablesData.cdbk_nb;
        Tables.cdbk_nb_low1    = TestTablesData.cdbk_nb_low1;
        Tables.cdbk_nb_low2    = TestTablesData.cdbk_nb_low2;
        Tables.cdbk_nb_high1   = TestTablesData.cdbk_nb_high1;
        Tables.cdbk_nb_high2   = TestTablesData.cdbk_nb_high2;
       
        Ltp3Tap s_ltpNb   = new Ltp3Tap(Tables.gain_cdbk_nb, 7, 7);
        Ltp3Tap s_ltpVlbr = new Ltp3Tap(Tables.gain_cdbk_lbr, 5, 0);
        Ltp3Tap s_ltpLbr  = new Ltp3Tap(Tables.gain_cdbk_lbr, 5, 7);
        Ltp3Tap s_ltpMed  = new Ltp3Tap(Tables.gain_cdbk_lbr, 5, 7);
        LtpForcedPitch s_ltpFP   = new LtpForcedPitch();

        NoiseSearch s_noiseSearch    = new NoiseSearch();
        SplitShapeSearch s_ssNbVlbrSearch = new SplitShapeSearch(10, 4, Tables.exc_10_16_table, 4, 0);
        SplitShapeSearch s_ssNbLbrSearch  = new SplitShapeSearch(10, 4, Tables.exc_10_32_table, 5, 0);
        SplitShapeSearch s_ssNbSearch     = new SplitShapeSearch(5, 8, Tables.exc_5_64_table, 6, 0);
        SplitShapeSearch s_ssNbMedSearch  = new SplitShapeSearch(8, 5, Tables.exc_8_128_table, 7, 0);
        SplitShapeSearch s_ssSbSearch     = new SplitShapeSearch(5, 8, Tables.exc_5_256_table, 8, 0);
        SplitShapeSearch s_ssNbUlbrSearch = new SplitShapeSearch(20, 2, Tables.exc_20_32_table, 5, 0);

        NbLU s_nbLU    = new NbLU();
        LbrLU s_lprLU  = new LbrLU();
        
        /* initialize narrow-band modes */
        s_nbsubmodes = new SubMode[16];
        for (int i=0; i < 16; i++)
            s_nbsubmodes[i] = null;
        /* 2150 bps "vocoder-like" mode for comfort noise */
        s_nbsubmodes[1] = new SubMode(0, 1, 0, 0, s_lprLU, s_ltpFP, s_noiseSearch, .7f, .7f, -1);
        /* 5.95 kbps very low bit-rate mode */
        s_nbsubmodes[2] = new SubMode(0, 0, 0, 0, s_lprLU, s_ltpVlbr, s_ssNbVlbrSearch, 0.7f, 0.5f, .55f);
        /* 8 kbps low bit-rate mode */
        s_nbsubmodes[3] = new SubMode(-1, 0, 1, 0, s_lprLU, s_ltpLbr, s_ssNbLbrSearch, 0.7f, 0.55f, .45f);
        /* 11 kbps medium bit-rate mode */
        s_nbsubmodes[4] = new SubMode(-1, 0, 1, 0, s_lprLU, s_ltpMed, s_ssNbMedSearch, 0.7f, 0.63f, .35f);
        /* 15 kbps high bit-rate mode */
        s_nbsubmodes[5] = new SubMode(-1, 0, 3, 0, s_nbLU, s_ltpNb, s_ssNbSearch, 0.7f, 0.65f, .25f);
        /* 18.2 high bit-rate mode */
        s_nbsubmodes[6] = new SubMode(-1, 0, 3, 0, s_nbLU, s_ltpNb, s_ssSbSearch, 0.68f, 0.65f, .1f);
        /* 24.6 kbps high bit-rate mode */
        s_nbsubmodes[7] = new SubMode(-1, 0, 3, 1, s_nbLU, s_ltpNb, s_ssNbSearch, 0.65f, 0.65f, -1);       
        /* 3.95 kbps very low bit-rate mode */
        s_nbsubmodes[8] = new SubMode(0, 1, 0, 0, s_lprLU, s_ltpFP, s_ssNbUlbrSearch, .7f, .5f, .65f);
    }

 
}
