/* Copyright (C) 2002 Jean-Marc Valin 

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.xiph.speex;


/**
 *
 */
class ModesWB extends ModesNB {

   /*  ================================================
         PACKAGE DATA MEMBERS
       ================================================ */

    static SubMode s_wbsubmodes[];
    static SubMode s_uwbsubmodes[];
    
    ModesWB(){
        super();
    }
    
   /*  ================================================
         PACKAGE INSTANCE METHODS
       ================================================ */

    void init()
    {
        super.init();
        
        Tables.hexc_10_32_table = TestTablesData.hexc_10_32_table;
        Tables.hexc_table       = TestTablesData.hexc_table;  
        Tables.high_lsp_cdbk    = TestTablesData.high_lsp_cdbk;
        Tables.high_lsp_cdbk2   = TestTablesData.high_lsp_cdbk2;

        HighLU s_highLU = new HighLU();
    
        SplitShapeSearch s_ssCbHighLbrSearch = new SplitShapeSearch(10, 4, Tables.hexc_10_32_table, 5, 0);
        SplitShapeSearch s_ssCbHighSearch    = new SplitShapeSearch(8, 5, Tables.hexc_table, 7, 1);
        
  
        s_wbsubmodes  = new SubMode[8];
        s_uwbsubmodes = new SubMode[8];
        for (int i=0; i < 8; i++)
        {
            s_wbsubmodes[i] = s_uwbsubmodes [i] = null;
        }
        s_wbsubmodes[1]  = new SubMode(0, 0, 1, 0, s_highLU, null, null, .75f, .75f, -1);
        s_wbsubmodes[2]  = new SubMode(0, 0, 1, 0, s_highLU, null, s_ssCbHighLbrSearch, .85f, .6f, -1);
        s_wbsubmodes[3]  = new SubMode(0, 0, 1, 0, s_highLU, null, s_ssCbHighSearch, .75f, .7f, -1);
        s_wbsubmodes[4]  = new SubMode(0, 0, 1, 1, s_highLU, null, s_ssCbHighSearch, .75f, .75f, -1);
        s_uwbsubmodes[1] = new SubMode(0, 0, 1, 0, s_highLU, null, null, .75f, .75f, -1);
        
    }

}
