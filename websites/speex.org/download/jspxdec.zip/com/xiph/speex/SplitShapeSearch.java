/* Copyright (C) 2002 Jean-Marc Valin 

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.xiph.speex;


/**
 *
 */
class SplitShapeSearch extends CbSearch {
 
   /*  ================================================
         PRIVATE DATA MEMBERS
       ================================================ */
    private int     m_subvect_size;
    private int     m_nb_subvect;
    private int     m_shape_cb[];
    private int     m_shape_bits;
    private int     m_have_sign;
    private int     m_ind[]; 
    private int     m_signs[];
 
   /*  ================================================
         PRIVATE DATA MEMBERS
       ================================================ */
    SplitShapeSearch(int     subvect_size,
                     int     nb_subvect,
                     int     shape_cb[],
                     int     shape_bits,
                     int     have_sign)
    {
        m_subvect_size = subvect_size;
        m_nb_subvect   = nb_subvect;
        m_shape_cb     = shape_cb;
        m_shape_bits   = shape_bits;
        m_have_sign    = have_sign;  
        m_ind          = new int[nb_subvect]; 
        m_signs        = new int[nb_subvect];
    }

    /**
     *
     */
    void unquant(float exc[], int es, int nsf, Bits bits)
    {
        int i,j;
        int shape_cb_size = 1<<m_shape_bits;

        /* Decode codewords and gains */
        for (i=0;i<m_nb_subvect;i++)
        {
            if (m_have_sign!=0)
                m_signs[i] = bits.unpack(1);
            else
                m_signs[i] = 0;
            m_ind[i] = bits.unpack(m_shape_bits);
        }

        /* Compute decoded excitation */
        for (i=0;i<m_nb_subvect;i++)
        {
            float s=1.0f;
            if (m_signs[i]!=0)
                s=-1.0f;
            for (j=0;j<m_subvect_size;j++){
                exc[es+m_subvect_size*i+j]+=s*0.03125f*(float)m_shape_cb[m_ind[i]*m_subvect_size+j]; 
            }
        }
    }
    
}
