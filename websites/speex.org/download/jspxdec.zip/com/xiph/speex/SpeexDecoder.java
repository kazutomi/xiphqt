/* Copyright (C) 2002 Jean-Marc Valin 

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.xiph.speex;
 
/**
 *
 */
public class SpeexDecoder{
 
    
    /*  ================================================
          PRIVATE INSTANCE MEMBERS
        ================================================ */
    private int           m_packetNo;
    private int           m_sampleRate;
    private int           m_channelCount;
    private float         m_decodedData[];
    private short         m_outputData[];
    private int           m_outputSize;
    private int           m_secondSize;
    private Bits          m_bits;
    private Decoder       m_decoder;
    private int           m_frameSize;
    private boolean       m_bHeaderRead;
    
  /*  ================================================
       PUBLIC INSTANCE METHODS
      ================================================ */
 	
	/**
	 * 
	 */
 	public SpeexDecoder() 
 	{	    
	    m_bits = new Bits();
	    
	    initialize();
	}
     
    /**
     * 
     */
    public int getSampleRate() 
    {
        return (m_sampleRate);    
    }
     
    /**
     * 
     */
    public int getChannels() 
    {
        return (m_channelCount);
    }
    
    /**
     * Pull the decoded data out into a byte array at the given offset
     */
    public boolean getProcessedData(byte data[], int offset) 
    {    
        if (m_outputSize<=0)
        {
            return (false);
        }
        
	    for(int i=0; i < m_outputSize; i++) {
		    int dx     =  offset + (i<<1);
   	        data[dx]   = (byte) (m_outputData[i] & 0xff);
	        data[dx+1] = (byte) ((m_outputData[i] >> 8) &  0xff );
		}
		m_outputSize = 0;
    
        return (true);
    }

    /**
     * 
     */
    public int getProcessedDataByteSize() 
    {
	    return (m_outputSize*2);	
    }
    
    /**
     * This is where the actual decoding takes place
     */
    public boolean processData(byte data[], int offset, int len)
    {
        int i=0;
        
        /* if we tried to read bad packet header, input stream is in error */
        if (m_packetNo>0 && !m_bHeaderRead)
        {
            return (false);
        }
 
 
        /* if first packet, process as Speex header*/
        if (m_packetNo==0)
        {
           if (!readHeader(data, offset, len))
           {
              m_packetNo++;
              return (false);
           }
                
           m_bHeaderRead = true;
        } 
        else if (m_packetNo!=1) /* ignores comment packets */
        {
                /* read packet bytes into bitstream */
                m_bits.read_from(data, offset, len);

                /* decode the bitstream */
                m_decoder.decode(m_bits, m_decodedData);

                /* PCM saturation */
                for (i=0;i<m_frameSize*m_channelCount;i++)
                {
                    if (m_decodedData[i]>32767.0f)
                        m_decodedData[i]=32767.0f;
                    else if (m_decodedData[i]<-32768.0f)
                        m_decodedData[i]=-32768.0f;
                }

                /* convert to short and save to buffer */
                for (i=0; i<m_frameSize*m_channelCount; i++, m_outputSize++)
                {
                    m_outputData[m_outputSize]= (m_decodedData[i]>0) ? 
                        (short) (m_decodedData[i]+.5) : (short) (m_decodedData[i]-.5);
                } 
        }/* else */
        
        m_packetNo++;
        
    	return (true);
    }
    
    
    /*  ================================================
          PRIVATE INSTANCE MEMBERS
        ================================================ */
											
    /**
     *  Initializes all class data members. 
     */
    void initialize()
    {
        m_packetNo     = 0;
        m_sampleRate   = 0;
        m_channelCount = 0;
        m_decodedData  = null;
        m_outputData   = null;
        m_outputSize   = 0;
        m_secondSize   = 0;
        m_decoder      = null;
        m_frameSize    = 0;
        m_bHeaderRead  = false;
    }		

    /**
     *  Reads the header packet. 
     */
    private boolean readHeader(byte[] packet, int offset, int bytes)
    {
        int    mode  = 0;
        
        initialize();
               
        if (bytes!=80)
        {
            return (false);
        }

        if (!"Speex   ".equals(new String(packet, 0, 8)))
        {
            return (false);
        }    
 
        mode = packet[40+offset] & 0xFF;
        
        if (mode==0)
        {
            new ModesNB().init();
        }
        else 
        {
            /* we do a class for name so that if we know that we're only playing  
               narrowband clips, we can create a jar that only has the narrowband 
               required clips, saving about 10K in footprint size. */
            try {
              ((ModesNB)Class.forName("com.xiph.speex.ModesWB").newInstance()).init();
            }catch (Exception e){
                return (false);
            }
        }
              
        switch (mode)
        {
        case 0:   m_decoder = new NbDecoder(); break;
        case 1:   m_decoder = new WbDecoder(); break;
        case 2:   m_decoder = new UwbDecoder(); break;
        default:  return (false);             
        }  
        
        /* initialize the speex decoder */
        m_decoder.init();
   
        /* set decoder format and properties */
        m_frameSize      = m_decoder.getframesize();
        
        m_sampleRate     = bytestoint(packet, offset+36);
        m_channelCount   = bytestoint(packet, offset+48);
        m_secondSize     = m_sampleRate*m_channelCount;
        m_decodedData    = new float[m_secondSize*2];
        m_outputData     = new short[m_secondSize*20];
   
        m_bits.init();

        return (true);
    }	
    
    /**
     *
     */
    private int bytestoint(byte[] a, int i)
    {
         return ((a[i+3] & 0xFF) << 24) | ((a[i+2] & 0xFF) << 16) | ((a[i+1] & 0xFF) << 8) | (a[i+0] & 0xFF);
    }
}

