/* Copyright (C) 2002 Jean-Marc Valin 

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.xiph.speex;

/**
 *
 */
abstract class Tables {
 
   /*  ================================================
         DATA MEMBERS
       ================================================ */

    static int exc_20_32_table[]; //640
    static int exc_10_16_table[]; //160
    static int exc_10_32_table[]; //320
    static int exc_5_256_table[]; //1280
    static int exc_5_64_table[]; //320
    static int exc_8_128_table[]; //1024
    static int gain_cdbk_nb[]; //384
    static int gain_cdbk_lbr[]; //96
    static int cdbk_nb[]; //640
    static int cdbk_nb_low1[]; //320
    static int cdbk_nb_low2[]; //320
    static int cdbk_nb_high1[]; //320
    static int cdbk_nb_high2[]; //320
    static int hexc_10_32_table[]; //320
    static int hexc_table[]; //1024  
    static int high_lsp_cdbk[]; //512
    static int high_lsp_cdbk2[]; //512

}
