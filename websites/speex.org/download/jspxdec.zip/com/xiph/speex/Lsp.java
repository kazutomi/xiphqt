/* 
Original copyright
	FILE........: AKSLSPD.C
	TYPE........: Turbo C
	COMPANY.....: Voicetronix
	AUTHOR......: David Rowe
	DATE CREATED: 24/2/93

Modified by Jean-Marc Valin

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.xiph.speex;

/**
 *
 */
class Lsp {
 
   /*  ================================================
         PRIVATE DATA MEMBERS
       ================================================ */
 
    /**
     *
     */
    private float pw[];
    
 
   /*  ================================================
         PRIVATE DATA MEMBERS
       ================================================ */

    Lsp()
    {
        pw  = new float[42];
    }

    /**
     *  
     */
    void lsp2lpc(float freq[], float ak[], int lpcrdr)
    {
        int i,j;
        float xout1,xout2,xin1,xin2;
        int n1,n2,n3,n4=0;
        int m = lpcrdr/2;

        for (i=0; i < 4*m+2; i++)
        {
            pw[i] = 0.0f;
        }

        xin1 = 1.0f;
        xin2 = 1.0f;

        /* reconstruct P(z) and Q(z) by  cascading second order
           polynomials in form 1 - 2xz(-1) +z(-2), where x is the
           LSP coefficient */
        for(j=0;j<=lpcrdr;j++)
        {
            int i2=0;
	    
            for(i=0;i<m;i++,i2+=2)
            {
	            n1 = i*4;
	            n2 = n1 + 1;
	            n3 = n2 + 1;
	            n4 = n3 + 1;
	            xout1 = xin1 - 2*(freq[i2]) * pw[n1] + pw[n2];
	            xout2 = xin2 - 2*(freq[i2+1]) * pw[n3] + pw[n4];
	            pw[n2] = pw[n1];
	            pw[n4] = pw[n3];
	            pw[n1] = xin1;
	            pw[n3] = xin2;
	            xin1 = xout1;
	            xin2 = xout2;
	        }
	        xout1    = xin1 + pw[n4+1];
	        xout2    = xin2 - pw[n4+2];
	        ak[j]    = (xout1 + xout2)*0.5f;
	        pw[n4+1] = xin1;
	        pw[n4+2] = xin2;
	        xin1     = 0.0f;
	        xin2     = 0.0f;
        } 
    }

    /**
     *  Makes sure the LSPs are stable
     */
    void enforce_margin(float lsp[], int len, float margin)
    {
        int i;
        
        if (lsp[0]<margin)
            lsp[0]=margin;
        
        if (lsp[len-1]>(float)Math.PI-margin)
            lsp[len-1]=(float)Math.PI-margin;
            
        for (i=1;i<len-1;i++)
        {
            if (lsp[i]<lsp[i-1]+margin)
                lsp[i]=lsp[i-1]+margin;

            if (lsp[i]>lsp[i+1]-margin)
                lsp[i]= .5f * (lsp[i] + lsp[i+1]-margin);
        }
    }
    
}
