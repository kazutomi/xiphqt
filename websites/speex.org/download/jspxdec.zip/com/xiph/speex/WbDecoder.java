/* Copyright (C) 2002 Jean-Marc Valin 

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
   
   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   
   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   
   - Neither the name of the Xiph.org Foundation nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.
   
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package com.xiph.speex;

/**
 *
 */
class WbDecoder extends Decoder
{

    static float s_h0[] = {
        3.596189e-05f, -0.0001123515f,
        -0.0001104587f, 0.0002790277f,
        0.0002298438f, -0.0005953563f,
        -0.0003823631f, 0.00113826f,
        0.0005308539f, -0.001986177f,
        -0.0006243724f, 0.003235877f,
        0.0005743159f, -0.004989147f,
        -0.0002584767f, 0.007367171f,
        -0.0004857935f, -0.01050689f,
        0.001894714f, 0.01459396f,
        -0.004313674f, -0.01994365f,
        0.00828756f, 0.02716055f,
        -0.01485397f, -0.03764973f,
        0.026447f, 0.05543245f,
        -0.05095487f, -0.09779096f,
        0.1382363f, 0.4600981f,
        0.4600981f, 0.1382363f,
        -0.09779096f, -0.05095487f,
        0.05543245f, 0.026447f,
        -0.03764973f, -0.01485397f,
        0.02716055f, 0.00828756f,
        -0.01994365f, -0.004313674f,
        0.01459396f, 0.001894714f,
        -0.01050689f, -0.0004857935f,  
        0.007367171f, -0.0002584767f,
        -0.004989147f, 0.0005743159f,
        0.003235877f, -0.0006243724f,
        -0.001986177f, 0.0005308539f,
        0.00113826f, -0.0003823631f,
        -0.0005953563f, 0.0002298438f,
        0.0002790277f, -0.0001104587f,
        -0.0001123515f, 3.596189e-05f
   };

   static float s_h1[] = {
        3.596189e-05f, 0.0001123515f,
        -0.0001104587f, -0.0002790277f,
        0.0002298438f, 0.0005953563f,
        -0.0003823631f, -0.00113826f,
        0.0005308539f, 0.001986177f,
        -0.0006243724f, -0.003235877f,
        0.0005743159f, 0.004989147f,
        -0.0002584767f, -0.007367171f,
        -0.0004857935f, 0.01050689f,
        0.001894714f, -0.01459396f,
        -0.004313674f, 0.01994365f,
        0.00828756f, -0.02716055f,
        -0.01485397f, 0.03764973f,
        0.026447f, -0.05543245f,
        -0.05095487f, 0.09779096f,
        0.1382363f, -0.4600981f,
        0.4600981f, -0.1382363f,
        -0.09779096f, 0.05095487f,
        0.05543245f, -0.026447f,
        -0.03764973f, 0.01485397f,
        0.02716055f, -0.00828756f,
        -0.01994365f, 0.004313674f,
        0.01459396f, -0.001894714f,
        -0.01050689f, 0.0004857935f,
        0.007367171f, 0.0002584767f,
        -0.004989147f, -0.0005743159f,
        0.003235877f, 0.0006243724f,
        -0.001986177f, -0.0005308539f,
        0.00113826f, 0.0003823631f,
        -0.0005953563f, -0.0002298438f,
        0.0002790277f, 0.0001104587f,
       -0.0001123515f, -3.596189e-05f
   };

    static final int QMF_ORDER = 64;

   /*  ================================================
         PACKAGE INSTANCE METHODS
       ================================================ */
    WbDecoder(){
        super();
    }
    
    /**
     *
     */
    void control(int request, float ptr[])
    {
        int i=0;

        switch(request)
        {
        case GET_PI_GAIN:
            for (i=0;i<nbSubframes;i++)
                ptr[i]=pi_gain[i];
            break;

        case GET_EXC:
        case GET_INNOV:
            for (i=0;i<full_frame_size;i++)
                ptr[i]=0;
            for (i=0;i<frame_size;i++)
                ptr[2*i]=2*exc[i];
            break;
        }  
    }
    
    /**
     *
     */
    int  decode(Bits bits, float out[])
    {
        int i, sub, wideband, ret;

        /* Decode the low-band */
        if ((ret = lowdec.decode(bits, x0d))!=0)
        {
            return ret;
        }

        /* vheck "wideband bit" */
        wideband = bits.peek(); 
        if (wideband!=0)
        {
            /*Regular wideband frame, read the submode*/
            wideband  = bits.unpack(1);
            submodeID = bits.unpack(3);
        } 
        else
        {
            /* was a narrowband frame, set "null submode"*/
            submodeID = 0;
        }


        for (i=0;i<frame_size;i++)
            exc[i]=0;

        /* If null mode (no transmission), just set a couple things to zero*/
        if (submodes[submodeID] == null)
        {
            for (i=0;i<frame_size;i++)
                exc[i]=0;

            first=1;

            /* Final signal synthesis from excitation */
            m_filters.iir_mem2(exc, 0, interp_qlpc, high, 0, frame_size, lpcSize, mem_sp);

            m_filters.fir_mem_up(x0d, s_h0, y0, full_frame_size, QMF_ORDER, g0_mem);
            m_filters.fir_mem_up(high, s_h1, y1, full_frame_size, QMF_ORDER, g1_mem);

            for (i=0;i<full_frame_size;i++)
                out[i]=2*(y0[i]-y1[i]);

            return 0;
        }

        lowdec.control(GET_PI_GAIN, low_pi_gain);
        lowdec.control(GET_EXC, low_exc);
        lowdec.control(GET_INNOV, low_innov);

        submodes[submodeID].lu.unquant(qlsp, lpcSize, bits);
   
        if (first!=0)
        {
            for (i=0;i<lpcSize;i++)
                old_qlsp[i] = qlsp[i];
        }

        for (sub=0;sub<nbSubframes;sub++)
        {
            float tmp, filter_ratio, el=0.0f, rl=0.0f,rh=0.0f;
            int subIdx=subframeSize*sub;
      
            /* LSP interpolation */
            tmp = (1.0f + sub)/nbSubframes;
            for (i=0;i<lpcSize;i++)
                interp_qlsp[i] = (1-tmp)*old_qlsp[i] + tmp*qlsp[i];

            /* LSPs to x-domain */
            for (i=0;i<lpcSize;i++)
                interp_qlsp[i] = (float)Math.cos(interp_qlsp[i]);

            m_lsp.enforce_margin(interp_qlsp, lpcSize, .002f);

            /* LSP to LPC */
            m_lsp.lsp2lpc(interp_qlsp, interp_qlpc, lpcSize);

            float r=.9f, k1,k2,k3;
            k1=submodes[submodeID].lpc_enh_k1;
            k2=submodes[submodeID].lpc_enh_k2;
            k3=k1-k2;
            m_filters.bw_lpc(k1, interp_qlpc, awk1, lpcSize);
            m_filters.bw_lpc(k2, interp_qlpc, awk2, lpcSize);
            m_filters.bw_lpc(k3, interp_qlpc, awk3, lpcSize);

            /* Calculate reponse ratio between low & high filter in band middle (4000 Hz) */      
            tmp=1;
            pi_gain[sub]=0;
            for (i=0;i<=lpcSize;i++)
            {
                rh += tmp*interp_qlpc[i];
                tmp = -tmp;
                pi_gain[sub]+=interp_qlpc[i];
            }
            rl           = low_pi_gain[sub];
            rl           = 1/(Math.abs(rl)+.01f);
            rh           = 1/(Math.abs(rh)+.01f);
            filter_ratio = Math.abs(.01f+rh)/(.01f+Math.abs(rl));
      
            /* reset excitation buffer */
            for (i=subIdx;i<subIdx+subframeSize;i++)
                exc[i]=0;

            if (submodes[submodeID].innovation==null)
            {
                float g;
                int quant;

                quant = bits.unpack(5);
                g     = (float)Math.exp(((double)quant-10)/8.0);       
                g     /= filter_ratio;
         
                /* High-band excitation using the low-band excitation and a gain */
                for (i=subIdx;i<subIdx+subframeSize;i++)
                    exc[i]=folding_gain*g*low_innov[i];
            } 
            else {
                float gc, scale;
            
                int qgc = bits.unpack(4);

                for (i=subIdx;i<subIdx+subframeSize;i++)
                    el+=low_exc[i]*low_exc[i];

                gc    = (float)Math.exp((1/3.7f)*qgc-2);

                scale = gc*(float)Math.sqrt(1+el)/filter_ratio;

                submodes[submodeID].innovation.unquant(exc, subIdx, subframeSize, bits); 

                for (i=subIdx;i<subIdx+subframeSize;i++)
                    exc[i]*=scale;

                if (submodes[submodeID].double_codebook!=0) 
                {
                    for (i=0;i<subframeSize;i++)
                        innov2[i]=0;
                    submodes[submodeID].innovation.unquant(innov2, 0, subframeSize, bits); 
                    for (i=0;i<subframeSize;i++)
                        innov2[i]*=scale*(1/2.5f);
                    for (i=0;i<subframeSize;i++)
                        exc[subIdx+i] += innov2[i];
                }
            }

            for (i=subIdx;i<subIdx+subframeSize;i++)
                high[i]=exc[i];

            m_filters.filter_mem2(high, subIdx, awk2, awk1, subframeSize, lpcSize, mem_sp, lpcSize);
            m_filters.filter_mem2(high, subIdx, awk3, interp_qlpc, subframeSize, lpcSize, mem_sp, 0);
        }

        m_filters.fir_mem_up(x0d, s_h0, y0, full_frame_size, QMF_ORDER, g0_mem);
        m_filters.fir_mem_up(high, s_h1, y1, full_frame_size, QMF_ORDER, g1_mem);

        for (i=0;i<full_frame_size;i++)
            out[i]=2*(y0[i]-y1[i]);

        for (i=0;i<lpcSize;i++)
            old_qlsp[i] = qlsp[i];

        first=0;
        
        return (0);
    }
    
    /**
     *
     */
    int  getframesize()
    {
        return (full_frame_size);
    }
    
    /**
     *
     */
    void init()
    {
        lowdec = new NbDecoder();
        sbinit(160, 40, 8, 640, ModesWB.s_wbsubmodes, 3, .7f);
    }
  
    /*  ================================================
          PROTECTED DATA MEMBERS
        ================================================ */

    void sbinit(int  mframeSize, int msubframeSize, int mlpcSize, int mbufSize, 
       SubMode msubmodes[], int mdefaultSubmode, float mfolding_gain)
    {
   
        lowdec.init();
        
        full_frame_size = 2*mframeSize;
        frame_size      = mframeSize;
        subframeSize    = msubframeSize;
        nbSubframes     = mframeSize/msubframeSize;
        lpcSize         = 8;
        folding_gain    = mfolding_gain;

        submodes        = msubmodes;
        submodeID       = mdefaultSubmode;

        first=1;

        x0d         = new float[frame_size];
        high        = new float[full_frame_size];
        y0          = new float[full_frame_size];
        y1          = new float[full_frame_size];

        g0_mem      = new float[QMF_ORDER];
        g1_mem      = new float[QMF_ORDER];

        exc         = new float[frame_size];

        qlsp        = new float[lpcSize];
        old_qlsp    = new float[lpcSize];
        interp_qlsp = new float[lpcSize];
        interp_qlpc = new float[(lpcSize+1)];

        pi_gain     = new float[nbSubframes];
        mem_sp      = new float[2*lpcSize];
 
        low_pi_gain = new float[nbSubframes]; 
        low_exc     = new float[frame_size];
        low_innov   = new float[frame_size];
   
        awk1        = new float[9];
        awk2        = new float[9];
        awk3        = new float[9];  
        innov2      = new float[subframeSize];
    }
  
   /*  ================================================
         PROTECTED DATA MEMBERS
       ================================================ */

    protected Decoder lowdec;
  
   /*  ================================================
         PRIVATE DATA MEMBERS
       ================================================ */
               
    private int   full_frame_size;
    private int   frame_size;
    private int   subframeSize;
    private int   nbSubframes;
    private int   lpcSize;
    private int   first;
    private float folding_gain;

    private float x0d[];
    private float high[];
    private float y0[], y1[];
    private float g0_mem[], g1_mem[];

    private float exc[];
    private float qlsp[];
    private float old_qlsp[];
    private float interp_qlsp[];
    private float interp_qlpc[];

    private float mem_sp[];
    private float pi_gain[];
    private float low_pi_gain[], low_exc[], low_innov[];
    private float awk1[], awk2[], awk3[];
    private float innov2[];

    private SubMode  submodes[];
    private int      submodeID;
 
};