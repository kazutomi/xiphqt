package com.xiph.speex;

import java.io.*;

/**
 * Writes basic pcm wave files from binary audio data.<BR>
 *
 * Here's an example that writes 2 seconds of silence
 *  <pre>
 *  PcmWaveWriter s_wsw = new PcmWaveWriter();
 *  byte[] silence = new byte[16*2*44100];
 *  wsw.SetFormat(2, 44100);
 *  wsw.Open("C:\\out.wav");
 *  wsw.WriteHeader(); 
 *  wsw.WriteData(silence, 0, silence.length);
 *  wsw.WriteData(silence, 0, silence.length);
 *  wsw.Close(); 
 *  </pre>
 *
 *  @author Jim Lawrence, helloNetwork.com
 */
public class PcmWaveWriter {

    /*  ================================================
          PRIVATE INSTANCE DATA MEMBERS
        ================================================ */

    private int              m_channels;
    private int              m_sampleRate;
    private RandomAccessFile m_raf; 
    private int              m_size;
  
    /*  ================================================
          PUBLIC INSTANCE METHODS
        ================================================ */
    /**
     *  Empty constructor. 
     */
    public PcmWaveWriter()
    {
        m_channels   = 0;
        m_sampleRate = 0;
        m_raf        = null;
        m_size       = 0;
    }

    /**
     *  closes the output file. MUST be called to have a correct stream. 
     */
    public void Close() throws IOException 
    {
        /* update the total file length field from RIFF chunk */
        m_raf.seek(4);
        int fileLength = (int) m_raf.length() - 8;
        WriteInt(fileLength);
    
        /* update the data chunk length size */
        m_raf.seek(40);
        WriteInt(m_size);
    
        /* close the output file */
        m_raf.close(); 
    }
  
    /**
     *  Open the output file. 
     *  @param filename filename to open.
     */
    public void Open(String filename) throws IOException 
    {
        new File(filename).delete(); 
        m_raf = new RandomAccessFile(filename, "rw");
        m_size = 0;   
    }
  
    /**
     *  Sets the output format. Must be called before WriteHeader().
     */
    public void SetFormat(int channels, int sampleRate)
    {
        m_channels   = channels;
        m_sampleRate = sampleRate;
    }
 
    /**
     *  Writes a packet of audio. 
     *  @param data audio data
     */
    public void WriteData(byte[] data, int offset, int len) throws IOException 
    {
        m_raf.write(data, offset, len);
        m_size+= len;
    }
 
    /**
     *  Writes the initial data chunks that start the wave file. 
     *  Prepares file for data samples to written. 
     */
    public void WriteHeader() throws IOException {
  
        /* writes the RIFF chunk indicating wave format */
        byte[] chkid = new String("RIFF").getBytes(); 
        m_raf.write(chkid, 0, chkid.length);
        WriteInt(0); /* total length must be blank */
        chkid = new String("WAVE").getBytes(); 
        m_raf.write(chkid, 0, chkid.length);
    
        /* format subchunk: of size 16 */
        chkid = new String("fmt ").getBytes(); 
        m_raf.write(chkid, 0, chkid.length);
        WriteInt(16);
    
        short channels   = (short) m_channels;
        int   samples    = m_sampleRate;
        short   bits     = 16;
        
        WriteShort((short)0x01);
        WriteShort(channels);
        WriteInt(samples);
        WriteInt(samples*channels*(bits/8));
        WriteShort((short) (channels*(bits/8)));
        WriteShort(bits);
    
        /* write the start of data chunk */
        chkid = new String("data").getBytes(); 
        m_raf.write(chkid, 0, chkid.length);
        WriteInt(0);
    }
  
   
    /*  ================================================
        PRIVATE INSTANCE METHODS
        ================================================ */
    /**
     * Writes a Little-endian short
     */  
    private void WriteShort(short v) throws IOException 
    {
        m_raf.writeByte((0xff & v));
        m_raf.writeByte((0xff & (v >>> 8)));
    }
  
    /**
     * Writes a Little-endian int
     */
    private  void WriteInt(int v) throws IOException 
    {
        m_raf.writeByte(0xff & v);
        m_raf.writeByte(0xff & (v >>>    8));
        m_raf.writeByte(0xff & (v >>> 16));
        m_raf.writeByte(0xff & (v >>> 24));
    }

}