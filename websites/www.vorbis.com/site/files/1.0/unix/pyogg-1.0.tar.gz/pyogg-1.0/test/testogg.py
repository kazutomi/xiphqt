import ogg

print "Yay"
