# globalfuncs.py
#
# miscellaneous global functions

import string

def t2h(s):
    codes = [ ['&', '&amp;'], ['\n', '<br>'] ]
    for c in codes:
        s = string.replace(s, c[0], c[1])
    return s

def dbesc(s):
    return string.replace(s, "'", "''")


def get_about_box():
    from infobox import InfoBox
    box = InfoBox()

    box.title = 'What is Ogg Vorbis?'
    box.more = '/about.psp'
    box.title_image = '/images/NewsBox-bg.png'
    box.title_image_r = '/images/NewsBox-right-bg.png'
    box.fontsize = -1

    one = box.start()
    two = """
    Ogg Vorbis is a completely open, patent-free, professional audio encoding and streaming technology with all the benefits of Open Source.
    <br><br>
    <center>
    Learn more by reading the <a href="/faq.psp">FAQ</a>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
    --
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
    Get <a href="/faq_listen.psp">set up</a> to listen to Vorbis.
    </center>
    """

    three = box.finish()

    return one + two + three


def get_feature_box():
    from infobox import InfoBox
    box = InfoBox()

    box.title = 'Featured Music'
    box.title_image = '/images/NewsBox-bg.png'
    box.title_image_r = '/images/NewsBox-right-bg.png'
    box.fontsize = -1

    one = box.start()
    
    two = """
    Courtesy of Moonshine, we have an track from Keoki's new CD - <i>Jealousy</i><br>
    Listen to <a href="/music/keoki_passiton.ogg">Pass It On</a>!
    """

    three = box.finish()

    return one + two + three
