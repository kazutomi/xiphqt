@echo off
echo ---+++--- Building Vorbisfile (Dynamic) ---+++---

if .%SRCROOT%==. set SRCROOT=c:\src
           
set OLDPATH=%PATH%
set OLDINCLUDE=%INCLUDE%
set OLDLIB=%LIB%

call "c:\program files\microsoft visual studio\vc98\bin\vcvars32.bat"
echo Setting include/lib paths for Vorbis
set INCLUDE=%INCLUDE%;%SRCROOT%\ogg\include;c:\src\vorbis\include
set LIB=%LIB%;%SRCROOT%\ogg\win32\Dynamic_Release;%SRCROOT%\vorbis\win32\Dynamic_Release
echo Compiling...
msdev vorbisfile_dynamic.dsp /useenv /make "vorbisfile_dynamic - Win32 Release" /rebuild

set PATH=%OLDPATH%
set INCLUDE=%OLDINCLUDE%
set LIB=%OLDLIB%
