/******************************************************************
 * CopyPolicy: GNU Public License 2 applies
 * 
 * OggSquish Vorbis demo encoder/player
 * Copyright (C) 1999 Xiphophorus and Monty <monty@xiph.org>
 *
 ******************************************************************/

/* $Id: version.h,v 1.2 1999/07/13 08:00:13 mwhitson Exp $ */

#define VERSION \
        "OggSquish Vorbis I encoder/player release 0.0 (June 30, 1999)\n"\
	"(C) 1999 Xiphophorus and Monty <monty@xiph.org>\n"\
	"http://www.xiph.org/OggSquish/vorbis.html\n"
