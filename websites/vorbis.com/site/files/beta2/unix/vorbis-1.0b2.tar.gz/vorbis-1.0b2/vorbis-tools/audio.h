
#ifndef __AUDIO_H
#define __AUDIO_H

#include "encode.h"
#include <stdio.h>

typedef struct {
	short format;
	short channels;
	int samplerate;
	int bytespersec;
	short align;
	short samplesize;
} wav_fmt;

int wav_open(FILE *in, oe_enc_opt *opt);
int raw_open(FILE *in, oe_enc_opt *opt);

long wav_read_stereo(void *, double **buffer, int samples);
long wav_read_mono(void *, double **buffer, int samples);

#endif /* __AUDIO_H */

