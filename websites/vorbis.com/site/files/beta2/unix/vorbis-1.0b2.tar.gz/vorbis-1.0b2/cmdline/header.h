/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggSQUISH PLAYER/CONVERTER SOURCE CODE. *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS RESTRICTED  *
 * BY DISTRIBUTION TERMS THAT SHOULD BE INCLUDED WITH THIS SOURCE.  *
 * PLEASE READ THESE TERMS BEFORE USING OR DISTRIBUTING.            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-1999             *
 * by 1999 Monty <monty@xiph.org> and The XIPHOPHORUS Company       *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

  author: Monty <monty@xiph.org>
  modifications by: Monty
  function: Read/Write various PCM format headers

 ********************************************************************/

/* $Id: header.h,v 1.3 1999/07/15 07:33:27 mwhitson Exp $ */

#ifndef _V_HEADER_H_
#define _V_HEADER_H_

typedef struct file_type{
  long channels;
  long rate;
  long bits;
  long bigendian;
  long sign;
  double end;
  long type;
} file_type;

#define TYPE_UNKNOWN 0
#define TYPE_WAV     1
#define TYPE_AIFF    2
#define TYPE_AIFC    3
#define TYPE_CDR     4
#define TYPE_VORBIS  100

extern long CheckWav(char *infile,int bytes,file_type *f);
extern void WriteWav(FILE *f,file_type *t);
extern void FinishWav(FILE *f,file_type *t);
extern long CheckAiff(char *infile,int bytes,file_type *t);
extern void WriteAifc(FILE *f,file_type *t);
extern void FinishAifc(FILE *f,file_type *t);

#endif
