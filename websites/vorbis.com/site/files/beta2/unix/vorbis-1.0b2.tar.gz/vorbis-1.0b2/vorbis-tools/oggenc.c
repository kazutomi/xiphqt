/* OggEnc
 *
 * This program is distributed under the GNU General Public License, version 2.
 * A copy of this license is included with this source.
 *
 * Copyright 2000, Michael Smith <msmith@labyrinth.net.au>
 *
 * Portions from Vorbize, (c) Kenneth Arnold <kcarnold@yahoo.com>
 * and libvorbis examples, (c) Monty <monty@xiph.org>
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <getopt.h>
#include <string.h>
#include <time.h>

#ifdef WIN32
#include <io.h>
#include <fcntl.h>
#endif


#include <vorbis/modes.h>
#include "encode.h"

#include "audio.h"

#define VERSION_STRING "OggEnc v0.4\n"
#define CHUNK 4096 /* We do reads, etc. in multiples of this */

/* Define supported formats here */
input_format formats[] = {
	{wav_open, "wav", "WAV file reader"},
	{NULL, NULL, NULL}
};

struct option long_options[] = {
	{"quiet",0,0,'q'},
	{"help",0,0,'h'},
	{"comment",1,0,'c'},
	{"artist",1,0,'a'},
	{"album",1,0,'l'},
	{"title",1,0,'t'},
	{"names",1,0,'n'},
	{"output",1,0,'o'},
	{"version",0,0,'v'},
	{"raw",0,0,'r'},
	{"mode",1,0,'m'}
};
	
char *generate_name_string(char *format, char *artist, char *title, char *album);
void parse_options(int argc, char **argv, oe_options *opt);
void build_comments(vorbis_comment *vc, oe_options *opt, int filenum, oe_enc_opt *eopt);
void usage(void);
vorbis_info *choose_mode(int modenum, int channels);


#ifdef WIN32
char *rindex(char *s, int c)
{
	char *ret = NULL;

	while(*s)
	{
		if(*s == (char)c)
			ret=s;
		s++;
	}
	return ret;
}
#endif


int main(int argc, char **argv)
{
	oe_options opt = {NULL, 0, NULL, 0, NULL, 0, NULL, 0, 
		0,0, NULL,NULL,0}; /* Default values */
	int i;

	char **infiles;
	int numfiles;
	long nextserial;

	parse_options(argc, argv, &opt);

	if(optind >= argc)
	{
		fprintf(stderr, "ERROR: No input files specified. Use -h for help.\n");
		exit(1);
	}
	else
	{
		infiles = argv + optind;
		numfiles = argc - optind;
	}

	/* Now, do some checking for illegal argument combinations */

	for(i = 0; i < numfiles; i++)
	{
		if(!strcmp(infiles[i], "-") && numfiles > 1)
		{
			fprintf(stderr, "ERROR: Multiple files specified when using stdin\n");
			exit(1);
		}
	}

	if(numfiles > 1 && opt.outfile)
	{
		fprintf(stderr, "ERROR: Multiple input files with specified output filename: suggest using -n\n");
		exit(1);
	}

	/* We randomly pick a serial number. This is then incremented for each file */
	srand(time(NULL));
	nextserial = rand();

	for(i = 0; i < numfiles; i++)
	{
		/* Once through the loop for each file */

		oe_enc_opt      enc_opts;
		vorbis_comment  vc;
		char *out_fn = NULL;
		FILE *in, *out = NULL;
		int foundformat = 0;
		int closeout = 0, closein = 0;


		/* Set various encoding defaults */

		enc_opts.serialno = nextserial++;
		enc_opts.quiet = opt.quiet;
		enc_opts.artist = NULL;
		enc_opts.title = NULL;
		enc_opts.album = NULL;
		
		/* OK, let's build the vorbis_comments structure */
		build_comments(&vc, &opt, i, &enc_opts);

		if(!strcmp(infiles[i], "-"))
		{
#ifdef WIN32 
			_setmode( _fileno( stdin ), _O_BINARY );
#endif

			in = stdin;
			if(!opt.outfile)
			{
#ifdef WIN32 
				_setmode( _fileno( stdout ), _O_BINARY );
#endif
				out = stdout;
			}
		}
		else
		{
			in = fopen(infiles[i], "rb");

			if(in == NULL)
			{
				fprintf(stderr, "ERROR: Cannot open input file \"%s\"\n", infiles[i]);
				free(out_fn);
				continue;
			}

			closein = 1;
		}

		if(opt.outfile && !strcmp(opt.outfile, "-"))
		{
#ifdef WIN32 
			_setmode( _fileno( stdout ), _O_BINARY );
#endif
			out = stdout;
		}
		else if(out == NULL)
		{
			if(opt.outfile)
			{
				out_fn = strdup(opt.outfile);
			}
			else if(opt.namefmt)
			{
				out_fn = generate_name_string(opt.namefmt, enc_opts.artist, enc_opts.title, enc_opts.album);
			}
			else if(opt.title)
			{
				out_fn = malloc(strlen(enc_opts.title) + 5);
				strcpy(out_fn, enc_opts.title);
				strcat(out_fn, ".ogg");
			}
			else
			{
				/* Create a filename from existing filename, replacing extension with .ogg */
				char *start, *end;

				start = rindex(infiles[i], '/');
				if(start)
					start += 1; /* Skip over the / */
				else
					start = infiles[i];

				end = rindex(infiles[i], '.');
				end = end?end:(start + strlen(infiles[i])+1);
			
				out_fn = malloc(end - start + 5);
				strncpy(out_fn, start, end-start);
				out_fn[end-start] = 0;
				strcat(out_fn, ".ogg");
			}


			out = fopen(out_fn, "wb");
			if(out == NULL)
			{
				if(closein)
					fclose(in);
				fprintf(stderr, "ERROR: Cannot open output file \"%s\"\n", out_fn);
				free(out_fn);
				continue;
			}	
			closeout = 1;
		}

		/* Now, set the rest of the options */
		enc_opts.out = out;
		enc_opts.comments = &vc;
		enc_opts.filename = out_fn;

		/* Now, we need to select an input audio format */

		if(opt.rawmode)
			raw_open(in, &enc_opts);
		else
		{
			int j=0;
			while(formats[j].open_func)
			{
				if(formats[j].open_func(in, &enc_opts))
				{
					foundformat = 1;
					break;
				}
				j++;
			}
		}

		if(!foundformat)
		{
			fprintf(stderr, "ERROR: Input file \"%s\" is not a supported format\n", infiles[i]);
			free(out_fn);
			continue;
		}

		enc_opts.mode = choose_mode(opt.modenum, enc_opts.channels);

		if(!opt.quiet)
			fprintf(stderr, "Encoding using encoder mode %d\n", opt.modenum?opt.modenum:3);

		oe_encode(&enc_opts);

		if(out_fn) free(out_fn);
		free(enc_opts.mode);
		vorbis_comment_clear(&vc);
		if(closein)
			fclose(in);
		if(closeout)
			fclose(out);
	}/* Finished this file, loop around to next... */

	return 0;

}

void usage(void)
{
	fprintf(stdout, 
		VERSION_STRING
		"(c) 2000 Michael Smith <msmith@labyrinth.net.au)\n"
		"\n"
		"Usage: oggenc [options] input.wav [...]\n"
		"\n"
		"OPTIONS:\n"
		" General:\n"
		" -q, --quiet          Produce no output to stderr\n"
		" -h, --help           Print this help text\n"
		" -r, --raw            Raw mode. Input files are read directly as PCM data\n"
		" -m, --mode           Select encoding mode, takes an argument between 1 and 6\n"
		"                      The default is mode 3. Higher numbers are higher quality.\n"
		"\n"
		" Naming:\n"
		" -o, --output=fn      Write file to fn (only valid in single-file mode)\n"
		" -n, --names=string   Produce filenames as this string, with %%a, %%t, %%l\n"
		"                      replaced by artist, title, album respectively (see below\n"
		"                      for specifying these). Note that this can be given as a \n"
		"                      single string to specify a particular output filename.\n"
		"                      %%%% gives a literal %%.\n"
		" -c, --comment=c      Add the given string as an extra comment. This may be\n"
		"                      used multiple times.\n"
		" -t, --title          Title for this track\n"
		" -l, --album          Name of album\n"
		" -a, --artist         Name of artist\n"
		"                      If multiple input files are given, then multiple\n"
		"                      instances of the previous three arguments will be used,\n"
		"                      in the order they are given. If fewer titles are\n"
		"                      specified than files, OggEnc will print a warning, and\n"
		"                      reuse the final one for the remaining files.\n"
		"\n"
		"INPUT FILES:\n"
		" OggEnc input files must currently be 44.1kHz, 16 bit stereo WAV files.\n"
		" You can specify taking the file from stdin by using - as the input filename.\n"
		" Alternatively, the --raw option may be used to use a raw PCM data file, with\n"
		" the same restrictions as above.\n"
		" In this mode, output is to stdout unless an outfile filename is specified\n"
		" with -o\n"
		"\n"
		"MODES:\n"
		" OggEnc support multiple different modes. Each of these is a fully VBR mode,\n"
		" but they vary in intended (average) bitrate. The following table shows \n"
		" approximate average bitrates (note that mode 3 is the default)\n"
		"     Mode    |    Bitrate\n"
		"       1     |       N/A\n"
		"       2     |    128 kbps\n"
		"       3     |    160 kbps\n"
		"       4     |    192 kbps\n"
		"       5     |    256 kbps\n"
		"       6     |    350 kbps\n\n");
}

char *generate_name_string(char *format, char *artist, char *title, char *album)
{
	char *buffer;
	char *cur;
	char next;

	buffer = calloc(CHUNK,1);

	cur = buffer;


	while(*format)
	{
		next = *format++;

		if(next == '%')
		{
			switch(*format++)
			{
				case '%':
					*cur++ = '%';
					break;
				case 'a':
					strcat(buffer, artist?artist:"(none)");
					cur += strlen(artist?artist:"(none)");
					break;
				case 't':
					strcat(buffer, title?title:"(none)");
					cur += strlen(title?title:"(none)");
					break;
				case 'l':
					strcat(buffer, album?album:"(none)");
					cur += strlen(album?album:"(none)");
					break;
				default:
					fprintf(stderr, "WARNING: Ignoring illegal escape character '%c' in name format\n", *(format - 1));
					break;
			}
		}
		else
			*cur++ = next;
	}

	return buffer;
}

void parse_options(int argc, char **argv, oe_options *opt)
{
	int ret;
	int option_index = 1;

	while((ret = getopt_long(argc, argv, "a:c:hl:m:n:o:qrt:v", 
					long_options, &option_index)) != -1)
	{
		switch(ret)
		{
			case 0:
				fprintf(stderr, "Internal error parsing command line options\n");
				exit(1);
				break;
			case 'a':
				opt->artist = realloc(opt->artist, (++opt->artist_count)*sizeof(char *));
				opt->artist[opt->artist_count - 1] = strdup(optarg);
				break;
			case 'c':
				opt->comments = realloc(opt->comments, (++opt->comment_count)*sizeof(char *));
				opt->comments[opt->comment_count - 1] = strdup(optarg);
				break;
			case 'l':
				opt->album = realloc(opt->album, (++opt->album_count)*sizeof(char *));
				opt->album[opt->album_count - 1] = strdup(optarg);
				break;
			case 't':
				opt->title = realloc(opt->title, (++opt->title_count)*sizeof(char *));
				opt->title[opt->title_count - 1] = strdup(optarg);
				break;
			case 'm':
				opt->modenum = atoi(optarg);
				break;
			case 'n':
				if(opt->namefmt)
				{
					fprintf(stderr, "WARNING: Multiple name formats specified, using final\n");
					free(opt->namefmt);
				}
				opt->namefmt = strdup(optarg);
				break;
			case 'o':
				if(opt->outfile)
				{
					fprintf(stderr, "WARNING: Multiple output files specified, suggest using -n\n");
					free(opt->outfile);
				}
				opt->outfile = strdup(optarg);
				break;
			case 'h':
				usage();
				exit(0);
				break;
			case 'q':
				opt->quiet = 1;
				break;
			case 'r':
				opt->rawmode = 1;
				break;
			case 'v':
				fprintf(stderr, VERSION_STRING);
				exit(0);
				break;
			case '?':
				fprintf(stderr, "WARNING: Unknown option specified, ignoring->\n");
				break;
			default:
				usage();
				exit(0);
		}
	}
}

void build_comments(vorbis_comment *vc, oe_options *opt, int filenum, oe_enc_opt *eopt)
{
	int i;

	vorbis_comment_init(vc);

	for(i = 0; i < opt->comment_count; i++)
		vorbis_comment_add(vc, opt->comments[i]);

	if(opt->title_count)
	{
		if(filenum >= opt->title_count)
		{
			if(!opt->quiet)
				fprintf(stderr, "WARNING: Insufficient titles specified, defaulting to final title.\n");
			i = opt->title_count-1;
		}
		else
			i = filenum;

		eopt->title = opt->title[i];
		vorbis_comment_add_tag(vc, "title", opt->title[i]);
	}

	if(opt->artist_count)
	{
		if(filenum >= opt->artist_count)
			i = opt->artist_count-1;
		else
			i = filenum;
	
		eopt->artist = opt->artist[i];
		vorbis_comment_add_tag(vc, "artist", opt->artist[i]);
	}
	
	if(opt->album_count)
	{
		if(filenum >= opt->album_count)
		{
			i = opt->album_count-1;
		}
		else
			i = filenum;

		eopt->album = opt->album[i];	
		vorbis_comment_add_tag(vc, "album", opt->album[i]);
	}
}

vorbis_info *choose_mode(int modenum, int channels)
{
	vorbis_info *mode = malloc(sizeof(vorbis_info));

	if(modenum > 6 || modenum < 0)
		fprintf(stderr, "Warning: Unrecognised mode (choose from 1-6), defaulting to mode B (3)\n");

	switch(modenum)
	{
	case 0:
		memcpy(mode, &info_B, sizeof(vorbis_info)); /* Default */
		break;
	case 1:
		fprintf(stderr, "Warning: mode AA (1) is not yet implemented. Increasing to mode A (2)\n");
		memcpy(mode, &info_A, sizeof(vorbis_info)); 
		break;
	case 2:
		memcpy(mode, &info_A, sizeof(vorbis_info)); 
		break;
	case 3:
		memcpy(mode, &info_B, sizeof(vorbis_info)); 
		break;
	case 4:
		memcpy(mode, &info_C, sizeof(vorbis_info)); 
		break;
	case 5:
		memcpy(mode, &info_D, sizeof(vorbis_info)); 
		break;
	case 6:
		memcpy(mode, &info_E, sizeof(vorbis_info)); 
		break;
	default:
		memcpy(mode, &info_B, sizeof(vorbis_info)); 
	}

	if(channels ==1)
		mode->channels = 1; /* Edit the mode struct to reflect 
							   mono rather than stereo */
	return mode;
}
