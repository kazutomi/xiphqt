/* OggEnc
 **
 ** This program is distributed under the GNU General Public License, version 2.
 ** A copy of this license is included with this source.
 **
 ** Copyright 2000, Michael Smith <msmith@labyrinth.net.au>
 **
 ** Portions from Vorbize, (c) Kenneth Arnold <kcarnold@yahoo.com>
 ** and libvorbis examples, (c) Monty <monty@xiph.org>
 **/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#ifndef WIN32
#include <sys/time.h>
#include <unistd.h>
#endif

#include <vorbis/codec.h>
#include "encode.h"


#define READSIZE 1024


static void update_statistics(char *fn, long total, long done, double time,long counter);

int oe_encode(oe_enc_opt *opt)
{

	ogg_stream_state os;
	ogg_page 		 og;
	ogg_packet 		 op;

	vorbis_dsp_state vd;
	vorbis_block     vb;

	long samplesdone=0;
	long counter=0,counter2=0;
    int eos;

#ifndef WIN32
	struct timeval start_time, end_time, cur_time;


	/* get start time. Should abstract this into a generic timer interface, for portability */
	gettimeofday(&start_time, NULL);
#endif

	/* Now, set up the analysis engine, stream encoder, and other
	   preparation before the encoding begins.
	 */

	vorbis_analysis_init(&vd,opt->mode);
	vorbis_block_init(&vd,&vb);

	ogg_stream_init(&os, opt->serialno);

	/* Now, build the three header packets and send through to the stream 
	   output stage (but defer actual file output until the main encode loop) */

	{
		ogg_packet header_main;
		ogg_packet header_comments;
		ogg_packet header_codebooks;

		/* Build the packets */
		vorbis_analysis_headerout(&vd,opt->comments,
				&header_main,&header_comments,&header_codebooks);

		/* And stream them out */
		ogg_stream_packetin(&os,&header_main);
		ogg_stream_packetin(&os,&header_comments);
		ogg_stream_packetin(&os,&header_codebooks);
	}

	eos = 0;

	/* Main encode loop - continue until end of file */
	while(!eos)
	{
		double **buffer = vorbis_analysis_buffer(&vd, READSIZE);
		long samples_read = opt->read_samples(opt->readdata, 
				buffer, READSIZE);

		if(samples_read ==0)
			/* Tell the library that we wrote 0 bytes - signalling the end */
			vorbis_analysis_wrote(&vd,0);
		else
		{
			samplesdone += samples_read;

			if((counter++%16==0) && !opt->quiet)
			{
#ifndef WIN32
				double time;

				gettimeofday(&cur_time, NULL);

				time = cur_time.tv_sec - start_time.tv_sec +
						(cur_time.tv_usec - start_time.tv_usec)/1000000;

				update_statistics(opt->filename, 
						opt->total_samples_per_channel, samplesdone,time,counter2++);
#else
				update_statistics(opt->filename, opt->total_samples_per_channel, samplesdone, 0, counter2++);
#endif
			}

			/* Tell the library how many samples (per channel) we wrote 
			   into the supplied buffer */
			vorbis_analysis_wrote(&vd, samples_read);
		}

		/* While we can get enough data from the library to analyse, one
		   block at a time... */
		while(vorbis_analysis_blockout(&vd,&vb)==1)
		{

			/* Do the main analysis, creating a packet */
			vorbis_analysis(&vb, &op);

			/* Add packet to bitstream */
			ogg_stream_packetin(&os,&op);

			/* If we've gone over a page boundary, we can do actual output,
			   so do so (for however many pages are available) */

			while(!eos)
			{
				int result = ogg_stream_pageout(&os,&og);
				if(!result) break;

				fwrite(og.header,1,og.header_len, opt->out);
				fwrite(og.body,1,og.body_len, opt->out);

				if(ogg_page_eos(&og))
					eos = 1;
			}
		}
	}

	/* Cleanup time */

	ogg_stream_clear(&os);

	vorbis_block_clear(&vb);
	vorbis_dsp_clear(&vd);

	if(!opt->quiet)
	{
#ifndef WIN32
		double time_elapsed, speed_ratio;
		if(opt->filename)
			fprintf(stderr, "\n\nDone encoding file \"%s\"\n", opt->filename);
		else
			fprintf(stderr, "\n\nDone encoding.\n");

		gettimeofday(&end_time, NULL);
		time_elapsed = (double)end_time.tv_sec - (double)start_time.tv_sec
			+ ((double)end_time.tv_usec - (double)start_time.tv_usec)/1000000.0;
		speed_ratio = (double)opt->total_samples_per_channel / (double)opt->rate / time_elapsed;
#endif
		

		fprintf(stderr, "\n\tFile length:  %dm %04.1fs\n",
				(int)(opt->total_samples_per_channel/opt->rate/60),
				opt->total_samples_per_channel/opt->rate - 
				floor(opt->total_samples_per_channel/opt->rate/60)*60);
#ifndef WIN32
		fprintf(stderr, "\tElapsed time: %dm %04.1fs\n",
				(int)(time_elapsed/60),
				time_elapsed - floor(time_elapsed/60)*60);
		fprintf(stderr, "\tRate:         %.4f\n\n", speed_ratio);
#endif

	}

	return 0;
}

static void update_statistics(char *fn, long total, long done, double time,long counter)
{
	static char *spinner="|/-\\";
	double remain_time;
	int minutes=0,seconds=0;

	if(total)
	{
		remain_time = time/((double)done/(double)total) - time;
		minutes = ((int)remain_time)/60;
		seconds = (int)(remain_time - (float)((int)remain_time/60)*60);
	}

	if(fn && total && time > 1.0)
		fprintf(stderr, "\rEncoding \"%s\" [%5.1f%%] [%2dm%.2ds remaining] %c", fn, 
				done*100.0/total, minutes, seconds,
				spinner[counter%4]);
	else if(fn && total)
		fprintf(stderr, "\rEncoding \"%s\" [%5.1f%%] %c", fn, 
				done*100.0/total,
				spinner[counter%4]);
	else if(fn)
		fprintf(stderr, "\rEncoding \"%s\" [???%%] %c", fn, 
				spinner[counter%4]);
	else if(total && time > 1.0)
		fprintf(stderr, "\rEncoding to standard output [%5.1f%%] [%dm%ds remaining] %c", 
				done*100.0/total, minutes, seconds,
				spinner[counter%4]);
	else if(total)
		fprintf(stderr, "\rEncoding to standard output [%5.1f%%] %c", 
				done*100.0/total,
				spinner[counter%4]);
	else
		fprintf(stderr, "\rEncoding to standard output [???%%] %c",
				spinner[counter%4]);
}



