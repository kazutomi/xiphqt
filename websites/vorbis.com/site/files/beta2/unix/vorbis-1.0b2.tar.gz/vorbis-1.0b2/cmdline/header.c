/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggSQUISH PLAYER/CONVERTER SOURCE CODE. *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS RESTRICTED  *
 * BY DISTRIBUTION TERMS THAT SHOULD BE INCLUDED WITH THIS SOURCE.  *
 * PLEASE READ THESE TERMS BEFORE USING OR DISTRIBUTING.            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-1999             *
 * by 1999 Monty <monty@xiph.org> and The XIPHOPHORUS Company       *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

  author: Monty <monty@xiph.org>
  modifications by: Monty
  function: Read/Write various PCM format headers

 ********************************************************************/

static const char rcsid[] = "$Id";

#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include "header.h"

/* Simple, local platform storage conversion stuff */

long GetNum(char *s,int endianness,int bytes){
  long ret;
  if(!endianness)s+=bytes-1;
  ret=*s;
  while(--bytes){
    if(endianness)
      s++;
    else
      s--;
    ret<<=8;
    ret|=(*s)&0xff;
  }
  return(ret);
}

void PutNum(long num,FILE *f,int endianness,int bytes){
  int i;
  if(!endianness)
    i=0;
  else
    i=bytes-1;
  while(bytes--){
    if(fputc((num>>(i<<3))&0xff,f)==EOF)
      perror("Unable to write output");
    if(endianness)
      i--;
    else
      i++;
  }
}

/* bigendian IEEE-754 80 bit float to double (Apple SANE, needed for AIFC) */

double IEEE80toDOUBLE(char *stream){
  /*    0        1        2        3       ....     9     */
  /* seeeeeee eeeeeeee nmmmmmmm mmmmmmmm   ....  mmmmmmmm */
  int s=stream[0]&0x80;
  int e=((stream[0]&0x7f)<<8)|(stream[1]&0xff);
  double ret;
  double f=((unsigned long)(stream[2]&0xff)<<24)|
    ((stream[3]&0xff)<<16)|
      ((stream[4]&0xff)<<8)|
	(stream[5]&0xff);

  if(e==32767)
    /* won't happen in an AIFC header; this is an error */
    reporterror("Invalid sample rate in AIF[C] file ");
  
  f=ldexp(f,32);
  f+=((stream[6]&0xff)<<24)|
    ((stream[7]&0xff)<<16)|
      ((stream[8]&0xff)<<8)|
	(stream[9]&0xff);
  ret=ldexp(f,e-16446);
  if(s)return(-ret);
  return(ret);
}
	
/* The below is constructed with sample rates in mind; essentially manageble,
   numbers abs(x) > 1 */
   
void PutFloat10(long num,FILE *f){
  char s[10];
  long e=16446,temp;
  memset(s,0,10);

  if(num<0){
    s[0]='\200';
    num=-num;
  }
  temp=num;

  while(temp>1){
    e++;
    temp>>=1;
  }
  
  s[0]|=(e>>8)&0x7f;
  s[1]=e&0xff;

  num<<=31-e;
  s[2]=(num>>24)&0xff;
  s[3]=(num>>16)&0xff;
  s[4]=(num>>8)&0xff;
  s[5]=num&0xff;

  if(fwrite(s,1,10,f)!=10)
    perror("Unable to write output");
}

/* On to actual header handling.  These return <n> on positive read
   (bytes of header), 0 on 'not my type' and -1 on 'submit more data' */

long CheckWav(char *infile,int bytes,file_type *f){
  
  /* Currently very clumsy code taken from old Ogg.  This should be
     re-written */
  
  if(bytes<40)return(-1);

  /* Izzit Da Shoez? */    
  if(!memcmp("RIFF",infile,4) && !memcmp("WAVE",infile+8,4)){
    /* It's a WAV file */
    int ptr=12;

    /* Look for the format chunk; none of the other chunks are worth
       reading */

    while(ptr<bytes-30){
      if(!strncmp("fmt",infile+ptr,3)){
	/* OK, this is our audio specs chunk.  Slurp it up. */
	ptr+=8;  /* past the chunk bytes */

	/* Check that this is PCM */
	if(memcmp(infile+ptr,"\001\000",2)) 
	  /* The data is stored as little endian :) */
	  /* This is not a PCM file. */
	  reporterror("This WAV file contains a proprietary data format.\n"
		      "Can't continue reading.\n");
	
	ptr+=2;
	f->channels=GetNum(infile+ptr,0,2);
	ptr+=2;
	f->rate=GetNum(infile+ptr,0,4);
	ptr+=4;
	/* Don't need 'ave bytes' or 'block size' for most files */
	ptr+=6;
	/* bits per sample */
	f->bits=GetNum(infile+ptr,0,2);
	ptr+=2;
	f->bigendian=0; /* WAVE is for little endian PCs */
	if(f->bits<9)
	  f->sign=0;
	else
	  f->sign=-1;  /* WAVE is always signed when >8 bits*/
	
	/* Now, align things to the beginning of the data */
	/* Look for 'dataxxxx' */
	while(ptr<bytes-8){
	  if(!strncmp("data",infile+ptr,4)){
	    ptr+=4;
	    /* We're there.  How big? */
	    f->end=GetNum(infile+ptr,0,4);
	    ptr+=4;
	    f->end/=f->channels;
	    f->end/=((f->bits)-1)/8+1;

	    /* OK, it's incorrect to assume only one chunk. 
	       fix this later. */
	    
	    f->type=TYPE_WAV;
	    return(ptr);
	  }
	  ptr++;
	}
	/* No data? */
	reporterror("Cannot find beginning of data in WAVE file.\n");
      }
      ptr++;
    }
    /* Well then.  We can't read it */
    reporterror("File has a WAVE header, but is missing the\n"
		"required audio format chunk.");
  }
			
  /* Well, then, it's not a WAVE file */
  return(0);
}

void WriteWav(FILE *f,file_type *t){

  /* Again, quick, dirty and too simple.  */

  fwrite("RIFF\0\0\0\0WAVEfmt ",1,16,f);
  PutNum(16,f,0,4);
  PutNum(1,f,0,2);
  PutNum(t->channels,f,0,2);
  PutNum(t->rate,f,0,4);
  PutNum(t->rate*t->channels*((t->bits-1)/8+1),f,0,4);
  PutNum(((t->bits-1)/8+1)*t->channels,f,0,2);
  PutNum(t->bits,f,0,2);
  fwrite("data\0\0\0\0",1,8,f);
  t->bigendian=0;
  if(t->bits>8)
    t->sign=-1;
  else
    t->sign=0;

  /* Have to finish setting the size fields later :( */
}

void FinishWav(FILE *f,file_type *t){
  long size=ftell(f)-8;
  if(fseek(f,4,SEEK_SET))
    reporterror("Couldn't seek to finish the .WAV header!");
  PutNum(size-8,f,0,4);
  
  if(fseek(f,40,SEEK_SET))
    reporterror("Couldn't seek to finish the .WAV header!");
  PutNum(size-44,f,0,4);
}

long CheckAiff(char *infile,int bytes,file_type *t){

  /* Do both AIFF and AIFC here.  We can't do the AIFC compression tho */

  if(bytes<30)return(-1);
  if(!memcmp("FORM",infile,4) && !memcmp("AIF",infile+8,3)){
    int ptr;
    if(infile[11]=='C'){
      t->type=TYPE_AIFC;
    }else{
      if(infile[11]!='F')return(0);
      t->type=TYPE_AIFF;
    }

    /* It's an AIFF/C file */
    ptr=12;

    while(ptr<bytes-10){
      /* What chunk is this?.... */
      if(!memcmp("SSND",infile+ptr,4))
	reporterror("AIFF[-C] input: No COMM chunk preceeds the sound data!");
      if(!memcmp("COMM",infile+ptr,4)){
	if(ptr>=bytes-GetNum(infile+ptr+4,1,4)-8)return(-1);
	t->channels=GetNum(infile+ptr+8,1,2);
	t->rate=IEEE80toDOUBLE(infile+ptr+16);
	t->bits=GetNum(infile+ptr+14,1,2);
	t->bigendian=1; /* AIFF/C always bigendian */
	t->sign=-1;  /* AIFF/C is always signed */
	t->end=GetNum(infile+ptr+10,1,4);
	
	if(t->type==TYPE_AIFC) /* we need to make certain this isn't
				 compressed data; can't handle that
				 yet */
	  if(memcmp(infile+ptr+26,"NONE",4))
	    reporterror("This AIFF-C uses compression; Ogg can't read \n"
			"it (yet).\n");
	
	/* OK!  Now find the SSND chunk... */
	ptr+=8+GetNum(infile+ptr+4,1,4);
	if(ptr%2)ptr++;
	
	while(ptr<bytes-12){
	  if(!memcmp("SSND",infile+ptr,4)){
	    /* Whamo.  Here it is. */
	    ptr+=8;
	    ptr+=GetNum(infile+ptr,1,4);
	    ptr+=4; /* ignore block size field */
	    if(ptr%2)ptr++;
	    
	    return(ptr);
	  }
	  ptr+=8+GetNum(infile+ptr+4,1,4);
	  if(ptr%2)ptr++;
	}
	reporterror("Couldn't find sound data in AIFF[-C] file.");

      }
      ptr+=8+GetNum(infile+ptr+4,1,4);
      if(ptr%2)ptr++;
      
    }
    reporterror("Couldn't find COMM chunk in AIFF[-C] header.");
  }
  return(0);
}

void WriteAifc(FILE *f,file_type *t){
  /* Again, quick and dirty (and too naieve) */
  
  fwrite("FORM\0\0\0\0AIFC",1,12,f);                /* 12 */
  
  fprintf(f,"FVER");                                /* 16 */
  PutNum(4,f,1,4);                                  /* 20 */
  PutNum(2726318400UL,f,1,4);                       /* 24 */
  
  fprintf(f,"COMM");                                
  PutNum(38,f,1,4);
  PutNum(t->channels,f,1,2);                        /* 34 */
  PutNum(0,f,1,4); /* Catch on the other side */    
  PutNum(t->bits,f,1,2);                                
  PutFloat10(t->rate,f);                            /* 50 */

  fprintf(f,"NONE");                                /* 54 */
  PutNum(14,f,1,1);                                 /* 55 */
  fprintf(f,"not compressed");                      /* 69 */
  PutNum(0,f,1,1);                                  /* 70 */

  fprintf(f,"SSND");                                /* 74 */
  PutNum(0,f,1,4); /* later */
  PutNum(0,f,1,4);
  PutNum(0,f,1,4);                                  /* 86 */

  t->bigendian=1; /* AIFF/C always bigendian */
  t->sign=-1;   /* AIFF/C is always signed */

}

void FinishAifc(FILE *f,file_type *t){
  long size=ftell(f);
  long frames;

  /* Have to pad if not word aligned */
  if(size%2){
    fputc(0,f);
    size++;
  }
  frames=(size-86)/t->channels/((t->bits-1)/8+1);

  /* FORM size */
  if(fseek(f,4,SEEK_SET))
    reporterror("Couldn't seek to finish the AIFF-C header!");
  PutNum(size-8,f,1,4);

  /* COMM frames */
  if(fseek(f,34,SEEK_SET))
    reporterror("Couldn't seek to finish the AIFF-C header!");
  PutNum(frames,f,1,4);

  /* SSND size */
  if(fseek(f,74,SEEK_SET))
    reporterror("Couldn't seek to finish the AIFF-C header!");
  PutNum(size-78,f,1,4);
}

