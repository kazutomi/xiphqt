/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-1999             *
 * by 1999 Monty <monty@xiph.org> and The XIPHOPHORUS Company       *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 function: ogg vorbis example app toplevel
 author: Monty <xiphmont@mit.edu>
 modifications by: Monty, Wrong Mike
 last modification date: Jun 27 1999 

 ********************************************************************/

static const char rcsid[] = "$Id: main.c,v 1.4 1999/07/26 07:39:51 mwhitson Exp $";

#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <errno.h>
#include <signal.h>
#include <stdarg.h>

#include "version.h"
#include "header.h"

static int verbose=1;

static const struct cmd {
  char *name;
  int mode;
} cmds[] = {
  { "encode", 0 },
  { "decode", 1 },
  { "play", 2},
  { NULL, 0 }
};

void sigtermhandler(int signum){



}

void report(int level, char *fmt, ...){
  va_list args;
  va_start(args,fmt);

  if(level<=verbose)
    vfprintf(stderr,fmt,args);

  va_end(args);
}

void reporterror(char *fmt, ...){
  va_list args;
  va_start(args,fmt);

  vfprintf(stderr,fmt,args);
  
  va_end(args);
  exit(1);
}



void usage(FILE *f){
  fprintf(f,"\n"VERSION"\n"
	  "USAGE, ENCODING: ogg encode [options] [inputfile] [outputfile]\n"
	  "       DECODING: ogg decode [options] [inputfile] [outputfile]\n"
	  "       PLAYBACK: ogg [options] [inputfile]\n\n"
	  "GENERAL OPTIONS:\n"
	  "  -v --verbose      Verbose progress and update reporting\n"
	  "  -q --quiet        No progress or update reporting.  Errors\n"
	  "                    still reported.\n"
	  "  -h --help         Report this usage information\n"
	  "  -Q --query        Query and report information about the input\n"
	  "                    file then exit.  Implies -v.\n\n"
	  "ENCODE OPTIONS:\n"
	  "  -m --mode <n>     Compression mode\n" 
	  "                      0) 128 kbps\n"
          "                      1) 96 kbps\n"
          "                      2) 80 kbps\n"
          "                      3) 64 kbps (default)\n"
          "                      4) 56 kbps\n"
          "                      5) 48 kbps\n"
          "                      6) 40 kbps\n"
          " --no-coupling      Disable use of coupled stereo; keeps channels\n"
          "                    strictly seperated in coding.\n\n"
	  "DECODE OPTIONS:\n"
	  "  -w --output-wav   output WAV file (default)\n"
	  "  -f --output-aiff  output AIFF file\n"
	  "  -a --output-aifc  output AIFF-C file\n"
	  "  -c --output-cdr   output CDR format (44.1kHz 16 MSB-first stereo)\n\n"
	  "PLAYBACK OPTIONS:\n"
	  "  -d --device <d>   kernel audio device to use for playback\n\n"

	  "Input file and output file are optional; default input and output\n"
	  "are stdin and stderr respectively.  Either may be explicitly\n"
	  "specified using a filename of '-'.\n\n");
}

const char *optstring="vqQhm:wfacd:";
struct option options[]={
  {"verbose",no_argument,NULL,'v'},
  {"quiet",no_argument,NULL,'q'},
  {"help",no_argument,NULL,'h'},
  {"query",no_argument,NULL,'Q'},

  {"mode",required_argument,NULL,'m'},
  {"no-coupling",no_argument,NULL,1},

  {"output-wav",no_argument,NULL,'w'},
  {"output-aiff",no_argument,NULL,'f'},
  {"output-aifc",no_argument,NULL,'a'},
  {"output-cdr",no_argument,NULL,'c'},

  {"device",required_argument,NULL,'d'},
  {NULL,0,NULL,0}
};

int main(int argc,char *argv[]){
  int mode=2; /* playback */
  int queryonly=0;
  int compression=3;
  int coupling=1;
  int outtype=TYPE_WAV;

  FILE *infile=stdin,*outfile=stdout;

  signal(SIGPIPE,SIG_IGN);
  /* Reset some signal handlers to make sure that we restart
  interrupted system calls when appropriate/necessary. */
  signal(SIGSTOP,SIG_DFL);
  signal(SIGCONT,SIG_DFL);
  /* Make sure we catch and deal with sigterm */
  signal(SIGINT,&sigtermhandler);

  /* parse command line */
  {
    int c,longopt_index;
    char *device=NULL;
    const struct cmd *cm = cmds;
    
    /* look up the command name; default is "play".  Tweak argv/argc
       as needed for getopt. */
    if(argc>1)
      for(cm = cmds; cm->name; cm++)
	if (!strcmp(argv[1],cm->name)) {
	  mode = cm->mode;
	  argv++;
	  argc--;
	}

    while((c=getopt_long(argc,argv,optstring,options,&longopt_index))!=EOF){
      switch(c){
      case 'v':
	verbose=2;
	break;
      case 'q':
	verbose=0;
	break;
      case 'h':
	usage(stdout);
	exit(0);
      case 'Q':
	verbose=2;
	queryonly=1;
	break;

      case 'm':
	compression=atoi(optarg);
	if(compression<0 || compression>6)
	  reporterror("Valid range for compression modes: 0-6\n");

      case 1:
	coupling=0;
	break;

      case 'w':
	outtype=TYPE_WAV;
	break;
      case 'f':
	outtype=TYPE_AIFF;
	break;
      case 'a':
	outtype=TYPE_AIFC;
	break;
      case 'c':
	outtype=TYPE_CDR;
	break;

      case 'd':
	device=strdup(optarg);
	break;
      default:
	usage(stderr);
	exit(1);
      }
    }

    /* look at the end to see if we have filenames */

    if(optind>=argc)
      if(strcmp(argv[optind],"-")){
	infile=fopen(argv[optind],"rb");
	if(infile==NULL)
	  reporterror("Unable to open input file %s: %s\n",argv[optind],
		      strerror(errno));
      }

    optind++;

    if(optind>=argc)
      if(strcmp(argv[optind],"-")){
	outfile=fopen(argv[optind],"wb");
	if(outfile==NULL)
	  reporterror("Unable to open output file %s: %s\n",argv[optind],
		      strerror(errno));
      }

    /* Identify input and output file types */
    {
      /* we need to keep an input buffer even before checking headers
	 due to headers being different sizes in different formats.
	 All the header sizes we need to deal with will be < 4096 bytes */

      int insize=4096;
      char *inbuffer=malloc(insize);
      int bufferfill=0;
      int buffercursor=0;
      int ret,input_eof=0;
      file_type intype;

      /*      vorbis_state *invorbis;
      vorbis_state *outvorbis; */

      bufferfill=fill_buffer(infile,inbuffer,bufferfill,insize);
      if(bufferfill<insize)input_eof=1;

      /* WAV, AIF[C] are just PCM after a header.  Ogg files are
	 headered, but the header is an integral part of the
	 bitstream; you can't identify it then throw it away */

      /* Try WAV */
      if((ret=CheckWav(infile,bufferfill,&intype))){
	if(ret<0)
	  reporterror("Unable to parse WAV file header.\n");
	buffercursor=ret;

      }else if((ret=CheckAiff(inbuffer,bufferfill,&intype))){ 	/* Try AIFF[-C] */
	if(ret<0)
	  reporterror("Unable to parse AIFF[-C] file header.\n");
	buffercursor=ret;

#if 0
      }else if((invorbis=vorbis_open(inbuffer,bufferfill))){ 	  /* Try Ogg */
	/* Vorbis places 'vital stats' into the initial portion of the
	   header; the bitstream read isn't fully prepped yet, but we
	   have some stats on it, and we know it's vorbis.  This way
	   we know we have an Ogg stream without needing to get into
	   the 'feed me Seymour' loop (which is needed for vorbis
	   streams that package probability tables) */

	bufferfill=0; /* libvorbis copied in all the data */

	/* move the vital stats */
	intype.channels=vorbis_get_channels(invorbis);
	intype.rate=vorbis_get_rate(invorbis);
	intype.bits=-1;
	intype.bigendian=-1;
	intype.sign=1;
	intype.type=TYPE_VORBIS;

	/* A vorbis bitstream does have sizing... at the end of the
               stream.  Can we seek to the end and grab it? */

	intype.end=-1;
#endif	

      }else{
	/* Urgh.  Don't accept headerless formats right now */
	reporterror("Input file is not WAV, AIFF[-C] or Ogg Vorbis.\n");

      }
    }
  }
  return(0);
}
