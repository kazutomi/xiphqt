/* riff.h -- Defines the strcture RIFF, which holds a RIFF header.
 *           This was ripped almost exactly out of mpg123. 
 *           Thanks, Samuel Audet!
 */

typedef unsigned char byte;
typedef unsigned short int word;
typedef unsigned long int dword;

struct RIFF
{
  byte riffheader[4];
  dword WAVElen;
  struct
  {
    byte fmtheader[8];
    dword fmtlen;
    struct
    {
      word FormatTag;
      word Channels;
      dword SamplesPerSec;
      dword AvgBytesPerSec;
      word BlockAlign;
      word BitsPerSample;	/* format specific for PCM */
    }
    fmt;
    struct
    {
      byte dataheader[4];
      dword datalen;
      /* PCM data follows... */
    }
    data;
  }
  WAVE;
};
